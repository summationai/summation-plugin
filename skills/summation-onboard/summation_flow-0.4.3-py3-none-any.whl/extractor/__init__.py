"""Claim-ledger extractor (stage 2).

Turns a source document into a `claim-ledger/v1` artifact: one row per number,
with enough context that every downstream cold-verify check can read it.

Standard library plus `jsonschema` only.
"""

# Bump on any change that alters ledger content, so a consumer can tell a
# stale ledger from a current one by reading `extractor.version` in the file
# itself rather than trusting a path.
#   0.6.3  count labels and exact integer count envelopes
#   0.6.2  duration words parse consistently from milliseconds through years
#   0.6.1  duration labels and schemas include hours and months
#   0.6.0  period.kind classified from each label; digits inside named
#          entities no longer claimed
#   0.5.0  schema v1.1: comparison.base_claim_id, derived_from
__version__ = "0.6.3"
NAME = "plg-e2e-claim-extractor"
