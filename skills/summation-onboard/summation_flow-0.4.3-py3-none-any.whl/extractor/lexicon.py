"""Word lists and label heuristics.

Everything here is a stated rule, so a reviewer can argue with it. Nothing
here decides whether a claim is *right* — only what the document appears to
be saying about it.
"""

from __future__ import annotations

import re

# --- direction ---------------------------------------------------------------
DIRECTION_WORDS = [
    "grew", "grow", "growth", "rose", "rising", "increased", "increase",
    "gained", "gain", "added", "improved", "improvement", "climbed", "up",
    "quadrupled", "doubled", "tripled", "outperformed", "expanded",
    "fell", "fall", "falling", "declined", "decline", "dropped", "drop",
    "down", "gave back", "give-back", "slipped", "softer", "soft", "weakest",
    "shortfall", "miss", "missed", "worsened", "off", "reduced", "faded",
    "winding down", "compression", "gave up", "lost", "shrank",
    "flat", "held", "holding", "steady", "steadier", "unchanged",
]
_DIRECTION_RE = re.compile(
    r"\b(" + "|".join(sorted((re.escape(w) for w in DIRECTION_WORDS),
                             key=len, reverse=True)) + r")\b",
    re.IGNORECASE)

# --- superlatives ------------------------------------------------------------
SUPERLATIVES = [
    "second-largest", "third-largest", "single largest", "single worst",
    "single best", "largest", "biggest", "smallest", "highest", "lowest",
    "worst", "best", "most", "least", "top", "cleanest", "weakest",
    "strongest", "fastest", "slowest", "only", "whole decline",
]
_SUPERLATIVE_RE = re.compile(
    r"\b(" + "|".join(sorted((re.escape(w) for w in SUPERLATIVES),
                             key=len, reverse=True)) + r")\b",
    re.IGNORECASE)

# --- causal markers ----------------------------------------------------------
CAUSAL_MARKERS = [
    "driven by", "drove", "because of", "because", "due to", "led to",
    "as a result", "thanks to", "off the back of", "on the back of",
    "the reason", "which is why", "resulted in", "caused by", "attributable to",
    "on account of", "reflects", "explains",
    ", so ",   # the causal "so", not the intensifier ("so small to plan on")
]
_CAUSAL_RE = re.compile(
    r"(" + "|".join(sorted((re.escape(w) for w in CAUSAL_MARKERS),
                           key=len, reverse=True)) + r")",
    re.IGNORECASE)

# --- forward looking ---------------------------------------------------------
# Deliberately narrow. A block marked forward-looking may be exempted from
# wave-1 checks downstream, so over-marking hides defects. Only unambiguous
# statements about a future period qualify; an incidental future clause beside
# a historical claim does not.
FORWARD_MARKERS = [
    "we expect", "we anticipate", "expects to", "will be", "will stay",
    "going to be", "next week", "next month", "forecast", "we plan to",
    "on current trend", "through the rest of", "upcoming",
]
_FORWARD_RE = re.compile(
    r"(" + "|".join(re.escape(w) for w in FORWARD_MARKERS) + r")",
    re.IGNORECASE)


def direction_words(sentence: str):
    return _dedupe(m.group(0).lower() for m in _DIRECTION_RE.finditer(sentence))


def superlatives(sentence: str):
    found = _dedupe(m.group(0).lower() for m in _SUPERLATIVE_RE.finditer(sentence))
    # "second-largest" already implies "largest"; keep the specific form only.
    for compound in ("second-largest", "third-largest", "single largest",
                     "single worst", "single best"):
        if compound in found:
            base = compound.split("-")[-1].split(" ")[-1]
            if base in found:
                found.remove(base)
    return found


def causal_markers(text: str):
    return _dedupe(m.group(0).lower() for m in _CAUSAL_RE.finditer(text))


def forward_looking(text: str) -> bool:
    return bool(_FORWARD_RE.search(text))


def _dedupe(it):
    out = []
    for x in it:
        if x not in out:
            out.append(x)
    return out


# --- polarity ----------------------------------------------------------------
# Checked in order. First hit wins.
POLARITY_RULES = [
    ("lower_is_better", [
        "stockout", "stock-out", "out of stock", "markdown", "mark-down",
        "clearance", "weeks of supply", "aged inventory", "cancel rate",
        "return rate", "defect", "backorder",
    ]),
    ("neutral", [
        "share", "on hand", "on-hand", "on order", "on-order", "inventory",
        "receipts", "mix", "count", "rank", "owner", "week", "period",
    ]),
    ("higher_is_better", [
        "demand", "revenue", "sales", "margin", "gm", "sell-through",
        "sell through", "sellthrough", "units", "aur", "average unit retail",
        "in-stock", "in stock", "conversion", "traffic", "profit",
    ]),
]


def polarity_for(*texts):
    blob = " ".join(t for t in texts if t).lower()
    for verdict, keys in POLARITY_RULES:
        for k in keys:
            if k in blob:
                return verdict
    return "unknown"


# --- units and scale from a column header / tile label ------------------------
_SCALE_HEADER_RE = re.compile(
    r"\(\s*\$?\s*0{3}s?\s*\)|\bin thousands\b|\bthousands\b|\(\s*\$?\s*m\s*\)"
    r"|\bin millions\b|\bmillions\b|\bin billions\b", re.IGNORECASE)


def scale_from_label(label: str):
    """Return ``(scale, verbatim)`` declared by a header/caption, else (None, None)."""
    if not label:
        return None, None
    m = _SCALE_HEADER_RE.search(label)
    if m:
        txt = m.group(0)
        low = txt.lower()
        if "000" in low or "thousand" in low:
            return "thousands", txt
        if "million" in low or low.strip("() ") == "m":
            return "millions", txt
        if "billion" in low:
            return "billions", txt
    if re.search(r"\bwhole dollars\b", label, re.IGNORECASE):
        return "ones", re.search(r"\bwhole dollars\b", label,
                                 re.IGNORECASE).group(0)
    return None, None


CURRENCY_WORDS = ("demand", "retail", "dollar", "revenue", "sales", "price",
                  "aur", "cost", "$", "size", "value")
UNITS_WORDS = ("units", "unit ", "qty", "quantity")
PERCENT_WORDS = ("%", "rate", "share", "yoy", "pct")
POINTS_WORDS = ("pts", "points", " move")
COUNT_WORDS = ("#", "count", "rank")
#: Duration units stay distinct — "days late" and "weeks of supply" must never
#: become comparable to each other just because both are time.
DURATION_UNITS = (
    "milliseconds", "seconds", "minutes", "hours",
    "days", "weeks", "months", "years",
)
DURATION_RE = re.compile(r"\b(" + "|".join(DURATION_UNITS) + r")\b")

#: Plural labels that are money or states, not things you count one by one.
NOT_COUNT_LAST_WORDS = frozenset(
    {"status", "returns", "savings", "earnings", "proceeds", "sales",
     "dollars", "points", "pts"}
)


def unit_from_label(label: str):
    if not label:
        return None
    low = label.lower()
    if any(w in low for w in POINTS_WORDS):
        return "points"
    if "%" in low:
        return "percent"
    if any(w in low for w in COUNT_WORDS):
        return "count"
    if any(w in low for w in UNITS_WORDS):
        return "units"
    if any(w in low for w in CURRENCY_WORDS):
        return "currency"
    if any(w in low for w in PERCENT_WORDS):
        return "percent"
    duration = DURATION_RE.search(low)
    if duration:
        return duration.group(1)
    # A label whose last word is a plural noun names the thing being counted:
    # "Vendors", "Late orders", "Active stores". Counting is the only reading
    # that survives the money/rate branches above, so "count" is safe here.
    words = re.findall(r"[a-z]+", low)
    if (words and len(words[-1]) > 2 and words[-1].endswith("s")
            and words[-1] not in NOT_COUNT_LAST_WORDS):
        return "count"
    return None


# --- roles -------------------------------------------------------------------
NON_FOOTING_COLUMN_RE = re.compile(
    r"\byoy\b|\bmove\b|\bchange\b|gm\s*%|\bmargin\b|\brate\b|\baur\b|"
    r"average unit retail", re.IGNORECASE)
FOOTING_SHARE_RE = re.compile(r"\bshare\b", re.IGNORECASE)
RANK_COLUMN_RE = re.compile(r"^\s*#\s*$|\brank\b", re.IGNORECASE)


def column_role(column_label, row_kind):
    """Role for a table cell, from its column label and the row's kind.

    ``row_kind`` is one of ``component``, ``subtotal``, ``tail``, ``total``.
    Columns that do not foot (rates, deltas, weighted averages) never get
    ``total``/``subtotal``, because footing them would be wrong.
    """
    label = column_label or ""
    if RANK_COLUMN_RE.search(label):
        return "rank"
    if NON_FOOTING_COLUMN_RE.search(label):
        return "delta" if re.search(r"\byoy\b|\bmove\b|\bchange\b", label,
                                    re.IGNORECASE) else "rate"
    if row_kind == "total":
        return "total"
    if row_kind == "subtotal":
        return "subtotal"
    return "component"


def column_foots(column_label):
    """True when cells in this column participate in a sum down the table."""
    label = column_label or ""
    if RANK_COLUMN_RE.search(label):
        return False
    if FOOTING_SHARE_RE.search(label):
        return True
    return not NON_FOOTING_COLUMN_RE.search(label)


# --- periods -----------------------------------------------------------------
_TRAILING_RE = re.compile(
    r"\b(?:trailing|rolling|last|past)\s+"
    r"(\d+|one|two|three|four|five|six|seven|eight|nine|ten|twelve|"
    r"thirteen|twenty-eight|fifty-two)[\s-]*"
    r"(day|days|week|weeks|month|months)\b", re.IGNORECASE)
_HYPHEN_WINDOW_RE = re.compile(
    r"\b(one|two|three|four|five|six|seven|eight|nine|ten|twelve|\d+)-"
    r"(day|week|month)\b(?:\s+(?:total|average|rolling))?", re.IGNORECASE)

_WORD_NUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
             "seven": 7, "eight": 8, "nine": 9, "ten": 10, "twelve": 12,
             "thirteen": 13, "twenty-eight": 28, "fifty-two": 52}


def _num(word):
    w = word.lower()
    return _WORD_NUM.get(w, int(w) if w.isdigit() else None)


_WEEK_ENDING_RE = re.compile(
    r"\bweek\s+(?:ending|ended)\b|\bw/?e\b|\bweek\s+of\b", re.IGNORECASE)
_MONTH_RE = re.compile(
    r"\bmonth\s+(?:ending|ended|of)\b|\bMTD\b", re.IGNORECASE)
_QUARTER_RE = re.compile(r"\bquarter\b|\bQ[1-4]\b|\bQTD\b", re.IGNORECASE)
_YEAR_RE = re.compile(r"\byear\s+(?:ending|ended)\b|\bYTD\b|\bfull year\b",
                      re.IGNORECASE)
_POINT_IN_TIME_RE = re.compile(r"\bas of\b|\bas at\b|\bsnapshot\b",
                               re.IGNORECASE)
_FISCAL_RE = re.compile(r"\bfiscal\b|\bFY\d{2,4}\b|\b20\d{2}W\d{1,2}\b",
                        re.IGNORECASE)


def kind_from_label(label):
    """Classify a period label by its OWN semantics.

    This is the discriminating field. If every claim is stamped with the same
    kind, a tile labelled "trailing 4 weeks" sitting in a weekly report stops
    standing out — and that mislabelling is exactly what a period-integrity
    check exists to catch. So the kind must be read from the label in front
    of it, never from a document-level definition applied uniformly.

    "Week ending Saturday 4 April 2026" is a ``calendar_week``. A footnote
    elsewhere describing the measurement as "the trailing seven days closing
    on the Saturday named in the header" does not change what *this* label
    says; it is a separate statement, and reconciling the two is a check.

    Returns ``(kind, length_days)``; ``length_days`` is None when the label
    does not imply one.
    """
    if not label:
        return "unknown", None
    win = period_from_text(label)
    if win:
        _, kind, length = win
        return kind, length
    if _WEEK_ENDING_RE.search(label):
        return "calendar_week", 7
    if _MONTH_RE.search(label):
        return "calendar_month", None
    if _QUARTER_RE.search(label):
        return "calendar_quarter", None
    if _YEAR_RE.search(label):
        return "calendar_year", None
    if _FISCAL_RE.search(label):
        return "fiscal_period", None
    if _POINT_IN_TIME_RE.search(label):
        return "point_in_time", None
    return "unknown", None


def period_from_text(text):
    """Detect a stated window like 'trailing 4 weeks' / 'rolling four-week'.

    Returns ``(label, kind, length_days)`` or ``None``.
    """
    if not text:
        return None
    m = _TRAILING_RE.search(text)
    if m:
        n = _num(m.group(1))
        unit = m.group(2).lower()
        return _window(m.group(0), n, unit)
    m = _HYPHEN_WINDOW_RE.search(text)
    if m:
        n = _num(m.group(1))
        return _window(m.group(0), n, m.group(2).lower())
    return None


def _window(label, n, unit):
    if n is None:
        return (label, "unknown", None)
    if unit.startswith("day"):
        return (label, "trailing_days", n)
    if unit.startswith("week"):
        return (label, "trailing_weeks", n * 7)
    if unit.startswith("month"):
        return (label, "calendar_month", None)
    return (label, "unknown", None)


# --- caption parsing ---------------------------------------------------------
_SORT_RE = re.compile(
    r"((?:sorted\s+)?by\s+[a-z][a-z \-']*?)(,\s*(?:highest|lowest)\s+first)?"
    r"(?=[.,;]|$)", re.IGNORECASE)
_RANKED_RE = re.compile(r"\bRanked\b[^.,]*", re.IGNORECASE)
_SCOPE_HINT_RE = re.compile(
    r"\bTop\s+\d+\s+of\s+[\d,]+\b|\bAll\s+(?:\d+|three|the)\b|\b1P only\b|"
    r"\bexclud\w+\b|\bnot broken out\b|\bsuppressed\b|\bonly\b",
    re.IGNORECASE)


def sentences(text):
    if not text:
        return []
    parts = re.split(r"(?<=[.!?])\s+(?=[A-Z—“\"'$\d])", text.strip())
    return [p.strip() for p in parts if p.strip()]


_TOPN_RE = re.compile(r"\btop\s+\d+\b", re.IGNORECASE)


def parse_caption(caption):
    """Pull ``(declared_sort, declared_scope, declared_scale)`` out of a caption.

    A bare "by <something>" is *not* treated as a sort declaration on its own:
    "Owned inventory versus third-party / drop-ship, by vendor code" describes
    a classification, not an order. A sort is only recorded when the caption
    also carries an ordering signal ("sorted by", "highest first") or selects
    a top-N, where being ordered by the selection metric is implied.
    """
    if not caption:
        return None, None, None
    sort = None
    m = _SORT_RE.search(caption)
    if m:
        explicit = bool(m.group(2)) or m.group(1).lower().startswith("sorted")
        if explicit or _TOPN_RE.search(caption):
            sort = (m.group(1) + (m.group(2) or "")).strip().rstrip(".,;")
    if sort is None:
        rm = _RANKED_RE.search(caption)
        if rm:
            sort = rm.group(0).strip().rstrip(".,;")

    sents = sentences(caption)
    scope = None
    if sents:
        first = sents[0]
        if sort and sort in first:
            first = first.replace(sort, "").replace(" ,", ",")
        first = re.sub(r"\s{2,}", " ", first).strip(" ,.;")
        scope = first or None
    extra = [s for s in sents[1:] if _SCOPE_HINT_RE.search(s)]
    if extra:
        scope = ((scope + ". ") if scope else "") + " ".join(extra)
    scale, scale_verbatim = scale_from_label(caption)
    return sort, scope, scale_verbatim


# --- named entities ----------------------------------------------------------
_CAP_RUN_RE = re.compile(r"\b([A-Z][A-Za-z''’]*(?:\s+[A-Z][A-Za-z''’]*)+)\b")
_ALLCAPS_RE = re.compile(r"\b([A-Z]{2,}(?:\s+[A-Z]{2,})*)\b")
_CAP_SINGLE_RE = re.compile(r"\b([A-Z][a-z''’]{2,})\b")


def named_entities(text, vocabulary):
    """Capitalised runs, all-caps tokens, and single capitals the document
    itself uses as dimension members (``vocabulary``)."""
    out = []
    for m in _CAP_RUN_RE.finditer(text):
        out.append(m.group(1))
    for m in _ALLCAPS_RE.finditer(text):
        out.append(m.group(1))
    for m in _CAP_SINGLE_RE.finditer(text):
        tok = m.group(1)
        if any(tok == v or v.startswith(tok + " ") or (" " + tok) in v
               for v in vocabulary):
            out.append(tok)
    return _dedupe(out)
