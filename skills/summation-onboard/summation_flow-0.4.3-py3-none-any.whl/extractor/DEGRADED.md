# Degradations

Every shortcut taken, with the reason and the smallest fix. Per SPEC §0.2:
degradation is allowed, hiding it is not.

---

## X1 — HTML only. PDF, `.sdoc`, `.md`, `.docx`, `.xlsx` are not implemented

**Status:** DEGRADED (format coverage), not BLOCKED.

`extractor.run` rejects any extension other than `.html`/`.htm` with exit
code 2. The schema's `source.format` enum admits six formats; one is
supported.

The detector record says so rather than staying silent —
`extraction_report.detectors_run` carries `pdf_text_layer`, `ocr` and
`xlsx_sheets`, each with outcome `unsupported_format`. A consumer can tell
"we did not try" from "we tried and found nothing".

**Why:** stdlib-plus-`jsonschema` only. There is no PDF text-layer reader in
the standard library, and writing one is a different project.

**Smallest fix:** a `readers/` package with one module per format, each
returning the same `Document` interface `domdoc.py` exposes. `.sdoc` and
`.md` are close to free; PDF needs a dependency and SPEC §2 already predicts
its table reconstruction will be the worst of the set.

**Consequence for SPEC 2.6:** fidelity is measured for HTML only. There is no
per-format comparison because there is only one format.

---

## X2 — `metric_label` is left empty for 33 of 93 prose claims

**Status:** DEGRADED (completeness), deliberately.

Prose metric labels are resolved by matching the ≤70 characters before and
≤45 after the number against the document's *own* vocabulary — its column
headers and KPI tile labels — plus a short built-in list. When nothing
matches, `metric_label` is omitted rather than guessed, and
`confidence.notes` says so.

Example: `"Apparel → Tops → T-Shirt fell 15.7% against last year"` gets
`entity: {"Class": "Apparel → Tops → T-Shirt"}` and `direction_words:
["fell"]`, but no metric label — the sentence never names the metric.

**Why:** guessing a label from nearby words invents an attribution. The
downstream direction/polarity check works from `entity` + `sentence`, which
are both present, so the loss is bounded.

**Counted at:** `detectors_run["prose_metric_label_resolution"].detail`.

**Smallest fix:** resolve prose metrics against the stage-3 metric-layer
artifact instead of the document's own header strings. That artifact does not
exist yet at stage 2, which is why `metric_id` is null on every claim.

---

## X3 — `named_entities` is a capitalisation heuristic

Capitalised runs of two or more words, all-caps tokens, and single
capitalised words that the document itself uses as a dimension member. This
finds `"The Vancouver Canucks"` — the ungrounded-claim case — but also picks
up the leading `"The"` and any sentence-initial proper-looking word.

**Why:** no NER without third-party packages.

**Smallest fix:** strip a leading determiner, and drop single tokens that are
not also table members. (The second half is already done; the first is not.)

---

## X4 — `char_span` is in characters, not bytes

Offsets index the UTF-8-decoded string. The document contains multi-byte
characters (`—`, `−`, `·`, `→`), so a byte-oriented consumer must decode
first. The schema does not say which, so this is a stated convention rather
than a violation.

---

## X5 — spelled-out cardinals below two are dropped

`"a pricing one"` and `"every one of"` are pronouns. Claiming a value of 1
for them would invent a number, so cardinals under two are only extracted
when an explicit unit word follows (`"one week"`). The cost: the grain
statement `"one row per product per week"` produces no claim.

**Counted at:** `detectors_run["spelled_out_cardinals"]`.

---

## X7 — prose comparison bases are left null (rule attempted, measured, removed)

**Status:** DEGRADED (coverage), by measurement rather than by omission.

`comparison.base_claim_id` resolves for **35 of 88** comparisons. The
breakdown, which `detectors_run["comparison_base_resolved"].detail` also
carries:

| | count | why |
|---|---|---|
| resolved | 35 | table YoY columns and KPI tiles — structural pairings |
| no base in the document | 48 | chiefly `GM move` columns: the tables print `GM % TY` but never `GM % LY`, so the second operand does not exist |
| prose deltas, left null | 5 | this degradation |

A prose rule **was** implemented and then removed. It matched the explicit
"A against B" shape inside one sentence, both sides the same unit, with a
percent delta present. Scored on this document it was **0 true positives and
1 false positive**:

> "Womens is the weakest on margin at **47.3%**, down 1.1 points, and it
> carries **$10.5M** of on-hand retail against **$85,290** of weekly demand"

It paired 47.3% — a gross margin — as a `percent_change` of $10.5M over
$85,290, a relation the author never wrote. Meanwhile the one true target in
the document ("$515,481 against $539,519 a year ago … or 4.5%") carries three
currency figures rather than two and was missed.

Knowing that 47.3% is a margin and not a movement of the two dollar figures
requires the **stage-3 metric layer**, which does not exist at stage 2 — the
same reason `metric_id` is null on every claim.

**Smallest fix:** resolve prose bases after stage 3 lands, gated on the
delta's `metric_id` matching the operands' `metric_id`.

The reasoning is preserved in the `_link_prose_comparison` docstring in
`build.py` so the next person does not re-add the same rule, and
`test_derivations.py::test_no_prose_delta_claims_a_fabricated_base` fails if
they do.

---

## X6 — `checkable_fraction` is a stated definition, not a universal one

0.8828 for this document. A claim counts as checkable when at least one
in-document relationship can be run against it: it anchors or belongs to a
footing; its value restates another claim's; it carries a comparison; it is
an explicit null; or it sits in the sort-key column of a table with a
declared sort. The definition is in the `checkable_fraction` docstring in
`build.py`.

Read it as *"checkable by the eight wave-1 families over this ledger"*, not
as a claim about all possible checks. A different check set gives a different
number, and the number should be republished with the check set it belongs
to.
