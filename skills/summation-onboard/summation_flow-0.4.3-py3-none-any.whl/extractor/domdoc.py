"""A minimal, position-tracking HTML DOM built on `html.parser`.

Why hand-rolled: the build is restricted to the standard library plus
`jsonschema`. No BeautifulSoup, no lxml.

Two things this layer must get right, because everything downstream depends
on them:

1.  **Character positions.** Every text fragment keeps the absolute character
    offset it occupied in the source file. That gives each claim a real
    `char_span` and a real line number, which is how extraction fidelity is
    measured against the answer key.
2.  **Whitespace collapsing with an index map.** HTML collapses runs of
    whitespace. Sentences must be read collapsed, but offsets must still point
    back into the raw file. `text_with_map()` returns the collapsed string and
    a parallel array of absolute offsets, one per output character.

`convert_charrefs` is deliberately **off**. With it on, `html.parser` merges
entity references into the surrounding data chunk and the decoded length stops
matching the raw length, so offsets silently drift. Handling `&mdash;` and
friends explicitly keeps the map exact — and em dashes are load-bearing here
(they mark genuine nulls).
"""

from __future__ import annotations

import bisect
import html as _htmlmod
import re
from html.parser import HTMLParser

VOID_TAGS = {
    "area", "base", "br", "col", "embed", "hr", "img", "input",
    "link", "meta", "param", "source", "track", "wbr",
}

# Content of these elements is markup-ish noise, never document text.
OPAQUE_TAGS = {"style", "script"}

_WS_RE = re.compile(r"[\s ]+")


class Text:
    """A leaf text fragment with exact source coordinates."""

    kind = "text"
    __slots__ = ("decoded", "abs_start", "abs_end", "parent")

    def __init__(self, decoded: str, abs_start: int, abs_end: int, parent=None):
        self.decoded = decoded
        self.abs_start = abs_start
        self.abs_end = abs_end
        self.parent = parent

    def __repr__(self):  # pragma: no cover - debugging aid
        return f"Text({self.decoded!r}@{self.abs_start})"


class Element:
    """An HTML element node."""

    kind = "element"
    __slots__ = ("tag", "attrs", "children", "parent", "abs_start", "abs_end")

    def __init__(self, tag: str, attrs: dict, parent=None, abs_start: int = 0):
        self.tag = tag
        self.attrs = attrs
        self.children = []
        self.parent = parent
        self.abs_start = abs_start
        self.abs_end = abs_start

    # -- convenience ------------------------------------------------------
    @property
    def id(self):
        return self.attrs.get("id")

    @property
    def classes(self):
        return (self.attrs.get("class") or "").split()

    def child_elements(self, *tags):
        want = set(tags)
        return [c for c in self.children
                if c.kind == "element" and (not want or c.tag in want)]

    def descendants(self):
        for c in self.children:
            yield c
            if c.kind == "element":
                yield from c.descendants()

    def find_all(self, tag):
        return [d for d in self.descendants()
                if d.kind == "element" and d.tag == tag]

    def find(self, tag):
        for d in self.descendants():
            if d.kind == "element" and d.tag == tag:
                return d
        return None

    def find_by_class(self, cls):
        return [d for d in self.descendants()
                if d.kind == "element" and cls in d.classes]

    def __repr__(self):  # pragma: no cover - debugging aid
        ident = f"#{self.id}" if self.id else ""
        return f"<{self.tag}{ident}>"


def text_with_map(node):
    """Collapse a subtree to display text, with an offset map.

    Returns ``(text, offsets)`` where ``offsets[i]`` is the absolute character
    offset in the source file of ``text[i]``. Whitespace runs (including
    ``\\xa0``) collapse to a single space, matching how a browser renders it.
    Leading and trailing whitespace is trimmed.
    """
    chars = []
    offs = []

    def walk(n):
        if n.kind == "text":
            raw_is_1to1 = (n.abs_end - n.abs_start) == len(n.decoded)
            for i, ch in enumerate(n.decoded):
                chars.append(ch)
                offs.append(n.abs_start + i if raw_is_1to1 else n.abs_start)
        else:
            if n.tag in OPAQUE_TAGS:
                return
            for c in n.children:
                walk(c)

    walk(node)

    out_chars = []
    out_offs = []
    pending_ws = False
    for ch, off in zip(chars, offs):
        if _WS_RE.match(ch):
            pending_ws = True
            continue
        if pending_ws and out_chars:
            out_chars.append(" ")
            out_offs.append(off)
        pending_ws = False
        out_chars.append(ch)
        out_offs.append(off)
    return "".join(out_chars), out_offs


class _Builder(HTMLParser):
    def __init__(self, src: str):
        super().__init__(convert_charrefs=False)
        self.src = src
        self.line_starts = [0]
        for i, ch in enumerate(src):
            if ch == "\n":
                self.line_starts.append(i + 1)
        self.root = Element("#document", {}, None, 0)
        self.stack = [self.root]

    # -- position helpers -------------------------------------------------
    def _abs(self) -> int:
        line, col = self.getpos()
        return self.line_starts[line - 1] + col

    # -- handlers ---------------------------------------------------------
    def handle_starttag(self, tag, attrs):
        el = Element(tag, {k: (v if v is not None else "") for k, v in attrs},
                     self.stack[-1], self._abs())
        self.stack[-1].children.append(el)
        if tag not in VOID_TAGS:
            self.stack.append(el)

    def handle_startendtag(self, tag, attrs):
        el = Element(tag, {k: (v if v is not None else "") for k, v in attrs},
                     self.stack[-1], self._abs())
        self.stack[-1].children.append(el)

    def handle_endtag(self, tag):
        end = self._abs()
        for depth in range(len(self.stack) - 1, 0, -1):
            if self.stack[depth].tag == tag:
                for el in self.stack[depth:]:
                    el.abs_end = end
                del self.stack[depth:]
                return
        # Stray close tag: ignore, matching browser tolerance.

    def _add_text(self, decoded, abs_start, abs_end):
        parent = self.stack[-1]
        if parent.tag in OPAQUE_TAGS:
            return
        parent.children.append(Text(decoded, abs_start, abs_end, parent))

    def handle_data(self, data):
        start = self._abs()
        self._add_text(data, start, start + len(data))

    def _raw_ref_len(self, start, fallback):
        # Entity refs may or may not carry the trailing ';'. Measure the source.
        window = self.src[start:start + 16]
        semi = window.find(";")
        return semi + 1 if 0 <= semi <= 12 else fallback

    def handle_entityref(self, name):
        start = self._abs()
        raw_len = self._raw_ref_len(start, len(name) + 1)
        decoded = _htmlmod.unescape("&" + name + ";")
        self._add_text(decoded, start, start + raw_len)

    def handle_charref(self, name):
        start = self._abs()
        raw_len = self._raw_ref_len(start, len(name) + 2)
        decoded = _htmlmod.unescape("&#" + name + ";")
        self._add_text(decoded, start, start + raw_len)


class Document:
    """Parsed document plus offset/line utilities."""

    def __init__(self, src: str, path: str = "<memory>"):
        self.src = src
        self.path = path
        b = _Builder(src)
        b.feed(src)
        b.close()
        self.root = b.root
        self.line_starts = b.line_starts

    def line_of(self, abs_offset: int) -> int:
        """1-indexed source line containing ``abs_offset``."""
        return bisect.bisect_right(self.line_starts, abs_offset)

    def body(self):
        return self.root.find("body") or self.root

    def title(self):
        t = self.root.find("title")
        if t is None:
            return None
        return text_with_map(t)[0] or None


def parse(src: str, path: str = "<memory>") -> Document:
    return Document(src, path)


def css_path(el: Element) -> str:
    """A readable, reasonably specific selector for an element."""
    parts = []
    node = el
    while node is not None and node.tag != "#document":
        seg = node.tag
        if node.id:
            seg += "#" + node.id
            parts.append(seg)
            break
        cls = [c for c in node.classes if c]
        if cls:
            seg += "." + ".".join(cls)
        parent = node.parent
        if parent is not None:
            sibs = [c for c in parent.children
                    if c.kind == "element" and c.tag == node.tag]
            if len(sibs) > 1:
                seg += f":nth-of-type({sibs.index(node) + 1})"
        parts.append(seg)
        node = parent
    return " > ".join(reversed(parts))
