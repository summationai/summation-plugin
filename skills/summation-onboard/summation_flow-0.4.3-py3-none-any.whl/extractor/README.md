# Claim-ledger extractor — stage 2

Turns a source document into a `claim-ledger/v1` artifact: **one row per
number**, with enough context that every stage-4 cold-verify check can read it
without touching the document again.

Standard library plus `jsonschema`. No BeautifulSoup, no lxml, no pandas —
HTML parsing is hand-rolled on `html.parser`.

*Last updated: 2026-08-05. Numbers below are actual output, reproduced by the
commands shown.*

> **The canonical ledger is `extractor/out/ledger.json` — nowhere else.**
> Point the check engine at that path. Every ledger records
> `extractor.version` and `extracted_at`, so a consumer can tell a stale file
> from a current one without trusting a path: the current build is
> **v0.6.3**, 477 claims, `period.kind` = 471 `calendar_week` / 4
> `trailing_days` / 2 `trailing_weeks`. Anything reporting 478 claims or 476
> `trailing_days` is a pre-v0.6.0 copy.

---

## Run it

```bash
python3 -m extractor.run \
  --input tests/extractor/fixtures/2026-04-04-nhl-adult-apparel-jerseys-headwear.html \
  --out   extractor/out/ledger.json \
  --expect-sha256 5eb79d9e0e5f65566ae48eaa1f60b8690f518c33232c0e5e4c6d55d0587ab755
```

`--expect-sha256` is optional but recommended: it exits `3` if the document
changed, so a later edit cannot silently invalidate line-number-based
fidelity numbers.

```
wrote extractor/out/ledger.json
  parse wall-clock      : 53.0 ms
  claims_found          : 477
  unparseable           : 0
  tables_found          : 10
  prose_blocks_found    : 41
  precision_indeterminable: 17
  unit_unknown          : 8
  checkable_fraction    : 0.8826
  detectors_run         : 32 (7 found_nothing, 3 unsupported_format)
  schema                : VALID
```

Exit codes: `0` valid, `1` schema validation failed, `2` unsupported input
format, `3` input hash mismatch. `--no-validate` skips validation,
`--schema` points at a different schema, `-q` silences the summary.

**Parse wall-clock (SPEC 2.7):** five consecutive runs on the 27,076-byte,
550-line HTML fixture — 52.5, 54.7, 53.2, 52.4, 53.7 ms. HTML is the only
format implemented, so there is no per-format comparison (see `DEGRADED.md`
X1).

> **Fixture note.** The task brief quoted the fixture as 526 lines / 25,989
> bytes / sha256 `e5918d23…`. The fixture on disk was revised on top of that
> (commit `3693892`, "landscape print fix"): it is now **550 lines / 27,076
> bytes / sha256 `5eb79d9e…`**, which is what `cleanroom-answers.json` and
> `CLEANROOM.md` §8.2 record. Everything here ran against the current file
> and the current answer key, and `git status --porcelain` in `cleanroom/` is
> empty. The revision added only a print-media `<style>` block and an HTML
> comment; both are skipped, and no CSS value (`17%`, `9px`, `11mm`) reaches
> the ledger. A test asserts the ledger hash equals the sealed hash, so this
> cannot drift unnoticed.

---

## Layout

| File | What it does |
|---|---|
| `domdoc.py` | Position-tracking DOM on `html.parser`. Keeps exact source character offsets through whitespace collapsing, so every claim gets a real `char_span`. |
| `numparse.py` | Number recognition: precision, rounding envelope, unit, scale, sign, nulls, spelled-out cardinals, calendar masking. |
| `lexicon.py` | Word lists and label rules: direction words, superlatives, causal markers, forward-looking markers, polarity, caption parsing, period parsing. |
| `build.py` | Walks the document and assembles the ledger. |
| `run.py` | CLI + schema validation. |
| `tools/fidelity.py` | Measures coverage against the sealed answer key. |
| `tools/precision_audit.py` | The 45-row hand-verified precision table. |
| `tests/` | 89 pytest tests. |

---

## What is implemented

**Tables (10 found).** Every numeric cell, with `row_label`, `column_label`,
`row_index`, `column_index`, `table_id` and a DOM selector. Row kind comes
from the row's class (`total` / `subtotal` / `tail`) or from sitting inside
`<tfoot>`. Non-numeric cells in a row become that row's `entity` dimensions,
keyed by their column header — so a claim in the actions table carries
`{"Signal": "...", "Where": "Colorado Avalanche", "Owner": "Amara Renko"}`.

**Tables[] context.** `declared_sort`, `declared_scope`, `declared_scale`
parsed from captions and column headers:

| table | declared_sort | declared_scope | declared_scale |
|---|---|---|---|
| `tbl-teams` | `by net demand, highest first` | `Top 5 of 62 teams` | `Whole dollars` |
| `tbl-vendors` | `sorted by net demand, highest first` | `Top 5 of 26 vendors` | `($000)` |
| `tbl-1p3p` | *(none)* | `Owned inventory versus third-party / drop-ship, by vendor code` | `Whole dollars` |
| `tbl-actions` | `Ranked action signals for the week` | *(none)* | *(none)* |

A bare "by X" is **not** recorded as a sort. `"…, by vendor code"` describes a
classification, not an order; recording it would hand a downstream sort-order
check a false positive. A sort is recorded only with an explicit ordering
signal (`sorted by`, `highest first`, `Ranked`) or a top-N selection.

**Prose (88 claims, 41 blocks).** Every number with its **full containing
sentence**, plus `direction_words` (65 claims) and `superlatives` (35).
Blocks carry `causal_markers`, `forward_looking`, `named_entities` and
`claim_ids`.

**KPI tiles (8 tiles, 20 claims).** `location.kind: "kpi_tile"`. The tile
value, plus each number on the comparison line — last-year base values and
signed deltas separately.

**Footnotes (5 claims).** `location.kind: "footnote"`. Footnote 2's *"365
days earlier"* is read as a document-level declaration and stamped onto
`comparison.alignment_days` for all 88 comparison-bearing claims, so the
day-of-week alignment check has something to test.

**Periods.** `period.kind` is classified from each label's **own** words, not
from a document-level definition applied uniformly:

| kind | claims | label |
|---|---|---|
| `calendar_week` | 419 | `Week ending Saturday 4 April 2026` |
| `calendar_week` | 52 | `… — prior year (LY)` |
| `trailing_days` | 4 | `trailing seven days` |
| `trailing_weeks` | 1 | `trailing 4 weeks` |
| `trailing_weeks` | 1 | `trailing four-week` |

This field is the discriminating one, and it is only useful if it varies. A
`Week ending X` window with `length_days: 7` is a `calendar_week`; stamping
it `trailing_days` because footnote 1 defines the measurement as "the
trailing seven days closing on the Saturday named in the header" flattens
the whole document to one kind and makes the odd window out invisible.

Footnote 1's definition is still recorded — as
`detectors_run["document_period_definition"]`, and as readable footnote text
— because the header label and the footnote saying different things is
itself a check. It just does not overwrite the label's kind.

**Derivations (schema v1.1).** 117 claims carry `derived_from`; 35 of 88
comparisons carry `base_claim_id` — **100% of the structurally resolvable
set**. Only relations the document itself makes derivable are claimed:

| operation | count | read off |
|---|---|---|
| `share_of` | 42 | a Share cell over the total row's primary measure |
| `sum` | 40 | totals and subtotals, mirroring `aggregates_claims` |
| `percent_change` | 33 | a YoY column beside its TY/LY pair, and KPI tile deltas |
| `point_change` | 2 | a points move between two rates printed together |

`asserted_by` is set honestly: **82 `document_structure`, 35 `inferred`,
0 `prose_statement`**. The 35 inferred are Share columns whose header is a
bare `"Share"` — the table never says what the denominator is, so the
relation is conventional rather than stated. Where the header does say
(`"Share of NHL"`), it is `document_structure`.

**Base coverage is complete where it is possible.** Every table that prints a
YoY column beside a TY/LY pair has **100%** of those cells linked:

| table | comparisons | base linked | why not the rest |
|---|---|---|---|
| `tbl-league` | 4 | 2 | `GM move` — no `GM % LY` printed |
| `tbl-teams` | 12 | 7 | `GM move` |
| `tbl-departments` | 8 | 4 | `GM move` |
| `tbl-classes` | 13 | 7 | `GM move` |
| `tbl-1p3p` | 6 | 3 | `GM move` |
| `tbl-vendors` | 13 | 7 | `GM move` |
| `tbl-assortment` | 7 | 0 | table prints YoY with **no LY column at all** |
| `tbl-brands` | 13 | 0 | same |

The 53 unlinked comparisons have no prior-year value **anywhere in the
document** to point at. Fabricating one would be exactly the failure this
field exists to prevent. `test_derivations.py::test_every_resolvable_table_base_is_actually_resolved`
fails if a resolvable pairing is ever left to a heuristic.

Prose deltas are also left null — a rule for them was written, measured at 0
true positives and 1 false positive, and removed (`DEGRADED.md` X7). A wrong
relation makes a check assert arithmetic the author never wrote, which is
worse than a missing one.

**Phantom numbers inside names.** `47 Brand` and `'47` are vendor and brand
names. Read as the number 47, they become claims a movement check will marry
to the nearest dollar figure. Any number falling inside a dimension member
the document itself names is skipped and counted at
`detectors_run["numbers_inside_named_entities_skipped"]`. The genuine `47` —
a Units cell in the styles table — is untouched.

`base_claim_id` is written as an explicit `null` rather than omitted, so
"we looked and the base is not here" is distinguishable from "we never
looked".

**Roles and footings.** 41 claims carry `aggregates_claims` (still populated
alongside `derived_from`, per the plain-footing contract). A total that
sits above a subtotal aggregates `[subtotal, tail]`, not the raw components —
so the Teams total believes it is two parts, and the Teams subtotal believes
it is five. Rate columns (`GM % TY`, `YoY`, `GM move`, `AUR`) never claim to
foot, because a weighted average is not a sum.

Role census: `component` 164, `delta` 123, `standalone` 68, `rate` 56,
`total` 38, `count` 17, `rank` 7, `subtotal` 5.

**Polarity.** `higher_is_better` 298, `neutral` 100, `unknown` 75,
`lower_is_better` 5. Stockout and markdown rows resolve to
`lower_is_better`; demand, margin, units and sell-through to
`higher_is_better`; share, on-hand and on-order to `neutral`. A column with
no keyword of its own (`YoY`, `GM move`) inherits from the nearest preceding
column that has one.

**Confidence basis** is derived from *how* the value was obtained, never from
self-report: `structured_cell` 385, `prose_parsed` 93. Nothing in an HTML
source is allowed to claim `ocr` or `chart_estimate`, and a test enforces it.

---

## Precision and the rounding envelope

`displayed_precision` is the count of decimal digits **actually rendered**,
after stripping sign, currency symbol, parentheses, thousands separators and
any scale or unit suffix. `rounding_envelope` is
`0.5 × 10^-precision × scale_factor`, in units of `value_parsed`.

| rendered | precision | value_parsed | envelope |
|---|---|---|---|
| `$1,240` | 0 | 1240 | 0.5 |
| `41.9%` | 1 | 41.9 | 0.05 |
| `1.32%` | 2 | 1.32 | 0.005 |
| `$1.2M` | 1 | 1,200,000 | 50,000 |
| `(3.4)%` | 1 | −3.4 | 0.05 |
| `100.1%` | 1 | 100.1 | 0.05 |
| `192,301` under a `($000)` header | 0 | 192,301,000 | 500 |
| `—` | null | null | null |

A declared scale is **applied**, not second-guessed. Whether the values honour
a `($000)` header is a downstream check.

A scale declaration only governs the unit it was written about: `Whole
dollars` and `($000)` are statements about money, so they never reach a
percentage, a point move or a unit count. Those get `scale_source: "absent"`.
`scale_inferred` is **0** — the extractor never infers scale from magnitude,
because doing so would pre-judge the check that ought to catch it.

---

## Fidelity — measured, not asserted

```bash
python3 -m extractor.tools.fidelity \
  --ledger extractor/out/ledger.json \
  --answers cleanroom-answers.json \
  --source cleanroom/reports/2026-04-04-nhl-adult-apparel-jerseys-headwear.html
```

```
answer-key references          : 34
  extracted (+/-2 line window) : 34  (100.0%)
  extracted (exact same line)  : 33  (97.1%)
claims found in total          : 477
  unparseable                  : 0
  precision indeterminable     : 17
  checkable_fraction           : 0.8826
MISSES: none
```

**34 of 34 = 100%** of answer-key-referenced claims extracted: all 11 planted
defects (D01–D11) and all 23 must-not-flag positions (N01a–N08b). One match
lands two lines off the key's cited line, because the key sometimes cites a
table row's opening tag line while the cell itself sits on the next line;
both the strict and the windowed number are printed so the tolerance is
visible.

The answer key is read **only** to ask "did we produce a claim here?".
No defect detection is implemented, and no answer-key knowledge is encoded in
the extractor. Detection is a different component's job.

### Totals

| | |
|---|---|
| numbers found in total | **477** |
| could not parse | **0** |
| explicit nulls (em dash), emitted as claims with `value_parsed: null` | 17 |
| precision indeterminable | 17 (exactly the 17 nulls) |
| unit unknown | 8 |
| bare integers deliberately skipped inside text cells | 20 |
| numbers skipped inside a named entity (e.g. "47 Brand") | 1 |
| calendar literals masked out of number scanning | 8 |
| spelled-out cardinals extracted | 13 |
| charts found / unreadable | 0 / 0 |

Em dashes are **not** counted as unparseable. `—` in a last-year column is an
explicit null the document rendered on purpose, not a value that failed to
parse; conflating them would let a real parse failure hide. They are recorded
separately in `detectors_run["em_dash_null_cells"]`.

### Precision-derivation accuracy

```bash
python3 -m extractor.tools.precision_audit extractor/out/ledger.json
```

```
precision_correct   : 45/45  (100.0%)
envelope_correct    : 45/45  (100.0%)
value_correct       : 45/45  (100.0%)
unit_correct        : 45/45  (100.0%)
scale_correct       : 45/45  (100.0%)
```

**Sample: 45 values**, hand-checked (the brief asks for at least 25). The
sample is not random — it is a census of every distinct *display shape* in the
document, so every rendering form the author used is covered exactly once:
`$10.5M`, `(−3.5%)`, `+0.20 points`, `192,301` under a `($000)` header,
`34 cents`, `sixty-two`, `—`, and 38 more. The table lives in
`tools/precision_audit.py` and a test asserts the live ledger still matches
it.

**The audit found two real bugs, both fixed:**

1. `(−3.5%)` was captured as `(−3.5%` — the closing parenthesis fell outside
   the pattern because it sits after the `%`, so `value_displayed` was not
   what the document rendered. Fixed, plus the sign rule: a printed minus
   inside brackets is a bracketed negative, not a double negative.
2. `814,431 units` was typed `currency`, inherited from the tile label *"On
   order (retail)"*, even though the text says "units". Fixed by treating
   `units` as a unit suffix, so the literal beats the label.

---

## Tests

```bash
python3 -m pytest tests/extractor -q
```

```
........................................................................ [ 80%]
.................                                                        [100%]
89 passed in 0.33s
```

Required cases are all present:

* **Schema validation of the real output** — `test_ledger.py::test_real_output_validates_against_the_committed_schema`, validating against `schemas/claim-ledger.schema.json` with `Draft202012Validator`.
* **Precision derivation** across `$1,240`, `41.9%`, `1.32%`, `$1.2M`, `(3.4)%`, `100.1%` and em-dash nulls — `test_precision.py`, 17 parametrised literals plus dedicated null, declared-scale and scale-leakage tests.
* **Envelope computation** — `test_envelope_formula`, plus `test_no_claim_carries_an_invented_value`, which recomputes every one of the 477 envelopes from that claim's own precision and scale.
* **`period.kind` agrees with `period.label`** on every claim — `test_period.py::test_every_claim_kind_agrees_with_its_own_label`, plus a test that the document is never flattened to a single kind.
* **Negatives are recorded** — `test_detectors_record_negatives` asserts `detectors_run` contains `found_nothing` entries and names them: `chart_images_img`, `chart_vector_svg`, `chart_canvas`, `sdoc_cell_traceability`, `colspan_rowspan_cells`, `table_row_length_mismatch`, `headings_with_numbers`.

Also covered: fidelity recall cannot regress below 100%; a ragged table row
lowers confidence instead of guessing an alignment; an unparseable numeric
cell is counted rather than dropped; nothing is marked `sourced` without
traceability; rate columns do not claim to foot; forward-looking marking does
not sweep in historical claims.

`test_derivations.py` covers the v1.1 fields, including the negatives: every
operand resolves to a real claim and no derivation is self-referential;
`GM move` claims no fabricated operand; no prose delta claims a base;
`base_claim_id` is always present even when null.

One test is worth calling out — `test_derivations_actually_compute` walks
every `sum` relation and checks it inside the combined rounding envelope. It
asserts that **at least one fails**. That is deliberate: the clean-room
document has planted footing breaks, and a run where everything foots means
the extractor stopped reading the document properly. The test pins the count
rather than repairing anything.

---

## Detectors, including the ones that found nothing

28 rows. "Ran the pass and found nothing" and "never ran the pass" are
different states, and the record keeps them apart.

**found (18):** `document_title` 1, `document_period_label` 1,
`yoy_alignment_declaration` 1, `html_tables` 10,
`table_cell_numeric_values` 365, `kpi_tiles` 8, `prose_blocks` 41,
`table_captions` 10, `declared_sort_captions` 7,
`declared_scope_captions` 9, `declared_scale_declarations` 4, `footnotes` 5,
`em_dash_null_cells` 17, `spelled_out_cardinals` 13,
`prose_numbers_inside_table_cells` 14,
`bare_integers_skipped_in_text_cells` 20, `calendar_literals_masked` 8,
`prose_metric_label_resolution` 60.

**found_nothing (7):** `headings_with_numbers`,
`table_column_count_integrity`, `colspan_rowspan_cells`, `chart_images_img`,
`chart_vector_svg`, `chart_canvas`, `sdoc_cell_traceability`.

`table_column_count_integrity` is the guard against a silently truncated
table. Every body row's cell count is asserted against its header row, and
any mismatch is named (`"tbl-x row 3 (tail): 6 cells vs 7 header columns"`)
rather than counted anonymously — a misaligned column makes every footing
check to its right fail in a way that looks like a real defect. On this
document: **all 10 tables clean**, and the detail line says so explicitly
instead of staying silent.

**unsupported_format (3):** `pdf_text_layer`, `ocr`, `xlsx_sheets` — the
input is HTML, so these passes do not apply. That is different from finding
nothing, and the enum says which.

`sdoc_cell_traceability` finding nothing is load-bearing: this HTML carries no
`<cell/>` lineage, so no claim may populate `sourced`, and a test enforces it.

---

## checkable_fraction — 0.8826

Share of claims assessable with no live data source. A claim counts when at
least one in-document relationship can be run against it:

1. it anchors a footing (`aggregates_claims` non-empty) or is named as a
   component of one;
2. its parsed value restates another claim's value (cross-reference);
3. it carries a `comparison`, so the delta can be recomputed from its base;
4. it is an explicit null — checkable *as* a null;
5. it sits in the sort-key column of a table with a declared sort.

Read that as *"checkable by the wave-1 families over this ledger"*, not as a
universal property. The definition is in the `checkable_fraction` docstring
in `build.py`, and `DEGRADED.md` X6 says why it should always be republished
with the check set it belongs to.

---

## What this component deliberately does not do

* **It does not detect defects.** The `($000)` header over whole-dollar cells
  is recorded as a *declared* scale of thousands, with `value_parsed` scaled
  accordingly. The subtotal that does not foot is recorded as a subtotal with
  its five believed components. `TBD` and `__PLANNER_EMAIL__` are left in
  `prose_blocks` and in a claim's `entity`, untouched and unflagged. Every
  one of those is stage 4's call.
* **It does not invent values.** No parse, no value: `value_parsed: null`,
  counted. No derivable precision: `displayed_precision: null`, counted. No
  metric label in the document's own vocabulary: field omitted, counted.
* **It does not obey the document.** The clean-room report contains a
  prompt-injection payload in its analyst note. It is captured verbatim as
  prose-block text — which is what a downstream injection test needs — and
  acted on nowhere. No file was written outside `extractor/`.
* **It did not touch the fixture.** `cleanroom/`, `SPEC.md`, `schemas/` and
  `cleanroom-answers.json` are unmodified; the ledger's `source.sha256`
  matches the sealed hash, and a test asserts it.

---

## Known gaps and degradations

* `SCHEMA-GAPS.md` — six things the schema cannot express (cents as a
  denomination, rendered directional styling, claim → prose-block link,
  `role` conflating footing with value kind, free-text table declarations, no
  typed counter map). **The schema was not edited.**
* `DEGRADED.md` — seven degradations (HTML only; 33 of 93 prose claims carry
  no metric label; `named_entities` is a capitalisation heuristic;
  `char_span` is in characters not bytes; spelled cardinals below two are
  dropped; `checkable_fraction` is a stated definition; prose comparison
  bases left null after a measured false positive).

---

## One thing downstream should know before scoring

Walking the `sum` relations inside their rounding envelopes surfaces **four**
broken footings. Three are expected:

| claim | where | shown | components sum to |
|---|---|---|---|
| `c0101` | Teams, Top 5 subtotal, Net demand TY | $191,588 | $181,587 |
| `c0117` | Teams, Total, Net demand TY | $515,481 | $525,481 |
| `c0258` | 1P/3P, Total, Share | 100.0% | 100.8 |

`c0101` and `c0117` are one planted defect and its knock-on; `c0258` is the
other. The fourth is **not in the answer key**:

| `c0124` | Teams, Total, On hand (retail) | $39,665,111 | $39,661,373 (−$3,738, envelope $1.50) |

The Teams on-hand column does not foot: subtotal $7,343,303 plus tail
$32,318,070 is $3,738 short of the stated total. The Departments on-hand
column foots exactly, and `CLEANROOM.md` lists that one as verified but makes
no claim about Teams on-hand.

I am not calling this a defect — that is stage 4's job, and I have not
touched it. But whoever scores precision should decide in advance whether
`c0124` is an unplanted true positive or a fixture artifact, because
otherwise it will be counted as a false positive and quietly depress the
engine's measured precision.
