# Schema gaps

Things the extractor found in the clean-room document that
`schemas/claim-ledger.schema.json` cannot express. **The schema was not
edited.** Each gap lists what was lost and the smallest change that would
close it.

---

## G1 — no sub-unit currency denomination — **CLOSED**

> **Closed.** The schema already carried an optional `denomination` beside
> `currency_code`. What was missing was a producer: 152 currency claims in this
> document, zero denominations, while `coldverify` defaulted an absent value to
> `major` — so the refuse-when-unknown valve could never fire and the 100x error
> below was invisible rather than absent. The extractor now writes the field,
> and `34 cents` carries `denomination: minor` with
> `value_in_major_units: 0.34`. See `tests/extractor/test_denomination.py`.
>
> Written from evidence in the literal only: a `cents` suffix is `minor`, a
> currency symbol is `major`, and a currency unit inherited from a column header
> is left unwritten — a header says which quantity a column holds, not which
> denomination it is written in. That is 130 of the 152 here. The other 22 sit
> under headers like `Net demand TY ($000)`, whose own text is not visible where
> the literal is parsed; absent still reads as `major` to every consumer, so
> they behave exactly as they always have.

**Where:** `"average unit retail slipped 34 cents to $42.96"` (line 100).

`unit` has `currency`, and `scale` has `ones / thousands / millions /
billions`. There was no way to say "this figure is in cents". The claim was
emitted as `unit: currency`, `value_parsed: 34.0` — the displayed magnitude,
not `0.34` — with the denomination written into `confidence.notes`, where no
check would systematically find it.

A downstream arithmetic check that reads `34` as dollars disagrees with
`$43.30 − $42.96 = $0.34` by a factor of 100.

---

## G2 — no place for rendered directional styling

The document colours movement cells green (`class="up"`) or red
(`class="dn"`). That styling is an assertion the author made and it is
checkable: on line 81, `−10.4%` on-hand retail is styled **green**, which is
only coherent if inventory is treated as lower-is-better.

`direction_words` is documented as *language* ("grew, declined, improved"), so
a CSS class does not belong in it — putting it there would let a polarity
check treat a colour as a word. The class is recorded in `confidence.notes`
instead, where no check will systematically find it.

**Smallest fix:** an optional `rendered_direction` enum
(`positive / negative / neutral`) on the claim.

---

## G3 — claims cannot point back at their prose block

`prose_blocks[].claim_ids` links block → claims, but there is no claim →
block link. `causal_markers` and `forward_looking` live only on the block, so
a check holding a claim must scan every block to find its context. Workable,
but O(claims × blocks) and easy to get wrong.

**Smallest fix:** an optional `block_id` on the claim's `location`.

---

## G4 — `role` conflates "what kind of number" with "does it foot"

> **Partly closed by schema v1.1.** `derived_from` now carries the arithmetic
> relation independently of `role`, so a Share cell can be `role: component`
> *and* `derived_from: {operation: share_of}`. The naming collision below
> still stands, but it no longer costs information.


The enum mixes footing positions (`component`, `subtotal`, `total`) with
value kinds (`rate`, `delta`, `rank`, `count`). A Share column cell is both a
rate *and* a component that sums to 100. Only one can be recorded.

This extractor resolves it by **footing first**: any column that sums down the
table (currency, unit counts, share) gets `component`/`subtotal`/`total`;
columns that do not (`GM % TY`, `YoY`, `GM move`, `AUR`) get `rate` or
`delta`. The rule is in `lexicon.column_role` / `lexicon.column_foots`. The
cost is that share cells never read as `rate`, so a checker looking for rates
by role alone will miss them; it must read `unit == "percent"` too.

**Smallest fix:** split into `footing_role` and `value_kind`.

---

## G5 — table-level declarations are free text only

`declared_sort`, `declared_scope` and `declared_scale` are strings. A
sort-order check has to re-parse `"sorted by net demand, highest first"` to
learn the column and the direction, which is the same parsing this extractor
already did.

**Smallest fix:** allow an optional structured form alongside the verbatim
string, e.g. `{"column": "Net demand TY", "direction": "desc"}`.

---

## G6 — `extraction_report` has no slot for typed coverage counts

`additionalProperties: false` means counts such as *explicit null cells*,
*spelled-out cardinals*, *bare integers deliberately skipped inside text
cells* and *calendar literals masked* have nowhere to go as first-class
fields. They are recorded as `detectors_run` rows with `count` and `detail`,
which is readable but not machine-addressable by name.

**Smallest fix:** an optional `counters: {string: integer}` map.
