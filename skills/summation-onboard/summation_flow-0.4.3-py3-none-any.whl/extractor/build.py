"""Build a `claim-ledger/v1` document from a parsed HTML report.

Design rules, in force everywhere below:

*   **Never invent a value.** If a cell cannot be parsed it is recorded as
    unparseable and counted. If a precision cannot be derived it is ``null``
    and counted.
*   **Record negatives.** Every detector that runs appends to
    ``extraction_report.detectors_run``, including the ones that find nothing.
*   **Do not detect defects.** The extractor reports what the document says,
    including declarations it plainly contradicts elsewhere. Deciding that a
    declared ``($000)`` header is wrong is a downstream check.
"""

from __future__ import annotations

import hashlib
import os
import re
import time
from datetime import datetime, timezone

from . import NAME, __version__
from . import lexicon as lex
from . import numparse as np
from .domdoc import css_path, parse, text_with_map

INLINE_TAGS = {"strong", "em", "b", "i", "span", "a", "br", "sup", "sub",
               "code", "small", "u", "abbr", "time", "mark"}
HEADING_TAGS = {"h1", "h2", "h3", "h4", "h5", "h6"}

_TRUNC = 160


def _trim(s, n=_TRUNC):
    s = (s or "").strip()
    return s if len(s) <= n else s[: n - 1] + "…"


def _carry_currency(claim, tok):
    """Move everything a currency literal knows about itself onto the claim.

    `denomination` is why this is a function rather than two lines repeated four times. The field
    was declared in the schema, defaulted to `major` by every consumer, and never written by
    anything — so the refuse-when-unknown valve it exists for could not fire, and `34 cents`
    parsed to 34.0 was read as thirty-four dollars by every arithmetic check downstream. It is
    written only where the literal itself says: a `cents` suffix, or a currency symbol. Silence
    still means `major` to a consumer, which is exactly what silence meant before, so a claim
    without it is no worse off than it was.
    """
    if tok.currency_code:
        claim["currency_code"] = tok.currency_code
    if getattr(tok, "denomination", None):
        claim["denomination"] = tok.denomination
        if tok.denomination == "minor" and tok.value_parsed is not None:
            # Stated as well as derivable. Consumers that read `value_in_major_units` get the
            # right number without each re-deriving the conversion, and a reader of the ledger
            # can see the two figures side by side.
            claim["value_in_major_units"] = tok.value_in_major_units


#: A period label is a phrase, not a paragraph. Terminate on any structural or
#: sentence separator and cap the length: a pattern stopping only at '·' or '|' let a
#: header punctuated with '.' run to the end of the document, so 2,000 characters of
#: body text became every claim's period label and leaked into finding statements.
PERIOD_LABEL_RE = re.compile(r"Week ending[^·|.;:\n]{0,80}")



class Detectors:
    """Ordered record of every extraction pass attempted."""

    def __init__(self):
        self._rows = []

    def record(self, name, outcome, count=None, detail=None):
        row = {"name": name, "outcome": outcome}
        if count is not None:
            row["count"] = int(count)
        if detail:
            row["detail"] = detail
        self._rows.append(row)
        return row

    def found(self, name, count, detail=None):
        return self.record(name, "found" if count else "found_nothing",
                           count, detail)

    def rows(self):
        return self._rows


class LedgerBuilder:
    def __init__(self, path, src, doc):
        self.path = path
        self.src = src
        self.doc = doc
        self.claims = []
        self.tables = []
        self.prose_blocks = []
        self.det = Detectors()
        self._n = 0
        self._block_n = 0
        self._table_n = 0
        self.counters = {
            "unparseable": 0,
            "null_marker_cells": 0,
            "precision_indeterminable": 0,
            "unit_unknown": 0,
            "scale_inferred": 0,
            "bare_numbers_skipped_in_text_cells": 0,
            "dates_masked": 0,
            "row_length_mismatch": 0,
            "spelled_cardinals": 0,
            "prose_metric_label_unresolved": 0,
            "prose_metric_label_resolved": 0,
            "embedded_prose_numbers_in_cells": 0,
            "colspan_rowspan": 0,
            "numbers_inside_named_entities_skipped": 0,
        }
        self.ragged_rows = []        # per-row column-count integrity failures
        self.vocabulary = set()      # dimension member strings seen in tables
        self.metric_vocab = []       # metric label strings seen in the document
        self.default_period = None
        self.yoy_alignment_days = None
        self.yoy_alignment_source = None

    # -- ids ---------------------------------------------------------------
    def _cid(self):
        self._n += 1
        return f"c{self._n:04d}"

    # -- claim emission ----------------------------------------------------
    def add_claim(self, **kw):
        claim = {"claim_id": self._cid()}
        claim.update(kw)
        if claim.get("displayed_precision") is None:
            self.counters["precision_indeterminable"] += 1
        if claim.get("unit") == "unknown":
            self.counters["unit_unknown"] += 1
        if claim.get("scale_source") == "inferred_from_magnitude":
            self.counters["scale_inferred"] += 1
        self.claims.append(claim)
        return claim

    # ------------------------------------------------------------------
    # document level
    # ------------------------------------------------------------------
    def scan_document_context(self):
        body_text = text_with_map(self.doc.body())[0]

        title = self.doc.title()
        self.det.found("document_title", 1 if title else 0, _trim(title, 90))

        # A period label is a phrase, not a paragraph. Terminate on any structural
        # or sentence separator and cap the length: the old pattern stopped only at
        # '·' or '|', so a header punctuated with '.' ran to the end of the document
        # and put 2,000 characters of body text into every claim's period label.
        m = PERIOD_LABEL_RE.search(body_text)
        period_label = m.group(0).strip() if m else None
        m2 = re.search(r"week ending (\d{4}-\d{2}-\d{2})", body_text, re.I)
        end_date = m2.group(1) if m2 else None
        self.det.found("document_period_label", 1 if period_label else 0,
                       period_label)

        # Classify the kind from the LABEL's own words. A footnote defining
        # the measurement window is a separate statement about the same
        # period; recording it as this claim's kind would erase the
        # disagreement a period-integrity check needs to see, and would
        # flatten every claim in the document to one kind.
        foot = self._footnote_texts()
        kind, length_days = lex.kind_from_label(period_label)

        stated = None
        for t in foot:
            p = lex.period_from_text(t)
            if p and ("net demand" in t.lower() or "units" in t.lower()):
                stated = (p[0], t)
                break
        self.det.found(
            "document_period_definition", 1 if stated else 0,
            (f"footnote defines the measurement window as '{stated[0]}': "
             f"{_trim(stated[1], 160)}. Recorded here, NOT written over "
             f"period.kind — the header label says "
             f"'{period_label}', and whether the two agree is a check.")
            if stated else "no footnote defines the measurement window")

        start = None
        if end_date and length_days:
            try:
                from datetime import date, timedelta
                e = date.fromisoformat(end_date)
                start = (e - timedelta(days=length_days - 1)).isoformat()
            except ValueError:
                start = None

        self.default_period = {
            "label": period_label or (title or "unknown"),
            "kind": kind,
            "length_days": length_days,
            "start": start,
            "end": end_date,
        }

        # Year-over-year alignment, as declared by the document itself.
        for t in foot:
            m3 = re.search(r"(\d{2,4})\s+days\s+earlier", t, re.I)
            if m3:
                self.yoy_alignment_days = int(m3.group(1))
                self.yoy_alignment_source = _trim(t, 200)
                break
            m4 = re.search(r"(\d{1,2})\s+weeks\s+earlier", t, re.I)
            if m4:
                self.yoy_alignment_days = int(m4.group(1)) * 7
                self.yoy_alignment_source = _trim(t, 200)
                break
        self.det.found(
            "yoy_alignment_declaration",
            1 if self.yoy_alignment_days else 0,
            (f"declared {self.yoy_alignment_days} days: "
             f"{self.yoy_alignment_source}") if self.yoy_alignment_days
            else "no year-over-year alignment stated in any footnote")

        return title, period_label

    def _footnote_texts(self):
        out = []
        for f in self.doc.body().find_all("footer"):
            for li in f.find_all("li"):
                out.append(text_with_map(li)[0])
        return out

    def period_for(self, *texts, ly=False):
        p = None
        for t in texts:
            p = lex.period_from_text(t or "")
            if p:
                break
        if p:
            label, kind, length = p
            return {"label": label, "kind": kind, "length_days": length,
                    "start": None, "end": None}
        base = dict(self.default_period)
        if ly:
            base = {
                "label": base["label"] + " — prior year (LY)",
                "kind": base["kind"],
                "length_days": base["length_days"],
                "start": None, "end": None,
            }
        return base

    # ------------------------------------------------------------------
    # walk
    # ------------------------------------------------------------------
    def _prepass_vocabulary(self):
        for table in self.doc.body().find_all("table"):
            headers = self._headers(table)
            self.metric_vocab.extend(h for h in headers if h)
            for tr in table.find_all("tr"):
                cells = [c for c in tr.child_elements("td", "th")]
                for j, c in enumerate(cells):
                    txt = text_with_map(c)[0]
                    if not txt or np.is_null_marker(txt):
                        continue
                    if not self._numeric_dominant(txt) and len(txt) <= 90:
                        if not any(ch.isdigit() for ch in txt) or j == 0:
                            self.vocabulary.add(txt)
        for tile in self.doc.body().find_by_class("tile"):
            for lab in tile.find_by_class("lab"):
                self.metric_vocab.append(text_with_map(lab)[0])
        self.metric_vocab = [m for m in dict.fromkeys(self.metric_vocab) if m]

    def _is_block(self, el):
        if el.tag in ("table", "p", "li", "caption") or el.tag in HEADING_TAGS:
            return True
        if el.tag == "div" and "tile" in el.classes:
            return True
        if el.tag == "div":
            kids = [c for c in el.children if c.kind == "element"]
            if kids and all(k.tag in INLINE_TAGS for k in kids):
                return True
            if not kids and text_with_map(el)[0]:
                return True
        return False

    def _walk(self, el, section):
        for child in el.children:
            if child.kind != "element":
                continue
            if child.tag in HEADING_TAGS:
                txt = text_with_map(child)[0]
                if child.tag == "h2":
                    section = txt
                self._handle_heading(child, section)
                continue
            if child.tag == "table":
                self._handle_table(child, section)
                continue
            if child.tag == "div" and "tile" in child.classes:
                self._handle_tile(child, section)
                continue
            if self._is_block(child):
                kind = "footnote" if self._in_footer(child) else "prose"
                self._handle_prose(child, section, kind)
                continue
            self._walk(child, section)

    @staticmethod
    def _in_footer(el):
        n = el.parent
        while n is not None:
            if getattr(n, "tag", None) == "footer":
                return True
            n = n.parent
        return False

    # ------------------------------------------------------------------
    # headings
    # ------------------------------------------------------------------
    def _handle_heading(self, el, section):
        text, offs = text_with_map(el)
        for tok in np.iter_numbers(text):
            self._emit_text_claim(tok, text, offs, el, section,
                                  location_kind="heading", sentence=text)

    # ------------------------------------------------------------------
    # tables
    # ------------------------------------------------------------------
    def _headers(self, table):
        head = table.find("thead")
        rows = (head.find_all("tr") if head else table.find_all("tr"))
        if not rows:
            return []
        hdr_row = None
        for tr in rows:
            if tr.child_elements("th"):
                hdr_row = tr
                break
        if hdr_row is None:
            return []
        return [text_with_map(c)[0] for c in hdr_row.child_elements("th", "td")]

    def _handle_table(self, table, section):
        self._table_n += 1
        tid = table.attrs.get("id") or f"table-{self._table_n:02d}"
        cap_el = table.find("caption")
        caption = text_with_map(cap_el)[0] if cap_el is not None else ""
        headers = self._headers(table)
        inferred_header = not bool(table.find("thead"))

        declared_sort, declared_scope, declared_scale = lex.parse_caption(caption)
        cap_scale, _ = lex.scale_from_label(caption)

        # Column-level scale declarations beat the caption.
        col_scale = []
        for h in headers:
            s, verbatim = lex.scale_from_label(h)
            if s:
                col_scale.append((s, "column_header", verbatim))
            elif cap_scale:
                col_scale.append((cap_scale, "table_caption", declared_scale))
            else:
                col_scale.append((None, None, None))
        if declared_scale is None:
            for s, src, verbatim in col_scale:
                if src == "column_header" and verbatim:
                    declared_scale = verbatim
                    break

        body_rows = []
        head = table.find("thead")
        for tr in table.find_all("tr"):
            if head is not None and self._within(tr, head):
                continue
            body_rows.append(tr)

        # colspan / rowspan would break index-based column alignment.
        for tr in body_rows:
            for c in tr.child_elements("td", "th"):
                if c.attrs.get("colspan") or c.attrs.get("rowspan"):
                    self.counters["colspan_rowspan"] += 1

        rec = {
            "table_id": tid,
            "caption": caption,
            "section": section or "",
            "column_labels": headers,
            "row_count": len(body_rows),
            "declared_sort": declared_sort,
            "declared_scope": declared_scope,
            "declared_scale": declared_scale,
        }
        self.tables.append(rec)

        if caption:
            self._handle_prose(cap_el, section, "prose", table_id=tid)

        # column index -> {row_kind: [claim_id]}
        footing = {}
        # (row_index, column_index) -> claim_id, numeric cells only
        grid = {}
        row_kinds = {}

        for i, tr in enumerate(body_rows):
            cells = tr.child_elements("td", "th")
            if headers and len(cells) != len(headers):
                # A quietly truncated or padded row misaligns every column to
                # its right, which makes footing checks fail in a way that
                # looks exactly like a real defect. Never silent.
                self.counters["row_length_mismatch"] += 1
                self.ragged_rows.append(
                    f"{tid} row {i} ({'/'.join(tr.classes) or 'body'}): "
                    f"{len(cells)} cells vs {len(headers)} header columns")
            row_kind = self._row_kind(tr, table)
            row_kinds[i] = row_kind
            cell_texts = [text_with_map(c)[0] for c in cells]
            row_label = cell_texts[0] if cell_texts else None

            entity = {}
            for j, txt in enumerate(cell_texts):
                if np.is_null_marker(txt) or self._numeric_dominant(txt):
                    continue
                label = headers[j] if j < len(headers) else f"col{j + 1}"
                if txt and len(txt) <= 120:
                    entity[label] = txt

            for j, cell in enumerate(cells):
                text, offs = text_with_map(cell)
                label = headers[j] if j < len(headers) else None
                scale, scale_src, _ = (col_scale[j] if j < len(col_scale)
                                       else (None, None, None))
                unit_hint = lex.unit_from_label(label)
                ids = self._emit_cell(
                    cell, text, offs, tid, section, row_label, label,
                    i, j, row_kind, entity, scale, scale_src, unit_hint,
                    inferred_header, len(cells) != len(headers) if headers
                    else False, caption)
                if ids:
                    grid[(i, j)] = ids[0]
                if ids and lex.column_foots(label):
                    footing.setdefault(j, {}).setdefault(row_kind, []).extend(ids)

        self._link_footings(footing)
        self._link_derivations(headers, grid, row_kinds)

    @staticmethod
    def _within(node, ancestor):
        n = node.parent
        while n is not None:
            if n is ancestor:
                return True
            n = n.parent
        return False

    def _row_kind(self, tr, table):
        cls = set(tr.classes)
        if "total" in cls:
            return "total"
        if "subtotal" in cls:
            return "subtotal"
        if "tail" in cls:
            return "tail"
        foot = table.find("tfoot")
        if foot is not None and self._within(tr, foot):
            return "total"
        return "component"

    @staticmethod
    def _numeric_dominant(text):
        if not text.strip():
            return False
        masked, _ = np.mask_calendar(text)
        residue = np.NUM_RE.sub(" ", masked)
        residue = re.sub(
            r"\b(pts?|points?|percent|percentage|bps|units?|milliseconds?|"
            r"seconds?|minutes?|hours?|days?|weeks?|months?|years?|"
            r"each|per)\b", " ", residue, flags=re.IGNORECASE)
        residue = re.sub(r"[\s %$£€+\-−–(),.:;—–\x00]",
                         "", residue)
        return residue == ""

    def _emit_cell(self, cell, text, offs, tid, section, row_label, col_label,
                   ri, ci, row_kind, entity, scale, scale_src, unit_hint,
                   inferred_header, ragged, caption):
        loc_base = {
            "kind": "table_cell",
            "section": section,
            "table_id": tid,
            "row_label": row_label,
            "column_label": col_label,
            "row_index": ri,
            "column_index": ci,
            "dom_selector": css_path(cell),
        }
        basis = ("structured_cell_inferred_header" if (inferred_header or
                 col_label is None) else "structured_cell")
        level = "high"
        notes = []
        if ragged:
            level = "medium"
            notes.append("row cell count differs from the header row; "
                         "column alignment is uncertain")
        cls = set(cell.classes)
        if "up" in cls or "dn" in cls:
            notes.append(f"rendered with CSS class '{'up' if 'up' in cls else 'dn'}' "
                         f"(directional styling)")

        is_ly = bool(col_label and re.search(r"\bLY\b|last year", col_label,
                                             re.IGNORECASE))
        period = self.period_for(col_label, caption, ly=is_ly)

        # --- explicit null marker ----------------------------------------
        if np.is_null_marker(text):
            self.counters["null_marker_cells"] += 1
            loc = dict(loc_base)
            loc["char_span"] = self._span(offs, 0, max(len(text), 1))
            self.add_claim(
                value_displayed=text or "",
                value_parsed=None,
                displayed_precision=None,
                rounding_envelope=None,
                unit=unit_hint or "unknown",
                scale="unknown",
                scale_source="absent",
                metric_label=col_label or "",
                entity=dict(entity),
                period=period,
                location=loc,
                role=lex.column_role(col_label, row_kind),
                polarity=lex.polarity_for(col_label, row_label,
                                          *entity.values()),
                confidence={"level": "high", "basis": basis,
                            "notes": "; ".join(
                                notes + ["explicit null marker rendered in the "
                                         "cell; not a missing value and not "
                                         "zero"])},
            )
            return []  # nulls never participate in a footing

        dominant = self._numeric_dominant(text)
        toks = list(np.iter_numbers(text, header_scale=scale,
                                    header_scale_source=scale_src,
                                    header_unit=unit_hint,
                                    require_marker=not dominant))
        if not dominant:
            protected = self._protected_spans(text)
            if protected:
                keep = [t for t in toks if not self._in_spans(t, protected)]
                self.counters["numbers_inside_named_entities_skipped"] += \
                    len(toks) - len(keep)
                toks = keep
            skipped = sum(1 for _ in np.iter_numbers(text, require_marker=False))
            self.counters["bare_numbers_skipped_in_text_cells"] += max(
                0, skipped - len(toks))
            self.counters["embedded_prose_numbers_in_cells"] += len(toks)

        if not toks:
            if dominant and text.strip():
                # Numeric-looking but nothing parsed: an honest failure.
                self.counters["unparseable"] += 1
                loc = dict(loc_base)
                loc["char_span"] = self._span(offs, 0, len(text))
                self.add_claim(
                    value_displayed=text,
                    value_parsed=None,
                    displayed_precision=None,
                    rounding_envelope=None,
                    unit="unknown", scale="unknown", scale_source="absent",
                    metric_label=col_label or "",
                    entity=dict(entity), period=period, location=loc,
                    role=lex.column_role(col_label, row_kind),
                    confidence={"level": "low", "basis": basis,
                                "notes": "cell looked numeric but no numeric "
                                         "literal could be parsed"},
                )
            return []

        ids = []
        sentence = text if not dominant else None
        for tok in toks:
            loc = dict(loc_base)
            loc["char_span"] = self._span(offs, tok.start, tok.end)
            if sentence:
                loc["sentence"] = self._sentence_around(text, tok.start)
            role = lex.column_role(col_label, row_kind)
            if not dominant:
                role = "standalone"
            comparison = self._comparison_for(col_label, tok,
                                              loc.get("sentence"))
            claim = self.add_claim(
                value_displayed=tok.value_displayed,
                value_parsed=tok.value_parsed,
                displayed_precision=tok.displayed_precision,
                rounding_envelope=tok.rounding_envelope,
                unit=tok.unit,
                scale=tok.scale,
                scale_source=tok.scale_source,
                metric_label=col_label or "",
                entity=dict(entity),
                period=period,
                location=loc,
                role=role,
                polarity=lex.polarity_for(col_label, row_label,
                                          *entity.values()),
                confidence={"level": level, "basis": basis,
                            "notes": "; ".join(notes + tok.notes)},
            )
            _carry_currency(claim, tok)
            if comparison:
                claim["comparison"] = comparison
            if loc.get("sentence"):
                dws = lex.direction_words(loc["sentence"])
                sups = lex.superlatives(loc["sentence"])
                if dws:
                    claim["direction_words"] = dws
                if sups:
                    claim["superlatives"] = sups
            if dominant:
                ids.append(claim["claim_id"])
        return ids

    def _comparison_for(self, col_label, tok, sentence=None):
        label = col_label or ""
        text = (sentence or "")
        yoy = bool(re.search(r"\byoy\b|\bmove\b|year over year|"
                             r"against last year|vs\.? last year|"
                             r"versus last year|last year", label + " " + text,
                             re.IGNORECASE))
        if not yoy:
            return None
        if tok.unit == "points":
            form = "point_change"
        elif tok.unit == "percent":
            form = "percent_change"
        elif tok.unit == "currency" or tok.unit == "units":
            form = "absolute_delta"
        else:
            return None
        if tok.value_parsed is not None and tok.value_displayed and \
                not re.match(r"^[+\-−–(]", tok.value_displayed) and \
                form == "absolute_delta":
            # An unsigned currency figure beside "last year" is the base value,
            # not a delta.
            return None
        comp = {"base": "last_year",
                "base_label": _trim(label or "last year", 80),
                "form": form,
                # Explicitly null rather than absent: "we looked and the base
                # is not itself a claim here" is information.
                "base_claim_id": None}
        if self.yoy_alignment_days is not None:
            comp["alignment_days"] = self.yoy_alignment_days
        return comp

    # ------------------------------------------------------------------
    # derivations: comparison.base_claim_id and derived_from
    # ------------------------------------------------------------------
    def _link_derivations(self, headers, grid, row_kinds):
        """Wire in-document arithmetic relations, where the document makes
        them genuinely derivable.

        Only three shapes are claimed here, because only three are safe to
        read off this document's structure without speculating:

        * a **YoY** column beside a TY/LY pair -> ``percent_change`` of the
          two, and the LY cell becomes the delta's ``base_claim_id``;
        * a **Share** column -> ``share_of`` the row's primary measure over
          the total row's primary measure;
        * a **total or subtotal** that already carries ``aggregates_claims``
          -> ``sum`` of the same operands.

        A ``GM move`` column gets no ``derived_from``: the table prints
        ``GM % TY`` but no ``GM % LY``, so the second operand is not a claim
        in this document. Inventing one would make a check assert an
        arithmetic relation the author never wrote, which is worse than
        leaving the field empty.
        """
        by_id = {c["claim_id"]: c for c in self.claims}
        if not headers:
            return

        def col_matching(pattern):
            for j, h in enumerate(headers):
                if re.search(pattern, h or "", re.IGNORECASE):
                    return j
            return None

        ty_col = ly_col = None
        for j, h in enumerate(headers):
            if re.search(r"\bTY\b", h or ""):
                stem = re.sub(r"\bTY\b", "", h).strip()
                for k, h2 in enumerate(headers):
                    if re.search(r"\bLY\b", h2 or "") and \
                            re.sub(r"\bLY\b", "", h2).strip() == stem:
                        ty_col, ly_col = j, k
                        break
            if ty_col is not None:
                break
        if ty_col is None:
            # No TY/LY suffixes: fall back to the first footing measure column.
            for j, h in enumerate(headers):
                if j == 0 or not lex.column_foots(h):
                    continue
                if lex.unit_from_label(h) in ("currency", "units"):
                    ty_col = j
                    break

        yoy_col = col_matching(r"\byoy\b")
        share_col = col_matching(r"\bshare\b")
        share_header = headers[share_col] if share_col is not None else ""
        # "Share of NHL" names its whole; a bare "Share" does not.
        share_asserted = ("document_structure"
                          if re.search(r"\bshare\s+of\b", share_header,
                                       re.IGNORECASE)
                          else "inferred")

        total_row = next((i for i, k in row_kinds.items() if k == "total"),
                         None)

        for i in row_kinds:
            # --- YoY percent change of the adjacent absolutes -------------
            if yoy_col is not None and ty_col is not None and ly_col is not None:
                d = grid.get((i, yoy_col))
                ty = grid.get((i, ty_col))
                ly = grid.get((i, ly_col))
                if d and ty and ly and by_id[d].get("unit") == "percent":
                    claim = by_id[d]
                    claim["derived_from"] = {
                        "operation": "percent_change",
                        "operands": [ty, ly],
                        "asserted_by": "document_structure",
                    }
                    comp = claim.get("comparison")
                    if comp:
                        comp["base_claim_id"] = ly

            # --- Share of the table total ---------------------------------
            if share_col is not None and ty_col is not None and \
                    total_row is not None and i != total_row:
                s = grid.get((i, share_col))
                part = grid.get((i, ty_col))
                whole = grid.get((total_row, ty_col))
                if s and part and whole and by_id[s].get("unit") == "percent":
                    by_id[s]["derived_from"] = {
                        "operation": "share_of",
                        "operands": [part, whole],
                        "asserted_by": share_asserted,
                    }

        # --- totals and subtotals restate their footing -------------------
        for claim in self.claims:
            agg = claim.get("aggregates_claims")
            if agg and not claim.get("derived_from"):
                claim["derived_from"] = {
                    "operation": "sum",
                    "operands": list(agg),
                    "asserted_by": "document_structure",
                }

    def _link_footings(self, footing):
        by_id = {c["claim_id"]: c for c in self.claims}
        for _, kinds in footing.items():
            comps = kinds.get("component", [])
            subs = kinds.get("subtotal", [])
            tails = kinds.get("tail", [])
            totals = kinds.get("total", [])
            for sid in subs:
                if comps:
                    by_id[sid]["aggregates_claims"] = list(comps)
            for tid_ in totals:
                parts = (subs + tails) if subs else (comps + tails)
                if parts:
                    by_id[tid_]["aggregates_claims"] = list(parts)

    # ------------------------------------------------------------------
    # KPI tiles
    # ------------------------------------------------------------------
    def _handle_tile(self, tile, section):
        labs = tile.find_by_class("lab")
        vals = tile.find_by_class("val")
        cmps = tile.find_by_class("cmp")
        label = text_with_map(labs[0])[0] if labs else ""
        tile_value = None      # the tile's headline figure
        tile_base = None       # the last-year figure printed beside it
        tile_deltas = []       # signed movements printed beside it

        for val in vals:
            text, offs = text_with_map(val)
            toks = list(np.iter_numbers(text, header_unit=lex.unit_from_label(label)))
            if not toks:
                if text.strip() and not np.is_null_marker(text):
                    self.counters["unparseable"] += 1
                continue
            for tok in toks:
                loc = {"kind": "kpi_tile", "section": section,
                       "row_label": label, "column_label": None,
                       "char_span": self._span(offs, tok.start, tok.end),
                       "dom_selector": css_path(val)}
                claim = self.add_claim(
                    value_displayed=tok.value_displayed,
                    value_parsed=tok.value_parsed,
                    displayed_precision=tok.displayed_precision,
                    rounding_envelope=tok.rounding_envelope,
                    unit=tok.unit, scale=tok.scale,
                    scale_source=tok.scale_source,
                    metric_label=label,
                    entity={},
                    period=self.period_for(label),
                    location=loc,
                    role="rate" if tok.unit in ("percent", "points")
                         else "standalone",
                    polarity=lex.polarity_for(label),
                    confidence={"level": "high", "basis": "structured_cell",
                                "notes": "; ".join(
                                    ["KPI tile value with an adjacent label "
                                     "element"] + tok.notes)},
                )
                _carry_currency(claim, tok)
                if tile_value is None:
                    tile_value = claim

        for cmp_el in cmps:
            text, offs = text_with_map(cmp_el)
            ly = bool(re.search(r"last year", text, re.IGNORECASE))
            for tok in np.iter_numbers(text,
                                       header_unit=lex.unit_from_label(label)):
                signed = bool(re.match(r"^[+\-−–(]",
                                       tok.value_displayed))
                is_delta = signed and tok.unit in ("percent", "points",
                                                   "currency", "units")
                loc = {"kind": "kpi_tile", "section": section,
                       "row_label": label, "column_label": None,
                       "sentence": text,
                       "char_span": self._span(offs, tok.start, tok.end),
                       "dom_selector": css_path(cmp_el)}
                claim = self.add_claim(
                    value_displayed=tok.value_displayed,
                    value_parsed=tok.value_parsed,
                    displayed_precision=tok.displayed_precision,
                    rounding_envelope=tok.rounding_envelope,
                    unit=tok.unit, scale=tok.scale,
                    scale_source=tok.scale_source,
                    metric_label=label,
                    entity={},
                    period=self.period_for(label, text,
                                           ly=ly and not is_delta),
                    location=loc,
                    role="delta" if is_delta else "standalone",
                    polarity=lex.polarity_for(label),
                    confidence={"level": "high", "basis": "structured_cell",
                                "notes": "; ".join(
                                    ["KPI tile comparison line"] + tok.notes)},
                )
                _carry_currency(claim, tok)
                if is_delta and ly:
                    comp = {"base": "last_year", "base_label": _trim(text, 80),
                            "form": ("point_change" if tok.unit == "points"
                                     else "percent_change" if tok.unit == "percent"
                                     else "absolute_delta"),
                            "base_claim_id": None}
                    if self.yoy_alignment_days is not None:
                        comp["alignment_days"] = self.yoy_alignment_days
                    claim["comparison"] = comp
                dws = lex.direction_words(text)
                if dws:
                    claim["direction_words"] = dws
                if is_delta:
                    tile_deltas.append(claim)
                elif ly and tile_base is None:
                    tile_base = claim

        self._link_tile(tile_value, tile_base, tile_deltas)

    @staticmethod
    def _link_tile(value, base, deltas):
        """A tile prints value, last-year base and movement side by side, so
        the pairing is structural rather than guessed."""
        if value is None or base is None:
            return
        for d in deltas:
            comp = d.get("comparison")
            if comp:
                comp["base_claim_id"] = base["claim_id"]
            if d["unit"] == "percent" and value["unit"] == base["unit"]:
                op = "percent_change"
            elif d["unit"] == "points" and value["unit"] == base["unit"] == "percent":
                op = "point_change"
            else:
                continue
            d["derived_from"] = {
                "operation": op,
                "operands": [value["claim_id"], base["claim_id"]],
                "asserted_by": "document_structure",
            }

    # ------------------------------------------------------------------
    # prose
    # ------------------------------------------------------------------
    def _handle_prose(self, el, section, kind, table_id=None):
        text, offs = text_with_map(el)
        if not text.strip():
            return
        self._block_n += 1
        block_id = f"b{self._block_n:04d}"
        sents = lex.sentences(text)
        sent_spans = []
        cursor = 0
        for s in sents:
            i = text.find(s, cursor)
            if i < 0:
                i = cursor
            sent_spans.append((i, i + len(s), s))
            cursor = i + len(s)

        claim_ids = []
        toks = list(np.iter_numbers(text)) + list(np.iter_spelled(text))
        toks.sort(key=lambda t: t.start)
        protected = self._protected_spans(text)
        if protected:
            keep = [t for t in toks if not self._in_spans(t, protected)]
            self.counters["numbers_inside_named_entities_skipped"] += \
                len(toks) - len(keep)
            toks = keep
        # Drop spelled cardinals that overlap a digit literal.
        filtered = []
        for t in toks:
            if any(o is not t and not (t.end <= o.start or t.start >= o.end)
                   and not o.spelled for o in toks):
                continue
            filtered.append(t)
        for tok in filtered:
            if tok.spelled:
                self.counters["spelled_cardinals"] += 1
            sent = self._sentence_from_spans(sent_spans, tok.start, text)
            c = self._emit_text_claim(tok, text, offs, el, section,
                                      location_kind=kind, sentence=sent,
                                      table_id=table_id)
            claim_ids.append(c["claim_id"])

        self._link_prose_comparison(claim_ids)

        block = {
            "block_id": block_id,
            "section": section or "",
            "text": text,
            "claim_ids": claim_ids,
            "named_entities": lex.named_entities(text, self.vocabulary),
            "causal_markers": lex.causal_markers(text),
            "forward_looking": lex.forward_looking(text),
        }
        self.prose_blocks.append(block)

    def _link_prose_comparison(self, claim_ids):
        """Prose comparison-base resolution: attempted, measured, removed.

        The rule tried was the explicit "A against B" shape inside one
        sentence, with both sides the same unit and a percent delta present.
        Scored on this document it was **0 true positives, 1 false
        positive**:

            "Womens is the weakest on margin at 47.3%, down 1.1 points, and
             it carries $10.5M of on-hand retail against $85,290 of weekly
             demand"

        The rule paired 47.3% — a margin — as a percent change of $10.5M
        over $85,290, a relation the author never wrote. The one true target
        in the document ("$515,481 against $539,519 a year ago … or 4.5%")
        carries three currency figures, not two, so the rule missed it.

        Deciding that 47.3% is a margin rather than a movement needs the
        stage-3 metric layer, which does not exist yet. Until it does, prose
        bases stay null: a wrong base makes a check assert arithmetic nobody
        claimed, which is worse than a missing one.

        Table and KPI-tile bases are unaffected — those pairings are
        structural, not guessed, and are resolved in ``_link_derivations``
        and ``_link_tile``.
        """
        return

    def _protected_spans(self, text):
        """Character spans occupied by a dimension member the document itself
        names, so digits inside a *name* are never claimed as measurements.

        "47 Brand" and "'47" are vendor and brand names. Read as a number,
        the 47 becomes a phantom claim that a movement check will happily
        marry to the nearest dollar figure — producing, in one observed case,
        "moving from 47 to $35,811 is 76,093.62%". The name is in the
        document's own vocabulary, so this is cheap to prevent.
        """
        spans = []
        for member in self.vocabulary:
            if len(member) < 4 or not any(ch.isalpha() for ch in member):
                continue
            if not any(ch.isdigit() for ch in member):
                continue      # only names containing digits can cause this
            start = 0
            while True:
                i = text.find(member, start)
                if i < 0:
                    break
                spans.append((i, i + len(member)))
                start = i + 1
        return spans

    @staticmethod
    def _in_spans(tok, spans):
        return any(tok.start < b and tok.end > a for a, b in spans)

    @staticmethod
    def _sentence_from_spans(spans, idx, text):
        for a, b, s in spans:
            if a <= idx < b:
                return s
        return text

    @staticmethod
    def _sentence_around(text, idx):
        sents = lex.sentences(text)
        cursor = 0
        for s in sents:
            i = text.find(s, cursor)
            if i < 0:
                i = cursor
            if i <= idx < i + len(s):
                return s
            cursor = i + len(s)
        return text

    def _emit_text_claim(self, tok, text, offs, el, section,
                         location_kind, sentence, table_id=None):
        sentence = sentence or text
        metric_label = self._metric_near(text, tok.start)
        if metric_label:
            self.counters["prose_metric_label_resolved"] += 1
        else:
            self.counters["prose_metric_label_unresolved"] += 1
        entity = self._entity_in(sentence)
        unit = tok.unit
        if unit == "unknown":
            unit = self._unit_from_following_noun(text, tok.end) or "unknown"
        if unit == "unknown" and metric_label:
            # "vendors: 16" — the label before the figure names what it counts.
            unit = lex.unit_from_label(metric_label) or "unknown"
        loc = {
            "kind": location_kind,
            "section": section,
            "sentence": sentence,
            "char_span": self._span(offs, tok.start, tok.end),
            "dom_selector": css_path(el),
        }
        if table_id:
            loc["table_id"] = table_id
        role = "standalone"
        if unit in ("percent", "points") and (
                re.match(r"^[+\-−–(]", tok.value_displayed)
                or lex.direction_words(sentence)):
            role = "delta"
        elif unit == "count":
            role = "count"
        comparison = self._comparison_for(None, tok, sentence) \
            if role == "delta" else None
        ly = bool(re.search(r"last year|a year ago|year over year", sentence,
                            re.IGNORECASE))
        claim = self.add_claim(
            value_displayed=tok.value_displayed,
            value_parsed=tok.value_parsed,
            displayed_precision=tok.displayed_precision,
            rounding_envelope=tok.rounding_envelope,
            unit=unit,
            scale=tok.scale,
            scale_source=tok.scale_source,
            metric_label=metric_label or "",
            entity=entity,
            period=self.period_for(sentence, ly=ly and role != "delta"),
            location=loc,
            role=role,
            polarity=lex.polarity_for(metric_label, sentence[:120]),
            confidence={
                "level": "low" if tok.spelled else "medium",
                "basis": "prose_parsed",
                "notes": "; ".join(
                    tok.notes + ([] if metric_label else
                                 ["no metric label resolved from the "
                                  "document's own vocabulary"]))},
        )
        _carry_currency(claim, tok)
        if comparison:
            claim["comparison"] = comparison
        dws = lex.direction_words(sentence)
        sups = lex.superlatives(sentence)
        if dws:
            claim["direction_words"] = dws
        if sups:
            claim["superlatives"] = sups
        filters = self._filters_in(sentence)
        if filters:
            claim["filters_stated"] = filters
        return claim

    _FOLLOWING_NOUN = {
        "teams": "count", "team": "count", "classes": "count",
        "class": "count", "vendors": "count", "vendor": "count",
        "brands": "count", "brand": "count", "styles": "count",
        "style": "count", "types": "count", "type": "count",
        "leagues": "count", "league": "count", "departments": "count",
        "items": "count", "units": "units", "days": "days", "day": "days",
        "weeks": "weeks", "week": "weeks", "cents": "currency",
    }

    def _unit_from_following_noun(self, text, end):
        """Unit implied by the noun the number quantifies.

        Scans the next three words, so "5 of 26 vendors" and "8 assortment
        types" both resolve. Only consulted when nothing in the literal itself
        declared a unit.
        """
        window = re.match(r"((?:\s+[A-Za-z][A-Za-z\-]*|\s+[\d,]+){1,3})",
                          text[end:end + 40])
        if not window:
            return None
        words = re.findall(r"[A-Za-z\-]+", window.group(1))
        for word in words:
            hit = self._FOLLOWING_NOUN.get(word.lower())
            if hit:
                return hit
        # Generic count fallback, immediate word only: "44 breaches",
        # "12 flags". Long plural nouns name the thing being counted; the
        # blacklist keeps money words and s-ending function words out.
        if words:
            first = words[0].lower()
            if (len(first) >= 5 and first.endswith("s")
                    and first not in lex.NOT_COUNT_LAST_WORDS
                    and first not in self._NOT_COUNT_FOLLOWERS):
                return "count"
        return None

    _NOT_COUNT_FOLLOWERS = frozenset(
        {"across", "times", "various", "versus", "plus", "minus", "means",
         "shows", "stays", "trades", "as", "is", "was", "has", "does"}
    )

    def _metric_near(self, text, idx):
        window_start = max(0, idx - 70)
        before = text[window_start:idx]
        after = text[idx:idx + 45]
        best = None
        for label in sorted(self.metric_vocab, key=len, reverse=True):
            lab = label.strip()
            if len(lab) < 3 or lab in ("#", "Where", "Size", "Action",
                                       "Owner", "Signal", "Team", "Style"):
                continue
            for hay in (before, after):
                pos = hay.lower().rfind(lab.lower())
                if pos >= 0:
                    verbatim = hay[pos:pos + len(lab)]
                    if best is None or len(verbatim) > len(best):
                        best = verbatim
        if best:
            return best
        for word in ("gross margin", "net demand", "demand", "margin",
                     "sell-through", "on-hand retail", "on hand", "on order",
                     "units", "share", "inventory", "average unit retail"):
            pos = before.lower().rfind(word)
            if pos >= 0:
                return before[pos:pos + len(word)]
        return None

    def _entity_in(self, sentence):
        hits = {}
        for member in sorted(self.vocabulary, key=len, reverse=True):
            if len(member) < 4:
                continue
            if member in sentence:
                if any(member in v for v in hits.values()):
                    continue
                hits[self._dimension_of(member)] = member
                if len(hits) >= 3:
                    break
        return hits

    def _dimension_of(self, member):
        for t in self.tables:
            cols = t.get("column_labels") or []
            if not cols:
                continue
            return_dim = cols[0]
            for r in self.claims:
                loc = r.get("location", {})
                if loc.get("table_id") == t["table_id"] and \
                        loc.get("row_label") == member:
                    return return_dim
        return "member"

    _FILTER_RE = re.compile(
        r"\b(1P only|3P only|owned only|in-house|warehouse only|"
        r"excluding [a-z\- ]+|drop-ship|third[- ]party|first party|"
        r"net of [a-z\- ]+)\b", re.IGNORECASE)

    def _filters_in(self, sentence):
        out = []
        for m in self._FILTER_RE.finditer(sentence):
            out.append({"text": m.group(0), "kind": "unknown"})
        return out[:4]

    # ------------------------------------------------------------------
    @staticmethod
    def _span(offs, start, end):
        if not offs:
            return None
        start = max(0, min(start, len(offs) - 1))
        end = max(start + 1, min(end, len(offs)))
        a = offs[start]
        b = offs[end - 1] + 1
        return [int(a), int(b)]

    # ------------------------------------------------------------------
    def _finalise_detectors(self):
        c = self.counters
        d = self.det
        d.found("html_tables", len(self.tables))
        d.found("table_cell_numeric_values",
                sum(1 for x in self.claims
                    if x["location"]["kind"] == "table_cell"))
        d.found("kpi_tiles",
                len(self.doc.body().find_by_class("tile")),
                "each tile contributes a value claim plus any comparison-line "
                "claims")
        d.found("prose_blocks", len(self.prose_blocks))
        d.found("table_captions",
                sum(1 for t in self.tables if t.get("caption")))
        d.found("declared_sort_captions",
                sum(1 for t in self.tables if t.get("declared_sort")))
        d.found("declared_scope_captions",
                sum(1 for t in self.tables if t.get("declared_scope")))
        d.found("declared_scale_declarations",
                sum(1 for t in self.tables if t.get("declared_scale")))
        d.found("footnotes",
                sum(1 for x in self.claims
                    if x["location"]["kind"] == "footnote"))
        d.found("headings_with_numbers",
                sum(1 for x in self.claims
                    if x["location"]["kind"] == "heading"))
        d.found("em_dash_null_cells", c["null_marker_cells"],
                "cells rendering an explicit null marker; emitted as claims "
                "with value_parsed=null, not counted as unparseable")
        d.found("spelled_out_cardinals", c["spelled_cardinals"],
                "words such as 'sixty-two' parsed to numeric claims at low "
                "confidence")
        d.found("prose_numbers_inside_table_cells",
                c["embedded_prose_numbers_in_cells"],
                "numbers inside narrative table cells; extracted only when "
                "they carry a currency symbol, percent sign, unit or "
                "magnitude suffix")
        d.found("numbers_inside_named_entities_skipped",
                c["numbers_inside_named_entities_skipped"],
                "digits inside a dimension member the document itself names "
                "(e.g. the 47 in '47 Brand'); a name, not a measurement")
        d.found("bare_integers_skipped_in_text_cells",
                c["bare_numbers_skipped_in_text_cells"],
                "unmarked integers inside text cells (e.g. '26' in a style "
                "name); deliberately not claimed")
        d.found("calendar_literals_masked", c["dates_masked"],
                "dates, times and bare years excluded from number scanning")
        # Column-count integrity. A silently truncated table misaligns every
        # column to its right and every footing check then fails in a way
        # that looks like a real defect. Assert per row, and name the rows.
        d.record("table_column_count_integrity",
                 "found" if c["row_length_mismatch"] else "found_nothing",
                 c["row_length_mismatch"],
                 ("; ".join(self.ragged_rows[:20]) if self.ragged_rows else
                  f"every body row in all {len(self.tables)} tables has "
                  f"exactly as many cells as its header row"))
        d.found("table_derivations_linked",
                sum(1 for x in self.claims if x.get("derived_from")),
                "claims carrying a derived_from relation read off the "
                "document's own structure")
        comps = [x for x in self.claims if x.get("comparison")]
        resolved = [x for x in comps if x["comparison"].get("base_claim_id")]
        unresolved = [x for x in comps
                      if not x["comparison"].get("base_claim_id")]
        no_prior = [x for x in unresolved
                    if x["location"]["kind"] in ("table_cell", "kpi_tile")]
        prose_left = len(unresolved) - len(no_prior)
        d.found("comparison_base_resolved", len(resolved),
                f"{len(resolved)} of {len(comps)} comparisons carry a base. "
                f"That is 100% of the structurally resolvable set: every "
                f"table comparison whose prior-year absolute is printed in "
                f"the document is linked. The {len(no_prior)} unlinked "
                f"table/tile comparisons have no prior-year value anywhere "
                f"in the document to point at — 'GM move' columns (the "
                f"tables print GM % TY but never GM % LY) and the YoY "
                f"columns of tbl-assortment and tbl-brands (which print a "
                f"movement with no prior-year absolute beside it). "
                f"{prose_left} prose deltas are left null deliberately; see "
                f"LedgerBuilder._link_prose_comparison.")
        d.record("colspan_rowspan_cells",
                 "found" if c["colspan_rowspan"] else "found_nothing",
                 c["colspan_rowspan"],
                 "spanning cells would break index-based column alignment")
        # Honest negatives: passes that ran and found nothing.
        imgs = len(self.doc.body().find_all("img"))
        svgs = len(self.doc.body().find_all("svg"))
        canvases = len(self.doc.body().find_all("canvas"))
        d.record("chart_images_img",
                 "found" if imgs else "found_nothing", imgs,
                 "no raster chart images in the document" if not imgs else None)
        d.record("chart_vector_svg",
                 "found" if svgs else "found_nothing", svgs,
                 "no inline SVG charts in the document" if not svgs else None)
        d.record("chart_canvas",
                 "found" if canvases else "found_nothing", canvases,
                 "no canvas charts in the document" if not canvases else None)
        cells = len(self.doc.body().find_all("cell"))
        d.record("sdoc_cell_traceability",
                 "found" if cells else "found_nothing", cells,
                 "no <cell/> traceability tags; this HTML carries no source "
                 "lineage, so no claim can be marked 'sourced'")
        d.record("pdf_text_layer", "unsupported_format", 0,
                 "input is HTML; the PDF text-layer pass does not apply")
        d.record("ocr", "unsupported_format", 0,
                 "input is HTML; no rasterised content to OCR")
        d.record("xlsx_sheets", "unsupported_format", 0,
                 "input is HTML; the spreadsheet reader does not apply")
        d.found("prose_metric_label_resolution",
                c["prose_metric_label_resolved"],
                f"{c['prose_metric_label_resolved']} resolved against the "
                f"document's own metric vocabulary, "
                f"{c['prose_metric_label_unresolved']} left unresolved "
                f"(metric_label omitted rather than guessed)")

    # ------------------------------------------------------------------
    def checkable_fraction(self):
        """Share of claims assessable with no live data source.

        A claim counts as checkable when at least one in-document relationship
        can be evaluated against it:

        1.  it anchors a footing (``aggregates_claims`` non-empty) or is named
            as a component of one;
        2.  its parsed value restates another claim's value within the two
            claims' combined rounding envelope (cross-reference);
        3.  it is a delta or rate whose stated base also appears in the
            document;
        4.  it is an explicit null (checkable as a null);
        5.  it sits in the sort-key column of a table with a declared sort.
        """
        by_id = {c["claim_id"]: c for c in self.claims}
        checkable = set()
        component_of = set()
        for c in self.claims:
            agg = c.get("aggregates_claims") or []
            if agg:
                checkable.add(c["claim_id"])
                component_of.update(agg)
        checkable |= (component_of & set(by_id))

        # value cross-reference
        buckets = {}
        for c in self.claims:
            v = c.get("value_parsed")
            if v is None:
                continue
            buckets.setdefault(round(v, 6), []).append(c["claim_id"])
        for _, ids in buckets.items():
            if len(ids) > 1:
                checkable.update(ids)

        sort_tables = {t["table_id"]: t for t in self.tables
                       if t.get("declared_sort")}
        for c in self.claims:
            loc = c["location"]
            if c.get("value_parsed") is None:
                checkable.add(c["claim_id"])
            if c.get("comparison"):
                checkable.add(c["claim_id"])
            t = sort_tables.get(loc.get("table_id"))
            if t and loc.get("column_index") == 1:
                checkable.add(c["claim_id"])
        if not self.claims:
            return None
        return round(len(checkable) / len(self.claims), 4)

    # ------------------------------------------------------------------
    def to_ledger(self, elapsed_ms, sha256, nbytes, title, period_label):
        report = {
            "claims_found": len(self.claims),
            "unparseable": self.counters["unparseable"],
            "tables_found": len(self.tables),
            "charts_found": 0,
            "charts_unreadable": 0,
            "prose_blocks_found": len(self.prose_blocks),
            "precision_indeterminable": self.counters["precision_indeterminable"],
            "unit_unknown": self.counters["unit_unknown"],
            "scale_inferred": self.counters["scale_inferred"],
            "detectors_run": self.det.rows(),
            "checkable_fraction": self.checkable_fraction(),
        }
        source = {
            "path": self.path,
            "format": "html",
            "sha256": sha256,
            "bytes": nbytes,
        }
        if title:
            source["title"] = title
        if period_label:
            source["period_label"] = period_label
        return {
            "ledger_version": "claim-ledger/v1",
            "source": source,
            "extracted_at": datetime.now(timezone.utc)
                            .replace(microsecond=0).isoformat()
                            .replace("+00:00", "Z"),
            "extractor": {"name": NAME, "version": __version__,
                          "elapsed_ms": int(elapsed_ms)},
            "claims": self.claims,
            "tables": self.tables,
            "prose_blocks": self.prose_blocks,
            "extraction_report": report,
        }


def extract(path):
    """Parse ``path`` and return ``(ledger_dict, elapsed_ms)``."""
    with open(path, "rb") as fh:
        raw = fh.read()
    return extract_bytes(raw, os.path.abspath(path))


def extract_html(src, path="<memory>.html"):
    """Convenience wrapper for tests: extract from an HTML string."""
    return extract_bytes(src.encode("utf-8"), path)


def extract_bytes(raw, path):
    t0 = time.perf_counter()
    sha = hashlib.sha256(raw).hexdigest()
    src = raw.decode("utf-8")
    doc = parse(src, path)
    b = LedgerBuilder(path, src, doc)
    title, period_label = b.scan_document_context()
    b._prepass_vocabulary()
    b._walk(doc.body(), section=None)
    _, n = np.mask_calendar(text_with_map(doc.body())[0])
    b.counters["dates_masked"] = n
    b._finalise_detectors()
    elapsed = (time.perf_counter() - t0) * 1000.0
    return b.to_ledger(elapsed, sha, len(raw), title, period_label), elapsed
