"""CLI: ``python -m extractor.run --input <file> --out <ledger.json>``."""

from __future__ import annotations

import argparse
import json
import os
import sys

from .build import extract

# The schema travels inside the package. It used to be looked up one directory ABOVE the
# package, which only worked while the package sat in the repo that held `schemas/`; an
# installed copy found nothing and silently skipped the validation it reports as done.
SCHEMA_DEFAULT = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "schemas", "claim-ledger.schema.json")


def validate(ledger, schema_path=SCHEMA_DEFAULT):
    """Validate a ledger against the committed schema. Returns a list of errors."""
    import jsonschema

    with open(schema_path) as fh:
        schema = json.load(fh)
    validator = jsonschema.Draft202012Validator(schema)
    return sorted(validator.iter_errors(ledger), key=lambda e: list(e.path))


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="extractor.run",
        description="Build a claim-ledger/v1 artifact from a source document.")
    ap.add_argument("--input", "-i", required=True, help="source document")
    ap.add_argument("--out", "-o", required=True, help="output ledger JSON")
    ap.add_argument("--schema", default=SCHEMA_DEFAULT,
                    help="claim-ledger JSON schema (default: repo schema)")
    ap.add_argument("--no-validate", action="store_true",
                    help="skip schema validation (not recommended)")
    ap.add_argument("--expect-sha256", default=None,
                    help="fail if the input's sha256 differs. Use this so a "
                         "later edit to the document cannot silently "
                         "invalidate line-number-based fidelity numbers.")
    ap.add_argument("--quiet", "-q", action="store_true")
    args = ap.parse_args(argv)

    ext = os.path.splitext(args.input)[1].lower()
    if ext not in (".html", ".htm"):
        print(f"error: only HTML input is implemented; got '{ext}'. "
              f"See extractor/DEGRADED.md.", file=sys.stderr)
        return 2

    ledger, elapsed = extract(args.input)

    got = ledger["source"]["sha256"]
    if args.expect_sha256 and got != args.expect_sha256:
        print(f"error: input sha256 mismatch\n"
              f"  expected {args.expect_sha256}\n"
              f"  got      {got}\n"
              f"The document changed. Line-number-based fidelity numbers are "
              f"not valid until the answer key is re-verified.",
              file=sys.stderr)
        return 3

    errors = []
    if not args.no_validate:
        errors = validate(ledger, args.schema)

    os.makedirs(os.path.dirname(os.path.abspath(args.out)) or ".",
                exist_ok=True)
    with open(args.out, "w") as fh:
        json.dump(ledger, fh, indent=2, ensure_ascii=False)
        fh.write("\n")

    if not args.quiet:
        r = ledger["extraction_report"]
        print(f"wrote {args.out}")
        print(f"  parse wall-clock      : {elapsed:.1f} ms")
        print(f"  claims_found          : {r['claims_found']}")
        print(f"  unparseable           : {r['unparseable']}")
        print(f"  tables_found          : {r['tables_found']}")
        print(f"  prose_blocks_found    : {r['prose_blocks_found']}")
        print(f"  precision_indeterminable: {r['precision_indeterminable']}")
        print(f"  unit_unknown          : {r['unit_unknown']}")
        print(f"  checkable_fraction    : {r['checkable_fraction']}")
        print(f"  detectors_run         : {len(r['detectors_run'])} "
              f"({sum(1 for d in r['detectors_run'] if d['outcome'] == 'found_nothing')}"
              f" found_nothing, "
              f"{sum(1 for d in r['detectors_run'] if d['outcome'] == 'unsupported_format')}"
              f" unsupported_format)")

    if errors:
        print(f"\nSCHEMA VALIDATION FAILED — {len(errors)} error(s):",
              file=sys.stderr)
        for e in errors[:20]:
            print(f"  at {list(e.path)}: {e.message}", file=sys.stderr)
        return 1
    if not args.quiet:
        print("  schema                : VALID")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
