"""Hand-verified precision/envelope/unit table for the clean-room document.

Every distinct *display shape* the document renders appears exactly once
below. Each row was checked by eye against the rendered string, not copied
from extractor output: for each literal a human read the decimals actually
shown, applied ``0.5 * 10^-precision * scale_factor``, and confirmed the unit.
Two extractor bugs were found and fixed this way, both listed in the README.

Sample size: 45 distinct rendered shapes (the brief asks for at least 25).

Columns: rendered, displayed_precision, rounding_envelope, value_parsed,
unit, scale.
"""

from __future__ import annotations

import json
import sys

HAND_CHECKED = [
    ("$10.5M",        1, 50000.0,  10500000.0,  "currency", "millions"),
    ("$24,039",       0, 0.5,      24039.0,     "currency", "ones"),
    ("$3.13M",        2, 5000.0,   3130000.0,   "currency", "millions"),
    ("$39,665,111",   0, 0.5,      39665111.0,  "currency", "ones"),
    ("$39.67M",       2, 5000.0,   39670000.0,  "currency", "millions"),
    ("$4,000",        0, 0.5,      4000.0,      "currency", "ones"),
    ("$4,369,324",    0, 0.5,      4369324.0,   "currency", "ones"),
    ("$42.96",        2, 0.005,    42.96,       "currency", "ones"),
    ("$515,481",      0, 0.5,      515481.0,    "currency", "ones"),
    ("(−3.5%)",       1, 0.05,     -3.5,        "percent",  "ones"),
    ("+0.20 points",  2, 0.005,    0.2,         "points",   "ones"),
    ("+13.7 pts",     1, 0.05,     13.7,        "points",   "ones"),
    ("+4.6 pts",      1, 0.05,     4.6,         "points",   "ones"),
    ("+5.1%",         1, 0.05,     5.1,         "percent",  "ones"),
    ("+55.2%",        1, 0.05,     55.2,        "percent",  "ones"),
    ("+934.2%",       1, 0.05,     934.2,       "percent",  "ones"),
    ("0.20 points",   2, 0.005,    0.2,         "points",   "ones"),
    ("0.4 points",    1, 0.05,     0.4,         "points",   "ones"),
    ("1,408",         0, 0.5,      1408.0,      "units",    "ones"),
    ("1.32%",         2, 0.005,    1.32,        "percent",  "ones"),
    ("100.0%",        1, 0.05,     100.0,       "percent",  "ones"),
    ("12,000",        0, 0.5,      12000.0,     "units",    "ones"),
    ("13.7 points",   1, 0.05,     13.7,        "points",   "ones"),
    # Declared ($000). The declaration is honoured here; whether the values
    # respect it is a downstream check, not an extraction decision.
    ("192,301",       0, 500.0,    192301000.0, "currency", "thousands"),
    ("2.4 percent",   1, 0.05,     2.4,         "percent",  "ones"),
    # Sub-unit denomination: see SCHEMA-GAPS.md. value_parsed is the displayed
    # magnitude (34), with the denomination recorded in confidence.notes.
    ("34 cents",      0, 0.5,      34.0,        "currency", "ones"),
    ("365 days",      0, 0.5,      365.0,       "days",     "ones"),
    ("4.5%",          1, 0.05,     4.5,         "percent",  "ones"),
    ("5",             0, 0.5,      5.0,         "count",    "ones"),
    ("51.0%",         1, 0.05,     51.0,        "percent",  "ones"),
    ("62",            0, 0.5,      62.0,        "count",    "ones"),
    ("804",           0, 0.5,      804.0,       "units",    "ones"),
    ("814,431 units", 0, 0.5,      814431.0,    "units",    "ones"),
    # Unit honestly unknown: "the top five styles" quantifies nothing named.
    ("five",          0, 0.5,      5.0,         "unknown",  "ones"),
    ("five percent",  0, 0.5,      5.0,         "percent",  "ones"),
    ("four-week",     0, 0.5,      4.0,         "weeks",    "ones"),
    ("seven days",    0, 0.5,      7.0,         "days",     "ones"),
    ("sixty-two",     0, 0.5,      62.0,        "count",    "ones"),
    ("three",         0, 0.5,      3.0,         "count",    "ones"),
    # Explicit null marker: unit inherited from the column, value null.
    ("—",          None, None,     None,        "currency", "unknown"),
    ("−$34,406",      0, 0.5,      -34406.0,    "currency", "ones"),
    ("−0.4 points",   1, 0.05,     -0.4,        "points",   "ones"),
    ("−0.4 pts",      1, 0.05,     -0.4,        "points",   "ones"),
    ("−10.4%",        1, 0.05,     -10.4,       "percent",  "ones"),
    ("−4.5%",         1, 0.05,     -4.5,        "percent",  "ones"),
]


def audit(ledger):
    """Compare the live ledger against the hand-checked table.

    Returns ``(rows, summary)``.
    """
    by_display = {}
    for c in ledger["claims"]:
        by_display.setdefault(c["value_displayed"], c)

    rows = []
    for shown, prec, env, val, unit, scale in HAND_CHECKED:
        c = by_display.get(shown)
        if c is None:
            rows.append({"rendered": shown, "status": "absent"})
            continue
        checks = {
            "precision": c["displayed_precision"] == prec,
            "envelope": c["rounding_envelope"] == env,
            "value": c["value_parsed"] == val,
            "unit": c["unit"] == unit,
            "scale": c["scale"] == scale,
        }
        rows.append({"rendered": shown,
                     "status": "ok" if all(checks.values()) else "mismatch",
                     "checks": checks,
                     "got": {"precision": c["displayed_precision"],
                             "envelope": c["rounding_envelope"],
                             "value": c["value_parsed"],
                             "unit": c["unit"], "scale": c["scale"]}})
    n = len(rows)
    summary = {
        "sample_size": n,
        "precision_correct": sum(1 for r in rows
                                 if r.get("checks", {}).get("precision")),
        "envelope_correct": sum(1 for r in rows
                                if r.get("checks", {}).get("envelope")),
        "value_correct": sum(1 for r in rows
                             if r.get("checks", {}).get("value")),
        "unit_correct": sum(1 for r in rows
                            if r.get("checks", {}).get("unit")),
        "scale_correct": sum(1 for r in rows
                             if r.get("checks", {}).get("scale")),
        "absent": sum(1 for r in rows if r["status"] == "absent"),
    }
    return rows, summary


def main(argv=None):
    argv = argv or sys.argv[1:]
    if not argv:
        print(__doc__)
        return 2
    ledger = json.load(open(argv[0]))
    rows, summary = audit(ledger)
    n = summary["sample_size"]
    for k in ("precision", "envelope", "value", "unit", "scale"):
        v = summary[f"{k}_correct"]
        print(f"{k + '_correct':<20}: {v}/{n}  ({v / n:.1%})")
    bad = [r for r in rows if r["status"] != "ok"]
    if bad:
        print("\nnot matching the hand-checked table:")
        for r in bad:
            print(f"  {r['rendered']!r}: {r.get('got', r['status'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
