"""Measure extraction fidelity against the sealed answer key.

The answer key is used **only** to ask "did the extractor produce a claim at
the place this defect lives?". Nothing here feeds back into the extractor, and
the extractor never reads the key. Detection is a different component's job.

Run:

    python -m extractor.tools.fidelity \
        --ledger out/ledger.json \
        --answers ../cleanroom-answers.json \
        --source ../cleanroom/reports/<doc>.html

The key's line numbers are valid for one document hash. A table row in this
document can span two source lines, and the key sometimes cites the row's
opening line rather than the line the cell itself sits on. Matching therefore
uses a +/-2 line window, and both the strict and windowed numbers are printed
so the tolerance is visible rather than assumed.
"""

from __future__ import annotations

import argparse
import bisect
import json
import re
import sys

LINE_WINDOW = 2


def line_index(src):
    return [0] + [i + 1 for i, ch in enumerate(src) if ch == "\n"]


def line_of(starts, offset):
    return bisect.bisect_right(starts, offset)


def norm(s):
    """Compare displayed values without caring about minus-sign flavour."""
    return re.sub(r"[\s ]", "", (s or "")).replace("−", "-") \
             .replace("–", "-")


def load(ledger_path, source_path):
    ledger = json.load(open(ledger_path))
    src = open(source_path, encoding="utf-8").read()
    starts = line_index(src)
    claims = []
    for c in ledger["claims"]:
        span = c["location"].get("char_span")
        c = dict(c)
        c["_line"] = line_of(starts, span[0]) if span else None
        claims.append(c)
    return ledger, claims, src, starts


def near(claims, line, window=LINE_WINDOW):
    return [c for c in claims
            if c["_line"] is not None and abs(c["_line"] - line) <= window]


def exact(claims, line):
    return [c for c in claims if c["_line"] == line]


# Every answer-key reference, and what a *complete extraction* must contain at
# that spot for the corresponding check to be runnable at all. Values are the
# displayed strings the document renders.
EXPECT = {
    "D01": (183, ["$191,588"]),
    "D02": (277, ["15.7%"]),
    "D03": (107, ["$18,400"]),
    "D04": (328, ["192,301"]),
    "D05": (279, ["2.4 percent"]),
    "D06": (300, ["41.9%"]),
    "D07": (75, ["$515,481"]),
    "D08": (508, ["365 days"]),
    "D09": (330, ["48,379"]),
    "D10": (503, []),          # template token: prose block, no number
    "D11": (492, []),          # "TBD": table entity + prose block, no number
    "N01a": (253, ["29.9%"]),
    "N01b": (255, ["25.0%"]),
    "N01c": (257, ["11.7%"]),
    "N01d": (259, ["9.4%"]),
    "N01e": (261, ["5.7%"]),
    "N01f": (263, ["18.2%"]),
    "N02a": (174, ["12.9%"]),
    "N02b": (176, ["6.2%"]),
    "N02c": (178, ["5.7%"]),
    "N02d": (180, ["5.5%"]),
    "N02e": (182, ["5.0%"]),
    "N02f": (186, ["64.8%"]),
    "N03": (173, ["+934.2%"]),
    "N04a": (179, ["—"]),
    "N04b": (431, ["—"]),
    "N05": (90, ["1.32%"]),
    "N06a": (219, ["$287,603"]),
    "N06b": (221, ["$142,588"]),
    "N06c": (223, ["$85,290"]),
    "N06d": (227, ["$515,481"]),
    "N07": (386, []),          # forward-looking prose, no number on the line
    "N08a": (66, ["−0.4 points"]),
    "N08b": (115, ["0.20 points"]),
}

# Non-numeric answer-key references: prove the text is reachable in the ledger.
TEXT_REACHABLE = {
    "D10": ("__PLANNER_EMAIL__", "prose_blocks"),
    "D11": ("TBD", "prose_blocks+table_entity"),
    "N07": ("On current trend", "prose_blocks"),
}


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--ledger", required=True)
    ap.add_argument("--answers", required=True)
    ap.add_argument("--source", required=True)
    ap.add_argument("--json", action="store_true",
                    help="emit machine-readable results")
    args = ap.parse_args(argv)

    ledger, claims, _src, _starts = load(args.ledger, args.source)
    answers = json.load(open(args.answers))

    # Fixture drift guard: the key's line numbers are valid for one hash only.
    want_sha = answers["fixture"]["primary_document"]["sha256"]
    got_sha = ledger["source"]["sha256"]
    drift = want_sha != got_sha

    rows = []
    for key, (line, values) in sorted(EXPECT.items()):
        cands_w = near(claims, line)
        cands_e = exact(claims, line)
        if values:
            hit_w = all(any(norm(c["value_displayed"]) == norm(v)
                            for c in cands_w) for v in values)
            hit_e = all(any(norm(c["value_displayed"]) == norm(v)
                            for c in cands_e) for v in values)
            matched = [c["claim_id"] for c in cands_w
                       if any(norm(c["value_displayed"]) == norm(v)
                              for v in values)]
        else:
            needle, where = TEXT_REACHABLE[key]
            hit_w = hit_e = any(needle in b["text"] for b in
                                ledger.get("prose_blocks", [])) or \
                any(needle in json.dumps(c.get("entity", {}))
                    for c in ledger["claims"])
            matched = [where] if hit_w else []
        rows.append({"ref": key, "line": line, "expects": values,
                     "windowed": hit_w, "strict": hit_e, "matched": matched})

    total = len(rows)
    win = sum(1 for r in rows if r["windowed"])
    strict = sum(1 for r in rows if r["strict"])

    rep = ledger["extraction_report"]
    out = {
        "fixture_hash_matches": not drift,
        "answer_key_refs": total,
        "found_windowed": win,
        "found_strict_same_line": strict,
        "recall_windowed": round(win / total, 4),
        "recall_strict": round(strict / total, 4),
        "claims_found": rep["claims_found"],
        "unparseable": rep["unparseable"],
        "precision_indeterminable": rep["precision_indeterminable"],
        "checkable_fraction": rep["checkable_fraction"],
        "misses": [r["ref"] for r in rows if not r["windowed"]],
        "rows": rows,
    }
    if args.json:
        json.dump(out, sys.stdout, indent=2)
        print()
        return 0

    if drift:
        print("!! fixture hash differs from the sealed answer key; line "
              "numbers may not apply", file=sys.stderr)
    print(f"answer-key references          : {total}")
    print(f"  extracted (+/-{LINE_WINDOW} line window) : {win}  "
          f"({win / total:.1%})")
    print(f"  extracted (exact same line)  : {strict}  ({strict / total:.1%})")
    print(f"claims found in total          : {rep['claims_found']}")
    print(f"  unparseable                  : {rep['unparseable']}")
    print(f"  precision indeterminable     : {rep['precision_indeterminable']}")
    print(f"  checkable_fraction           : {rep['checkable_fraction']}")
    if out["misses"]:
        print(f"MISSES: {', '.join(out['misses'])}")
    else:
        print("MISSES: none")
    print()
    for r in rows:
        flag = "ok " if r["windowed"] else "MISS"
        print(f"  {flag} {r['ref']:<5} line {r['line']:>3}  "
              f"{','.join(r['expects']) or '(non-numeric)':<14} "
              f"-> {','.join(r['matched']) or '-'}")
    return 0 if not out["misses"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
