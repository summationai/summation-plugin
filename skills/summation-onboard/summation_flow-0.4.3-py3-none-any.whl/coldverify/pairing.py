"""Resolving movements, share sets and comparable siblings from the ledger.

Several families need the same three derived structures, and each of them is a
place where a naive implementation invents relationships that are not in the
document. Every resolver here is conservative: it returns ``None`` rather than
guess, and it says *how* it resolved so a finding can explain itself.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional

from .envelope import percent_change_band, sum_band, within
from .ledger import Claim, Ledger, _PARENTHESISED, normalise_numeric_text

GROWTH_WORDS = {
    "grew", "grow", "grown", "growth", "rose", "rise", "risen", "increased",
    "increase", "up", "gained", "gain", "climbed", "climb", "expanded",
    "expansion", "accelerated", "higher", "jumped", "surged", "added",
}
DECLINE_WORDS = {
    "declined", "decline", "fell", "fall", "fallen", "decreased", "decrease",
    "down", "dropped", "drop", "lost", "loss", "shrank", "shrunk", "contracted",
    "slowed", "lower", "softened", "eroded", "reduced",
}
IMPROVE_WORDS = {
    "improved", "improve", "improvement", "better", "stronger", "strengthened",
    "recovered", "healthier", "gains",
}
WORSEN_WORDS = {
    "worsened", "worsen", "worse", "deteriorated", "weaker", "weakened",
    "degraded", "eroded",
}
FLAT_WORDS = {"flat", "unchanged", "stable", "steady", "held", "in line", "level"}

#: Hedges that make a flatness claim approximate. "Almost flat at −0.6%" is honest
#: prose about a small move, not an assertion that the move was zero.
FLAT_HEDGES = (
    "almost", "nearly", "roughly", "broadly", "largely", "about", "approximately",
    "essentially", "more or less", "close to", "relatively", "fairly", "-ish",
)


def flatness_is_hedged(sentence: str) -> bool:
    """Whether a flatness word in this sentence is qualified by a hedge."""
    text = (sentence or "").lower()
    for word in FLAT_WORDS:
        for match in re.finditer(rf"\b{re.escape(word)}\b", text):
            window = text[max(0, match.start() - 30) : match.start()]
            if any(hedge in window for hedge in FLAT_HEDGES):
                return True
    return False

SHARE_LABEL_RE = re.compile(
    r"share|mix|%\s*of|pct\s*of|percent\s*of|of\s*total|contribution|composition|penetration",
    re.IGNORECASE,
)

TOP_N_RE = re.compile(
    r"\btop\s+(one|two|three|four|five|six|seven|eight|nine|ten|\d+)\b", re.IGNORECASE
)
BOTTOM_N_RE = re.compile(
    r"\b(bottom|worst)\s+(one|two|three|four|five|six|seven|eight|nine|ten|\d+)\b",
    re.IGNORECASE,
)
WORD_NUMBERS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "eleven": 11, "twelve": 12, "twenty": 20,
}

TRAILING_KINDS = {"trailing_days", "trailing_weeks"}

LOWER_IS_BETTER_HINTS = (
    "stockout", "out of stock", "markdown", "return rate", "cancel", "churn",
    "defect", "backorder", "aged", "shrink", "days of supply",
)


def word_to_int(token: str) -> Optional[int]:
    token = token.strip().lower()
    if token.isdigit():
        return int(token)
    return WORD_NUMBERS.get(token)


# ---------------------------------------------------------------------------
# Movements
# ---------------------------------------------------------------------------


@dataclass
class Movement:
    """A resolved change for one claim.

    ``delta`` is in the metric's own units when ``form`` is an absolute or point
    change, and in percent when ``form`` is ``percent_change``. ``basis`` records
    how it was resolved so a finding can be explained and audited.
    """

    claim: Claim
    delta: Optional[float]
    delta_band: Optional[float]
    form: str
    basis: str
    new: Optional[float] = None
    old: Optional[float] = None
    new_claim: Optional[Claim] = None
    old_claim: Optional[Claim] = None

    @property
    def resolved(self) -> bool:
        return self.delta is not None

    @property
    def sign(self) -> Optional[int]:
        """``+1``, ``-1``, or ``0`` when the move is inside its own band."""
        if self.delta is None:
            return None
        if self.delta_band is not None and within(self.delta, self.delta_band):
            return 0
        if self.delta > 0:
            return 1
        if self.delta < 0:
            return -1
        return 0

    @property
    def participants(self) -> list[Claim]:
        out = [self.claim]
        for c in (self.new_claim, self.old_claim):
            if c is not None and c.claim_id != self.claim.claim_id:
                out.append(c)
        return out


def is_caption_count(claim: Claim) -> bool:
    """Whether this figure is a caption's own count rather than a reported value.

    "Top 5 of 62 teams by net demand, highest first" yields the numbers 5 and 62, and
    an extractor reasonably attaches the caption's superlatives to them. They are not
    claims *about* a figure: nothing asserts that 5 is the largest anything. Treating
    them as ranked values reported eight superlatives as unverifiable and put "62"
    into competition with every net-demand figure in the table.
    """
    if claim.role in ("count", "rank") and not claim.row_label:
        return True
    # A table-attached figure with neither a row nor a column sits in the caption.
    if claim.table_id and not claim.row_label and not claim.column_label:
        return True
    return False


def explicitly_signed(claim: Claim) -> bool:
    """Whether the rendered figure carries its own sign.

    Load-bearing for the direction family. Analyst prose states a movement as an
    unsigned magnitude and puts the direction in a word: "units were down 3.7%"
    renders ``3.7%``, not ``−3.7%``. Reading the sign off that value and comparing
    it to the word "down" reports a contradiction in ordinary English.

    A figure is explicitly signed when it shows a leading ``+``, a minus in any of
    its typographic forms, or the accounting brackets. Only then does the *figure*
    make a directional assertion the words can contradict.
    """
    text = normalise_numeric_text(claim.value_displayed).strip()
    if not text:
        return False
    if text.lstrip("( ").startswith(("+", "-")):
        return True
    return bool(_PARENTHESISED.search(text))


def _period_order_key(claim: Claim) -> tuple:
    period = claim.period
    end = period.get("end") or ""
    start = period.get("start") or ""
    return (end, start, period.get("label", ""))


def find_counterpart(ledger: Ledger, claim: Claim) -> Optional[Claim]:
    """The base claim this figure is compared against, or ``None``.

    Resolution order, strictest first:

    1. ``comparison.base_claim_id`` — the document told us. No inference at all.
    2. A same-unit, same-metric, same-entity level whose ``period.label`` equals
       ``comparison.base_label`` verbatim, when exactly one such claim exists.
    3. A same-unit, same-metric, same-entity level in a different period, when
       exactly one such claim exists.

    Everything else returns ``None`` and the caller records the claim as not
    checkable. Three guards matter here, each of which produced a real false
    positive before it was added:

    * **No metric identity, no pairing.** ``label_key()`` is ``None`` for an
      unlabelled figure, and ``None`` never matches.
    * **Units must agree.** A ``+0.20 points`` movement is not a level that can be
      differenced against ``1.12%``; pairing them invented a fall from 1.12 to 0.2.
    * **The base must be a level.** A delta cannot be the base of another delta.
    """
    key = claim.label_key()
    if key is None:
        return None

    comparison = claim.comparison or {}

    declared = comparison.get("base_claim_id")
    if declared:
        stated = ledger.get(declared)
        if stated is not None and stated.value_parsed is not None:
            return stated
        return None

    entity = claim.entity_key()
    siblings = [
        c
        for c in ledger.claims
        if c.claim_id != claim.claim_id
        and c.label_key() == key
        and c.entity_key() == entity
        and c.unit == claim.unit
        and c.role != "delta"
        and c.value_parsed is not None
        and c.comparison is None
    ]
    if not siblings:
        return None

    base_label = (comparison.get("base_label") or "").strip().lower()
    if base_label:
        exact = [c for c in siblings if c.period_label.strip().lower() == base_label]
        if len(exact) == 1:
            return exact[0]

    others = [c for c in siblings if c.period_label != claim.period_label]
    if len(others) == 1:
        return others[0]
    return None


def resolve_movement(ledger: Ledger, claim: Claim) -> Movement:
    """Work out what movement, if any, this claim asserts."""
    comparison = claim.comparison or {}
    form = comparison.get("form")

    # Case 1: the claim itself is the delta. `role: "delta"` is enough on its own —
    # a figure rendered "+0.20 points" IS the movement, whether or not the
    # extractor also attached a comparison block. Treating it as a *level* and
    # differencing it against a real level is how a 0.2-point gain became a fall
    # from 1.12 to 0.2.
    if (
        claim.role == "delta"
        and form is None
        and claim.value_parsed is not None
        and explicitly_signed(claim)
    ):
        return Movement(
            claim=claim,
            delta=claim.value_parsed,
            delta_band=claim.envelope,
            form="absolute_delta",
            basis="claim_is_delta_by_role",
        )

    if form in ("absolute_delta", "point_change", "percent_change") and claim.value_parsed is not None:
        return Movement(
            claim=claim,
            delta=claim.value_parsed,
            delta_band=claim.envelope,
            form=form,
            basis="claim_is_delta",
            new_claim=None,
            old_claim=find_counterpart(ledger, claim),
        )

    # Case 2: the claim is a level with a comparison; find the base level.
    counterpart = find_counterpart(ledger, claim)
    if counterpart is not None and claim.value_parsed is not None:
        new, old = claim, counterpart
        # Order by period when dates allow it, so "grew" is judged against time.
        if _period_order_key(counterpart) > _period_order_key(claim) and claim.comparison is None:
            new, old = counterpart, claim
        if new.value_parsed is None or old.value_parsed is None:
            return Movement(claim, None, None, "unknown", "unresolved")
        delta = new.value_parsed - old.value_parsed
        band = sum_band([new.envelope, old.envelope])
        return Movement(
            claim=claim,
            delta=delta,
            delta_band=band,
            form="absolute_delta",
            basis="level_pair",
            new=new.value_parsed,
            old=old.value_parsed,
            new_claim=new,
            old_claim=old,
        )

    return Movement(claim, None, None, "unknown", "unresolved")


def percent_change_of(movement: Movement) -> tuple[Optional[float], Optional[float]]:
    """Relative change implied by a resolved level pair, with its band."""
    if movement.new is None or movement.old is None:
        return None, None
    if movement.old == 0:
        return None, None
    pct = 100.0 * (movement.new - movement.old) / movement.old
    band = percent_change_band(
        movement.new,
        movement.new_claim.envelope if movement.new_claim else None,
        movement.old,
        movement.old_claim.envelope if movement.old_claim else None,
        0.0,
    )
    return pct, band


# ---------------------------------------------------------------------------
# Polarity
# ---------------------------------------------------------------------------


def effective_polarity(claim: Claim) -> str:
    """Declared polarity, or a label-based inference for known bad-when-rising metrics.

    The inference only ever fires when polarity is absent or ``unknown``, and the
    finding it feeds is marked as resting on a heuristic.
    """
    declared = claim.polarity
    if declared in ("higher_is_better", "lower_is_better", "neutral"):
        return declared
    label = (claim.metric_label or "").lower()
    if any(hint in label for hint in LOWER_IS_BETTER_HINTS):
        return "lower_is_better_inferred"
    return "unknown"


def polarity_is_lower_better(polarity: str) -> bool:
    return polarity in ("lower_is_better", "lower_is_better_inferred")


def shares_its_sentence(claim: Claim, ledger: Optional[Ledger]) -> bool:
    """Whether another figure sits in the same sentence as this one."""
    sentence = (claim.sentence or "").strip()
    if not sentence or ledger is None:
        return False
    sharing = [c for c in ledger.claims if (c.sentence or "").strip() == sentence]
    if len(sharing) > 1:
        return True
    for block in ledger.prose_blocks:
        if block.text.strip() == sentence and len(block.claim_ids) > 1:
            return True
    return False


def _spans_opposing_vocabularies(words: set[str]) -> bool:
    return bool(
        (words & GROWTH_WORDS and words & DECLINE_WORDS)
        or (words & IMPROVE_WORDS and words & WORSEN_WORDS)
    )


def words_of(claim: Claim, ledger: Optional[Ledger] = None) -> set[str]:
    """Direction words attributable to *this* claim, or an empty set.

    Two restrictions, each of which removed a real class of false positive:

    * **The sentence is only swept when this claim is the only figure in it.**
      "Gross margin held at 51.0%, down 0.4 points" carries two figures; sweeping
      attaches "down" to the 51.0% level as well as to the 0.4-point move, and the
      engine then reports that a *level* contradicts the word "down".
    * **A shared sentence whose words point both ways attributes nothing.**
      Extractors populate ``direction_words`` per sentence, not per figure, so "the
      owned book grew 5.1% and the third-party book fell 10.2%" gives both figures
      ``["grew", "fell"]``. That is the extractor's ambiguity, not the author's
      self-contradiction, and the engine refuses to read it as either.

    A sentence with several numbers cannot have its verbs attributed by proximity,
    so the engine does not try.
    """
    words = set(claim.direction_words)
    shared = shares_its_sentence(claim, ledger)
    if shared and _spans_opposing_vocabularies(words):
        return set()
    if shared:
        return words
    sentence = claim.sentence or ""
    if not sentence:
        return words
    lowered = sentence.lower()
    for vocabulary in (GROWTH_WORDS, DECLINE_WORDS, IMPROVE_WORDS, WORSEN_WORDS, FLAT_WORDS):
        for word in vocabulary:
            if re.search(rf"\b{re.escape(word)}\b", lowered):
                words.add(word)
    return words


# ---------------------------------------------------------------------------
# Share sets and comparable groups
# ---------------------------------------------------------------------------


def column_groups(ledger: Ledger) -> dict[tuple, list[Claim]]:
    """Claims grouped by (table_id, column_label). Table cells only."""
    groups: dict[tuple, list[Claim]] = {}
    for claim in ledger.claims:
        if claim.table_id is None:
            continue
        groups.setdefault((claim.table_id, claim.column_label), []).append(claim)
    return groups


def is_share_group(ledger: Ledger, claims: list[Claim]) -> bool:
    """Whether a column of percents is a composition that ought to sum to 100.

    Requires an explicit share signal — the metric label, the column label or the
    table caption. Percent columns that are growth rates or margins must never be
    tested against 100, and there is no numeric way to tell them apart.
    """
    percents = [c for c in claims if c.unit == "percent" and c.value_parsed is not None]
    if len(percents) < 2:
        return False
    if any(c.comparison for c in percents):
        return False
    signals = []
    for claim in percents:
        signals.append(claim.metric_label or "")
        signals.append(claim.column_label or "")
    table = ledger.tables_by_id.get(percents[0].table_id or "")
    if table is not None:
        signals.append(table.caption)
    return any(SHARE_LABEL_RE.search(s) for s in signals if s)


def comparable_siblings(ledger: Ledger, claim: Claim) -> list[Claim]:
    """Claims a superlative on this claim can honestly be tested against.

    Same table and column, same metric, same period, same unit, and a component
    or standalone role — never a total, or "largest" would lose to the total.
    """
    if claim.table_id is None:
        return []
    key = claim.label_key()
    if key is None:
        return []
    out = []
    for other in ledger.column(claim.table_id, claim.column_label):
        if other.value_parsed is None:
            continue
        if other.role in ("total", "subtotal", "rank", "count"):
            continue
        # A figure with no row label is not a row of the table — it is a caption
        # count or a note that happens to belong to it.
        if not other.row_label:
            continue
        if other.unit != claim.unit:
            continue
        if other.label_key() != key:
            continue
        if other.period_label != claim.period_label:
            continue
        out.append(other)
    return out


def declared_sort_direction(declared_sort: Optional[str]) -> Optional[str]:
    """``"desc"``, ``"asc"``, or ``None`` when the declaration is not a sort."""
    if not declared_sort:
        return None
    text = declared_sort.lower()
    # "highest first" is how real captions say descending — the clean-room document
    # writes "Top 5 of 62 teams by net demand, highest first" — and missing it left
    # the sort check silent on every table in the report.
    if re.search(
        r"\b(desc|descending|high(?:est)?\s+to\s+low(?:est)?|largest\s+first|"
        r"highest\s+first|biggest\s+first|top\s+down)\b",
        text,
    ):
        return "desc"
    if re.search(
        r"\b(asc|ascending|low(?:est)?\s+to\s+high(?:est)?|smallest\s+first|"
        r"lowest\s+first|bottom\s+up)\b",
        text,
    ):
        return "asc"
    return None


def declared_sort_column(declared_sort: Optional[str]) -> Optional[str]:
    """The column named in a declaration like ``"by revenue desc"``."""
    if not declared_sort:
        return None
    # Stop at the direction phrase *or* a comma. Real captions write "by net demand,
    # highest first", and swallowing the direction into the column name meant the
    # column could never be matched against a real heading.
    match = re.search(
        r"by\s+(.+?)(?:\s*,|\s+(?:desc|descending|asc|ascending|high(?:est)?\s+to\s+low(?:est)?|"
        r"low(?:est)?\s+to\s+high(?:est)?|highest\s+first|lowest\s+first|largest\s+first|"
        r"smallest\s+first)\b|$)",
        declared_sort,
        re.IGNORECASE,
    )
    if not match:
        return None
    return match.group(1).strip() or None
