"""Tolerance envelope maths.

The single most load-bearing module in the engine. Nothing here ever compares two
numbers for equality. Every comparison is a band test.

Vocabulary
----------
``envelope``
    The maximum absolute error a *display* can hide for one value. A value shown
    as ``1.2`` with one decimal could truly be anything in ``[1.15, 1.25)``, so
    the envelope is ``0.05``. A value shown as ``$1.2M`` (scale ``millions``,
    precision 1) has an envelope of ``0.05 * 1e6 = 50_000`` in the units of
    ``value_parsed``, because ``value_parsed`` is scale-applied.

``band``
    An envelope propagated through an arithmetic operation. Sums and differences
    add envelopes. Products and quotients propagate *relative* error, i.e. the
    first-order partial derivatives of the operation.

Pass rule
---------
A discrepancy inside the band is a PASS. Only a discrepancy outside the band is a
FAIL. ``None`` anywhere in the inputs means the band is indeterminate and the
check must degrade to "not checkable" rather than guess.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Optional, Sequence

# Multiplier from a declared scale to the units of ``value_parsed``.
SCALE_FACTORS: dict[str, float] = {
    "ones": 1.0,
    "thousands": 1e3,
    "millions": 1e6,
    "billions": 1e9,
}

#: Relative slack used when comparing two *envelopes* to each other (never used
#: when comparing two values). Guards float representation only.
FLOAT_SLACK = 1e-9


def scale_factor(scale: Optional[str]) -> Optional[float]:
    """Multiplier for a declared scale, or ``None`` when it is unusable.

    ``unknown``, ``None`` and any unrecognised string all return ``None`` — the
    engine refuses to invent a scale it was not told.
    """
    if scale is None:
        return None
    return SCALE_FACTORS.get(scale)


def envelope_from_precision(
    displayed_precision: Optional[int], scale: Optional[str] = "ones"
) -> Optional[float]:
    """Maximum absolute error a display of this precision and scale can hide.

    ``0.5 * 10**-precision * scale_factor``.

    Returns ``None`` when precision is unknown or the scale is unusable, because
    an unknown envelope is not the same thing as a zero envelope. Treating an
    unknown envelope as zero would turn every rounding difference into a defect,
    which is the single worst false-positive mode this engine can have.
    """
    if displayed_precision is None:
        return None
    if displayed_precision < 0:
        return None
    factor = scale_factor(scale if scale is not None else "ones")
    if factor is None:
        return None
    return 0.5 * (10.0 ** -displayed_precision) * factor


def sum_band(envelopes: Sequence[Optional[float]]) -> Optional[float]:
    """Band for a sum or a difference: envelopes add.

    Worst-case, not root-sum-square. A band that is too tight produces false
    positives, and false positives on a customer's own shipped work are fatal to
    the product. Any ``None`` member makes the whole band indeterminate.
    """
    total = 0.0
    for env in envelopes:
        if env is None:
            return None
        total += env
    return total


def difference_band(
    env_a: Optional[float], env_b: Optional[float], env_result: Optional[float] = 0.0
) -> Optional[float]:
    """Band for ``a - b`` compared against a displayed result."""
    return sum_band([env_a, env_b, env_result])


def product_band(
    a: float, env_a: Optional[float], b: float, env_b: Optional[float]
) -> Optional[float]:
    """Band for ``a * b`` — first-order propagation, ``|b|*env_a + |a|*env_b``."""
    if env_a is None or env_b is None:
        return None
    return abs(b) * env_a + abs(a) * env_b


def quotient_band(
    numerator: float,
    env_numerator: Optional[float],
    denominator: float,
    env_denominator: Optional[float],
) -> Optional[float]:
    """Band for ``numerator / denominator`` — first-order relative propagation.

    ``env_n/|d| + |n|*env_d/d**2``. Returns ``None`` when the denominator is
    zero or could straddle zero inside its own envelope, because the quotient is
    then unbounded and no honest band exists.
    """
    if env_numerator is None or env_denominator is None:
        return None
    if denominator == 0:
        return None
    if abs(denominator) <= env_denominator:
        # The denominator's own display cannot rule out zero.
        return None
    return env_numerator / abs(denominator) + abs(numerator) * env_denominator / (
        denominator * denominator
    )


def percent_change_band(
    new: float,
    env_new: Optional[float],
    old: float,
    env_old: Optional[float],
    env_result: Optional[float] = 0.0,
) -> Optional[float]:
    """Band for ``100 * (new - old) / old`` compared against a displayed percent.

    Partials: ``d/dnew = 100/old``, ``d/dold = -100*new/old**2``.
    """
    if env_new is None or env_old is None or env_result is None:
        return None
    if old == 0 or abs(old) <= env_old:
        return None
    return (
        100.0 * env_new / abs(old)
        + 100.0 * abs(new) * env_old / (old * old)
        + env_result
    )


def within(discrepancy: float, band: Optional[float]) -> Optional[bool]:
    """``True`` inside the band, ``False`` outside, ``None`` when indeterminate.

    Uses ``<=`` so a discrepancy exactly on the boundary passes: the boundary is
    reachable by legitimate rounding.
    """
    if band is None:
        return None
    if not math.isfinite(discrepancy):
        return False
    return abs(discrepancy) <= band * (1.0 + FLOAT_SLACK)


# ---------------------------------------------------------------------------
# Footing bands
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class FootingVerdict:
    """Result of footing a total against its components.

    Attributes
    ----------
    verdict
        ``"pass"``          discrepancy inside the total's own display envelope.
        ``"precision"``     discrepancy exceeds the total's own envelope but sits
                            inside the summed-envelope band, so only rounding at
                            the component level explains it. The total is
                            displayed at a precision its components do not earn:
                            a reader footing the column gets a different number.
        ``"fail"``          discrepancy outside the summed-envelope band. No
                            rounding story explains it; the arithmetic is wrong.
        ``"indeterminate"`` a participating envelope is unknown.
    """

    verdict: str
    discrepancy: float
    computed: Optional[float]
    stated: Optional[float]
    single_band: Optional[float]
    summed_band: Optional[float]

    @property
    def is_finding(self) -> bool:
        return self.verdict in ("precision", "fail")


def foot_total(
    stated: Optional[float],
    env_stated: Optional[float],
    components: Sequence[Optional[float]],
    env_components: Sequence[Optional[float]],
) -> FootingVerdict:
    """Three-band footing test.

    The two footing cases the spec demands be distinguished:

    * *computed exactly, then rounded* — the stated total is the rounded true
      total. Its distance from the sum of the rounded components is bounded by
      the total's own envelope in the well-behaved case, and by the full summed
      band in the worst case.
    * *summed from already-rounded parts* — the displayed set is not
      self-consistent at the stated total's precision. The discriminator, per
      spec item 4.3/4.4, is a discrepancy that **exceeds the single-value
      envelope but sits inside the summed-envelope band**.

    Anything beyond the summed band is a plain arithmetic error.
    """
    if stated is None or any(c is None for c in components) or not components:
        return FootingVerdict(
            "indeterminate", float("nan"), None, stated, env_stated, None
        )
    computed = float(sum(c for c in components if c is not None))
    discrepancy = stated - computed

    single_band = env_stated
    parts_band = sum_band(list(env_components))
    summed_band = (
        None
        if (single_band is None or parts_band is None)
        else single_band + parts_band
    )

    if single_band is None or summed_band is None:
        return FootingVerdict(
            "indeterminate", discrepancy, computed, stated, single_band, summed_band
        )

    if within(discrepancy, single_band):
        verdict = "pass"
    elif within(discrepancy, summed_band):
        verdict = "precision"
    else:
        verdict = "fail"
    return FootingVerdict(
        verdict, discrepancy, computed, stated, single_band, summed_band
    )


def shares_band(env_components: Iterable[Optional[float]]) -> Optional[float]:
    """Band for a set of shares tested against an exact 100.

    100 is a mathematical constant, not a displayed value, so it contributes no
    envelope. Five shares each shown to one decimal give a band of
    ``5 * 0.05 = 0.25``, which is why a set summing to 99.8 passes.
    """
    return sum_band(list(env_components))


def rounds_to(value: float, precision: int) -> float:
    """Half-up rounding at a given decimal precision.

    Python's ``round`` is banker's rounding, which is not what a spreadsheet or
    a report renderer does. Display checks must model the renderer.
    """
    factor = 10.0**precision
    scaled = value * factor
    # Nudge by the float epsilon of the scaled magnitude so 2.675 -> 2.68.
    nudge = math.copysign(abs(scaled) * 1e-12 + 1e-12, scaled)
    return math.floor(abs(scaled + nudge) + 0.5) * math.copysign(1.0, scaled) / factor
