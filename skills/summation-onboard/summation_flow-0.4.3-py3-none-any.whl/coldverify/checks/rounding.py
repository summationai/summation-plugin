"""Family 5 — rounding (``rnd_``).

Rounding defects are the ones that survive every other check, because the numbers
all agree with each other. What fails is the *display*: a value of 49.6 shown as
50 next to a claim that a 50 target was met, or a total shown to two decimals when
its inputs only justify one.

This family also audits the extractor's own envelope field, because if
``rounding_envelope`` is wrong then every arithmetic check downstream is wrong in
the same direction.
"""

from __future__ import annotations

import re

from ..envelope import percent_change_band, rounds_to, sum_band, within
from ..findings import CheckContext, Finding, check, make_finding
from ..ledger import Claim
from ..pairing import column_groups

METRIC_LAYER = "metric_layer"

ATTAINMENT_RE = re.compile(
    r"\b(met|meets|hit|hits|reached|reaches|achieved|achieves|exceeded|exceeds|"
    r"at or above|on plan|delivered against)\b",
    re.IGNORECASE,
)
TARGET_LABEL_RE = re.compile(r"target|goal|plan|threshold|budget|forecast", re.IGNORECASE)


def _fmt(value: float | None) -> str:
    if value is None:
        return "unknown"
    return f"{value:,.4f}".rstrip("0").rstrip(".") or "0"


@check(
    "rnd_envelope_inconsistent",
    "The extractor's declared rounding envelope does not follow from the displayed "
    "precision and scale.",
)
def rnd_envelope_inconsistent(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        declared = claim.declared_envelope
        computed = claim.computed_envelope
        if declared is None or computed is None:
            continue
        if computed == 0:
            continue
        if abs(declared - computed) <= max(1e-9, abs(computed) * 1e-6):
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "rnd_envelope_inconsistent",
                [claim],
                "medium",
                f"{claim.claim_id} declares a rounding envelope of {_fmt(declared)} but its "
                f"precision of {claim.displayed_precision} at scale {claim.scale!r} gives "
                f"{_fmt(computed)}; every tolerance built on this claim is "
                f"{'too loose' if declared > computed else 'too tight'} by a factor of "
                f"{_fmt(declared / computed)}.",
                evidence_class="structural",
                detail={
                    "declared_envelope": declared,
                    "computed_envelope": computed,
                    "displayed_precision": claim.displayed_precision,
                    "scale": claim.scale,
                },
            )
        )
    return findings


@check(
    "rnd_precision_indeterminable",
    "A figure has no displayed precision, so no tolerance band can be built for it.",
)
def rnd_precision_indeterminable(ctx: CheckContext) -> list[Finding]:
    offenders = [c for c in ctx.ledger.claims if c.displayed_precision is None]
    if not offenders:
        return []
    ctx.touched(*offenders)
    return [
        make_finding(
            "rnd_precision_indeterminable",
            offenders,
            "low",
            f"{len(offenders)} figures carry no displayed precision, so every arithmetic check "
            f"touching them degrades to unchecked rather than passing.",
            evidence_class="coverage",
            precision_sensitive=True,
            detail={"claim_ids": [c.claim_id for c in offenders]},
        )
    ]


def _targets_for(ctx: CheckContext, claim: Claim) -> list[Claim]:
    """Target-like claims a value can honestly be tested against."""
    out = []
    for other in ctx.ledger.claims:
        if other.claim_id == claim.claim_id or other.value_parsed is None:
            continue
        is_target = TARGET_LABEL_RE.search(other.metric_label or "") or TARGET_LABEL_RE.search(
            other.column_label or ""
        ) or (other.comparison or {}).get("base") in ("target", "plan", "budget", "forecast")
        if not is_target:
            continue
        if other.unit != claim.unit:
            continue
        same_row = claim.table_id is not None and other.table_id == claim.table_id and other.row_label == claim.row_label
        same_metric = other.label_key() == claim.label_key() or claim.label_key() in (other.label_key() or "")
        if same_row or same_metric:
            out.append(other)
    return out


@check(
    "rnd_threshold_crossing",
    "A value below a threshold is displayed as a number that reaches it, so the display "
    "asserts an attainment the value does not support.",
    overturnable_by=METRIC_LAYER,
)
def rnd_threshold_crossing(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.value_parsed is None or claim.displayed_precision is None:
            continue
        shown = claim.display_digits
        factor = claim.scale_factor or 1.0
        if shown is None:
            continue
        shown_value = shown * factor
        for target in _targets_for(ctx, claim):
            target_value = target.value_parsed
            if target_value is None:
                continue
            actually_met = claim.value_parsed >= target_value
            display_met = shown_value >= target_value or rounds_to(
                claim.value_parsed, claim.displayed_precision
            ) * (factor if claim.scale not in (None, "ones") else 1.0) >= target_value
            if actually_met or not display_met:
                continue
            ctx.touched(claim, target)
            sentences = [claim.sentence] + [
                b.text for b in ctx.ledger.blocks_for(claim.claim_id)
            ]
            asserted = any(ATTAINMENT_RE.search(s or "") for s in sentences)
            severity = "high" if asserted else "medium"
            extra = (
                " The prose states the target was met."
                if asserted
                else " No prose asserts attainment, but the rendered figure does."
            )
            findings.append(
                make_finding(
                    "rnd_threshold_crossing",
                    [claim, target],
                    severity,
                    f"{claim.metric_label or claim.claim_id} is {_fmt(claim.value_parsed)} against "
                    f"a {target.metric_label or 'target'} of {target.value_displayed}, so the "
                    f"target was missed, but it is displayed as {claim.value_displayed}, which "
                    f"reads as reaching it.{extra}",
                    evidence_class="display",
                    overturnable_by=METRIC_LAYER,
                    precision_sensitive=True,
                    detail={
                        "value_parsed": claim.value_parsed,
                        "value_displayed": claim.value_displayed,
                        "target": target_value,
                        "prose_asserts_attainment": asserted,
                    },
                )
            )
    return findings


@check(
    "rnd_display_disagrees_with_value",
    "Rounding the parsed value at its own displayed precision does not reproduce the "
    "rendered figure.",
)
def rnd_display_disagrees_with_value(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.value_parsed is None or claim.displayed_precision is None:
            continue
        shown = claim.display_digits
        if shown is None:
            continue
        factor = claim.scale_factor or 1.0
        # Work in display units: divide the parsed value back down by the scale.
        in_display_units = claim.value_parsed / factor
        expected_display = rounds_to(in_display_units, claim.displayed_precision)
        tolerance = 0.5 * (10.0**-claim.displayed_precision) * 1.000001
        if abs(expected_display - shown) <= tolerance:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "rnd_display_disagrees_with_value",
                [claim],
                "high",
                f"{claim.metric_label or claim.claim_id} renders as {claim.value_displayed} but its "
                f"value {_fmt(claim.value_parsed)} rounds to {_fmt(expected_display)} at the "
                f"precision shown: the figure on the page is not the figure in the data.",
                evidence_class="display",
                precision_sensitive=True,
                scale_sensitive=True,
                detail={
                    "value_parsed": claim.value_parsed,
                    "display_digits": shown,
                    "expected_display": expected_display,
                    "displayed_precision": claim.displayed_precision,
                },
            )
        )
    return findings


@check(
    "rnd_precision_exceeds_components",
    "A total is displayed to a finer precision than any of its components, claiming "
    "accuracy its inputs do not carry.",
    overturnable_by=METRIC_LAYER,
)
def rnd_precision_exceeds_components(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in ctx.ledger.claims:
        if total.role not in ("total", "subtotal") or not total.aggregates_claims:
            continue
        parts = ctx.ledger.resolve(total.aggregates_claims)
        precisions = [p.displayed_precision for p in parts if p.displayed_precision is not None]
        if not precisions or total.displayed_precision is None:
            continue
        if total.displayed_precision <= max(precisions):
            continue
        ctx.touched(total, *parts)
        findings.append(
            make_finding(
                "rnd_precision_exceeds_components",
                [total] + parts,
                "medium",
                f"{total.metric_label or total.claim_id} is shown to "
                f"{total.displayed_precision} decimals while its components are shown to at most "
                f"{max(precisions)}, so the trailing digits of the total are not supported by "
                f"anything on the page.",
                evidence_class="declared_metadata",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={
                    "total_precision": total.displayed_precision,
                    "max_component_precision": max(precisions),
                },
            )
        )
    return findings


@check(
    "rnd_inconsistent_precision_in_column",
    "One table column shows the same unit at more than one precision.",
)
def rnd_inconsistent_precision_in_column(ctx: CheckContext) -> list[Finding]:
    findings = []
    for (table_id, column_label), claims in sorted(
        column_groups(ctx.ledger).items(), key=lambda kv: (kv[0][0], kv[0][1] or "")
    ):
        by_unit: dict[str, set[int]] = {}
        for claim in claims:
            if claim.displayed_precision is None or claim.unit in (None, "unknown"):
                continue
            by_unit.setdefault(claim.unit, set()).add(claim.displayed_precision)
        offending = {u: p for u, p in by_unit.items() if len(p) > 1}
        if not offending:
            continue
        ctx.touched(*claims)
        described = "; ".join(
            f"{unit} at {sorted(precisions)} decimals" for unit, precisions in sorted(offending.items())
        )
        findings.append(
            make_finding(
                "rnd_inconsistent_precision_in_column",
                claims,
                "low",
                f"column {column_label or '(unlabelled)'} of {table_id} shows {described}, so rows "
                f"cannot be compared at a single precision.",
                evidence_class="declared_metadata",
                detail={"precisions": {u: sorted(p) for u, p in offending.items()}},
            )
        )
    return findings


@check(
    "rnd_spurious_precision",
    "A count or a large-scale figure is shown to a precision the underlying quantity "
    "cannot have.",
)
def rnd_spurious_precision(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        precision = claim.displayed_precision
        if precision is None or precision == 0:
            continue
        reason = None
        if claim.unit == "count" and precision > 0:
            reason = f"a count shown to {precision} decimals"
        elif claim.unit in ("currency", "units") and claim.scale in ("millions", "billions") and precision >= 3:
            reason = f"a {claim.scale} figure shown to {precision} decimals"
        if reason is None:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "rnd_spurious_precision",
                [claim],
                "low",
                f"{claim.metric_label or claim.claim_id} is {reason} ({claim.value_displayed}), "
                f"which implies more accuracy than the quantity can carry.",
                evidence_class="declared_metadata",
                detail={"unit": claim.unit, "precision": precision, "scale": claim.scale},
            )
        )
    return findings


@check(
    "rnd_delta_below_resolution",
    "A stated change is smaller than the rounding envelope of the levels it was "
    "computed from, so it is noise from the display.",
    overturnable_by=METRIC_LAYER,
)
def rnd_delta_below_resolution(ctx: CheckContext) -> list[Finding]:
    from ..pairing import words_of
    from .arithmetic import _level_pair

    findings = []
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        if comparison.get("form") not in ("absolute_delta", "point_change", "percent_change"):
            continue
        if claim.value_parsed is None:
            continue
        if words_of(claim):
            # dir_moved_but_zero owns the case where prose asserts a movement.
            continue
        levels = _level_pair(ctx, claim)
        if levels is None:
            continue
        old, new = levels
        # The band must be in the same units as the stated change. Summing two
        # currency envelopes and comparing the result to a percentage reported
        # that "−10.4% is inside the 10,000 the display can hide", which is
        # comparing dollars to percent.
        if comparison.get("form") == "percent_change":
            band = percent_change_band(
                new.value_parsed or 0.0, new.envelope,
                old.value_parsed or 0.0, old.envelope,
                claim.envelope,
            )
        else:
            band = sum_band([old.envelope, new.envelope, claim.envelope])
        if band is None:
            continue
        if not within(claim.value_parsed, band):
            continue
        if claim.value_parsed == 0:
            continue
        ctx.touched(claim, old, new)
        findings.append(
            make_finding(
                "rnd_delta_below_resolution",
                [claim, new, old],
                "medium",
                f"the change of {claim.value_displayed} in "
                f"{claim.metric_label or claim.claim_id} is inside the {_fmt(band)} that the "
                f"levels' own display precision can hide, so the document cannot tell this move "
                f"from no move.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={"stated_delta": claim.value_parsed, "band": band},
            )
        )
    return findings
