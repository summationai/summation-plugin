"""Family 8 — template hygiene (``tpl_``).

Everything here is evidence that a document was produced from a template that was
not fully filled, or was carried forward from a previous period without being
updated. These are the cheapest defects to find and the most embarrassing to ship,
because a reader spots them instantly and then distrusts every other number.
"""

from __future__ import annotations

import re

from ..findings import CheckContext, Finding, check, make_finding

PLACEHOLDER_PATTERNS = [
    # Token placeholders, ordered longest-delimiter first so a `{{var}}` is not
    # also reported as a `{var}`. `__NAME__` is the style a mail-merge or an
    # environment substitution leaves behind, and it was the one this library
    # originally missed: `__PLANNER_EMAIL__` shipped in a real footnote.
    (r"__[A-Za-z][A-Za-z0-9_]*__", "an unsubstituted token placeholder"),
    (r"<<[^<>\n]{1,60}>>", "an unsubstituted angle placeholder"),
    (r"\[\[[^\]\n]{1,60}\]\]", "an unsubstituted bracket placeholder"),
    (r"@@[A-Za-z0-9_]{1,60}@@", "an unsubstituted at-placeholder"),
    (r"\$\{[^}\n]{1,60}\}", "an unsubstituted shell placeholder"),
    (r"%\([A-Za-z0-9_]{1,60}\)s", "an unsubstituted format placeholder"),
    (r"«[^»\n]{1,60}»", "an unsubstituted merge field"),
    (r"\b(?:REPLACE_ME|CHANGEME|CHANGE_ME|FILL_?ME|YOUR_[A-Z_]+)\b", "a replace-me marker"),
    (r"\bTODO\b", "a TODO marker"),
    (r"\bTBD\b", "a TBD marker"),
    (r"\bTK\b", "a TK marker"),
    (r"\bFIXME\b", "a FIXME marker"),
    (r"X{3,}", "an XXX placeholder"),
    (r"\{\{.*?\}\}", "an unrendered template variable"),
    (r"\{[a-z_][a-z0-9_]*\}", "an unrendered format placeholder"),
    (r"<insert[^>]*>", "an insert-here placeholder"),
    (r"\[insert[^\]]*\]", "an insert-here placeholder"),
    (r"lorem ipsum", "lorem ipsum filler"),
    (r"\bplaceholder\b", "the word placeholder"),
    (r"\$X\b", "a currency placeholder"),
    (r"\bN/A%", "an unfilled percentage"),
    (r"\bnan\b", "a NaN leak"),
]

SPREADSHEET_ERRORS = [
    "#REF!", "#DIV/0!", "#VALUE!", "#NAME?", "#N/A", "#NULL!", "#NUM!", "#SPILL!",
]

EMPTY_DISPLAYS = {"", "-", "--", "–", "—", "n/a", "na", "null", "none", "nan", "?", "tbd"}

PERIOD_LIKE_RE = re.compile(
    r"\b(?:week\s+\d{1,2}|w\d{1,2}|fy\d{2,4}|q[1-4]\s*(?:fy)?\d{0,4}|"
    r"january|february|march|april|may|june|july|august|september|october|november|december)\b",
    re.IGNORECASE,
)


def _normalise(text: str) -> str:
    return re.sub(r"\s+", " ", (text or "").strip().lower())


@check(
    "tpl_placeholder_text",
    "Placeholder or template markup survived into the delivered document.",
)
def tpl_placeholder_text(ctx: CheckContext) -> list[Finding]:
    findings = []
    scanned: list[tuple[str, str, list]] = []
    for block in ctx.ledger.prose_blocks:
        scanned.append((f"prose block {block.block_id}", block.text, ctx.ledger.resolve(block.claim_ids)))
    for claim in ctx.ledger.claims:
        scanned.append((f"{claim.claim_id} metric label", claim.metric_label, [claim]))
        scanned.append((f"{claim.claim_id} value", claim.value_displayed, [claim]))
        if claim.sentence:
            scanned.append((f"{claim.claim_id} sentence", claim.sentence, [claim]))
    for table in ctx.ledger.tables:
        scanned.append((f"{table.table_id} caption", table.caption, []))

    for where, text, claims in scanned:
        if not text:
            continue
        for pattern, description in PLACEHOLDER_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match is None:
                continue
            ctx.touched(*claims)
            findings.append(
                make_finding(
                    "tpl_placeholder_text",
                    claims,
                    "high",
                    f"{where} still contains {description} ({match.group(0)!r}), so the document "
                    f"was delivered before the template was filled.",
                    evidence_class="display",
                    detail={"where": where, "match": match.group(0), "pattern": pattern},
                    location=where,
                )
            )
            # One placeholder report per location. A `{{var}}` also matches the
            # single-brace pattern, and telling the reader twice is noise.
            break
    return findings


@check(
    "tpl_spreadsheet_error_value",
    "A spreadsheet error string was rendered as a figure.",
)
def tpl_spreadsheet_error_value(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        text = (claim.value_displayed or "").strip().upper()
        hit = next((err for err in SPREADSHEET_ERRORS if err in text), None)
        if hit is None:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "tpl_spreadsheet_error_value",
                [claim],
                "high",
                f"{claim.metric_label or claim.claim_id} renders as {claim.value_displayed!r}, a "
                f"spreadsheet error, so the underlying calculation failed and was published "
                f"anyway.",
                evidence_class="display",
                detail={"value_displayed": claim.value_displayed, "error": hit},
            )
        )
    return findings


@check(
    "tpl_empty_value_rendered",
    "A figure position renders as a dash, blank or n/a rather than a number.",
)
def tpl_empty_value_rendered(ctx: CheckContext) -> list[Finding]:
    findings = []
    offenders = [
        c
        for c in ctx.ledger.claims
        if _normalise(c.value_displayed) in EMPTY_DISPLAYS
    ]
    if not offenders:
        return []
    ctx.touched(*offenders)
    # A blank cell is ambiguous, not wrong. Real reports legitimately leave a
    # prior-year column empty for a line that did not exist last year, so 17 of them
    # is a coverage note about the document's readability — one note — rather than 17
    # defects. An *entire* blank row is a different thing and belongs to
    # tpl_empty_table_row, which reports it as a defect.
    columns = sorted({f"{c.table_id}/{c.column_label}" for c in offenders if c.table_id})
    return [
        make_finding(
            "tpl_empty_value_rendered",
            offenders[:5],
            "low",
            f"{len(offenders)} figure positions render as a dash, blank or n/a rather than a "
            f"number"
            + (f" (in {', '.join(columns[:4])})" if columns else "")
            + ", so a reader cannot tell a zero from missing data in them.",
            evidence_class="display",
            detail={
                "aggregate_key": "empty_value_positions",
                "affected_claim_count": len(offenders),
                "affected_claim_ids": [c.claim_id for c in offenders[:200]],
                "columns": columns,
            },
        )
    ]


@check(
    "tpl_stale_period_reference",
    "Prose names a period that no figure in the document covers, which is the signature "
    "of text carried over from a previous run.",
)
def tpl_stale_period_reference(ctx: CheckContext) -> list[Finding]:
    findings = []
    known = {_normalise(c.period_label) for c in ctx.ledger.claims if c.period_label}
    known.add(_normalise(ctx.ledger.source_period_label))
    for claim in ctx.ledger.claims:
        base_label = (claim.comparison or {}).get("base_label")
        if base_label:
            known.add(_normalise(base_label))
    known.discard("")
    known_text = " | ".join(known)
    for block in ctx.ledger.prose_blocks:
        mentions = {m.group(0) for m in PERIOD_LIKE_RE.finditer(block.text)}
        stale = sorted(
            m for m in mentions if _normalise(m) not in known and _normalise(m) not in known_text
        )
        if not stale:
            continue
        linked = ctx.ledger.resolve(block.claim_ids)
        ctx.touched(*linked)
        findings.append(
            make_finding(
                "tpl_stale_period_reference",
                linked,
                "medium",
                f"prose block {block.block_id} refers to {', '.join(stale)}, which no figure in "
                f"this document covers; the periods present are "
                f"{', '.join(sorted(k for k in known if k)) or 'none'}.",
                evidence_class="textual",
                detail={
                    "block_id": block.block_id,
                    "stale_mentions": stale,
                    "known_periods": sorted(k for k in known if k),
                },
                location=block.section or block.block_id,
            )
        )
    return findings


@check(
    "tpl_duplicate_prose_block",
    "Two prose blocks carry identical text.",
)
def tpl_duplicate_prose_block(ctx: CheckContext) -> list[Finding]:
    findings = []
    seen: dict[str, str] = {}
    for block in ctx.ledger.prose_blocks:
        key = _normalise(block.text)
        if len(key) < 20:
            continue
        if key in seen:
            findings.append(
                make_finding(
                    "tpl_duplicate_prose_block",
                    [],
                    "medium",
                    f"prose blocks {seen[key]} and {block.block_id} carry identical text, so one "
                    f"section was copied and not rewritten.",
                    evidence_class="structural",
                    detail={"blocks": [seen[key], block.block_id]},
                    location=block.section or block.block_id,
                )
            )
            continue
        seen[key] = block.block_id
    return findings


@check(
    "tpl_duplicate_location",
    "Two claims occupy the same table cell, so the extraction or the document has a "
    "duplicated figure.",
)
def tpl_duplicate_location(ctx: CheckContext) -> list[Finding]:
    findings = []
    seen: dict[tuple, str] = {}
    for claim in ctx.ledger.claims:
        if claim.table_id is None:
            continue
        if claim.row_index is None or claim.location.get("column_index") is None:
            continue
        # Keyed by the rendered value as well as the position. A cell reading
        # "$72,853 at 63.1% margin" holds two different figures at one position and
        # is perfectly ordinary; two claims carrying the *same* rendered value there
        # is a duplication.
        key = (
            claim.table_id,
            claim.row_index,
            claim.location.get("column_index"),
            _normalise(claim.value_displayed),
        )
        if key in seen:
            other = ctx.ledger.get(seen[key])
            participants = [c for c in (other, claim) if c is not None]
            ctx.touched(*participants)
            findings.append(
                make_finding(
                    "tpl_duplicate_location",
                    participants,
                    "medium",
                    f"{seen[key]} and {claim.claim_id} both sit at {claim.table_id} row "
                    f"{claim.row_index}, column {claim.location.get('column_index')} carrying the "
                    f"same value {claim.value_displayed!r}, so one figure is recorded twice.",
                    evidence_class="structural",
                    detail={"location": list(key)},
                )
            )
            continue
        seen[key] = claim.claim_id
    return findings


@check(
    "tpl_repeated_sentence_across_sections",
    "The same sentence appears in more than one section.",
)
def tpl_repeated_sentence_across_sections(ctx: CheckContext) -> list[Finding]:
    findings = []
    sentences: dict[str, set[str]] = {}
    for block in ctx.ledger.prose_blocks:
        for raw in re.split(r"(?<=[.!?])\s+", block.text):
            key = _normalise(raw)
            if len(key) < 30:
                continue
            sentences.setdefault(key, set()).add(block.section or block.block_id)
    for key, sections in sorted(sentences.items()):
        if len(sections) < 2:
            continue
        findings.append(
            make_finding(
                "tpl_repeated_sentence_across_sections",
                [],
                "low",
                f"the sentence {key[:70]!r} appears in {len(sections)} sections "
                f"({', '.join(sorted(sections))}), which reads as boilerplate rather than "
                f"analysis.",
                evidence_class="textual",
                detail={"sections": sorted(sections)},
            )
        )
    return findings


@check(
    "tpl_extraction_report_incomplete",
    "The extraction report omits a coverage field, so what the extractor attempted "
    "cannot be told from what it found.",
)
def tpl_extraction_report_incomplete(ctx: CheckContext) -> list[Finding]:
    report = ctx.ledger.extraction_report
    expected = [
        "tables_found",
        "charts_found",
        "charts_unreadable",
        "prose_blocks_found",
        "precision_indeterminable",
        "unit_unknown",
        "scale_inferred",
        "checkable_fraction",
    ]
    missing = [field for field in expected if report.get(field) is None]
    if not missing:
        return []
    return [
        make_finding(
            "tpl_extraction_report_incomplete",
            [],
            "low",
            f"the extraction report omits {', '.join(missing)}, so the run cannot distinguish a "
            f"detector that found nothing from one that never ran.",
            evidence_class="coverage",
            detail={"missing_fields": missing},
            location="extraction_report",
        )
    ]


@check(
    "tpl_detector_error_recorded",
    "An extraction detector reported an error or an unsupported format, so part of the "
    "document was never read.",
)
def tpl_detector_error_recorded(ctx: CheckContext) -> list[Finding]:
    findings = []
    detectors = ctx.ledger.extraction_report.get("detectors_run", []) or []
    for detector in detectors:
        if detector.get("outcome") != "error":
            continue
        findings.append(
            make_finding(
                "tpl_detector_error_recorded",
                [],
                "medium",
                f"the {detector.get('name')!r} detector finished with an error"
                + (f" ({detector.get('detail')})" if detector.get("detail") else "")
                + ", so whatever it covers is unchecked rather than clean.",
                evidence_class="coverage",
                detail=dict(detector),
                location="extraction_report",
            )
        )
    # `unsupported_format` on an HTML input means the OCR, PDF and spreadsheet passes
    # correctly declined to run. That is the detector working, not a gap in coverage,
    # so it is one low note naming them rather than one medium finding each.
    inapplicable = [d for d in detectors if d.get("outcome") == "unsupported_format"]
    if inapplicable:
        findings.append(
            make_finding(
                "tpl_detector_error_recorded",
                [],
                "low",
                f"{len(inapplicable)} extraction pass(es) do not apply to a "
                f"{ctx.ledger.source_format or 'this'} document "
                f"({', '.join(sorted(str(d.get('name')) for d in inapplicable))}), which is "
                f"expected and is recorded so the run's coverage can be read in full.",
                evidence_class="coverage",
                detail={
                    "aggregate_key": "detectors_inapplicable_to_this_format",
                    "detectors": [d.get("name") for d in inapplicable],
                    "source_format": ctx.ledger.source_format,
                },
                location="extraction_report",
            )
        )
    return findings


@check(
    "tpl_unreadable_charts",
    "Charts in the document could not be read, so their figures are outside every check.",
)
def tpl_unreadable_charts(ctx: CheckContext) -> list[Finding]:
    report = ctx.ledger.extraction_report
    unreadable = report.get("charts_unreadable")
    if not unreadable:
        return []
    found = report.get("charts_found")
    return [
        make_finding(
            "tpl_unreadable_charts",
            [],
            "medium",
            f"{unreadable} of {found if found is not None else 'an unknown number of'} charts "
            f"could not be read, so any figure that appears only in a chart is unchecked.",
            evidence_class="coverage",
            detail={"charts_unreadable": unreadable, "charts_found": found},
            location="extraction_report",
        )
    ]


@check(
    "tpl_empty_table_row",
    "A table row carries no values at all beyond its own row number, so it is an "
    "unfilled template row that shipped.",
)
def tpl_empty_table_row(ctx: CheckContext) -> list[Finding]:
    """Rows whose only content is their index.

    The defect a reader meets is "row 7 of the action table is blank", not "one
    cell renders as an em dash". Reporting the row is both the truer statement and
    the one that points at the fix, and it keeps the row-number claim — which is
    the only populated cell — inside the finding's evidence.
    """
    findings = []
    rows: dict[tuple, list] = {}
    for claim in ctx.ledger.claims:
        if claim.table_id is None:
            continue
        key = (claim.table_id, claim.row_label or claim.row_index)
        rows.setdefault(key, []).append(claim)

    for (table_id, row), claims in sorted(rows.items(), key=lambda kv: (kv[0][0], str(kv[0][1]))):
        if len(claims) < 2:
            continue
        indices = [c for c in claims if c.role in ("rank", "count") or c.column_label in ("#", "No", "No.")]
        values = [c for c in claims if c not in indices]
        if not indices or not values:
            continue
        empty = [
            c
            for c in values
            if c.value_parsed is None or _normalise(c.value_displayed) in EMPTY_DISPLAYS
        ]
        if len(empty) != len(values):
            continue
        ctx.touched(*claims)
        findings.append(
            make_finding(
                "tpl_empty_table_row",
                indices + empty,
                "medium",
                f"row {row!r} of {table_id} carries a row number but every value cell in it is "
                f"empty ({', '.join(sorted({c.value_displayed or '(blank)' for c in empty}))}), so "
                f"an unfilled template row shipped with the document.",
                evidence_class="structural",
                detail={
                    "table_id": table_id,
                    "row": row,
                    "empty_cells": [c.claim_id for c in empty],
                    "index_cells": [c.claim_id for c in indices],
                },
                location=table_id,
            )
        )
    return findings
