"""Family 4 — units and scale (``uni_``).

The schema is explicit: "percent and points are DIFFERENT units. Conflating them
is the most common defect in analyst prose." A margin moving from 40% to 43% grew
three *points*, or seven and a half *percent*. "Grew three percent" is wrong, and
it is wrong in a way that survives every arithmetic check, because the number
three is genuinely present in the data.

The second half of this family is scale: whether values honour the scale their
header declares. The schema says that is "a check, not an assumption".
"""

from __future__ import annotations

import re

from ..envelope import sum_band, within
from ..findings import CheckContext, Finding, check, make_finding
from ..ledger import Claim, metric_family_key
from .arithmetic import levels_behind

METRIC_LAYER = "metric_layer"

PERCENT_WORD_RE = re.compile(r"\bper\s?cent\b|\bpercent\b|%", re.IGNORECASE)
POINT_WORD_RE = re.compile(r"\bpoints?\b|\bppt\b|\bpps\b|\bbasis points?\b|\bbps?\b", re.IGNORECASE)
PERCENT_UNITS = {"percent", "points", "basis_points"}
SCALE_SUFFIX = {
    "k": 1e3,
    "m": 1e6,
    "mm": 1e6,
    "b": 1e9,
    "bn": 1e9,
    "thousand": 1e3,
    "million": 1e6,
    "billion": 1e9,
}


def _fmt(value: float | None) -> str:
    if value is None:
        return "unknown"
    return f"{value:,.4f}".rstrip("0").rstrip(".") or "0"


def _suffix_factor(displayed: str) -> float | None:
    text = (displayed or "").strip().lower()
    match = re.search(r"([a-z]+)\s*$", text)
    if not match:
        return None
    return SCALE_SUFFIX.get(match.group(1))


@check(
    "uni_percent_vs_points",
    "A move in a percent-unit metric is stated as a percent change when it is a point "
    "change, or the reverse.",
    overturnable_by=METRIC_LAYER,
)
def uni_percent_vs_points(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        form = comparison.get("form")
        if form not in ("percent_change", "point_change"):
            continue
        if claim.value_parsed is None:
            continue

        pair = levels_behind(ctx, claim)
        if pair is None:
            ctx.skip(
                "uni_percent_vs_points",
                "the two levels behind this change are not both resolvable, so the point "
                "change and the percent change cannot be told apart",
                [claim.claim_id],
            )
            continue
        old, new = pair
        if old.unit not in PERCENT_UNITS or new.unit not in PERCENT_UNITS:
            continue
        if old.value_parsed in (None, 0):
            continue
        ctx.touched(claim, old, new)

        point_change = (new.value_parsed or 0.0) - (old.value_parsed or 0.0)
        percent_change = 100.0 * point_change / (old.value_parsed or 1.0)
        band = claim.envelope
        matches_points = within(claim.value_parsed - point_change, band)
        matches_percent = within(claim.value_parsed - percent_change, band)

        # The stated number matching the point change while being *labelled* a
        # percent change is the classic defect.
        sentence_says_percent = bool(PERCENT_WORD_RE.search(claim.sentence)) and not POINT_WORD_RE.search(
            claim.sentence
        )
        sentence_says_points = bool(POINT_WORD_RE.search(claim.sentence))

        labelled_percent = form == "percent_change" or (claim.unit == "percent" and sentence_says_percent)
        labelled_points = form == "point_change" or claim.unit in ("points", "basis_points") or sentence_says_points

        if matches_points and not matches_percent and labelled_percent and not sentence_says_points:
            findings.append(
                make_finding(
                    "uni_percent_vs_points",
                    [claim, new, old],
                    "high",
                    f"{claim.metric_label or claim.claim_id} is described as a "
                    f"{claim.value_displayed} percent change, but moving from "
                    f"{old.value_displayed} to {new.value_displayed} is "
                    f"{_fmt(point_change)} percentage points, which is "
                    f"{_fmt(percent_change)} percent. Percent and points are different units.",
                    evidence_class="structural",
                    overturnable_by=METRIC_LAYER,
                    detail={
                        "stated": claim.value_parsed,
                        "point_change": point_change,
                        "percent_change": percent_change,
                        "form": form,
                    },
                )
            )
        elif matches_percent and not matches_points and labelled_points and not sentence_says_percent:
            findings.append(
                make_finding(
                    "uni_percent_vs_points",
                    [claim, new, old],
                    "high",
                    f"{claim.metric_label or claim.claim_id} is described as a "
                    f"{claim.value_displayed} point change, but the move from "
                    f"{old.value_displayed} to {new.value_displayed} is "
                    f"{_fmt(point_change)} points; {_fmt(percent_change)} is the percent change.",
                    evidence_class="structural",
                    overturnable_by=METRIC_LAYER,
                    detail={
                        "stated": claim.value_parsed,
                        "point_change": point_change,
                        "percent_change": percent_change,
                        "form": form,
                    },
                )
            )
    return findings


@check(
    "uni_unit_form_mismatch",
    "A claim's unit and its comparison form disagree: a percent unit carrying a point "
    "change, or a points unit carrying a percent change.",
    overturnable_by=METRIC_LAYER,
)
def uni_unit_form_mismatch(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        form = comparison.get("form")
        if form is None:
            continue
        bad = (claim.unit == "percent" and form == "point_change") or (
            claim.unit in ("points", "basis_points") and form == "percent_change"
        )
        if not bad:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "uni_unit_form_mismatch",
                [claim],
                "medium",
                f"{claim.metric_label or claim.claim_id} is recorded with unit {claim.unit!r} but "
                f"comparison form {form!r}; a reader cannot tell whether "
                f"{claim.value_displayed} means percent or points.",
                evidence_class="declared_metadata",
                overturnable_by=METRIC_LAYER,
                detail={"unit": claim.unit, "form": form},
            )
        )
    return findings


@check(
    "uni_scale_not_honoured",
    "The rendered digits multiplied by the declared scale do not give the parsed value.",
)
def uni_scale_not_honoured(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.value_parsed is None:
            continue
        digits = claim.display_digits
        factor = claim.scale_factor
        if digits is None or factor is None:
            if factor is None:
                ctx.skip(
                    "uni_scale_not_honoured",
                    f"scale {claim.scale!r} has no known factor, so the declared scale "
                    f"cannot be tested against the value",
                    [claim.claim_id],
                )
            continue
        # An inline suffix carries its own scale; honour it over the declared one.
        suffix = _suffix_factor(claim.value_displayed)
        effective = suffix if suffix is not None else factor
        expected = digits * effective
        band = claim.computed_envelope
        if band is None:
            continue
        if within(claim.value_parsed - expected, band):
            continue
        # Only report this as a *scale* defect when the gap is a scale factor. A
        # sub-unit gap between the glyphs and the value is a rounding defect and
        # belongs to rnd_display_disagrees_with_value; claiming it here would put
        # the finding in the wrong family and mislead the reader about the fix.
        if expected == 0:
            continue
        ratio = claim.value_parsed / expected
        if not any(
            abs(ratio - factor) <= abs(factor) * 0.01
            for factor in (1e-9, 1e-6, 1e-3, 1e3, 1e6, 1e9)
        ):
            ctx.skip(
                "uni_scale_not_honoured",
                "the glyphs and the value disagree, but not by a scale factor; "
                "rnd_display_disagrees_with_value owns that case",
                [claim.claim_id],
            )
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "uni_scale_not_honoured",
                [claim],
                "high",
                f"{claim.metric_label or claim.claim_id} renders as {claim.value_displayed} with "
                f"scale {claim.scale!r}, which is {_fmt(expected)}, but the value carried through "
                f"the document is {_fmt(claim.value_parsed)}: a factor of "
                f"{_fmt(claim.value_parsed / expected) if expected else 'unknown'}.",
                evidence_class="display",
                scale_sensitive=True,
                detail={
                    "display_digits": digits,
                    "declared_scale": claim.scale,
                    "scale_factor": effective,
                    "expected": expected,
                    "value_parsed": claim.value_parsed,
                },
            )
        )
    return findings


@check(
    "uni_mixed_units_in_total",
    "A total sums components of more than one unit.",
    overturnable_by=METRIC_LAYER,
)
def uni_mixed_units_in_total(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in ctx.ledger.claims:
        if total.role not in ("total", "subtotal") or not total.aggregates_claims:
            continue
        parts = ctx.ledger.resolve(total.aggregates_claims)
        units = {p.unit for p in parts if p.unit is not None}
        if len(units) < 2:
            continue
        ctx.touched(total, *parts)
        findings.append(
            make_finding(
                "uni_mixed_units_in_total",
                [total] + parts,
                "high",
                f"{total.metric_label or total.claim_id} adds components of "
                f"{len(units)} different units ({', '.join(sorted(units))}), so the total has no "
                f"single meaning.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={"units": sorted(units)},
            )
        )
    return findings


@check(
    "uni_mixed_currency_in_total",
    "A currency total sums components in more than one currency.",
    overturnable_by=METRIC_LAYER,
)
def uni_mixed_currency_in_total(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in ctx.ledger.claims:
        if total.role not in ("total", "subtotal") or not total.aggregates_claims:
            continue
        parts = ctx.ledger.resolve(total.aggregates_claims)
        codes = {p.currency_code for p in parts if p.currency_code}
        if len(codes) < 2:
            continue
        ctx.touched(total, *parts)
        findings.append(
            make_finding(
                "uni_mixed_currency_in_total",
                [total] + parts,
                "high",
                f"{total.metric_label or total.claim_id} adds amounts in "
                f"{', '.join(sorted(codes))} without a stated conversion.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={"currencies": sorted(codes)},
            )
        )
    return findings


@check(
    "uni_currency_code_absent",
    "A currency figure carries no currency code.",
)
def uni_currency_code_absent(ctx: CheckContext) -> list[Finding]:
    offenders = [
        c for c in ctx.ledger.claims if c.unit == "currency" and not c.currency_code
    ]
    if not offenders:
        return []
    ctx.touched(*offenders)
    return [
        make_finding(
            "uni_currency_code_absent",
            offenders,
            "low",
            f"{len(offenders)} currency figures carry no currency code, so a reader outside the "
            f"author's market cannot tell what the amounts are in.",
            evidence_class="coverage",
            detail={"claim_ids": [c.claim_id for c in offenders]},
        )
    ]


@check(
    "uni_unit_unknown",
    "A figure's unit is unknown or absent, which puts it outside the unit checks.",
)
def uni_unit_unknown(ctx: CheckContext) -> list[Finding]:
    from ..pairing import is_caption_count

    # A number inside a caption — "Top 5 of 62" — is not a measured figure and has no
    # unit to record, so its absence is not a coverage gap in the document.
    offenders = [
        c
        for c in ctx.ledger.claims
        if c.unit in (None, "unknown") and not is_caption_count(c)
    ]
    if not offenders:
        return []
    ctx.touched(*offenders)
    return [
        make_finding(
            "uni_unit_unknown",
            offenders,
            "low",
            f"{len(offenders)} figures have no unit recorded, so unit and scale checks cannot "
            f"reach them.",
            evidence_class="coverage",
            detail={"claim_ids": [c.claim_id for c in offenders]},
        )
    ]


@check(
    "uni_scale_inferred",
    "A figure's scale came from its magnitude rather than from a declaration.",
)
def uni_scale_inferred(ctx: CheckContext) -> list[Finding]:
    offenders = [
        c
        for c in ctx.ledger.claims
        if c.scale not in (None, "ones", "unknown")
        and c.scale_source in ("inferred_from_magnitude", "absent", None)
    ]
    if not offenders:
        return []
    ctx.touched(*offenders)
    return [
        make_finding(
            "uni_scale_inferred",
            offenders,
            "low",
            f"{len(offenders)} figures carry a scale that was inferred rather than declared, so "
            f"every arithmetic result built on them inherits that assumption.",
            evidence_class="coverage",
            scale_sensitive=True,
            detail={"claim_ids": [c.claim_id for c in offenders]},
        )
    ]


@check(
    "uni_percent_symbol_vs_unit",
    "A percent sign is rendered on a figure whose unit is not a percentage, or the "
    "reverse.",
)
def uni_percent_symbol_vs_unit(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        # "five percent" and "2.4 pts" state their unit in words. Only a figure
        # with no unit marker at all is ambiguous to a reader.
        has_symbol = bool(
            "%" in (claim.value_displayed or "")
            or PERCENT_WORD_RE.search(claim.value_displayed or "")
            or POINT_WORD_RE.search(claim.value_displayed or "")
        )
        if claim.unit is None or claim.unit == "unknown":
            continue
        # Points and basis points are percent-adjacent: a percent sign on them is
        # acceptable shorthand, and its absence is correct. Only a bare `percent`
        # unit is expected to render one.
        if claim.unit in ("points", "basis_points"):
            continue
        is_percentish = claim.unit == "percent"
        if has_symbol == is_percentish:
            continue
        # A missing percent sign only misleads in prose. In a table cell or a KPI
        # tile the column header or the tile label carries the unit, so a bare
        # number there is a house style, not a defect.
        if not has_symbol and claim.loc_kind != "prose":
            continue
        if has_symbol and claim.unit == "ratio":
            severity, note = "medium", "a ratio rendered with a percent sign"
        elif has_symbol:
            severity, note = "medium", f"a {claim.unit} figure rendered with a percent sign"
        else:
            severity, note = "low", f"a {claim.unit} figure rendered without a percent sign"
        ctx.touched(claim)
        findings.append(
            make_finding(
                "uni_percent_symbol_vs_unit",
                [claim],
                severity,
                f"{claim.metric_label or claim.claim_id} is {note} ({claim.value_displayed}), so "
                f"the magnitude a reader takes from it may be a hundred times out.",
                evidence_class="display",
                detail={"unit": claim.unit, "value_displayed": claim.value_displayed},
            )
        )
    return findings


@check(
    "uni_basis_points_magnitude",
    "A basis-points figure has a magnitude that reads as percent, or a percent figure "
    "has a magnitude that reads as basis points.",
)
def uni_basis_points_magnitude(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.value_parsed is None:
            continue
        value = abs(claim.value_parsed)
        if claim.unit == "basis_points" and value <= 5 and value != 0:
            statement = (
                f"{claim.metric_label or claim.claim_id} is recorded in basis points but shows "
                f"{claim.value_displayed}; {_fmt(value)} basis points is "
                f"{_fmt(value / 100.0)} of a percentage point, which is very likely a percent "
                f"figure mislabelled."
            )
        elif claim.unit == "percent" and value > 1000:
            statement = (
                f"{claim.metric_label or claim.claim_id} is recorded as a percent but shows "
                f"{claim.value_displayed}; a value above 1000% is more likely basis points."
            )
        else:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "uni_basis_points_magnitude",
                [claim],
                "medium",
                statement,
                evidence_class="heuristic",
                detail={"unit": claim.unit, "value_parsed": claim.value_parsed},
            )
        )
    return findings


@check(
    "uni_ratio_rendered_as_percent",
    "A ratio between 0 and 1 is rendered as if it were already a percentage.",
)
def uni_ratio_rendered_as_percent(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.unit != "ratio" or claim.value_parsed is None:
            continue
        if not (0 < abs(claim.value_parsed) < 1):
            continue
        if "%" not in (claim.value_displayed or ""):
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "uni_ratio_rendered_as_percent",
                [claim],
                "medium",
                f"{claim.metric_label or claim.claim_id} holds the ratio "
                f"{_fmt(claim.value_parsed)} but renders as {claim.value_displayed}: the value "
                f"needs multiplying by 100 before it carries a percent sign.",
                evidence_class="display",
                detail={"value_parsed": claim.value_parsed},
            )
        )
    return findings


@check(
    "uni_magnitude_vs_declared_scale",
    "A figure declares a large scale but carries a value too small for that scale to "
    "have been applied.",
)
def uni_magnitude_vs_declared_scale(ctx: CheckContext) -> list[Finding]:
    findings = []
    thresholds = {"thousands": 1e2, "millions": 1e4, "billions": 1e7}
    for claim in ctx.ledger.claims:
        if claim.value_parsed is None or claim.scale not in thresholds:
            continue
        if abs(claim.value_parsed) == 0:
            continue
        if abs(claim.value_parsed) >= thresholds[claim.scale]:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "uni_magnitude_vs_declared_scale",
                [claim],
                "medium",
                f"{claim.metric_label or claim.claim_id} declares scale {claim.scale!r} but its "
                f"value is {_fmt(claim.value_parsed)}, which is too small for the scale to have "
                f"been applied.",
                evidence_class="heuristic",
                scale_sensitive=True,
                detail={"scale": claim.scale, "value_parsed": claim.value_parsed},
            )
        )
    return findings


def _unit_of(claim: Claim) -> str:
    return claim.unit or "unknown"


@check(
    "uni_mixed_units_in_column",
    "One table column mixes units, so its values cannot be read against each other.",
)
def uni_mixed_units_in_column(ctx: CheckContext) -> list[Finding]:
    from ..pairing import column_groups

    findings = []
    for (table_id, column_label), claims in sorted(
        column_groups(ctx.ledger).items(), key=lambda kv: (kv[0][0], kv[0][1] or "")
    ):
        units = {_unit_of(c) for c in claims if c.unit not in (None, "unknown")}
        if len(units) < 2:
            continue
        # Mixed units only matter in a column the document treats as one series. An
        # action-signal table sizes each row in its own natural unit — "$3.1M" on one
        # row, "−8.7 points" on the next — and that column is a description, not a
        # series to be summed or ranked. A total in the column, or a declared sort on
        # it, is the document asserting otherwise.
        from ..pairing import declared_sort_column, declared_sort_direction

        table = ctx.ledger.tables_by_id.get(table_id)
        has_total = any(c.role in ("total", "subtotal") for c in claims)
        # `declared_sort` often holds a caption rather than a sort. "Ranked action
        # signals for the week" names no direction, so it is not the document
        # asserting an order — and a substring test on the column name matched
        # "Action" inside it, which let the gate through by accident.
        sorted_on = False
        if table and declared_sort_direction(table.declared_sort):
            named = declared_sort_column(table.declared_sort)
            if named and column_label:
                sorted_on = (
                    re.sub(r"[^a-z0-9]+", "", named.lower())
                    in re.sub(r"[^a-z0-9]+", "", column_label.lower())
                )
        if not (has_total or sorted_on):
            ctx.skip(
                "uni_mixed_units_in_column",
                f"{table_id}/{column_label} mixes units, but nothing in the document treats "
                f"the column as a single series (no total, no declared sort on it), so the "
                f"mix is a description rather than a defect",
                [c.claim_id for c in claims],
            )
            continue
        ctx.touched(*claims)
        findings.append(
            make_finding(
                "uni_mixed_units_in_column",
                claims,
                "medium",
                f"column {column_label or '(unlabelled)'} of {table_id} mixes "
                f"{', '.join(sorted(units))}, so the column cannot be summed or ranked as one "
                f"series.",
                evidence_class="structural",
                detail={"units": sorted(units)},
            )
        )
    return findings


@check(
    "uni_same_value_conflicting_units",
    "The same movement is stated in points in one place and in percent in another, so "
    "one of the two is the wrong unit.",
    overturnable_by=METRIC_LAYER,
)
def uni_same_value_conflicting_units(ctx: CheckContext) -> list[Finding]:
    """A table cell and a sentence carrying one number under two different units.

    "Headwear → Fitted grew 19.6% and gross margin improved 2.4 percent" next to a
    table cell reading ``+2.4 pts`` for the same row is the schema's named defect:
    percent and points are different units, and the document has used both for one
    quantity. The arithmetic checks cannot see it — 2.4 really is the number in the
    data — and the level pair needed by ``uni_percent_vs_points`` is often absent.

    Pairing requires the magnitudes to agree inside their envelopes **and** the
    section to match, so two coincidentally equal figures elsewhere in the document
    are not married together.
    """
    findings = []
    percentish = [
        c
        for c in ctx.ledger.claims
        if c.unit in PERCENT_UNITS and c.value_parsed is not None
    ]
    seen: set[tuple[str, str]] = set()
    for table_claim in percentish:
        if table_claim.loc_kind != "table_cell":
            continue
        for prose_claim in percentish:
            if prose_claim.loc_kind != "prose":
                continue
            if table_claim.unit == prose_claim.unit:
                continue
            # points versus percent only. basis_points against percent is a
            # magnitude question and belongs to uni_basis_points_magnitude.
            if {table_claim.unit, prose_claim.unit} != {"points", "percent"}:
                continue
            section_a = ctx.ledger.section_of(table_claim).strip()
            section_b = ctx.ledger.section_of(prose_claim).strip()
            if not section_a or section_a != section_b:
                continue
            band = sum_band([table_claim.envelope, prose_claim.envelope])
            if not within(
                abs(table_claim.value_parsed or 0.0) - abs(prose_claim.value_parsed or 0.0), band
            ):
                continue
            key = tuple(sorted((table_claim.claim_id, prose_claim.claim_id)))
            if key in seen:
                continue
            seen.add(key)
            points = table_claim if table_claim.unit == "points" else prose_claim
            percent = prose_claim if points is table_claim else table_claim
            ctx.touched(table_claim, prose_claim)
            findings.append(
                make_finding(
                    "uni_same_value_conflicting_units",
                    [percent, points],
                    "high",
                    f"the same movement of {_fmt(abs(points.value_parsed or 0.0))} appears as "
                    f"{points.value_displayed} at {points.where()} and as "
                    f"{percent.value_displayed} at {percent.where()}. Percent and points are "
                    f"different units, so one of the two statements is wrong.",
                    evidence_class="structural",
                    overturnable_by=METRIC_LAYER,
                    detail={
                        "points_claim": points.claim_id,
                        "percent_claim": percent.claim_id,
                        "value": points.value_parsed,
                        "section": section_a,
                    },
                )
            )
    return findings


@check(
    "uni_cross_partition_scale_disagreement",
    "Two tables that partition the same metric and period disagree by a factor of a "
    "thousand, so one of them did not honour its declared scale.",
    overturnable_by=METRIC_LAYER,
)
def uni_cross_partition_scale_disagreement(ctx: CheckContext) -> list[Finding]:
    """The check that catches a column header lying about its own scale.

    A weekly report partitions the same money several ways — by team, by department,
    by vendor, by first versus third party. Each partition must total the same
    amount. When one of them totals exactly a thousand times another, the scale
    declared on that table was not applied to its values, and every figure in it is
    three orders of magnitude wrong.

    The factor is what makes this a units finding rather than a data disagreement:
    an exact power of a thousand is a scale error, and anything else is a different
    defect (reported by ``ari_cross_partition_total_disagreement``).
    """
    findings, _ = _cross_partition(ctx, want_scale_factor=True)
    return findings


@check(
    "ari_cross_partition_total_disagreement",
    "Two tables that partition the same metric and period do not total the same amount.",
    overturnable_by=METRIC_LAYER,
)
def ari_cross_partition_total_disagreement(ctx: CheckContext) -> list[Finding]:
    _, findings = _cross_partition(ctx, want_scale_factor=True)
    return findings


#: How close a ratio must be to a power of a thousand to be called a scale error.
SCALE_RATIO_TOLERANCE = 0.01
SCALE_POWERS = (1e-9, 1e-6, 1e-3, 1e3, 1e6, 1e9)


def _partition_totals(ctx: CheckContext) -> dict[tuple, list]:
    """Per (metric, period, table): the claims that make up that table's whole.

    A table's whole is its declared total when it has one, and the sum of its
    components when it does not. Tables that break out only part of a population
    ("top 5 of 62") are excluded: their components are a subset by design, so they
    are not comparable to a full partition.
    """
    from ..pairing import TOP_N_RE, BOTTOM_N_RE

    groups: dict[tuple, list] = {}
    for claim in ctx.ledger.claims:
        if claim.table_id is None or claim.value_parsed is None:
            continue
        if claim.unit not in ("currency", "units", "count"):
            continue
        if claim.role not in ("component", "total"):
            continue
        key = (metric_family_key(claim), claim.period_label, claim.table_id, claim.column_label)
        groups.setdefault(key, []).append(claim)

    partitions: dict[tuple, list] = {}
    for (metric, period, table_id, column), claims in groups.items():
        if metric is None:
            continue
        table = ctx.ledger.tables_by_id.get(table_id)
        caption = f"{table.caption} {table.section}" if table else ""
        totals = [c for c in claims if c.role == "total"]
        if totals:
            members = totals
        else:
            if TOP_N_RE.search(caption) or BOTTOM_N_RE.search(caption):
                continue
            members = [c for c in claims if c.role == "component"]
        if not members:
            continue
        partitions[(metric, period, table_id, column)] = members
    return partitions


def _cross_partition(ctx: CheckContext, want_scale_factor: bool):
    """Compare every pair of partitions of the same metric and period.

    Disagreements are reported **per offending table**, not per pair. One table
    whose scale was not applied disagrees with every other partition of every
    metric it holds, which is a dozen pairs and one defect with one fix.
    """
    partitions = _partition_totals(ctx)
    by_metric: dict[tuple, list] = {}
    for (metric, period, table_id, column), members in partitions.items():
        by_metric.setdefault((metric, period), []).append((table_id, column, members))

    scale_offences: dict[tuple, dict] = {}
    plain_offences: dict[tuple, dict] = {}
    outlier_offences: dict[str, dict] = {}

    for (metric, period), entries in sorted(by_metric.items(), key=lambda kv: str(kv[0])):
        if len(entries) < 2:
            continue
        summed = []
        for table_id, column, members in entries:
            values = [m.value_in_major_units for m in members]
            if any(v is None for v in values):
                ctx.skip(
                    "uni_cross_partition_scale_disagreement",
                    f"{table_id} holds a currency figure whose denomination is unknown, so its "
                    f"total cannot be compared",
                    [m.claim_id for m in members],
                )
                continue
            summed.append(
                (table_id, column, members, float(sum(v or 0.0 for v in values)), sum_band([m.envelope for m in members]))
            )
        # Cluster the partitions by the total they claim. When one partition stands
        # alone against a majority that agree with each other, the lone one is the
        # defect and the majority is the reference. Naming it once is one finding for
        # one fix; the old pairwise report raised the same defect against every
        # agreeing partition in turn.
        clusters: list[list] = []
        for entry in summed:
            for cluster in clusters:
                band = sum_band([entry[4], cluster[0][4]])
                if within(entry[3] - cluster[0][3], band):
                    cluster.append(entry)
                    break
            else:
                clusters.append([entry])
        majority = max(clusters, key=len) if clusters else []
        lone = [c[0] for c in clusters if len(c) == 1 and c is not majority]
        outlier = lone[0][0] if (len(majority) >= 2 and len(lone) == 1) else None

        for index, (table_a, col_a, members_a, total_a, band_a) in enumerate(summed):
            for table_b, col_b, members_b, total_b, band_b in summed[index + 1 :]:
                if total_a == 0 or total_b == 0:
                    continue
                band = sum_band([band_a, band_b])
                if within(total_a - total_b, band):
                    continue
                ctx.touched(*members_a, *members_b)
                ratio = total_a / total_b
                power = next(
                    (p for p in SCALE_POWERS if abs(ratio - p) <= abs(p) * SCALE_RATIO_TOLERANCE),
                    None,
                )
                if power is not None:
                    # The table with the larger total is the one that failed to
                    # apply its scale; the agreeing partitions are the reference.
                    if total_a > total_b:
                        offender, offender_members = table_a, members_a
                        reference, reference_total = table_b, total_b
                        offender_total = total_a
                    else:
                        offender, offender_members = table_b, members_b
                        reference, reference_total = table_a, total_a
                        offender_total = total_b
                    factor = max(total_a, total_b) / min(total_a, total_b)
                    key = (offender, round(factor))
                    bucket = scale_offences.setdefault(
                        key,
                        {
                            "offender": offender,
                            "factor": factor,
                            "members": offender_members,
                            "references": [],
                            "metrics": [],
                            "offender_total": offender_total,
                            "reference_total": reference_total,
                        },
                    )
                    if reference not in bucket["references"]:
                        bucket["references"].append(reference)
                    if metric not in bucket["metrics"]:
                        bucket["metrics"].append(metric)
                elif outlier in (table_a, table_b):
                    if outlier == table_a:
                        off, off_members, off_total = table_a, members_a, total_a
                        ref, ref_total = table_b, total_b
                    else:
                        off, off_members, off_total = table_b, members_b, total_b
                        ref, ref_total = table_a, total_a
                    bucket = outlier_offences.setdefault(
                        off,
                        {
                            "offender": off,
                            "members": off_members[:5],
                            "metrics": [],
                            "references": [],
                            "offender_total": off_total,
                            "reference_total": ref_total,
                            "band": band,
                        },
                    )
                    if ref not in bucket["references"]:
                        bucket["references"].append(ref)
                    if metric not in bucket["metrics"]:
                        bucket["metrics"].append(metric)
                else:
                    key = (table_a, table_b)
                    bucket = plain_offences.setdefault(
                        key,
                        {
                            "tables": (table_a, table_b),
                            "members": members_a[:3] + members_b[:3],
                            "metrics": [],
                            "total_a": total_a,
                            "total_b": total_b,
                            "band": band,
                        },
                    )
                    if metric not in bucket["metrics"]:
                        bucket["metrics"].append(metric)

    scale_findings: list[Finding] = []
    if want_scale_factor:
        for (offender, _factor), bucket in sorted(scale_offences.items()):
            table = ctx.ledger.tables_by_id.get(offender)
            declared = table.declared_scale if table else None
            # When the table states a scale, the defect is that its *declaration* is
            # not honoured by its values, and the finding belongs under the check
            # whose name says exactly that. Comparing the declared scale to the
            # extractor's `claim.scale` — as that check used to do alone — can never
            # catch this, because both were derived from the same header: the header
            # and the metadata agree, and only the values disagree with both.
            check_id = (
                "sel_declared_scale_contradicted"
                if declared
                else "uni_cross_partition_scale_disagreement"
            )
            scale_findings.append(
                make_finding(
                    check_id,
                    bucket["members"][:5],
                    "high",
                    f"{offender} totals {_fmt(bucket['factor'])} times what "
                    f"{len(bucket['references'])} other partition(s) of the same figures total "
                    f"({', '.join(sorted(bucket['references']))}): "
                    f"{_fmt(bucket['offender_total'])} against {_fmt(bucket['reference_total'])} "
                    f"for {', '.join(sorted(bucket['metrics']))}. An exact power of a thousand "
                    f"means the scale declared on {offender}"
                    + (f" ({declared!r})" if declared else "")
                    + f" was not applied to its values, so every figure in it is out by "
                    f"{_fmt(bucket['factor'])} while the other partitions are right.",
                    evidence_class="arithmetic",
                    overturnable_by=METRIC_LAYER,
                    scale_sensitive=True,
                    detail={
                        "aggregate_key": f"cross_partition_scale:{offender}",
                        "evidence": "cross_partition_total",
                        "offending_table": offender,
                        "factor": bucket["factor"],
                        "reference_tables": sorted(bucket["references"]),
                        "metrics": sorted(bucket["metrics"]),
                        "offender_total": bucket["offender_total"],
                        "reference_total": bucket["reference_total"],
                        "declared_scale": declared,
                    },
                    location=offender,
                )
            )

    other_findings: list[Finding] = []
    for offender, bucket in sorted(outlier_offences.items()):
        refs = sorted(bucket["references"])
        other_findings.append(
            make_finding(
                "ari_cross_partition_total_disagreement",
                bucket["members"],
                "high",
                f"{offender} totals {_fmt(bucket['offender_total'])} for "
                f"{', '.join(sorted(bucket['metrics']))}, but {len(refs)} other partition(s) of "
                f"the same figures ({', '.join(refs)}) agree on "
                f"{_fmt(bucket['reference_total'])} — a gap of "
                f"{_fmt(abs(bucket['offender_total'] - bucket['reference_total']))} against a "
                f"rounding allowance of {_fmt(bucket['band'])}. The agreeing partitions are the "
                f"reference, so the figures to correct are in {offender}.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                detail={
                    "aggregate_key": f"cross_partition_total:{offender}",
                    "offending_table": offender,
                    "reference_tables": refs,
                    "metrics": sorted(bucket["metrics"]),
                    "offender_total": bucket["offender_total"],
                    "reference_total": bucket["reference_total"],
                    "band": bucket["band"],
                },
                location=offender,
            )
        )
    for (table_a, table_b), bucket in sorted(plain_offences.items()):
        other_findings.append(
            make_finding(
                "ari_cross_partition_total_disagreement",
                bucket["members"],
                "high",
                f"{table_a} and {table_b} both partition {', '.join(sorted(bucket['metrics']))} "
                f"for the same period, but they total {_fmt(bucket['total_a'])} and "
                f"{_fmt(bucket['total_b'])}, a gap of "
                f"{_fmt(abs(bucket['total_a'] - bucket['total_b']))} against a rounding allowance "
                f"of {_fmt(bucket['band'])}.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                detail={
                    "aggregate_key": f"cross_partition_total:{table_a}|{table_b}",
                    "tables": [table_a, table_b],
                    "metrics": sorted(bucket["metrics"]),
                    "total_a": bucket["total_a"],
                    "total_b": bucket["total_b"],
                    "band": bucket["band"],
                },
                location=f"{table_a} vs {table_b}",
            )
        )
    return scale_findings, other_findings
