"""Family 2 — direction and polarity (``dir_``).

The question this family answers is not "is the number right" but "does the word
attached to the number mean what the number does". A stockout rate that rises has
not improved, and a delta that rounds to zero has not grown.

Every check here uses the movement resolver in :mod:`coldverify.pairing`, which
refuses to invent a comparison the document did not make.
"""

from __future__ import annotations

from ..envelope import sum_band, within
from ..findings import CheckContext, Finding, check, make_finding
from ..pairing import (
    DECLINE_WORDS,
    explicitly_signed,
    flatness_is_hedged,
    FLAT_WORDS,
    GROWTH_WORDS,
    IMPROVE_WORDS,
    WORSEN_WORDS,
    effective_polarity,
    polarity_is_lower_better,
    resolve_movement,
    shares_its_sentence,
    words_of,
)

METRIC_LAYER = "metric_layer"


def _fmt(value: float | None) -> str:
    if value is None:
        return "unknown"
    return f"{value:,.4f}".rstrip("0").rstrip(".") or "0"


def _worded_claims(ctx: CheckContext):
    for claim in ctx.ledger.claims:
        words = words_of(claim, ctx.ledger)
        if words:
            yield claim, words


@check(
    "dir_polarity_improved",
    "A metric is described as improved while it moved in the direction its polarity "
    "calls worse.",
    overturnable_by=METRIC_LAYER,
)
def dir_polarity_improved(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim, words in _worded_claims(ctx):
        if not (words & IMPROVE_WORDS):
            continue
        polarity = effective_polarity(claim)
        if polarity in ("unknown", "neutral"):
            continue
        movement = resolve_movement(ctx.ledger, claim)
        if not movement.resolved or movement.sign in (None, 0):
            if not movement.resolved:
                ctx.skip(
                    "dir_polarity_improved",
                    "no base level for this metric in the ledger, so the movement is unresolved",
                    [claim.claim_id],
                )
            continue
        ctx.touched(*movement.participants)
        rising = movement.sign == 1
        lower_better = polarity_is_lower_better(polarity)
        improved = (not rising) if lower_better else rising
        if improved:
            continue
        direction = "rose" if rising else "fell"
        findings.append(
            make_finding(
                "dir_polarity_improved",
                movement.participants,
                "high",
                f"{claim.metric_label or claim.claim_id} is described as improved, but it "
                f"{direction} from {_fmt(movement.old)} to {_fmt(movement.new)} and this metric is "
                f"{'better when lower' if lower_better else 'better when higher'}, so that move is "
                f"a worsening.",
                evidence_class="textual" if polarity.endswith("_inferred") else "structural",
                overturnable_by=METRIC_LAYER,
                detail={
                    "words": sorted(words & IMPROVE_WORDS),
                    "polarity": polarity,
                    "old": movement.old,
                    "new": movement.new,
                    "delta": movement.delta,
                },
            )
        )
    return findings


@check(
    "dir_polarity_worsened",
    "A metric is described as worsened while it moved in the direction its polarity "
    "calls better.",
    overturnable_by=METRIC_LAYER,
)
def dir_polarity_worsened(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim, words in _worded_claims(ctx):
        if not (words & WORSEN_WORDS):
            continue
        if words & IMPROVE_WORDS:
            continue
        polarity = effective_polarity(claim)
        if polarity in ("unknown", "neutral"):
            continue
        movement = resolve_movement(ctx.ledger, claim)
        if not movement.resolved or movement.sign in (None, 0):
            continue
        ctx.touched(*movement.participants)
        rising = movement.sign == 1
        lower_better = polarity_is_lower_better(polarity)
        worsened = rising if lower_better else (not rising)
        if worsened:
            continue
        findings.append(
            make_finding(
                "dir_polarity_worsened",
                movement.participants,
                "high",
                f"{claim.metric_label or claim.claim_id} is described as worsening, but it moved "
                f"from {_fmt(movement.old)} to {_fmt(movement.new)}, which is an improvement for a "
                f"metric that is {'better when lower' if lower_better else 'better when higher'}.",
                evidence_class="textual" if polarity.endswith("_inferred") else "structural",
                overturnable_by=METRIC_LAYER,
                detail={
                    "words": sorted(words & WORSEN_WORDS),
                    "polarity": polarity,
                    "old": movement.old,
                    "new": movement.new,
                },
            )
        )
    return findings


@check(
    "dir_direction_sign_mismatch",
    "A growth word sits on a negative move, or a decline word sits on a positive move.",
    overturnable_by=METRIC_LAYER,
)
def dir_direction_sign_mismatch(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim, words in _worded_claims(ctx):
        grew = bool(words & GROWTH_WORDS)
        fell = bool(words & DECLINE_WORDS)
        if grew == fell:  # neither, or contradictory words handled elsewhere
            continue
        movement = resolve_movement(ctx.ledger, claim)
        if not movement.resolved:
            continue
        # An unsigned magnitude carries no direction of its own: "units were down
        # 3.7%" renders 3.7%, and the word supplies the sign. Only a figure that
        # is explicitly signed, or a movement derived from two levels, can
        # contradict the words attached to it.
        if movement.basis in ("claim_is_delta", "claim_is_delta_by_role") and not explicitly_signed(claim):
            ctx.skip(
                "dir_direction_sign_mismatch",
                "the change is rendered as an unsigned magnitude, so the direction word is "
                "the only statement of direction and there is nothing to contradict",
                [claim.claim_id],
            )
            continue
        sign = movement.sign
        if sign in (None, 0):
            continue
        if (grew and sign == 1) or (fell and sign == -1):
            continue
        ctx.touched(*movement.participants)
        word = sorted(words & (GROWTH_WORDS if grew else DECLINE_WORDS))[0]
        moved = "up" if sign == 1 else "down"
        findings.append(
            make_finding(
                "dir_direction_sign_mismatch",
                movement.participants,
                "high",
                f"{claim.metric_label or claim.claim_id} is described with {word!r} but the number "
                f"moved {moved} by {_fmt(abs(movement.delta or 0.0))} "
                f"({_fmt(movement.old)} to {_fmt(movement.new)})."
                if movement.old is not None
                else f"{claim.metric_label or claim.claim_id} is described with {word!r} but the "
                f"stated change is {claim.value_displayed}.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={
                    "word": word,
                    "delta": movement.delta,
                    "basis": movement.basis,
                },
            )
        )
    return findings


@check(
    "dir_contradictory_words",
    "One claim carries both a growth word and a decline word.",
)
def dir_contradictory_words(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        words = set(claim.direction_words)
        grew = words & GROWTH_WORDS
        fell = words & DECLINE_WORDS
        if not (grew and fell):
            continue
        # Extractors attach direction words per sentence, not per figure. Opposing
        # words on a figure that shares its sentence are the extractor's ambiguity,
        # not a self-contradiction by the author.
        if shares_its_sentence(claim, ctx.ledger):
            ctx.skip(
                "dir_contradictory_words",
                "the figure shares its sentence with others, so opposing direction words "
                "cannot be attributed to it alone",
                [claim.claim_id],
            )
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "dir_contradictory_words",
                [claim],
                "medium",
                f"{claim.metric_label or claim.claim_id} carries both {sorted(grew)} and "
                f"{sorted(fell)}, so the direction asserted is self-contradictory.",
                evidence_class="structural",
                detail={"growth": sorted(grew), "decline": sorted(fell)},
            )
        )
    return findings


@check(
    "dir_flat_but_moved",
    "A metric is called flat while the move is larger than the display could hide.",
    overturnable_by=METRIC_LAYER,
)
def dir_flat_but_moved(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim, words in _worded_claims(ctx):
        if not (words & FLAT_WORDS):
            continue
        if words & (GROWTH_WORDS | DECLINE_WORDS):
            continue
        if flatness_is_hedged(claim.sentence):
            continue
        movement = resolve_movement(ctx.ledger, claim)
        if not movement.resolved or movement.sign in (None, 0):
            continue
        # A bare percentage with no asserted comparison is not a movement at all.
        # "The top five together are 3.1% of demand ... a genuinely flat, long-tail
        # assortment" describes a shape, not a change over time.
        if movement.basis == "claim_is_delta_by_role":
            continue
        # Flat is a judgement, not arithmetic. Only call it out when the move is
        # several times the rounding band, so "roughly flat" survives.
        band = movement.delta_band
        if band is None:
            continue
        if abs(movement.delta or 0.0) <= 4.0 * band:
            continue
        ctx.touched(*movement.participants)
        findings.append(
            make_finding(
                "dir_flat_but_moved",
                movement.participants,
                "medium",
                f"{claim.metric_label or claim.claim_id} is called flat, but it moved "
                f"{_fmt(abs(movement.delta or 0.0))}, which is more than four times the "
                f"{_fmt(band)} the display could hide.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={"delta": movement.delta, "band": band},
            )
        )
    return findings


@check(
    "dir_moved_but_zero",
    "A movement word sits on a change that rounds to zero at the precision shown.",
    overturnable_by=METRIC_LAYER,
)
def dir_moved_but_zero(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim, words in _worded_claims(ctx):
        movement_words = words & (GROWTH_WORDS | DECLINE_WORDS | IMPROVE_WORDS | WORSEN_WORDS)
        if not movement_words:
            continue
        movement = resolve_movement(ctx.ledger, claim)
        if not movement.resolved:
            continue
        band = movement.delta_band
        if band is None:
            ctx.skip(
                "dir_moved_but_zero",
                "the change has no usable display precision, so a zero move cannot be told from a real one",
                [claim.claim_id],
            )
            continue
        if not within(movement.delta or 0.0, band):
            continue
        ctx.touched(*movement.participants)
        findings.append(
            make_finding(
                "dir_moved_but_zero",
                movement.participants,
                "medium",
                f"{claim.metric_label or claim.claim_id} is described with "
                f"{sorted(movement_words)} but the change shown is "
                f"{claim.value_displayed if movement.basis == 'claim_is_delta' else _fmt(movement.delta)}, "
                f"which is inside the {_fmt(band)} the display can hide: the movement asserted is "
                f"not distinguishable from no movement.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={
                    "words": sorted(movement_words),
                    "delta": movement.delta,
                    "band": band,
                    "basis": movement.basis,
                },
            )
        )
    return findings


@check(
    "dir_polarity_missing_for_judgement",
    "A metric is judged as improved or worsened but carries no polarity, so the "
    "judgement is unverifiable.",
)
def dir_polarity_missing_for_judgement(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim, words in _worded_claims(ctx):
        judged = words & (IMPROVE_WORDS | WORSEN_WORDS)
        if not judged:
            continue
        if effective_polarity(claim) != "unknown":
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "dir_polarity_missing_for_judgement",
                [claim],
                "low",
                f"{claim.metric_label or claim.claim_id} is called {sorted(judged)} but no polarity "
                f"is recorded for it, so whether the move is good cannot be checked without a "
                f"metric definition.",
                evidence_class="coverage",
                detail={"words": sorted(judged)},
            )
        )
    return findings


@check(
    "dir_prose_vs_table_direction",
    "A prose sentence asserts a direction that the table cell for the same metric "
    "contradicts.",
    overturnable_by=METRIC_LAYER,
)
def dir_prose_vs_table_direction(ctx: CheckContext) -> list[Finding]:
    """A prose direction word against the signed figure in the table.

    This is where an unsigned prose magnitude becomes checkable. "Apparel → Tops →
    T-Shirt fell 15.7% against last year" renders ``15.7%``, which asserts nothing
    directional on its own — but the table cell for that same row renders
    ``+15.7%``, which asserts growth. The document contradicts itself, and only the
    pair shows it.

    Two pairing routes, both requiring evidence rather than inference:

    1. a shared metric identity and entity, when the ledger supplies them; or
    2. the table's **row label appearing verbatim in the prose sentence**, together
       with magnitudes that agree inside their envelopes.

    Route 2 matters because prose figures often carry no metric label at all. A row
    label quoted in the sentence plus the same magnitude is strong evidence that the
    sentence is about that cell; a magnitude match alone would not be.
    """
    findings = []
    prose = [c for c in ctx.ledger.claims if c.loc_kind == "prose" and c.value_parsed is not None]
    deltas = [
        c
        for c in ctx.ledger.claims
        if c.loc_kind == "table_cell"
        and (c.comparison or {}).get("form") in ("absolute_delta", "percent_change", "point_change")
        and c.value_parsed is not None
        and explicitly_signed(c)
    ]
    for claim in prose:
        words = words_of(claim, ctx.ledger)
        grew = bool(words & GROWTH_WORDS)
        fell = bool(words & DECLINE_WORDS)
        if grew == fell:
            continue

        key = claim.label_key()
        cells = [
            c
            for c in deltas
            if key is not None
            and c.label_key() == key
            and c.entity_key() == claim.entity_key()
        ]
        route = "metric_identity"
        if len(cells) != 1:
            sentence = claim.sentence or ""
            cells = [
                c
                for c in deltas
                if c.row_label
                and c.row_label in sentence
                and c.unit == claim.unit
                and within(
                    abs(c.value_parsed or 0.0) - abs(claim.value_parsed or 0.0),
                    sum_band([c.envelope, claim.envelope]),
                )
            ]
            route = "row_label_quoted_in_sentence"
        if len(cells) != 1:
            continue

        cell = cells[0]
        if within(cell.value_parsed or 0.0, cell.envelope):
            continue
        cell_sign = 1 if (cell.value_parsed or 0.0) > 0 else -1
        if (grew and cell_sign == 1) or (fell and cell_sign == -1):
            continue
        ctx.touched(claim, cell)
        word = sorted(words & (GROWTH_WORDS if grew else DECLINE_WORDS))[0]
        subject = cell.row_label or claim.metric_label or "this metric"
        findings.append(
            make_finding(
                "dir_prose_vs_table_direction",
                [claim, cell],
                "high",
                f"the prose says {subject} {word} {claim.value_displayed}, but the table shows "
                f"the same movement as {cell.value_displayed} — the opposite direction.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={
                    "word": word,
                    "prose_value": claim.value_parsed,
                    "table_delta": cell.value_parsed,
                    "paired_by": route,
                },
            )
        )
    return findings
