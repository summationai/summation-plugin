"""Family 7 — selection honesty (``sel_``).

A table that says "top five by revenue" is making three separate promises: that the
rows are sorted, that there are five of them, and that they are the five largest.
A table that says "1P only" is making a promise about scope. Each promise is a
checkable assertion, and each is broken often.

Scope promises are definitional. Whether "1P only" excludes drop-ship is a fact
only the metric layer holds, so every scope finding here carries
``overturnable_by: "metric_layer"`` and an explicit upgrade path, per spec item
4.17.
"""

from __future__ import annotations

import re

from ..envelope import sum_band
from ..findings import CheckContext, Finding, check, make_finding
from ..ledger import Claim
from ..pairing import (
    is_caption_count as _is_caption_count,
    BOTTOM_N_RE,
    TOP_N_RE,
    comparable_siblings,
    declared_sort_column,
    declared_sort_direction,
    word_to_int,
)

METRIC_LAYER = "metric_layer"

#: Entity or row wording that contradicts a first-party-only scope. The list is
#: deliberately narrow: a false positive here accuses the author of a scope error
#: they did not make.
SCOPE_CONTRADICTIONS = {
    "1p": (
        r"\b3p\b|\bthird[- ]party\b|\bdrop[- ]?ship\b|\bmarketplace\b|\bvendor[- ]direct\b",
        "third-party or drop-ship rows",
    ),
    "3p": (r"\b1p\b|\bfirst[- ]party\b|\bowned inventory\b|\bwholesale\b", "first-party rows"),
    "dtc": (r"\bwholesale\b|\bb2b\b|\bretail partner\b", "wholesale rows"),
    "wholesale": (r"\bdtc\b|\bdirect to consumer\b|\be-?comm(erce)?\b", "direct-to-consumer rows"),
    "online": (r"\bstore\b|\bin[- ]store\b|\bbrick\b|\bretail door\b", "physical-store rows"),
    "excluding": (r"", ""),
}

SUPERLATIVE_MAX = {"largest", "highest", "biggest", "best", "top", "most", "greatest", "strongest", "fastest"}
SUPERLATIVE_MIN = {"smallest", "lowest", "worst", "least", "weakest", "slowest"}



#: Row labels that hold the remainder of a population rather than a broken-out
#: member. "Top 5 of 62 teams" legitimately shows five members, an "All other 57"
#: row, a subtotal and a total: the top-five promise is about the five, not the
#: table's row count.
REMAINDER_ROW_RE = re.compile(
    r"\ball\s+other\b|\bother\b|\bremaining\b|\bremainder\b|\brest\b|\ball\s+remaining\b",
    re.IGNORECASE,
)
TOTAL_ROW_RE = re.compile(r"\btotal\b|\bsubtotal\b|\bgrand\s+total\b", re.IGNORECASE)


def _rows_of(ctx: CheckContext, table_id: str) -> dict:
    """Claims grouped by row label, for a table.

    Claims with no row label are not rows. A caption reading "Top 5 of 62 teams"
    yields two ``count`` claims that belong to the table but sit in no row; treating
    them as a row made "62" a rival of every net-demand figure and reported the
    largest team as not being the largest.
    """
    rows: dict = {}
    for claim in ctx.ledger.in_table(table_id):
        if not claim.row_label:
            continue
        if claim.role in ("rank", "count"):
            continue
        rows.setdefault(claim.row_label, []).append(claim)
    return rows


def _row_kind(label, claims) -> str:
    """``total``, ``remainder`` or ``member``, judged for the row as a whole.

    A total row must be recognised from any of its cells. On a Total row the money
    columns carry ``role: "total"`` while the ratio and movement columns carry
    ``rate`` and ``delta``, so classifying cell by cell lets the total row leak into
    the member count and every table reads as one row over its declaration.
    """
    if any(c.role in ("total", "subtotal") for c in claims):
        return "total"
    if label and TOTAL_ROW_RE.search(str(label)):
        return "total"
    if label and REMAINDER_ROW_RE.search(str(label)):
        return "remainder"
    return "member"


def _member_rows(ctx: CheckContext, table_id: str) -> list:
    rows = _rows_of(ctx, table_id)
    return [label for label, claims in rows.items() if _row_kind(label, claims) == "member"]



def _ranking_column(table) -> str | None:
    """The column a top-N or sort promise actually ranks by.

    Read from ``declared_sort`` first, then from a "by <column>" phrase in the
    caption. ``None`` when the document does not say, in which case the extremeness
    check refuses rather than picking a column.
    """
    named = declared_sort_column(table.declared_sort)
    if named:
        return named
    caption = table.caption or ""
    match = re.search(
        r"\bby\s+([a-z0-9 %$£€/&()\-]+?)(?:,|\.|;|$|\s+highest|\s+lowest|\s+desc|\s+asc)",
        caption,
        re.IGNORECASE,
    )
    return match.group(1).strip() if match else None


def _in_ranking_column(claims: list, wanted: str | None) -> list:
    """Claims that sit in the named column, or [] when it cannot be identified."""
    if not wanted:
        return []
    norm = re.sub(r"[^a-z0-9]+", "", wanted.lower())
    if not norm:
        return []
    matched = [
        c
        for c in claims
        if norm in re.sub(r"[^a-z0-9]+", "", (c.column_label or "").lower())
        or norm in re.sub(r"[^a-z0-9]+", "", (c.metric_label or "").lower())
    ]
    return matched


def _fmt(value: float | None) -> str:
    if value is None:
        return "unknown"
    return f"{value:,.4f}".rstrip("0").rstrip(".") or "0"


def _ordered_rows(claims: list[Claim]) -> list[Claim]:
    """Claims in the order the table presents them."""
    with_index = [c for c in claims if c.row_index is not None]
    if len(with_index) == len(claims) and claims:
        return sorted(claims, key=lambda c: c.row_index or 0)
    return list(claims)


#: Column-label markers for the reporting period and for the comparison period.
CURRENT_PERIOD_MARKERS = ("ty", "this year", "this week", "current", "actual")
PRIOR_PERIOD_MARKERS = ("ly", "last year", "last week", "prior", "py", "previous")


def _target_column(ctx: CheckContext, table_id: str, wanted: str | None) -> list[Claim]:
    """Claims of the **one** column a declared sort names.

    "by net demand" in a table holding both "Net demand TY" and "Net demand LY"
    matched both, and the check then read the two columns interleaved as a single
    series: 66,271 followed by 6,408 followed by 32,011 is TY, LY, TY, and every
    table in the document looked unsorted.

    Where the candidates differ only by a period marker, the reporting period wins —
    "by net demand" in a report about this week means this week's column. Where they
    differ in any other way the column is genuinely ambiguous and the caller refuses.
    """
    claims = [c for c in ctx.ledger.in_table(table_id) if c.value_parsed is not None]
    if not claims:
        return []
    if wanted:
        wanted_norm = re.sub(r"[^a-z0-9]+", "", wanted.lower())
        matched = [
            c
            for c in claims
            if wanted_norm
            and (
                wanted_norm in re.sub(r"[^a-z0-9]+", "", (c.column_label or "").lower())
                or wanted_norm in re.sub(r"[^a-z0-9]+", "", (c.metric_label or "").lower())
            )
        ]
        by_column: dict = {}
        for claim in matched:
            by_column.setdefault(claim.column_label, []).append(claim)
        if len(by_column) == 1:
            return matched
        if len(by_column) > 1:
            current = [
                label
                for label in by_column
                if label
                and any(m in label.lower() for m in CURRENT_PERIOD_MARKERS)
                and not any(m in label.lower() for m in PRIOR_PERIOD_MARKERS)
            ]
            if len(current) == 1:
                return by_column[current[0]]
            return []
    columns = {c.column_label for c in claims}
    if len(columns) == 1:
        return claims
    return []


@check(
    "sel_declared_sort_violated",
    "A table declares a sort order that its rows do not follow.",
)
def sel_declared_sort_violated(ctx: CheckContext) -> list[Finding]:
    findings = []
    for table in sorted(ctx.ledger.tables, key=lambda t: t.table_id):
        direction = declared_sort_direction(table.declared_sort)
        if direction is None:
            continue
        # Only real member rows are in the declared order: a total sits below by
        # convention, a remainder row ("All other 57") sits last by design, and a
        # caption count ("Top 5 of 62") is in no row at all.
        members = _member_rows(ctx, table.table_id)
        column = declared_sort_column(table.declared_sort)
        candidates = [
            c
            for c in _target_column(ctx, table.table_id, column)
            if c.row_label in members
        ]
        rows = _ordered_rows(candidates)
        if len(rows) < 2:
            if not rows:
                ctx.skip(
                    "sel_declared_sort_violated",
                    f"declared sort {table.declared_sort!r} names a column no member row matches",
                    [],
                )
            continue
        ctx.touched(*rows)
        violations = []
        for previous, current in zip(rows, rows[1:]):
            a, b = previous.value_parsed or 0.0, current.value_parsed or 0.0
            band = sum_band([previous.envelope, current.envelope]) or 0.0
            if direction == "desc" and b - a > band:
                violations.append((previous, current))
            if direction == "asc" and a - b > band:
                violations.append((previous, current))
        if not violations:
            continue
        first_prev, first_cur = violations[0]
        findings.append(
            make_finding(
                "sel_declared_sort_violated",
                rows,
                "high",
                f"{table.table_id} declares {table.declared_sort!r} but "
                f"{first_cur.row_label or first_cur.claim_id} ({first_cur.value_displayed}) is "
                f"listed after {first_prev.row_label or first_prev.claim_id} "
                f"({first_prev.value_displayed}); "
                f"{len(violations)} adjacent pair(s) break the declared order.",
                evidence_class="structural",
                detail={
                    "declared_sort": table.declared_sort,
                    "violations": [
                        {"before": p.claim_id, "after": c.claim_id} for p, c in violations
                    ],
                    "order_as_presented": [c.value_parsed for c in rows],
                },
                location=table.table_id,
            )
        )
    return findings


@check(
    "sel_top_n_count_mismatch",
    "A table promising a top or bottom N does not contain N rows.",
)
def sel_top_n_count_mismatch(ctx: CheckContext) -> list[Finding]:
    findings = []
    for table in sorted(ctx.ledger.tables, key=lambda t: t.table_id):
        text = f"{table.caption} {table.section}"
        match = TOP_N_RE.search(text) or BOTTOM_N_RE.search(text)
        if match is None:
            continue
        promised = word_to_int(match.groups()[-1])
        if promised is None:
            continue
        members = _member_rows(ctx, table.table_id)
        rows = [
            c
            for c in ctx.ledger.in_table(table.table_id)
            if c.row_label in members and c.value_parsed is not None
        ]
        if not rows:
            continue
        actual = len(members)
        if actual == promised:
            continue
        ctx.touched(*rows)
        findings.append(
            make_finding(
                "sel_top_n_count_mismatch",
                rows,
                "medium",
                f"{table.table_id} is captioned {table.caption!r}, promising {promised} broken-out "
                f"rows, but holds {actual} (excluding totals and any remainder row).",
                evidence_class="structural",
                detail={"promised": promised, "actual": actual, "caption": table.caption},
                location=table.table_id,
            )
        )
    return findings


@check(
    "sel_top_n_not_extremes",
    "A top or bottom N table omits a value from elsewhere in the document that belongs "
    "in it.",
    overturnable_by=METRIC_LAYER,
)
def sel_top_n_not_extremes(ctx: CheckContext) -> list[Finding]:
    findings = []
    for table in sorted(ctx.ledger.tables, key=lambda t: t.table_id):
        text = f"{table.caption} {table.section}"
        top = TOP_N_RE.search(text)
        bottom = BOTTOM_N_RE.search(text)
        if not (top or bottom):
            continue
        members = _member_rows(ctx, table.table_id)
        # "Top 5 of 62 teams **by net demand**" ranks one column. Every other column
        # in the table — the share, the margin, the unit count — is along for the
        # ride, and testing those for extremeness accuses the author of a selection
        # error on a column nothing was selected by.
        ranking_column = _ranking_column(table)
        candidates = [
            c
            for c in ctx.ledger.in_table(table.table_id)
            if c.row_label in members and c.value_parsed is not None
        ]
        if not candidates:
            continue
        rows = _in_ranking_column(candidates, ranking_column)
        if not rows:
            ctx.skip(
                "sel_top_n_not_extremes",
                f"{table.table_id} promises a top or bottom list but the column it ranks by "
                f"({ranking_column or 'unstated'}) cannot be identified, so no column may be "
                f"tested for extremeness",
                [c.claim_id for c in candidates],
            )
            continue
        key = rows[0].label_key()
        period = rows[0].period_label
        unit = rows[0].unit
        # A "top 5 of 62 teams" list is a selection from the teams. Comparing its
        # floor against a department total, a league total or a class figure is a
        # category error — they are different populations that happen to share the
        # metric "Net demand TY". The population is the rows' entity dimension, and
        # without one there is nothing safe to compare against.
        dimensions = {c.entity_key() and tuple(sorted(c.entity.keys())) for c in rows}
        dimensions.discard(())
        dimensions.discard(False)
        if len(dimensions) != 1:
            ctx.skip(
                "sel_top_n_not_extremes",
                f"{table.table_id} promises a top or bottom list but its rows carry no single "
                f"entity dimension, so the population it selects from cannot be identified",
                [c.claim_id for c in rows],
            )
            continue
        dimension = next(iter(dimensions))
        inside = {c.claim_id for c in rows}
        outside = [
            c
            for c in ctx.ledger.claims
            if c.claim_id not in inside
            and c.table_id != table.table_id
            and tuple(sorted(c.entity.keys())) == dimension
            and c.label_key() == key
            and c.period_label == period
            and c.unit == unit
            and c.role not in ("total", "subtotal")
            and c.value_parsed is not None
        ]
        if not outside:
            continue
        ctx.touched(*rows, *outside)
        if top:
            floor = min(c.value_parsed or 0.0 for c in rows)
            intruders = [c for c in outside if (c.value_parsed or 0.0) > floor]
            word, bound = "top", floor
        else:
            ceiling = max(c.value_parsed or 0.0 for c in rows)
            intruders = [c for c in outside if (c.value_parsed or 0.0) < ceiling]
            word, bound = "bottom", ceiling
        if not intruders:
            continue
        findings.append(
            make_finding(
                "sel_top_n_not_extremes",
                rows + intruders,
                "high",
                f"{table.table_id} presents a {word} list bounded at {_fmt(bound)}, but the "
                f"document holds {len(intruders)} value(s) elsewhere that belong inside it "
                f"({', '.join(f'{c.row_label or c.claim_id} {c.value_displayed}' for c in intruders[:3])}).",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={
                    "bound": bound,
                    "intruders": [c.claim_id for c in intruders],
                },
                location=table.table_id,
            )
        )
    return findings


@check(
    "sel_declared_scope_contradicted",
    "A table declares a scope that its own rows contradict.",
    overturnable_by=METRIC_LAYER,
)
def sel_declared_scope_contradicted(ctx: CheckContext) -> list[Finding]:
    findings = []
    for table in sorted(ctx.ledger.tables, key=lambda t: t.table_id):
        scope = (table.declared_scope or "").strip()
        if not scope:
            continue
        scope_lower = scope.lower()
        rule = None
        for token, (pattern, description) in SCOPE_CONTRADICTIONS.items():
            if not pattern:
                continue
            if re.search(rf"\b{re.escape(token)}\b", scope_lower):
                rule = (token, pattern, description)
                break
        if rule is None:
            # An "excluding X" scope names its own contradiction.
            excl = re.search(r"exclud(?:ing|es)\s+([\w \-/]+)", scope_lower)
            if excl:
                term = excl.group(1).strip()
                rule = (term, rf"{re.escape(term)}", f"rows matching {term!r}")
        if rule is None:
            ctx.skip(
                "sel_declared_scope_contradicted",
                f"declared scope {scope!r} has no known contradiction pattern",
                [],
            )
            continue
        token, pattern, description = rule
        offenders = []
        examined = ctx.ledger.in_table(table.table_id)
        ctx.touched(*examined)
        for claim in examined:
            haystack = " ".join(
                [claim.row_label or "", claim.metric_label or ""]
                + [str(v) for v in claim.entity.values()]
                + [f.get("text", "") for f in claim.filters_stated]
            ).lower()
            if re.search(pattern, haystack):
                offenders.append(claim)
        if not offenders:
            continue
        ctx.touched(*offenders)
        findings.append(
            make_finding(
                "sel_declared_scope_contradicted",
                offenders,
                "medium",
                f"{table.table_id} declares the scope {scope!r} but contains {description}: "
                f"{', '.join(sorted({(c.row_label or c.claim_id) for c in offenders}))}. Whether "
                f"that wording really falls outside the declared scope is a metric-layer fact, so "
                f"this finding is provisional until the definition is resolved.",
                evidence_class="declared_metadata",
                overturnable_by=METRIC_LAYER,
                detail={
                    "declared_scope": scope,
                    "offending_claims": [c.claim_id for c in offenders],
                    "pattern": pattern,
                },
                location=table.table_id,
            )
        )
    return findings


@check(
    "sel_declared_scale_contradicted",
    "A table declares a scale that its values do not honour.",
    # The id is historical and stays stable for the platform runner; the defect is
    # about units and scale, so that is where it is filed.
    family="units_scale",
)
def sel_declared_scale_contradicted(ctx: CheckContext) -> list[Finding]:
    findings = []
    # Real captions write the scale as "($000)", "(000s)", "in thousands", "$m",
    # "(£m)". Missing any of these forms silently disables the check.
    keywords = {
        "thousand": "thousands", "000s": "thousands", "000'": "thousands",
        "(000": "thousands", "$000": "thousands", "000)": "thousands",
        " k)": "thousands", "(k)": "thousands", "in k": "thousands",
        "million": "millions", "mm": "millions", "(m)": "millions",
        "$m": "millions", "£m": "millions", "€m": "millions", " m)": "millions",
        "billion": "billions", "(bn": "billions", "$bn": "billions",
        "whole dollar": "ones", "whole pound": "ones", "whole unit": "ones",
        "actual": "ones",
    }
    for table in sorted(ctx.ledger.tables, key=lambda t: t.table_id):
        declared = (table.declared_scale or "").strip().lower()
        if not declared:
            continue
        expected = None
        for keyword, scale in keywords.items():
            if keyword in declared:
                expected = scale
                break
        if expected is None:
            continue
        # A scale stated in a caption governs the money in the table. A units or
        # count column in the same table is not in thousands of units just because
        # the dollars are in thousands of dollars.
        offenders = [
            c
            for c in ctx.ledger.in_table(table.table_id)
            if c.scale not in (None, "unknown")
            and c.scale != expected
            and c.unit == "currency"
        ]
        if not offenders:
            continue
        ctx.touched(*offenders)
        findings.append(
            make_finding(
                "sel_declared_scale_contradicted",
                offenders,
                "medium",
                f"{table.table_id} declares its figures are in {table.declared_scale!r} "
                f"({expected}), but {len(offenders)} of them carry scale "
                f"{', '.join(sorted({str(c.scale) for c in offenders}))}.",
                evidence_class="declared_metadata",
                scale_sensitive=True,
                detail={"declared_scale": table.declared_scale, "expected": expected},
                location=table.table_id,
            )
        )
    return findings


@check(
    "sel_superlative_false",
    "A superlative names a value that is not the extreme of its comparable set.",
    overturnable_by=METRIC_LAYER,
)
def sel_superlative_false(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        words = set(claim.superlatives)
        if not words:
            continue
        if _is_caption_count(claim):
            continue
        siblings = comparable_siblings(ctx.ledger, claim)
        if len(siblings) < 2 or claim.value_parsed is None:
            continue
        ctx.touched(claim, *siblings)
        values = [c.value_parsed or 0.0 for c in siblings]
        wants_max = bool(words & SUPERLATIVE_MAX)
        wants_min = bool(words & SUPERLATIVE_MIN)
        # "worst" on a lower-is-better metric means the highest value.
        from ..pairing import polarity_is_lower_better, effective_polarity

        if words & {"worst"} and polarity_is_lower_better(effective_polarity(claim)):
            wants_max, wants_min = True, False
        if words & {"best"} and polarity_is_lower_better(effective_polarity(claim)):
            wants_max, wants_min = False, True
        if wants_max == wants_min:
            continue
        extreme = max(values) if wants_max else min(values)
        band = sum_band([claim.envelope, max(siblings, key=lambda c: abs(c.value_parsed or 0.0)).envelope]) or 0.0
        gap = (extreme - claim.value_parsed) if wants_max else (claim.value_parsed - extreme)
        if gap <= band:
            continue
        holder = next(c for c in siblings if (c.value_parsed or 0.0) == extreme)
        findings.append(
            make_finding(
                "sel_superlative_false",
                [claim, holder],
                "high",
                f"{claim.row_label or claim.metric_label or claim.claim_id} is called "
                f"{', '.join(sorted(words))} at {claim.value_displayed}, but "
                f"{holder.row_label or holder.claim_id} is {holder.value_displayed} in the same "
                f"column.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={
                    "claimed": claim.value_parsed,
                    "extreme": extreme,
                    "extreme_claim": holder.claim_id,
                    "superlatives": sorted(words),
                },
            )
        )
    return findings


@check(
    "sel_row_count_mismatch",
    "A table's declared row count does not match the rows the ledger holds for it.",
)
def sel_row_count_mismatch(ctx: CheckContext) -> list[Finding]:
    findings = []
    for table in sorted(ctx.ledger.tables, key=lambda t: t.table_id):
        if table.row_count is None:
            continue
        claims = ctx.ledger.in_table(table.table_id)
        if not claims:
            continue
        rows = _rows_of(ctx, table.table_id)
        members = _member_rows(ctx, table.table_id)
        # A declaration may count members only, or members plus the total and
        # remainder rows. Either reading satisfying the declaration is a pass.
        if table.row_count in (len(members), len(rows)):
            continue
        keys = set(members)
        ctx.touched(*claims)
        findings.append(
            make_finding(
                "sel_row_count_mismatch",
                claims,
                "low",
                f"{table.table_id} declares {table.row_count} rows but the ledger holds "
                f"{len(keys)} member rows ({len(rows)} including totals and remainders), so the "
                f"extraction covers only part of the table.",
                evidence_class="coverage",
                detail={"declared_row_count": table.row_count, "extracted_rows": len(keys)},
                location=table.table_id,
            )
        )
    return findings


@check(
    "sel_inconsistent_filters",
    "Two figures for the same metric and period state different filters but are "
    "presented as comparable.",
    overturnable_by=METRIC_LAYER,
)
def sel_inconsistent_filters(ctx: CheckContext) -> list[Finding]:
    findings = []
    groups: dict[tuple, list[Claim]] = {}
    for claim in ctx.ledger.claims:
        if not claim.filters_stated:
            continue
        groups.setdefault((claim.label_key(), claim.period_label, claim.entity_key()), []).append(claim)
    for key, claims in sorted(groups.items(), key=lambda kv: str(kv[0])):
        if len(claims) < 2:
            continue
        signatures = {
            frozenset(
                f.get("text", "").strip().lower()
                for f in c.filters_stated
                if (f.get("kind") or "unknown") != "slice"
            )
            for c in claims
        }
        if len(signatures) < 2:
            continue
        ctx.touched(*claims)
        findings.append(
            make_finding(
                "sel_inconsistent_filters",
                claims,
                "medium",
                f"{claims[0].metric_label or key[0]} appears {len(claims)} times for "
                f"{key[1] or 'the same period'} under different definitional filters "
                f"({' | '.join(sorted(', '.join(sorted(s)) or '(none)' for s in signatures))}), so "
                f"the figures are not the same measure.",
                evidence_class="declared_metadata",
                overturnable_by=METRIC_LAYER,
                detail={"claim_ids": [c.claim_id for c in claims]},
            )
        )
    return findings
