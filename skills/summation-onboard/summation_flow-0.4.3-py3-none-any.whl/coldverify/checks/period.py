"""Family 6 — period integrity (``per_``).

The schema is explicit about the load-bearing case: "For trailing-window
year-over-year: 364 preserves day-of-week alignment, 365 does not. A 365 here on a
trailing window is a finding." Trailing-window comparisons shifted by 365 days
compare a Monday to a Sunday, which moves a full trading day of seasonality into
the result.

The rest of the family is about windows that are not what their label says, and
totals that add windows of different lengths.
"""

from __future__ import annotations

import re
from datetime import date, datetime
from typing import Optional

from ..envelope import sum_band, within
from ..findings import CheckContext, Finding, check, make_finding
from ..ledger import Claim, metric_family_key
from ..pairing import TRAILING_KINDS, column_groups, word_to_int

METRIC_LAYER = "metric_layer"

TRAILING_DAYS_RE = re.compile(
    r"\b(?:trailing|last|past|rolling|previous)\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten|"
    r"eleven|twelve|twenty)\s*(day|days|d)\b",
    re.IGNORECASE,
)
TRAILING_WEEKS_RE = re.compile(
    r"\b(?:trailing|last|past|rolling|previous|recent)\s+(\d+|one|two|three|four|five|six|seven|eight|nine|ten|"
    r"eleven|twelve|twenty)\s*(week|weeks|w)\b",
    re.IGNORECASE,
)
WEEK_ENDING_RE = re.compile(r"\bweek\s+end(?:ing|ed)\b", re.IGNORECASE)
MONTH_RE = re.compile(
    r"\b(january|february|march|april|may|june|july|august|september|october|november|december)\b",
    re.IGNORECASE,
)


def _parse_date(text: Optional[str]) -> Optional[date]:
    if not text:
        return None
    try:
        return datetime.strptime(text[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


#: Window kinds whose year-over-year comparison must shift by whole weeks.
#: Trailing windows are the schema's stated case, and a week ending on a named
#: weekday is the same case wearing a different label: a Saturday-ending week
#: compared 365 days earlier lands on a Friday-ending week, moving a full trading
#: day of seasonality into the result. Calendar months, quarters and years are
#: exempt — they are anchored to dates, not weekdays.
WEEKDAY_ANCHORED_KINDS = TRAILING_KINDS | {"calendar_week"}


def needs_weekday_alignment(claim: Claim) -> bool:
    """Whether this window's year-over-year comparison must shift by 364 days."""
    kind = claim.period.get("kind")
    if kind in WEEKDAY_ANCHORED_KINDS:
        return True
    if kind in ("calendar_month", "calendar_quarter", "calendar_year", "fiscal_period"):
        return False
    label = claim.period_label
    return bool(
        TRAILING_DAYS_RE.search(label)
        or TRAILING_WEEKS_RE.search(label)
        or WEEK_ENDING_RE.search(label)
    )


#: Kept for readers of the older name.
_is_trailing = needs_weekday_alignment


@check(
    "per_yoy_alignment_365",
    "A trailing-window year-over-year comparison is shifted 365 days, which breaks "
    "day-of-week alignment.",
)
def per_yoy_alignment_365(ctx: CheckContext) -> list[Finding]:
    """One finding per declared alignment, not one per affected figure.

    The document states its year-over-year convention once, usually in a footnote,
    and every comparison in the report inherits it. Emitting a finding per
    inheriting figure turns a single editorial decision into hundreds of rows, buries
    every other finding, and — because the answer key cites the footnote rather than
    the figures — scores a correct detection as hundreds of false positives.
    """
    findings = []
    groups: dict[int, list[Claim]] = {}
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        if comparison.get("base") != "last_year":
            continue
        alignment = comparison.get("alignment_days")
        if alignment is None or alignment == 364:
            continue
        if not needs_weekday_alignment(claim):
            continue
        groups.setdefault(int(alignment), []).append(claim)

    for alignment, affected in sorted(groups.items()):
        ctx.touched(*affected)
        declaring = _claims_declaring(ctx, alignment)
        cited = declaring + affected[:3]
        windows = sorted({c.period_label for c in affected if c.period_label})
        where = (
            declaring[0].where()
            if declaring
            else (affected[0].where() if affected else None)
        )
        findings.append(
            make_finding(
                "per_yoy_alignment_365",
                cited,
                "high",
                f"the document compares year over year with a {alignment}-day shift"
                + (
                    f", stated at {declaring[0].where()}"
                    if declaring
                    else ""
                )
                + f". The window is weekday-anchored ({', '.join(windows) or 'a weekly window'}), "
                f"so it needs 364 days — 52 whole weeks — to land on the same weekdays; "
                f"{alignment} days moves the comparison by {abs(alignment - 364)} day(s) of the "
                f"week and pulls a different trading day into the base. "
                f"{len(affected)} comparison figures in the document inherit this shift.",
                evidence_class="declared_metadata",
                detail={
                    "alignment_days": alignment,
                    "declared_by": [c.claim_id for c in declaring],
                    "affected_claim_count": len(affected),
                    "affected_claim_ids": [c.claim_id for c in affected[:200]],
                    "windows": windows,
                },
                location=where,
            )
        )
    return findings


def _claims_declaring(ctx: CheckContext, alignment: int) -> list[Claim]:
    """Claims that state the alignment in words, e.g. a "365 days" footnote.

    This is where the convention is authored, so it is where the finding belongs.
    Matching is on the value and the unit, not on wording, so it holds for any
    phrasing of the same footnote.
    """
    out = []
    for claim in ctx.ledger.claims:
        if claim.unit != "days" or claim.value_parsed is None:
            continue
        if int(claim.value_parsed) != alignment:
            continue
        if claim.loc_kind not in ("footnote", "prose"):
            continue
        out.append(claim)
    return out



def _clamp(text: str, limit: int = 60) -> str:
    """Shorten an extracted label for display. Statements are read by people."""
    one_line = " ".join((text or "").split())
    return one_line if len(one_line) <= limit else one_line[: limit - 1] + "…"


@check(
    "per_yoy_alignment_missing",
    "A trailing-window year-over-year comparison does not record its alignment, so "
    "whether day-of-week was preserved is unknown.",
)
def per_yoy_alignment_missing(ctx: CheckContext) -> list[Finding]:
    offenders = [
        c
        for c in ctx.ledger.claims
        if (c.comparison or {}).get("base") == "last_year"
        and (c.comparison or {}).get("alignment_days") is None
        and needs_weekday_alignment(c)
    ]
    if not offenders:
        return []
    ctx.touched(*offenders)
    # Period labels come from the document, so their length is the document's choice,
    # not ours. Clamp before they reach a statement a human has to read.
    windows = sorted({_clamp(c.period_label) for c in offenders if c.period_label})
    return [
        make_finding(
            "per_yoy_alignment_missing",
            offenders[:5],
            "medium",
            f"{len(offenders)} year-over-year comparisons over weekday-anchored windows "
            f"({', '.join(windows) or 'a weekly window'}) record no alignment, so a 365-day "
            f"shift cannot be ruled out for any of them.",
            evidence_class="coverage",
            detail={
                "affected_claim_count": len(offenders),
                "affected_claim_ids": [c.claim_id for c in offenders[:200]],
                "windows": windows,
            },
        )
    ]


@check(
    "per_label_vs_length",
    "A period label states a window length that the recorded length contradicts.",
)
def per_label_vs_length(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        length = claim.period.get("length_days")
        if length is None:
            continue
        label = claim.period_label
        expected = None
        match = TRAILING_DAYS_RE.search(label)
        if match:
            expected = word_to_int(match.group(1))
        else:
            match = TRAILING_WEEKS_RE.search(label)
            if match:
                weeks = word_to_int(match.group(1))
                expected = None if weeks is None else weeks * 7
        if expected is None or expected == length:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "per_label_vs_length",
                [claim],
                "high",
                f"{claim.metric_label or claim.claim_id} is labelled {label!r}, which is "
                f"{expected} days, but the window recorded is {length} days.",
                evidence_class="declared_metadata",
                detail={"label": label, "expected_days": expected, "length_days": length},
            )
        )
    return findings


@check(
    "per_length_vs_dates",
    "A window's recorded length does not match its start and end dates.",
)
def per_length_vs_dates(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        period = claim.period
        length = period.get("length_days")
        start = _parse_date(period.get("start"))
        end = _parse_date(period.get("end"))
        if length is None or start is None or end is None:
            continue
        inclusive = (end - start).days + 1
        if length in (inclusive, inclusive - 1):
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "per_length_vs_dates",
                [claim],
                "medium",
                f"{claim.metric_label or claim.claim_id} records a {length}-day window but its "
                f"dates {start} to {end} span {inclusive} days.",
                evidence_class="structural",
                detail={"length_days": length, "start": str(start), "end": str(end)},
            )
        )
    return findings


@check(
    "per_kind_label_mismatch",
    "A period's declared kind does not match the shape of its label.",
)
def per_kind_label_mismatch(ctx: CheckContext) -> list[Finding]:
    groups: dict[tuple, list[Claim]] = {}
    for claim in ctx.ledger.claims:
        kind = claim.period.get("kind")
        label = claim.period_label
        if not kind or not label or kind == "unknown":
            continue
        mismatch = None
        if WEEK_ENDING_RE.search(label) and kind not in ("calendar_week", "point_in_time"):
            mismatch = "a week-ending label"
        elif TRAILING_DAYS_RE.search(label) and kind != "trailing_days":
            mismatch = "a trailing-days label"
        elif TRAILING_WEEKS_RE.search(label) and kind != "trailing_weeks":
            mismatch = "a trailing-weeks label"
        elif MONTH_RE.search(label) and kind in TRAILING_KINDS:
            mismatch = "a calendar-month label"
        if mismatch is None:
            continue
        groups.setdefault((mismatch, kind, label), []).append(claim)

    # A label-versus-kind disagreement is a property of the window, not of each
    # figure that uses it. One window mislabelled across 472 cells is one defect
    # with one fix, so it is one finding.
    findings = []
    for (mismatch, kind, label), affected in sorted(groups.items()):
        ctx.touched(*affected)
        findings.append(
            make_finding(
                "per_kind_label_mismatch",
                affected[:5],
                "low",
                f"the window {_clamp(label)!r} carries {mismatch} but is recorded as kind "
                f"{kind!r}, so its "
                f"semantics are ambiguous. {len(affected)} figures use this window.",
                evidence_class="declared_metadata",
                detail={
                    "label": label,
                    "kind": kind,
                    "mismatch": mismatch,
                    "affected_claim_count": len(affected),
                    "affected_claim_ids": [c.claim_id for c in affected[:200]],
                },
            )
        )
    return findings


@check(
    "per_mixed_periods_in_total",
    "A total adds components covering different periods.",
    overturnable_by=METRIC_LAYER,
)
def per_mixed_periods_in_total(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in ctx.ledger.claims:
        if total.role not in ("total", "subtotal") or not total.aggregates_claims:
            continue
        parts = ctx.ledger.resolve(total.aggregates_claims)
        labels = {p.period_label for p in parts if p.period_label}
        if len(labels) < 2:
            continue
        ctx.touched(total, *parts)
        findings.append(
            make_finding(
                "per_mixed_periods_in_total",
                [total] + parts,
                "high",
                f"{total.metric_label or total.claim_id} adds components covering "
                f"{len(labels)} different periods ({', '.join(sorted(labels))}), so the total is "
                f"not a figure for any one window.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={"periods": sorted(labels)},
            )
        )
    return findings


@check(
    "per_mixed_periods_in_column",
    "One table column mixes periods, so its rows are not comparable.",
)
def per_mixed_periods_in_column(ctx: CheckContext) -> list[Finding]:
    findings = []
    for (table_id, column_label), claims in sorted(
        column_groups(ctx.ledger).items(), key=lambda kv: (kv[0][0], kv[0][1] or "")
    ):
        labels = {c.period_label for c in claims if c.period_label}
        if len(labels) < 2:
            continue
        ctx.touched(*claims)
        findings.append(
            make_finding(
                "per_mixed_periods_in_column",
                claims,
                "medium",
                f"column {column_label or '(unlabelled)'} of {table_id} mixes the periods "
                f"{', '.join(sorted(labels))}, so its rows are not comparable to each other.",
                evidence_class="structural",
                detail={"periods": sorted(labels)},
            )
        )
    return findings


@check(
    "per_comparison_length_mismatch",
    "A comparison sets two windows of different lengths against each other.",
    overturnable_by=METRIC_LAYER,
)
def per_comparison_length_mismatch(ctx: CheckContext) -> list[Finding]:
    from ..pairing import find_counterpart

    findings = []
    for claim in ctx.ledger.claims:
        if not claim.comparison:
            continue
        counterpart = find_counterpart(ctx.ledger, claim)
        if counterpart is None:
            continue
        a = claim.period.get("length_days")
        b = counterpart.period.get("length_days")
        if a is None or b is None or a == b:
            continue
        ctx.touched(claim, counterpart)
        findings.append(
            make_finding(
                "per_comparison_length_mismatch",
                [claim, counterpart],
                "high",
                f"{claim.metric_label or claim.claim_id} compares a {a}-day window "
                f"({claim.period_label}) against a {b}-day window ({counterpart.period_label}), so "
                f"the difference includes {abs(a - b)} extra day(s) of activity.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={"length_a": a, "length_b": b},
            )
        )
    return findings


@check(
    "per_base_equals_period",
    "A comparison names a base period identical to the claim's own period.",
)
def per_base_equals_period(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        base_label = (comparison.get("base_label") or "").strip().lower()
        if not base_label:
            continue
        if base_label != (claim.period_label or "").strip().lower():
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "per_base_equals_period",
                [claim],
                "high",
                f"{claim.metric_label or claim.claim_id} states a comparison base of "
                f"{comparison.get('base_label')!r}, which is its own period, so the change shown "
                f"compares the window to itself.",
                evidence_class="structural",
                detail={"period_label": claim.period_label, "base_label": comparison.get("base_label")},
            )
        )
    return findings


@check(
    "per_end_after_extraction",
    "A window ends after the document was extracted, so it covers data that did not "
    "exist yet.",
)
def per_end_after_extraction(ctx: CheckContext) -> list[Finding]:
    extracted = _parse_date(ctx.ledger.extracted_at)
    if extracted is None:
        return []
    findings = []
    for claim in ctx.ledger.claims:
        end = _parse_date(claim.period.get("end"))
        if end is None or end <= extracted:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "per_end_after_extraction",
                [claim],
                "medium",
                f"{claim.metric_label or claim.claim_id} covers a window ending {end}, after the "
                f"{extracted} extraction date, so part of it cannot have been observed.",
                evidence_class="structural",
                detail={"period_end": str(end), "extracted_at": str(extracted)},
            )
        )
    return findings


@check(
    "per_document_period_absent_from_claims",
    "The document states a period that no claim covers.",
)
def per_document_period_absent_from_claims(ctx: CheckContext) -> list[Finding]:
    doc_period = (ctx.ledger.source_period_label or "").strip()
    if not doc_period:
        return []
    labels = {(c.period_label or "").strip().lower() for c in ctx.ledger.claims}
    if doc_period.lower() in labels:
        return []
    # A document period is often a superset of the claim windows; only report when
    # no claim label shares any token with it.
    doc_tokens = {t for t in re.split(r"\W+", doc_period.lower()) if len(t) > 2}
    for label in labels:
        if doc_tokens & {t for t in re.split(r"\W+", label) if len(t) > 2}:
            return []
    return [
        make_finding(
            "per_document_period_absent_from_claims",
            [],
            "medium",
            f"the document declares the period {doc_period!r}, but no figure in it carries a "
            f"period label that shares any wording with that, so which window the report covers is "
            f"unverifiable.",
            evidence_class="textual",
            detail={"document_period": doc_period, "claim_periods": sorted(l for l in labels if l)},
            location="document header",
        )
    ]


@check(
    "per_same_value_across_window_lengths",
    "One figure is attributed to two windows of different lengths, so the same number "
    "is presented as covering both.",
    overturnable_by=METRIC_LAYER,
)
def per_same_value_across_window_lengths(ctx: CheckContext) -> list[Finding]:
    """A tile labelled "trailing 4 weeks" carrying the single-week figure.

    The defect is not that either number is wrong — both are the same number. It is
    that one of the two labels must be. A four-week total cannot equal the week it
    contains unless the other three weeks were zero, which no report claiming a
    four-week window means to assert.

    Detection needs no source data: two claims of the same metric, the same value
    inside their envelopes, and window lengths that differ. That is a contradiction
    the document makes against itself.
    """
    findings = []
    groups: dict[tuple, list[Claim]] = {}
    for claim in ctx.ledger.claims:
        if claim.value_parsed is None:
            continue
        if claim.unit not in ("currency", "units", "count"):
            continue
        length = claim.period.get("length_days")
        if length is None:
            continue
        key = metric_family_key(claim)
        if key is None:
            continue
        groups.setdefault((key, claim.entity_key()), []).append(claim)

    seen: set[tuple] = set()
    for (metric, _entity), claims in sorted(groups.items(), key=lambda kv: str(kv[0])):
        for index, first in enumerate(claims):
            for second in claims[index + 1 :]:
                len_a = first.period.get("length_days")
                len_b = second.period.get("length_days")
                if len_a == len_b:
                    continue
                band = sum_band([first.envelope, second.envelope])
                if not within((first.value_parsed or 0.0) - (second.value_parsed or 0.0), band):
                    continue
                if (first.value_parsed or 0.0) == 0:
                    continue
                pair = tuple(sorted((first.claim_id, second.claim_id)))
                if pair in seen:
                    continue
                seen.add(pair)
                longer, shorter = (
                    (second, first) if (len_b or 0) > (len_a or 0) else (first, second)
                )
                ctx.touched(first, second)
                findings.append(
                    make_finding(
                        "per_same_value_across_window_lengths",
                        [longer, shorter],
                        "high",
                        f"{longer.metric_label or metric} is shown as "
                        f"{longer.value_displayed} for {longer.period_label!r} "
                        f"({longer.period.get('length_days')} days) and the same figure "
                        f"{shorter.value_displayed} for {shorter.period_label!r} "
                        f"({shorter.period.get('length_days')} days). One number cannot cover both "
                        f"windows unless the extra "
                        f"{abs((len_a or 0) - (len_b or 0))} days contributed nothing, so one of "
                        f"the two labels is wrong.",
                        evidence_class="structural",
                        overturnable_by=METRIC_LAYER,
                        detail={
                            "metric": metric,
                            "longer_claim": longer.claim_id,
                            "longer_label": longer.period_label,
                            "longer_length_days": longer.period.get("length_days"),
                            "shorter_claim": shorter.claim_id,
                            "shorter_label": shorter.period_label,
                            "shorter_length_days": shorter.period.get("length_days"),
                            "value": longer.value_parsed,
                        },
                    )
                )
    return findings
