"""Family 3 — ungrounded claims (``gnd_``).

An ungrounded claim is an assertion the document makes that no number in the
ledger can support. Three shapes matter:

* a sentence with a figure in it that never became a ledger row, so nothing can
  ever check it;
* a causal assertion ("driven by", "because of") with no cause and effect pair to
  test;
* a superlative or a traceable-format figure with no source behind it.

Forward-looking statements are recorded at low severity only. A forecast is not a
defect, and flagging one as such is a false positive by policy.
"""

from __future__ import annotations

import re

from ..findings import CheckContext, Finding, check, make_finding
from ..ledger import BASIS_CONFIDENCE, Claim, numbers_in_text, parse_display_number

METRIC_LAYER = "metric_layer"

YEAR_RE = re.compile(r"^(19|20)\d{2}$")
COMPARATIVE_RE = re.compile(
    r"\b(more|less|higher|lower|larger|smaller|greater|fewer|better|worse|most|least|"
    r"biggest|largest|smallest|fastest|slowest|strongest|weakest)\b",
    re.IGNORECASE,
)
ORDINAL_SMALL = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "0"}


#: Wording that marks a block as defining a metric rather than reporting on one.
DEFINITIONAL_RE = re.compile(
    r"\bis defined as\b|\bdivided by\b|\bis the ratio\b|\bis calculated\b|"
    r"\bwhere shown\b|\bis weighted by\b|\bmeans\b|÷|\bis \(|\bis in-house\b|"
    r"\bis on-hand\b|\bcompares\b|\bexcludes\b|\bincludes\b",
    re.IGNORECASE,
)


def _is_definitional(text: str) -> bool:
    return bool(DEFINITIONAL_RE.search(text or ""))


def _comparable_set_exists_anywhere(ctx: CheckContext, claim: Claim) -> bool:
    """Whether the document holds a set this superlative could be ranked against.

    Matched on the looser metric family key plus unit and period, across table cells
    that are real rows. Two or more is a set.
    """
    from ..ledger import metric_family_key

    key = metric_family_key(claim)
    if key is None:
        return False
    peers = [
        other
        for other in ctx.ledger.claims
        if other.claim_id != claim.claim_id
        and other.row_label
        and other.loc_kind == "table_cell"
        and other.role not in ("total", "subtotal", "rank", "count")
        and other.unit == claim.unit
        and other.value_parsed is not None
        and metric_family_key(other) == key
    ]
    return len(peers) >= 2


def _norm_number_token(token: str) -> str:
    return token.strip().strip("()").replace(",", "").replace("$", "").replace("+", "")


#: Multipliers a prose figure may be written in relative to a claim's parsed value.
#: "$4.2M" in prose and ``4200000`` in the ledger are the same assertion.
_SCALE_MULTIPLIERS = (1.0, 1e3, 1e6, 1e9)


def _claim_numbers(claims: list[Claim]) -> list[float]:
    """Every numeric form a claim legitimately reads as, for prose matching."""
    numbers: list[float] = []
    for claim in claims:
        digits = parse_display_number(claim.value_displayed)
        if digits is not None:
            numbers.append(digits)
        if claim.value_parsed is not None:
            numbers.append(claim.value_parsed)
    return numbers


def _token_tolerance(token: str) -> float:
    """Half a unit of the token's own last written digit."""
    bare = _norm_number_token(token)
    if "." in bare:
        return 0.5 * 10.0 ** -len(bare.split(".", 1)[1])
    return 0.5


def _prose_number_matches(token: str, claim_numbers: list[float]) -> bool:
    """Whether a prose figure corresponds to some claim, at either's scale.

    String comparison is wrong here: a claim rendered ``$10.0M`` and prose saying
    ``10.0`` are the same number, and a claim parsed as ``10000000`` is too. So the
    comparison is numeric, at the tolerance of the token as written, across the
    scale multipliers a writer may use.
    """
    value = parse_display_number(token)
    if value is None:
        return False
    tolerance = _token_tolerance(token)
    for number in claim_numbers:
        for multiplier in _SCALE_MULTIPLIERS:
            if abs(abs(value) * multiplier - abs(number)) <= tolerance * multiplier:
                return True
            if multiplier != 1.0 and abs(abs(value) - abs(number) * multiplier) <= tolerance:
                return True
    return False


@check(
    "gnd_prose_number_not_extracted",
    "A prose block states a figure that is not present as any claim, so the figure is "
    "outside every check the engine can run.",
)
def gnd_prose_number_not_extracted(ctx: CheckContext) -> list[Finding]:
    findings = []
    claim_numbers = _claim_numbers(ctx.ledger.claims)
    period_labels = {c.period_label for c in ctx.ledger.claims if c.period_label}
    period_labels.add(ctx.ledger.source_period_label)
    for block in ctx.ledger.prose_blocks:
        linked = ctx.ledger.resolve(block.claim_ids)
        ctx.touched(*linked)
        unmatched = []
        for token in numbers_in_text(block.text):
            bare = _norm_number_token(token)
            if YEAR_RE.match(bare):
                continue
            if bare in ORDINAL_SMALL:
                continue
            if any(bare in (label or "") for label in period_labels):
                continue
            if _prose_number_matches(token, claim_numbers):
                continue
            unmatched.append(token)
        if not unmatched:
            continue
        findings.append(
            make_finding(
                "gnd_prose_number_not_extracted",
                linked,
                "medium",
                f"prose block {block.block_id} states {', '.join(sorted(set(unmatched))[:5])} "
                f"but no claim in the ledger carries those figures, so they are asserted without "
                f"anything to check them against.",
                evidence_class="textual",
                detail={"block_id": block.block_id, "unmatched": sorted(set(unmatched))},
                location=block.section or block.block_id,
            )
        )
    return findings


@check(
    "gnd_causal_marker_unsupported",
    "A causal assertion has no cause and effect pair of claims behind it.",
    overturnable_by=METRIC_LAYER,
)
def gnd_causal_marker_unsupported(ctx: CheckContext) -> list[Finding]:
    findings = []
    for block in ctx.ledger.prose_blocks:
        if not block.causal_markers:
            continue
        if block.forward_looking:
            continue
        if _is_definitional(block.text):
            # "Sell-through is units sold divided by (units sold + on hand). The rate
            # looks small because the on-hand base is large" is a method note
            # explaining a formula, not a causal claim about the week's performance.
            continue
        linked = ctx.ledger.resolve(block.claim_ids)
        ctx.touched(*linked)
        if len(linked) >= 2:
            continue
        severity = "high" if not linked else "medium"
        findings.append(
            make_finding(
                "gnd_causal_marker_unsupported",
                linked,
                severity,
                f"prose block {block.block_id} asserts causation "
                f"({', '.join(block.causal_markers)}) with {len(linked)} number(s) attached: a "
                f"cause and an effect are both needed before the claim can be tested.",
                evidence_class="textual",
                overturnable_by=METRIC_LAYER,
                detail={
                    "block_id": block.block_id,
                    "causal_markers": block.causal_markers,
                    "claim_count": len(linked),
                },
                location=block.section or block.block_id,
            )
        )
    return findings


@check(
    "gnd_comparative_without_number",
    "A comparative or superlative sentence carries no figure at all.",
)
def gnd_comparative_without_number(ctx: CheckContext) -> list[Finding]:
    findings = []
    for block in ctx.ledger.prose_blocks:
        if block.claim_ids:
            continue
        if numbers_in_text(block.text):
            continue
        match = COMPARATIVE_RE.search(block.text)
        if match is None:
            continue
        findings.append(
            make_finding(
                "gnd_comparative_without_number",
                [],
                "medium",
                f"prose block {block.block_id} makes a comparative claim "
                f"({match.group(0)!r}) with no figure attached, so "
                f"there is nothing to verify it against.",
                evidence_class="textual",
                detail={"block_id": block.block_id},
                location=block.section or block.block_id,
            )
        )
    return findings


@check(
    "gnd_superlative_uncheckable",
    "A superlative has no comparable sibling values in the ledger, so it cannot be "
    "tested even in principle.",
)
def gnd_superlative_uncheckable(ctx: CheckContext) -> list[Finding]:
    from ..pairing import comparable_siblings, is_caption_count

    findings = []
    for claim in ctx.ledger.claims:
        if not claim.superlatives:
            continue
        # "Top 5 of 62 teams" is a caption describing the selection, not a claim that
        # 5 is the largest of anything.
        if is_caption_count(claim):
            continue
        siblings = comparable_siblings(ctx.ledger, claim)
        if len(siblings) >= 2:
            continue
        # A prose superlative has no table of its own, so the set it ranks against
        # lives elsewhere in the document. "It is the largest class in the area at
        # 29.9% share" is checkable against the Share column two sections up, and
        # calling it unverifiable because the sentence is not inside that table is
        # wrong.
        if _comparable_set_exists_anywhere(ctx, claim):
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "gnd_superlative_uncheckable",
                [claim],
                "low",
                f"{claim.metric_label or claim.claim_id} is called "
                f"{', '.join(claim.superlatives)} but the ledger holds no comparable set for it, "
                f"so the ranking cannot be confirmed without the source data.",
                evidence_class="coverage",
                detail={
                    "aggregate_key": "superlatives_without_a_comparable_set",
                    "superlatives": claim.superlatives,
                    "siblings": len(siblings),
                },
            )
        )
    return findings


@check(
    "gnd_unsourced_figure",
    "A figure in a format that supports per-cell traceability carries no source "
    "reference.",
)
def gnd_unsourced_figure(ctx: CheckContext) -> list[Finding]:
    if not ctx.ledger.supports_traceability:
        return []
    findings = []
    unsourced = [c for c in ctx.ledger.claims if not c.sourced and c.value_parsed is not None]
    if not unsourced:
        return []
    ctx.touched(*unsourced)
    for claim in unsourced:
        findings.append(
            make_finding(
                "gnd_unsourced_figure",
                [claim],
                "medium",
                f"{claim.metric_label or claim.claim_id} shows {claim.value_displayed} with no "
                f"snapshot reference, although this document format carries traceability for its "
                f"other figures.",
                evidence_class="structural",
                detail={"format": ctx.ledger.source_format},
            )
        )
    return findings


@check(
    "gnd_forward_looking_figure",
    "A figure sits inside a forward-looking statement. Recorded for context only: a "
    "forecast is a decision, not a defect.",
)
def gnd_forward_looking_figure(ctx: CheckContext) -> list[Finding]:
    findings = []
    for block in ctx.ledger.prose_blocks:
        if not block.forward_looking:
            continue
        linked = ctx.ledger.resolve(block.claim_ids)
        if not linked:
            continue
        ctx.touched(*linked)
        findings.append(
            make_finding(
                "gnd_forward_looking_figure",
                linked,
                "low",
                f"prose block {block.block_id} is forward looking and carries "
                f"{len(linked)} figure(s); these are estimates and are excluded from the defect "
                f"count by policy.",
                evidence_class="coverage",
                detail={"block_id": block.block_id, "claim_ids": [c.claim_id for c in linked]},
                location=block.section or block.block_id,
            )
        )
    return findings


@check(
    "gnd_confidence_basis_mismatch",
    "A claim's declared confidence level does not follow from its evidence basis.",
)
def gnd_confidence_basis_mismatch(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        basis = claim.confidence_basis
        declared = claim.confidence_level_declared
        if basis is None or declared is None:
            continue
        expected = BASIS_CONFIDENCE.get(basis)
        if expected is None or expected == declared:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "gnd_confidence_basis_mismatch",
                [claim],
                "low",
                f"{claim.claim_id} declares confidence {declared!r} while its evidence basis "
                f"{basis!r} supports {expected!r}; the engine uses the basis, not the declaration.",
                evidence_class="coverage",
                detail={"declared": declared, "basis": basis, "expected": expected},
            )
        )
    return findings


@check(
    "gnd_claim_without_period",
    "A flow figure carries no period, so it cannot be tied to a window.",
)
def gnd_claim_without_period(ctx: CheckContext) -> list[Finding]:
    findings = []
    flows = {"currency", "units", "count"}
    for claim in ctx.ledger.claims:
        if claim.unit not in flows:
            continue
        if claim.period_label:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "gnd_claim_without_period",
                [claim],
                "low",
                f"{claim.metric_label or claim.claim_id} shows {claim.value_displayed} with no "
                f"period stated, so which window it covers is unverifiable.",
                evidence_class="coverage",
                detail={"unit": claim.unit},
            )
        )
    return findings
