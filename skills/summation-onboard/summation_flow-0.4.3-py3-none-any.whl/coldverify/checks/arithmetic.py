"""Family 1 — internal arithmetic (``ari_``).

Every comparison in this file is a band test from :mod:`coldverify.envelope`.
There is no ``==`` on a pair of numbers anywhere in it.

Findings here are marked ``overturnable_by: "metric_layer"`` wherever they depend
on ``aggregates_claims``, which the schema describes as *believed, not proven*.
Spec item 4.17 requires that upgrade path be visible rather than hidden.
"""

from __future__ import annotations

from typing import Optional

from ..envelope import (
    foot_total,
    percent_change_band,
    quotient_band,
    shares_band,
    sum_band,
    within,
)
from ..findings import CheckContext, Finding, check, make_finding
from ..ledger import UNICODE_MINUS, Claim
from ..pairing import column_groups, is_share_group

METRIC_LAYER = "metric_layer"


def _fmt(value: float | None, precision: int = 4) -> str:
    if value is None:
        return "unknown"
    if abs(value) >= 1000:
        return f"{value:,.{max(0, precision - 2)}f}".rstrip("0").rstrip(".")
    return f"{value:,.{precision}f}".rstrip("0").rstrip(".") or "0"


def _totals(ctx: CheckContext) -> list[Claim]:
    return [
        c
        for c in ctx.ledger.claims
        if c.role in ("total", "subtotal") and c.aggregates_claims
    ]


#: Units a change may legitimately be stated in relative to the levels behind it.
#: A margin moving from 40% to 43% is a 3-point change: the delta's unit is
#: `points` while the levels are `percent`, and that is correct, not a defect.
PERCENT_FAMILY = {"percent", "points", "basis_points"}


def _unit_compatible(
    delta_unit: Optional[str], level_unit: Optional[str], form: Optional[str] = None
) -> bool:
    """Whether a change in ``delta_unit`` can be drawn from levels in ``level_unit``.

    A **relative** change is dimensionless: "net sales fell 4.5%" is a percent
    change of dollars, and demanding that the levels also be percentages would
    refuse every year-over-year column in a real report.

    An **absolute** change must share its levels' dimension, with one exception the
    schema names: a margin moving from 40% to 43% is a 3-*point* change, so the
    percent family is compatible with itself.
    """
    if delta_unit == level_unit:
        return True
    if form == "percent_change" or delta_unit == "percent":
        return True
    if delta_unit in PERCENT_FAMILY and level_unit in PERCENT_FAMILY:
        return True
    return False


def levels_behind(ctx: CheckContext, claim: Claim):
    """The two level claims a delta is drawn from, oldest first, or ``None``.

    Refuses unless the relationship is either **asserted** by the document or
    unambiguous:

    * ``derived_from`` naming a difference, percent change or point change, or
      ``comparison.base_claim_id`` plus one same-metric level, are asserted and are
      used directly.
    * Otherwise the ledger must hold exactly two same-unit, same-metric,
      same-entity levels. Three candidates make the pairing a guess, and a guessed
      pairing produces a confident finding about a comparison the document never
      made.

    An unidentifiable metric (``label_key() is None``) never pairs.
    """
    derived = claim.derived_from
    if derived and derived.get("operation") in ("difference", "percent_change", "point_change"):
        operands = ctx.ledger.resolve(derived.get("operands") or [])
        if len(operands) == 2 and all(o.value_parsed is not None for o in operands):
            minuend, subtrahend = operands
            return subtrahend, minuend

    key = claim.label_key()
    if key is None:
        return None

    candidates = [
        c
        for c in ctx.ledger.claims
        if c.claim_id != claim.claim_id
        and c.comparison is None
        and c.role != "delta"
        and c.label_key() == key
        and c.entity_key() == claim.entity_key()
        and c.value_parsed is not None
    ]

    base_claim_id = (claim.comparison or {}).get("base_claim_id")
    if base_claim_id:
        base = ctx.ledger.get(base_claim_id)
        if base is None or base.value_parsed is None:
            return None
        others = [c for c in candidates if c.claim_id != base.claim_id]
        if len(others) == 1:
            return base, others[0]
        return None

    form = (claim.comparison or {}).get("form")
    levels = [c for c in candidates if _unit_compatible(claim.unit, c.unit, form)]
    if len(levels) != 2:
        return None
    # The two levels must be the same unit as each other, or differencing them is
    # meaningless however compatible each is with the delta.
    if levels[0].unit != levels[1].unit:
        return None
    levels.sort(
        key=lambda c: (
            c.period.get("end") or "",
            c.period.get("start") or "",
            c.period_label,
        )
    )
    return levels[0], levels[1]


#: Kept as a private alias so the rounding family's local import keeps working.
_level_pair = levels_behind


# ---------------------------------------------------------------------------


@check(
    "ari_total_footing",
    "A total or subtotal differs from its components by more than the propagated "
    "rounding envelope of the whole set.",
    overturnable_by=METRIC_LAYER,
)
def ari_total_footing(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in _totals(ctx):
        parts = ctx.ledger.resolve(total.aggregates_claims)
        missing = [cid for cid in total.aggregates_claims if ctx.ledger.get(cid) is None]
        if missing:
            ctx.skip(
                "ari_total_footing",
                f"aggregates_claims names claim ids absent from the ledger: {missing}",
                [total.claim_id],
            )
            continue
        if not parts:
            continue
        ctx.touched(total, *parts)
        verdict = foot_total(
            total.value_parsed,
            total.envelope,
            [p.value_parsed for p in parts],
            [p.envelope for p in parts],
        )
        if verdict.verdict == "indeterminate":
            ctx.skip(
                "ari_total_footing",
                "a participating value or display precision is unknown, so no honest band exists",
                [total.claim_id] + [p.claim_id for p in parts],
            )
            continue
        if verdict.verdict != "fail":
            continue
        findings.append(
            make_finding(
                "ari_total_footing",
                [total] + parts,
                "high",
                f"{total.metric_label or 'total'} is shown as {total.value_displayed} "
                f"but its {len(parts)} components sum to {_fmt(verdict.computed)}, "
                f"a gap of {_fmt(abs(verdict.discrepancy))} against a rounding allowance of "
                f"only {_fmt(verdict.summed_band)}.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                scale_sensitive=True,
                detail={
                    "stated": total.value_parsed,
                    "computed": verdict.computed,
                    "discrepancy": verdict.discrepancy,
                    "single_value_band": verdict.single_band,
                    "summed_band": verdict.summed_band,
                    "band_verdict": verdict.verdict,
                },
            )
        )
    return findings


@check(
    "ari_total_footing_precision",
    "A total's discrepancy against its components exceeds the total's own display "
    "envelope but stays inside the summed envelope of the parts: the column does "
    "not foot at the precision shown.",
    overturnable_by=METRIC_LAYER,
)
def ari_total_footing_precision(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in _totals(ctx):
        parts = ctx.ledger.resolve(total.aggregates_claims)
        if not parts or len(parts) != len(total.aggregates_claims):
            continue
        verdict = foot_total(
            total.value_parsed,
            total.envelope,
            [p.value_parsed for p in parts],
            [p.envelope for p in parts],
        )
        if verdict.verdict != "precision":
            continue
        # The middle band only carries meaning when the total is displayed *finer*
        # than its components. Six dollar amounts rounded to the nearest dollar can
        # accumulate a gap of several dollars against a total also shown to the
        # nearest dollar, and that is the exactly-computed-then-rounded case the
        # spec calls correct — not false precision. Firing there flags every
        # integer-dollar table in a real report.
        precisions = [p.displayed_precision for p in parts if p.displayed_precision is not None]
        if not precisions or total.displayed_precision is None:
            continue
        if total.displayed_precision <= max(precisions):
            continue
        findings.append(
            make_finding(
                "ari_total_footing_precision",
                [total] + parts,
                "medium",
                f"{total.metric_label or 'total'} is shown as {total.value_displayed}, but "
                f"adding the {len(parts)} components as displayed gives {_fmt(verdict.computed)}. "
                f"The gap of {_fmt(abs(verdict.discrepancy))} is larger than the total's own "
                f"rounding allowance of {_fmt(verdict.single_band)}, so it can only come from "
                f"rounding inside the parts: the total is presented at a precision its "
                f"components do not support.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={
                    "stated": total.value_parsed,
                    "sum_of_displayed_parts": verdict.computed,
                    "discrepancy": verdict.discrepancy,
                    "single_value_band": verdict.single_band,
                    "summed_band": verdict.summed_band,
                    "band_verdict": verdict.verdict,
                },
            )
        )
    return findings


@check(
    "ari_shares_sum_to_100",
    "A set of composition shares does not sum to 100 within the summed rounding "
    "envelope of the shares.",
    overturnable_by=METRIC_LAYER,
)
def ari_shares_sum_to_100(ctx: CheckContext) -> list[Finding]:
    findings = []
    for (table_id, column_label), claims in sorted(
        column_groups(ctx.ledger).items(), key=lambda kv: (kv[0][0], kv[0][1] or "")
    ):
        if not is_share_group(ctx.ledger, claims):
            continue
        shares = [
            c
            for c in claims
            if c.unit == "percent"
            and c.value_parsed is not None
            and c.role not in ("total", "subtotal")
        ]
        if len(shares) < 2:
            continue
        ctx.touched(*shares)
        total = sum(c.value_parsed or 0.0 for c in shares)
        band = shares_band([c.envelope for c in shares])
        if band is None:
            ctx.skip(
                "ari_shares_sum_to_100",
                "at least one share has no usable display precision",
                [c.claim_id for c in shares],
            )
            continue
        # Only a set that is *meant* to be a composition is judged. A column of
        # shares 40 points away from 100 is a different table, not a defect.
        if abs(total - 100.0) > max(band, 10.0):
            continue
        if within(total - 100.0, band):
            continue
        findings.append(
            make_finding(
                "ari_shares_sum_to_100",
                shares,
                "medium",
                f"the {len(shares)} shares in {table_id}/{column_label or 'the share column'} "
                f"sum to {_fmt(total)}%, not 100%. Rounding at the precision shown allows only "
                f"{_fmt(band)} of drift.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={"sum": total, "band": band, "n_shares": len(shares)},
            )
        )
    return findings


@check(
    "ari_subtotal_chain",
    "A total agrees with its immediate subtotals but not with the components those "
    "subtotals are built from.",
    overturnable_by=METRIC_LAYER,
)
def ari_subtotal_chain(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in _totals(ctx):
        if total.role != "total":
            continue
        subtotals = [
            c
            for c in ctx.ledger.resolve(total.aggregates_claims)
            if c.role == "subtotal" and c.aggregates_claims
        ]
        if not subtotals:
            continue
        leaves: list[Claim] = []
        for sub in subtotals:
            leaves.extend(ctx.ledger.resolve(sub.aggregates_claims))
        direct = [c for c in ctx.ledger.resolve(total.aggregates_claims) if c.role != "subtotal"]
        leaves.extend(direct)
        if not leaves:
            continue
        ctx.touched(total, *leaves)
        verdict = foot_total(
            total.value_parsed,
            total.envelope,
            [c.value_parsed for c in leaves],
            [c.envelope for c in leaves],
        )
        if verdict.verdict != "fail":
            continue
        findings.append(
            make_finding(
                "ari_subtotal_chain",
                [total] + leaves,
                "high",
                f"{total.metric_label or 'the total'} is shown as {total.value_displayed} but the "
                f"{len(leaves)} leaf components underneath its subtotals sum to "
                f"{_fmt(verdict.computed)}, outside the allowance of {_fmt(verdict.summed_band)}.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={
                    "stated": total.value_parsed,
                    "computed_from_leaves": verdict.computed,
                    "summed_band": verdict.summed_band,
                },
            )
        )
    return findings


@check(
    "ari_delta_consistency",
    "A stated absolute or point change does not equal the difference between the two "
    "levels the ledger holds for the same metric.",
    overturnable_by=METRIC_LAYER,
)
def ari_delta_consistency(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        if comparison.get("form") not in ("absolute_delta", "point_change"):
            continue
        if claim.value_parsed is None:
            continue
        # Find the two levels for the same metric and entity.
        pair = levels_behind(ctx, claim)
        if pair is None:
            ctx.skip(
                "ari_delta_consistency",
                "the two levels behind this change are not asserted by the document and "
                "cannot be resolved unambiguously, so the change is not checkable",
                [claim.claim_id],
            )
            continue
        old, new = pair
        ctx.touched(claim, old, new)
        implied = (new.value_parsed or 0.0) - (old.value_parsed or 0.0)
        band = sum_band([new.envelope, old.envelope, claim.envelope])
        verdict = within(claim.value_parsed - implied, band)
        if verdict is None:
            ctx.skip(
                "ari_delta_consistency",
                "a display precision is unknown, so no band exists",
                [claim.claim_id, old.claim_id, new.claim_id],
            )
            continue
        if verdict:
            continue
        findings.append(
            make_finding(
                "ari_delta_consistency",
                [claim, new, old],
                "high",
                f"the change in {claim.metric_label or 'the metric'} is shown as "
                f"{claim.value_displayed}, but {new.value_displayed} less "
                f"{old.value_displayed} is {_fmt(implied)}, outside the rounding allowance of "
                f"{_fmt(band)}.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={
                    "stated_delta": claim.value_parsed,
                    "implied_delta": implied,
                    "band": band,
                },
            )
        )
    return findings


@check(
    "ari_percent_change_consistency",
    "A stated percent change does not match the two levels it is drawn from, after "
    "first-order propagation of both levels' rounding envelopes.",
    overturnable_by=METRIC_LAYER,
)
def ari_percent_change_consistency(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        if comparison.get("form") != "percent_change":
            continue
        if claim.value_parsed is None:
            continue
        pair = levels_behind(ctx, claim)
        if pair is None:
            ctx.skip(
                "ari_percent_change_consistency",
                "the two levels behind this percent change are not asserted by the document "
                "and cannot be resolved unambiguously",
                [claim.claim_id],
            )
            continue
        old, new = pair
        if old.value_parsed in (None, 0):
            continue
        ctx.touched(claim, old, new)
        implied = 100.0 * ((new.value_parsed or 0.0) - old.value_parsed) / old.value_parsed
        band = percent_change_band(
            new.value_parsed or 0.0, new.envelope, old.value_parsed, old.envelope, claim.envelope
        )
        verdict = within(claim.value_parsed - implied, band)
        if verdict is None:
            ctx.skip(
                "ari_percent_change_consistency",
                "a display precision is unknown or the base could be zero, so no band exists",
                [claim.claim_id, old.claim_id, new.claim_id],
            )
            continue
        if verdict:
            continue
        findings.append(
            make_finding(
                "ari_percent_change_consistency",
                [claim, new, old],
                "high",
                f"{claim.metric_label or 'the metric'} is shown as changing "
                f"{claim.value_displayed}, but moving from {old.value_displayed} to "
                f"{new.value_displayed} is {_fmt(implied)}%, outside the propagated allowance of "
                f"{_fmt(band)} percentage points.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={
                    "stated_percent_change": claim.value_parsed,
                    "implied_percent_change": implied,
                    "band": band,
                },
            )
        )
    return findings


@check(
    "ari_percent_of_total",
    "A stated share of total does not equal the component divided by the total, after "
    "propagating both rounding envelopes through the quotient.",
    overturnable_by=METRIC_LAYER,
)
def ari_percent_of_total(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.unit != "percent" or claim.value_parsed is None:
            continue
        label = ((claim.metric_label or "") + " " + (claim.column_label or "")).lower()
        # A column headed plainly "Share" is a share of total as much as one headed
        # "% of total" is. Requiring the longer wording left the commonest real
        # column in a planner report unchecked.
        if not any(
            token in label
            for token in ("% of total", "share of total", "pct of total", "% of", "share", "mix")
        ):
            continue
        if claim.table_id is None:
            continue
        siblings = ctx.ledger.in_table(claim.table_id)
        total = next(
            (
                c
                for c in siblings
                if c.role == "total"
                and c.value_parsed not in (None, 0)
                and c.unit in ("currency", "units", "count")
            ),
            None,
        )
        # The numerator must be the same row, the same unit as the total, and the
        # column the total lives in — not merely any figure on that row.
        component = next(
            (
                c
                for c in siblings
                if c.row_label == claim.row_label
                and c.claim_id != claim.claim_id
                and total is not None
                and c.unit == total.unit
                and c.column_label == total.column_label
                and c.value_parsed is not None
            ),
            None,
        )
        if total is None or component is None:
            continue
        ctx.touched(claim, total, component)
        implied = 100.0 * (component.value_parsed or 0.0) / (total.value_parsed or 1.0)
        qband = quotient_band(
            component.value_parsed or 0.0, component.envelope, total.value_parsed or 1.0, total.envelope
        )
        # An unknown envelope on the share itself makes the band indeterminate.
        # Substituting zero here would turn every unlabelled precision into a
        # defect, which is the false-positive mode that matters most.
        band = (
            None
            if (qband is None or claim.envelope is None)
            else 100.0 * qband + claim.envelope
        )
        verdict = within(claim.value_parsed - implied, band)
        if verdict is None:
            ctx.skip(
                "ari_percent_of_total",
                "a display precision is unknown, so the quotient band cannot be propagated",
                [claim.claim_id, component.claim_id, total.claim_id],
            )
            continue
        if verdict:
            continue
        findings.append(
            make_finding(
                "ari_percent_of_total",
                [claim, component, total],
                "high",
                f"the share for {claim.row_label or 'this row'} is shown as "
                f"{claim.value_displayed}, but {component.value_displayed} of "
                f"{total.value_displayed} is {_fmt(implied)}%, outside the propagated allowance "
                f"of {_fmt(band)} percentage points.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                precision_sensitive=True,
                detail={"stated": claim.value_parsed, "implied": implied, "band": band},
            )
        )
    return findings


@check(
    "ari_double_counting",
    "One component is claimed by two different totals in the same table column, so it "
    "is counted twice.",
    overturnable_by=METRIC_LAYER,
)
def ari_double_counting(ctx: CheckContext) -> list[Finding]:
    findings = []
    owners: dict[str, list[Claim]] = {}
    for total in _totals(ctx):
        for cid in total.aggregates_claims:
            owners.setdefault(cid, []).append(total)
    for cid, totals in sorted(owners.items()):
        if len(totals) < 2:
            continue
        # A component legitimately rolls into a subtotal and then into the grand
        # total. Only same-level double claiming is a defect.
        levels = {t.role or "unknown" for t in totals}
        if levels == {"subtotal", "total"} and len(totals) == 2:
            continue
        component = ctx.ledger.get(cid)
        if component is None:
            continue
        ctx.touched(component, *totals)
        findings.append(
            make_finding(
                "ari_double_counting",
                [component] + totals,
                "medium",
                f"{component.metric_label or cid} ({component.value_displayed}) is listed as a "
                f"component of {len(totals)} separate {'/'.join(sorted(levels))} claims "
                f"({', '.join(t.claim_id for t in totals)}), so it is counted more than once.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={"component": cid, "totals": [t.claim_id for t in totals]},
            )
        )
    return findings


@check(
    "ari_self_referential_total",
    "A total lists itself among its own components.",
    overturnable_by=METRIC_LAYER,
)
def ari_self_referential_total(ctx: CheckContext) -> list[Finding]:
    findings = []
    for total in _totals(ctx):
        if total.claim_id not in total.aggregates_claims:
            continue
        ctx.touched(total)
        findings.append(
            make_finding(
                "ari_self_referential_total",
                [total],
                "high",
                f"{total.metric_label or total.claim_id} lists itself among its own components, "
                f"so any footing of it is circular.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={"claim_id": total.claim_id},
            )
        )
    return findings


@check(
    "ari_orphan_component",
    "A component sits in a column that has a total, but no total claims it.",
    overturnable_by=METRIC_LAYER,
)
def ari_orphan_component(ctx: CheckContext) -> list[Finding]:
    findings = []
    claimed = {cid for t in _totals(ctx) for cid in t.aggregates_claims}
    for (table_id, column_label), claims in sorted(
        column_groups(ctx.ledger).items(), key=lambda kv: (kv[0][0], kv[0][1] or "")
    ):
        totals = [c for c in claims if c.role in ("total", "subtotal") and c.aggregates_claims]
        if not totals:
            continue
        orphans = [
            c
            for c in claims
            if c.role == "component" and c.claim_id not in claimed and c.value_parsed is not None
        ]
        if not orphans:
            continue
        ctx.touched(*orphans)
        findings.append(
            make_finding(
                "ari_orphan_component",
                orphans + totals,
                "medium",
                f"{len(orphans)} component rows in {table_id}/{column_label or 'the value column'} "
                f"({', '.join((c.row_label or c.claim_id) for c in orphans)}) are not part of any "
                f"total in that column, so the total shown is either incomplete or the rows are "
                f"not comparable.",
                evidence_class="structural",
                overturnable_by=METRIC_LAYER,
                detail={
                    "orphans": [c.claim_id for c in orphans],
                    "totals": [t.claim_id for t in totals],
                },
            )
        )
    return findings


@check(
    "ari_unparseable_value",
    "A displayed value could not be parsed to a number, so nothing about it is "
    "checkable.",
)
def ari_unparseable_value(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.value_parsed is not None:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "ari_unparseable_value",
                [claim],
                "medium",
                f"the value shown as {claim.value_displayed!r} for "
                f"{claim.metric_label or 'an unnamed metric'} could not be read as a number, so "
                f"no arithmetic check can reach it.",
                evidence_class="coverage",
                detail={"value_displayed": claim.value_displayed},
            )
        )
    return findings


@check(
    "ari_sign_convention",
    "The rendered value carries a negative convention that the parsed value does not, "
    "or the reverse.",
)
def ari_sign_convention(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        if claim.value_parsed is None:
            continue
        text = claim.value_displayed.strip()
        accounting_negative = text.startswith("(") and text.endswith(")")
        # Every dash a renderer uses for a minus, not the two this check knew about. The HTML
        # extractor emits U+2212 MINUS SIGN, so ASCII plus U+2212 covered every ledger that
        # existed when this was written. A person reading a rendered page cannot tell U+2013 EN
        # DASH from U+2212 — they are the same mark to the eye — so a model-written ledger
        # transcribes whichever it chose, and this check then called every negative figure in
        # the document a sign-convention defect. Twenty-five of them on the first real one.
        minus_negative = text.startswith(tuple("-" + UNICODE_MINUS))
        display_negative = accounting_negative or minus_negative
        parsed_negative = claim.value_parsed < 0
        if display_negative == parsed_negative:
            continue
        if claim.value_parsed == 0:
            continue
        ctx.touched(claim)
        findings.append(
            make_finding(
                "ari_sign_convention",
                [claim],
                "high",
                f"{claim.metric_label or claim.claim_id} is rendered as {claim.value_displayed} "
                f"but carries the value {_fmt(claim.value_parsed)}: the sign shown and the sign "
                f"used do not agree, so every calculation touching it is inverted.",
                evidence_class="display",
                detail={
                    "value_displayed": claim.value_displayed,
                    "value_parsed": claim.value_parsed,
                },
            )
        )
    return findings


@check(
    "ari_delta_direction_vs_levels",
    "A percent change and the two levels behind it point in opposite directions.",
    overturnable_by=METRIC_LAYER,
)
def ari_delta_direction_vs_levels(ctx: CheckContext) -> list[Finding]:
    findings = []
    for claim in ctx.ledger.claims:
        comparison = claim.comparison or {}
        if comparison.get("form") not in ("percent_change", "absolute_delta", "point_change"):
            continue
        if claim.value_parsed is None:
            continue
        levels = _level_pair(ctx, claim)
        if levels is None:
            continue
        old, new = levels
        ctx.touched(claim, old, new)
        diff = (new.value_parsed or 0.0) - (old.value_parsed or 0.0)
        implied_band = sum_band([new.envelope, old.envelope])
        inside = within(diff, implied_band)
        if inside is None:
            continue
        implied_sign = 0 if inside else (1 if diff > 0 else -1)
        stated_inside = within(claim.value_parsed, claim.envelope)
        if stated_inside is None:
            continue
        stated_sign = 0 if stated_inside else (1 if claim.value_parsed > 0 else -1)
        if stated_sign == 0 or implied_sign == 0 or stated_sign == implied_sign:
            continue
        findings.append(
            make_finding(
                "ari_delta_direction_vs_levels",
                [claim, new, old],
                "high",
                f"the change for {claim.metric_label or claim.claim_id} is shown as "
                f"{claim.value_displayed}, but the levels move from {old.value_displayed} to "
                f"{new.value_displayed}, which is the opposite direction.",
                evidence_class="arithmetic",
                overturnable_by=METRIC_LAYER,
                detail={
                    "stated": claim.value_parsed,
                    "old": old.value_parsed,
                    "new": new.value_parsed,
                },
            )
        )
    return findings
