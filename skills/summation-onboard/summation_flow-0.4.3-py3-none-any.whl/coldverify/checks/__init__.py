"""Check modules. Importing this package registers every check.

Import order fixes nothing about execution order — the engine sorts by check id —
but every module must be imported here or its checks silently do not exist, which
would be exactly the "never ran the detector" failure the spec forbids.
"""

from . import arithmetic  # noqa: F401
from . import direction  # noqa: F401
from . import grounding  # noqa: F401
from . import period  # noqa: F401
from . import rounding  # noqa: F401
from . import selection  # noqa: F401
from . import template  # noqa: F401
from . import units  # noqa: F401

MODULES = [
    "arithmetic",
    "direction",
    "grounding",
    "units",
    "rounding",
    "period",
    "selection",
    "template",
]
