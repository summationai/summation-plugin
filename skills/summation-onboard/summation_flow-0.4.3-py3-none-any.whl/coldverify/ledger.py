"""Claim-ledger loading, schema validation and read-only accessors.

The ledger is the only input this engine has. It is never mutated. Every accessor
here is defensive: the schema makes most fields optional, so a check that assumes
a field exists is a bug in the check, not in the ledger.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from functools import cached_property
from typing import Iterator, Optional

from .envelope import envelope_from_precision, scale_factor

#: Inside the package first. The two repo-relative paths that follow are kept so a source
#: checkout still works, but an installed copy has no repo above it — and `load_schema`
#: returning None does not fail loudly, it silently downgrades every run to "validation
#: skipped". The first entry is the one that must always be there.
DEFAULT_SCHEMA_PATHS = (
    os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "schemas",
        "claim-ledger.schema.json",
    ),
    os.path.join(
        os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))),
        "schemas",
        "claim-ledger.schema.json",
    ),
    os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
        "schemas",
        "claim-ledger.schema.json",
    ),
)

#: Evidence class -> confidence. Ranked by how the value was *obtained*, never by
#: any model's self-report. Spec item 4.6 and agent-D rule D2.8.
BASIS_CONFIDENCE = {
    "structured_cell": "high",
    "structured_cell_inferred_header": "medium",
    "prose_parsed": "medium",
    "ocr": "low",
    "chart_estimate": "low",
}

CONFIDENCE_ORDER = ["low", "medium", "high"]

#: Formats that can carry a per-figure traceability reference. Used by the
#: unsourced-figure check so HTML and PDF are not punished for a thing they
#: structurally cannot do.
TRACEABLE_FORMATS = {"sdoc", "smd"}

#: A parenthesised numeric group, the accounting convention for a negative.
_PARENTHESISED = re.compile(r"\(\s*[^)]*\d[^)]*\)")

#: Characters a renderer uses for a minus sign that are not ASCII hyphen-minus.
#: A report that types U+2212 MINUS SIGN — which is typographically correct — must
#: not read as a positive number. Getting this wrong inverts the sign of every
#: negative figure in the document and produces one false positive per cell.
UNICODE_MINUS = "−–—‐‑⁃﹣－"

#: Space characters that appear inside rendered numbers as thousands separators.
UNICODE_SPACES = "     ⁠"

_DASH_THEN_DIGIT = re.compile(
    rf"^[\s(]*[{UNICODE_MINUS}-]\s*[$€£¥]?\s*[\d.]"
)


def normalise_numeric_text(text: str) -> str:
    """Fold a rendered number's typography onto ASCII.

    Only a dash that actually precedes a digit becomes a minus sign. A lone dash
    is an empty-cell marker, not the number zero, and must stay unparseable.
    """
    raw = str(text)
    for space in UNICODE_SPACES:
        raw = raw.replace(space, "")
    if _DASH_THEN_DIGIT.search(raw):
        for dash in UNICODE_MINUS:
            raw = raw.replace(dash, "-", 1)
    return raw

_NUM_IN_TEXT = re.compile(
    r"""
    (?<![\w.])                      # not mid-token
    \(?                             # optional accounting negative
    [-+]?
    (?:\$|€|£)?
    \d{1,3}(?:,\d{3})+(?:\.\d+)?    # 1,234 / 1,234.5
    |
    (?<![\w.])
    \(?[-+]?(?:\$|€|£)?\d+(?:\.\d+)?
    """,
    re.VERBOSE,
)


def schema_path() -> Optional[str]:
    for candidate in DEFAULT_SCHEMA_PATHS:
        if os.path.isfile(candidate):
            return candidate
    return None


def load_schema(path: Optional[str] = None) -> Optional[dict]:
    path = path or schema_path()
    if path is None or not os.path.isfile(path):
        return None
    with open(path, "r", encoding="utf-8") as handle:
        return json.load(handle)


class LedgerValidationError(ValueError):
    """Raised when a ledger does not satisfy the committed schema."""


def validate_ledger(raw: dict, schema: Optional[dict] = None) -> list[str]:
    """Return a list of human-readable schema errors. Empty list means valid."""
    schema = schema if schema is not None else load_schema()
    if schema is None:
        return ["schema not found on disk; validation skipped"]
    from jsonschema import validators as jsonschema_validators

    validator_cls = jsonschema_validators.validator_for(schema)
    validator = validator_cls(schema)
    errors = []
    for err in sorted(validator.iter_errors(raw), key=lambda e: list(e.absolute_path)):
        location = "/".join(str(p) for p in err.absolute_path) or "<root>"
        errors.append(f"{location}: {err.message}")
    return errors


@dataclass(frozen=True)
class Claim:
    """Read-only view over one ledger row."""

    raw: dict = field(repr=False)

    # -- identity ----------------------------------------------------------
    @property
    def claim_id(self) -> str:
        return self.raw["claim_id"]

    @property
    def value_displayed(self) -> str:
        return self.raw.get("value_displayed", "")

    @property
    def value_parsed(self) -> Optional[float]:
        v = self.raw.get("value_parsed")
        return None if v is None else float(v)

    @property
    def displayed_precision(self) -> Optional[int]:
        return self.raw.get("displayed_precision")

    @property
    def declared_envelope(self) -> Optional[float]:
        v = self.raw.get("rounding_envelope")
        return None if v is None else float(v)

    @property
    def unit(self) -> Optional[str]:
        return self.raw.get("unit")

    @property
    def currency_code(self) -> Optional[str]:
        return self.raw.get("currency_code")

    @property
    def scale(self) -> Optional[str]:
        return self.raw.get("scale")

    @property
    def scale_source(self) -> Optional[str]:
        return self.raw.get("scale_source")

    @property
    def metric_label(self) -> str:
        return self.raw.get("metric_label", "")

    @property
    def metric_id(self) -> Optional[str]:
        return self.raw.get("metric_id")

    @property
    def entity(self) -> dict:
        return self.raw.get("entity", {}) or {}

    @property
    def period(self) -> dict:
        return self.raw.get("period", {}) or {}

    @property
    def period_label(self) -> str:
        return self.period.get("label", "")

    @property
    def comparison(self) -> Optional[dict]:
        return self.raw.get("comparison")

    @property
    def filters_stated(self) -> list[dict]:
        return self.raw.get("filters_stated", []) or []

    @property
    def location(self) -> dict:
        return self.raw.get("location", {}) or {}

    @property
    def loc_kind(self) -> str:
        return self.location.get("kind", "")

    @property
    def section(self) -> str:
        """The claim's own section, or the empty string.

        Table cells usually carry no section of their own — it lives on the table —
        so :meth:`Ledger.section_of` should be preferred where a table is in scope.
        """
        return self.location.get("section") or ""

    @property
    def table_id(self) -> Optional[str]:
        return self.location.get("table_id")

    @property
    def row_label(self) -> Optional[str]:
        return self.location.get("row_label")

    @property
    def column_label(self) -> Optional[str]:
        return self.location.get("column_label")

    @property
    def row_index(self) -> Optional[int]:
        return self.location.get("row_index")

    @property
    def sentence(self) -> str:
        return self.location.get("sentence") or ""

    @property
    def role(self) -> Optional[str]:
        return self.raw.get("role")

    @property
    def aggregates_claims(self) -> list[str]:
        return self.raw.get("aggregates_claims", []) or []

    @property
    def derived_from(self) -> Optional[dict]:
        """How this figure was computed, when the document makes that derivable.

        Generalises ``aggregates_claims``. ``asserted_by: "inferred"`` lowers the
        confidence of anything built on it.
        """
        return self.raw.get("derived_from")

    @property
    def denomination(self) -> str:
        """``major``, ``minor`` or ``unknown``. Defaults to ``major`` per the schema."""
        return self.raw.get("denomination") or "major"

    @property
    def value_in_major_units(self) -> Optional[float]:
        """The value normalised to the major currency unit, when known.

        Falls back to ``value_parsed`` for a ``major`` denomination, and refuses
        (``None``) when the denomination is unknown — a figure that might be cents
        or might be dollars cannot be summed with either.
        """
        stated = self.raw.get("value_in_major_units")
        if stated is not None:
            return float(stated)
        if self.unit != "currency":
            return self.value_parsed
        if self.denomination == "major":
            return self.value_parsed
        if self.denomination == "minor" and self.value_parsed is not None:
            return self.value_parsed / 100.0
        return None

    @property
    def direction_words(self) -> list[str]:
        return [w.lower() for w in (self.raw.get("direction_words") or [])]

    @property
    def polarity(self) -> str:
        return self.raw.get("polarity") or "unknown"

    @property
    def superlatives(self) -> list[str]:
        return [w.lower() for w in (self.raw.get("superlatives") or [])]

    @property
    def sourced(self) -> Optional[dict]:
        return self.raw.get("sourced")

    @property
    def confidence_basis(self) -> Optional[str]:
        return (self.raw.get("confidence") or {}).get("basis")

    @property
    def confidence_level_declared(self) -> Optional[str]:
        return (self.raw.get("confidence") or {}).get("level")

    # -- derived -----------------------------------------------------------
    @property
    def scale_factor(self) -> Optional[float]:
        return scale_factor(self.scale if self.scale is not None else "ones")

    @cached_property
    def computed_envelope(self) -> Optional[float]:
        """Envelope derived from precision and scale, ignoring the declared one."""
        return envelope_from_precision(self.displayed_precision, self.scale or "ones")

    #: Units whose integer displays are cardinalities, not rounded measures. A
    #: currency or percent shown without decimals may hide rounding; a count of
    #: meetings, orders or units cannot — 24 meetings means exactly 24.
    _COUNT_UNITS = (None, "unknown", "units", "count")

    #: Displays that signal the writer rounded on purpose. Only cues attached to
    #: the value itself count; sentence-level hedging is the grounding checks'
    #: territory, not the envelope's.
    _APPROX_CUE = re.compile(r"[~≈]|\bapprox")

    @cached_property
    def is_exact_count(self) -> bool:
        """Whether this display is a bare integer count, exact by nature.

        True only when every signal agrees: integer value, integer display,
        no scale multiplier, a count-like unit, and no approximation cue in the
        display. Anything ambiguous keeps the precision-derived envelope.
        """
        if self.displayed_precision != 0:
            return False
        if self.scale not in (None, "ones"):
            return False
        if self.unit not in self._COUNT_UNITS:
            return False
        if self.value_parsed is None or not float(self.value_parsed).is_integer():
            return False
        if self._APPROX_CUE.search(self.value_displayed.lower()):
            return False
        return True

    @cached_property
    def envelope(self) -> Optional[float]:
        """The envelope checks should use.

        The extractor's declared ``rounding_envelope`` wins when present, because
        the extractor saw the rendered glyphs. When it is absent the engine
        derives it — except that a bare integer count is exact, so its display
        hides nothing (a five-row meeting table would otherwise tolerate a
        footing gap of 3 as "rounding drift"). When declared and computed
        disagree that is itself reported by ``rnd_envelope_inconsistent``, but
        the declared value is still honoured so one bad extractor field cannot
        cascade into arithmetic false positives.
        """
        declared = self.declared_envelope
        computed = self.computed_envelope
        if declared is not None:
            informative = computed is None or abs(declared - computed) > max(
                1e-9, abs(computed) * 1e-6
            )
            # A declaration that differs from the precision formula carries
            # knowledge the formula lacks — honour it. One that merely echoes
            # the formula adds nothing, so the count rule may still apply.
            if informative:
                return declared
        if self.is_exact_count:
            return 0.0
        return declared if declared is not None else computed

    @property
    def evidence_confidence(self) -> str:
        """Confidence from evidence class alone."""
        return BASIS_CONFIDENCE.get(self.confidence_basis or "", "low")

    @property
    def display_digits(self) -> Optional[float]:
        """The bare number visible in ``value_displayed``, ignoring scale.

        ``"$1.2M"`` -> ``1.2``. ``"(3.4)%"`` -> ``-3.4``. ``None`` when no number
        is legible.
        """
        return parse_display_number(self.value_displayed)

    @property
    def displayed_negative(self) -> bool:
        text = normalise_numeric_text(self.value_displayed).strip()
        return bool(_PARENTHESISED.search(text)) or text.lstrip("( ").startswith("-")

    def label_key(self) -> Optional[str]:
        """Metric identity for pairing claims, or ``None`` when unidentifiable.

        ``None`` is load-bearing. An empty ``metric_label`` normalises to the empty
        string, and if that were returned as an identity then every unlabelled
        prose figure in the document would be "the same metric" as every other —
        which is how a checker ends up comparing a vendor count of 47 against
        $35,811 and reporting a 76,000% error. No identity means no pairing.
        """
        if self.metric_id:
            return self.metric_id
        normalised = normalise_label(self.metric_label)
        return normalised or None

    def entity_key(self) -> tuple:
        return tuple(sorted((k, v) for k, v in self.entity.items()))

    def where(self) -> str:
        """Short human location, for finding statements."""
        loc = self.location
        bits = []
        if loc.get("section"):
            bits.append(str(loc["section"]))
        if loc.get("table_id"):
            cell = str(loc["table_id"])
            if loc.get("row_label"):
                cell += f"/{loc['row_label']}"
            if loc.get("column_label"):
                cell += f"/{loc['column_label']}"
            bits.append(cell)
        elif loc.get("page") is not None:
            bits.append(f"page {loc['page']}")
        if not bits:
            bits.append(self.loc_kind or "unknown location")
        return " ".join(bits)


def parse_display_number(text: str) -> Optional[float]:
    """Pull the numeric magnitude out of a rendered value string."""
    if text is None:
        return None
    raw = normalise_numeric_text(text).strip()
    if not raw:
        return None
    # Accounting negatives can carry a suffix outside the brackets: the schema's
    # own example is "(3.4)%", so an endswith(")") test is not enough. A printed
    # minus *inside* the brackets is the same negative stated twice, not a double
    # negative, so the two conventions are folded rather than multiplied.
    negative = bool(_PARENTHESISED.search(raw)) or raw.lstrip("( ").startswith("-")
    cleaned = raw.replace("(", "").replace(")", "")
    cleaned = re.sub(r"[^\d.,+-]", "", cleaned)
    cleaned = cleaned.replace(",", "")
    if cleaned.startswith("+"):
        cleaned = cleaned[1:]
    if cleaned.count("-") > 1 or cleaned.count(".") > 1:
        return None
    if cleaned in ("", "-", ".", "-."):
        return None
    try:
        value = float(cleaned)
    except ValueError:
        return None
    return -abs(value) if negative else value


def normalise_label(label: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (label or "").lower()).strip("_")


#: A parenthesised scale or currency annotation on a column heading. "Net demand TY
#: ($000)" and "Net demand TY" are the same metric wearing different column
#: furniture, and a cross-table comparison that cannot see that will never notice
#: the two disagree.
_LABEL_ANNOTATION = re.compile(
    r"\s*[\(\[]\s*(?:in\s+)?(?:[$£€]?\s*0{3,}s?|[$£€]?\s*(?:k|m|mm|bn|b)|thousands?|millions?|"
    r"billions?|whole\s+\w+|actual|[$£€]|usd|gbp|eur)\s*[\)\]]\s*",
    re.IGNORECASE,
)


#: A window annotation appended to a metric name. "Net demand — trailing 4 weeks"
#: is the metric "net demand" with its window written into the label, and the window
#: already lives in `period`. Without stripping it, the same figure carrying two
#: different window labels reads as two different metrics and the contradiction is
#: invisible.
_LABEL_WINDOW = re.compile(
    r"\s*[—–,:(\[]\s*(?:for\s+|the\s+)?(?:trailing|rolling|last|past|previous|prior|"
    r"year[- ]to[- ]date|ytd|mtd|qtd|wtd|this|current|ty|ly)\b[^)\]]*[)\]]?\s*$",
    re.IGNORECASE,
)


def metric_family_key(claim: "Claim") -> Optional[str]:
    """A looser metric identity that ignores scale, currency and window annotations.

    Used only where the comparison is between whole tables or between windows, never
    for pairing two figures as a level and its base — that keeps the strict
    ``label_key``, because a loose identity there would resurrect the mis-pairings
    the strict one exists to prevent.
    """
    if claim.metric_id:
        return claim.metric_id
    stripped = _LABEL_ANNOTATION.sub(" ", claim.metric_label or "")
    stripped = _LABEL_WINDOW.sub("", stripped)
    normalised = normalise_label(stripped)
    return normalised or None


def numbers_in_text(text: str) -> list[str]:
    """Numeric tokens visible in a prose string, as written."""
    return [m.group(0) for m in _NUM_IN_TEXT.finditer(text or "")]


@dataclass
class Table:
    raw: dict = field(repr=False)

    @property
    def table_id(self) -> str:
        return self.raw["table_id"]

    @property
    def caption(self) -> str:
        return self.raw.get("caption", "") or ""

    @property
    def section(self) -> str:
        return self.raw.get("section", "") or ""

    @property
    def column_labels(self) -> list[str]:
        return self.raw.get("column_labels", []) or []

    @property
    def row_count(self) -> Optional[int]:
        return self.raw.get("row_count")

    @property
    def declared_sort(self) -> Optional[str]:
        return self.raw.get("declared_sort")

    @property
    def declared_scope(self) -> Optional[str]:
        return self.raw.get("declared_scope")

    @property
    def declared_scale(self) -> Optional[str]:
        return self.raw.get("declared_scale")


@dataclass
class ProseBlock:
    raw: dict = field(repr=False)

    @property
    def block_id(self) -> str:
        return self.raw["block_id"]

    @property
    def text(self) -> str:
        return self.raw.get("text", "") or ""

    @property
    def section(self) -> str:
        return self.raw.get("section", "") or ""

    @property
    def claim_ids(self) -> list[str]:
        return self.raw.get("claim_ids", []) or []

    @property
    def named_entities(self) -> list[str]:
        return self.raw.get("named_entities", []) or []

    @property
    def causal_markers(self) -> list[str]:
        return self.raw.get("causal_markers", []) or []

    @property
    def forward_looking(self) -> bool:
        return bool(self.raw.get("forward_looking"))


class Ledger:
    """Loaded, indexed claim ledger."""

    def __init__(self, raw: dict, path: Optional[str] = None):
        self.raw = raw
        self.path = path
        self.claims = [Claim(c) for c in raw.get("claims", [])]
        self.tables = [Table(t) for t in raw.get("tables", []) or []]
        self.prose_blocks = [ProseBlock(p) for p in raw.get("prose_blocks", []) or []]
        self.by_id = {c.claim_id: c for c in self.claims}
        self.tables_by_id = {t.table_id: t for t in self.tables}

    # -- metadata ----------------------------------------------------------
    @property
    def source(self) -> dict:
        return self.raw.get("source", {}) or {}

    @property
    def source_format(self) -> str:
        return self.source.get("format", "")

    @property
    def source_period_label(self) -> str:
        return self.source.get("period_label", "") or ""

    @property
    def extracted_at(self) -> str:
        return self.raw.get("extracted_at", "")

    @property
    def extraction_report(self) -> dict:
        return self.raw.get("extraction_report", {}) or {}

    @property
    def claims_found(self) -> int:
        reported = self.extraction_report.get("claims_found")
        return int(reported) if reported is not None else len(self.claims)

    @property
    def checkable_fraction(self) -> Optional[float]:
        v = self.extraction_report.get("checkable_fraction")
        return None if v is None else float(v)

    @property
    def supports_traceability(self) -> bool:
        return self.source_format in TRACEABLE_FORMATS

    # -- indexes -----------------------------------------------------------
    def get(self, claim_id: str) -> Optional[Claim]:
        return self.by_id.get(claim_id)

    def resolve(self, claim_ids: list[str]) -> list[Claim]:
        return [self.by_id[cid] for cid in claim_ids if cid in self.by_id]

    def in_table(self, table_id: Optional[str]) -> list[Claim]:
        if table_id is None:
            return []
        return [c for c in self.claims if c.table_id == table_id]

    def column(self, table_id: str, column_label: Optional[str]) -> list[Claim]:
        return [
            c
            for c in self.in_table(table_id)
            if c.column_label == column_label
        ]

    def section_of(self, claim: Claim) -> str:
        """The claim's section, falling back to its table's.

        A table cell inherits the table's section. Without this, a check that pairs
        a cell with a sentence "in the same section" silently pairs nothing.
        """
        if claim.section:
            return claim.section
        table = self.tables_by_id.get(claim.table_id or "")
        return (table.section if table else "") or ""

    def blocks_for(self, claim_id: str) -> list[ProseBlock]:
        return [b for b in self.prose_blocks if claim_id in b.claim_ids]

    def __iter__(self) -> Iterator[Claim]:
        return iter(self.claims)

    def __len__(self) -> int:
        return len(self.claims)


def load_ledger(
    path: str, schema: Optional[dict] = None, validate: bool = True
) -> Ledger:
    with open(path, "r", encoding="utf-8") as handle:
        raw = json.load(handle)
    if validate:
        errors = validate_ledger(raw, schema)
        hard = [e for e in errors if not e.startswith("schema not found")]
        if hard:
            raise LedgerValidationError(
                "claim ledger failed schema validation:\n  - "
                + "\n  - ".join(hard[:20])
            )
    return Ledger(raw, path=path)


def ledger_from_dict(raw: dict, validate: bool = True) -> Ledger:
    if validate:
        errors = [
            e
            for e in validate_ledger(raw)
            if not e.startswith("schema not found")
        ]
        if errors:
            raise LedgerValidationError(
                "claim ledger failed schema validation:\n  - " + "\n  - ".join(errors[:20])
            )
    return Ledger(raw)


def worst_confidence(levels: list[str]) -> str:
    """The lowest confidence among the participants."""
    if not levels:
        return "low"
    return min(levels, key=lambda lvl: CONFIDENCE_ORDER.index(lvl) if lvl in CONFIDENCE_ORDER else 0)


def downgrade(level: str, steps: int = 1) -> str:
    idx = CONFIDENCE_ORDER.index(level) if level in CONFIDENCE_ORDER else 0
    return CONFIDENCE_ORDER[max(0, idx - steps)]
