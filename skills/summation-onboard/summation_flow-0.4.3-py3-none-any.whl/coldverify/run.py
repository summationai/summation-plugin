"""``python -m coldverify.run`` — run the wave-1 checks over a claim ledger.

    python -m coldverify.run --ledger ledger.json --out findings.json

The command makes no network call of any kind. It reads two files at most (the
ledger and the committed schema) and writes one.
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Optional

from .engine import ENGINE_VERSION, run_checks
from .findings import FAMILIES, REGISTRY
from .ledger import LedgerValidationError, load_ledger

#: Spec item 4.12 — how many findings a first-time user is shown, and in what
#: register. Handing a prospect forty defects in minute two is a failure mode, so
#: the default view is capped and ordered by severity. The full set is always
#: written to the findings file; only the console summary is capped.
DEFAULT_CONSOLE_CAP = 8

TONE = (
    "Register: these are questions about the document, not accusations about the "
    "author. Wave-1 findings are provisional until the metric layer lands."
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m coldverify.run",
        description="Local, deterministic cold verification of a claim ledger. Offline by definition.",
    )
    parser.add_argument("--ledger", required=True, help="path to a claim-ledger/v1 JSON file")
    parser.add_argument("--out", help="path to write the findings JSON")
    parser.add_argument(
        "--family",
        action="append",
        choices=sorted(FAMILIES),
        help="restrict the run to one family; repeatable",
    )
    parser.add_argument(
        "--check",
        action="append",
        help="restrict the run to one check id; repeatable",
    )
    parser.add_argument(
        "--no-validate",
        action="store_true",
        help="skip schema validation of the ledger (records a coverage gap instead)",
    )
    parser.add_argument(
        "--cap",
        type=int,
        default=None,
        help="cap the findings written to the output file; the console summary is always capped",
    )
    parser.add_argument(
        "--console-cap",
        type=int,
        default=DEFAULT_CONSOLE_CAP,
        help=f"how many findings to print (default {DEFAULT_CONSOLE_CAP})",
    )
    parser.add_argument("--quiet", action="store_true", help="write the file, print nothing")
    parser.add_argument(
        "--list-checks",
        action="store_true",
        help="print the registered check library and exit",
    )
    parser.add_argument(
        "--fail-on",
        choices=["never", "any", "tier_d"],
        default="never",
        help="exit non-zero when findings of this class exist (default never)",
    )
    return parser


def print_check_library() -> None:
    print(f"coldverify {ENGINE_VERSION} — {len(REGISTRY)} checks across {len(FAMILIES)} families\n")
    for family in sorted(FAMILIES):
        specs = [s for s in REGISTRY.values() if s.family == family]
        print(f"{family} ({FAMILIES[family]}_) — {len(specs)} checks")
        for spec in sorted(specs, key=lambda s: s.check_id):
            overturn = "  [overturnable by metric_layer]" if spec.overturnable_by else ""
            print(f"  {spec.check_id}{overturn}")
            print(f"      {spec.description}")
        print()


def summarise(result, console_cap: int) -> None:
    head = result.to_dict()
    coverage = head["coverage"]
    headline = head["headline"]
    print(
        f"coldverify {ENGINE_VERSION}: {len(REGISTRY)} checks over "
        f"{coverage['claims_in_ledger']} claims in {head['timings']['elapsed_ms']} ms"
    )
    print(
        f"  reached by a check: {coverage['claims_reached_by_a_check']} "
        f"({_pct(coverage['engine_checkable_fraction'])}); extractor reported checkable "
        f"{_pct(coverage['extractor_checkable_fraction'])}"
    )
    print(
        f"  checks: {coverage['checks_with_findings']} found, "
        f"{coverage['checks_found_nothing']} found nothing, {coverage['checks_errored']} errored"
    )
    print(
        f"  findings: {headline['findings_total']} total; tier D "
        f"{headline['tier_d_defects']} "
        f"({_num(headline['tier_d_per_100_claims'])} per 100 claims)"
    )
    if result.time_to_first_finding_ms is not None:
        print(f"  time to first finding: {result.time_to_first_finding_ms} ms")
    print()
    for finding in result.findings[:console_cap]:
        overturn = (
            f" — provisional, {finding.overturnable_by} can overturn it"
            if finding.overturnable_by
            else ""
        )
        print(f"  [{finding.severity}/{finding.confidence}] {finding.check_id}{overturn}")
        print(f"      {finding.statement}")
        if finding.claim_ids:
            print(f"      claims: {', '.join(finding.claim_ids[:8])}")
    remaining = len(result.findings) - min(console_cap, len(result.findings))
    if remaining > 0:
        print(f"\n  {remaining} further finding(s) in the output file.")
    print(f"\n  {TONE}")


def _pct(value: Optional[float]) -> str:
    return "unknown" if value is None else f"{100.0 * value:.1f}%"


def _num(value: Optional[float]) -> str:
    return "unknown" if value is None else f"{value:.2f}"


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.list_checks:
        print_check_library()
        return 0

    try:
        ledger = load_ledger(args.ledger, validate=not args.no_validate)
    except LedgerValidationError as exc:
        print(f"coldverify: {exc}", file=sys.stderr)
        return 2
    except (OSError, json.JSONDecodeError) as exc:
        print(f"coldverify: could not read {args.ledger}: {exc}", file=sys.stderr)
        return 2

    result = run_checks(
        ledger,
        only_families=set(args.family) if args.family else None,
        only_checks=set(args.check) if args.check else None,
    )

    payload = result.to_dict(cap=args.cap)
    if args.no_validate:
        payload["coverage"]["schema_validated"] = False
    else:
        payload["coverage"]["schema_validated"] = True

    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=False)
            handle.write("\n")
    if not args.quiet:
        summarise(result, args.console_cap)
        if args.out:
            print(f"\n  findings written to {args.out}")

    if args.fail_on == "any" and result.findings:
        return 1
    if args.fail_on == "tier_d" and result.tier_d_findings:
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
