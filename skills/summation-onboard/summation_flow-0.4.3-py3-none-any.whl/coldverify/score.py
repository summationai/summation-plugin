"""``python -m coldverify.score`` — score findings against a sealed answer key.

    python -m coldverify.score --findings findings.json --answer-key key.json

Reports, per family, precision and recall, plus the two headline numbers the spec
demands together (item 4.8): tier-D defects per 100 claims, and the checkable
fraction. Never one without the other — "six contradictions" means nothing until
the reader knows it is six in the third of the document that could be checked at
all.

Answer-key format
-----------------
No answer-key schema exists in ``~/plg-e2e/schemas`` yet, so this module defines
the shape it reads and validates it structurally. Extra fields are ignored, so a
richer key from the clean-room build will still score.

.. code-block:: json

    {
      "answer_key_version": "cleanroom-answers/v1",
      "source": {"path": "report.html", "sha256": "..."},
      "planted_defects": [
        {
          "defect_id": "d01",
          "family": "units_scale",
          "check_id": "uni_percent_vs_points",
          "claim_ids": ["c0007"],
          "description": "margin move stated as percent when it is points",
          "tier": "D"
        }
      ]
    }

Matching rule
-------------
A finding matches a planted defect when the families agree **and** either the
``check_id`` matches exactly, or the claim id sets intersect. Family agreement is
required in both branches, so a check that stumbles onto the right claim for the
wrong reason does not earn credit. ``claim_ids`` may be empty on a
document-level defect, in which case only the ``check_id`` branch can match.
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, field
from typing import Optional

from .findings import FAMILIES


@dataclass
class FamilyScore:
    family: str
    findings: int = 0
    planted: int = 0
    true_positives: int = 0
    matched_defects: set = field(default_factory=set)

    @property
    def false_positives(self) -> int:
        return max(0, self.findings - self.true_positives)

    @property
    def precision(self) -> Optional[float]:
        if self.findings == 0:
            return None
        return self.true_positives / self.findings

    @property
    def recall(self) -> Optional[float]:
        if self.planted == 0:
            return None
        return len(self.matched_defects) / self.planted

    @property
    def f1(self) -> Optional[float]:
        p, r = self.precision, self.recall
        if p is None or r is None or (p + r) == 0:
            return None
        return 2 * p * r / (p + r)

    def to_dict(self) -> dict:
        return {
            "family": self.family,
            "findings": self.findings,
            "planted_defects": self.planted,
            "true_positives": self.true_positives,
            "false_positives": self.false_positives,
            "missed": self.planted - len(self.matched_defects),
            "precision": self.precision,
            "recall": self.recall,
            "f1": self.f1,
        }


def validate_answer_key(key: dict) -> list[str]:
    """Structural problems with an answer key. Empty list means usable."""
    problems = []
    if not isinstance(key, dict):
        return ["answer key is not a JSON object"]
    defects = key.get("planted_defects")
    if not isinstance(defects, list):
        return ["answer key has no 'planted_defects' array"]
    for index, defect in enumerate(defects):
        if not isinstance(defect, dict):
            problems.append(f"planted_defects[{index}] is not an object")
            continue
        if not defect.get("defect_id"):
            problems.append(f"planted_defects[{index}] has no defect_id")
        family = defect.get("family")
        if family not in FAMILIES:
            problems.append(
                f"planted_defects[{index}] family {family!r} is not one of the eight wave-1 families"
            )
        if not defect.get("claim_ids") and not defect.get("check_id"):
            problems.append(
                f"planted_defects[{index}] has neither claim_ids nor check_id, so nothing can match it"
            )
    return problems


def expected_check_ids(defect: dict) -> list[str]:
    """The check ids a defect accepts.

    A key may name one check or several: a scale defect can legitimately surface as
    ``uni_scale_not_honoured``, ``uni_magnitude_vs_declared_scale`` or
    ``sel_declared_scale_contradicted``, and a key that lists all three is saying
    "any of these counts". Reading that list as a single string silently scores
    every one of them as a miss.
    """
    value = defect.get("check_id")
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    return [str(v) for v in value]


def finding_claim_ids(finding: dict) -> set:
    """Every claim a finding touches, inline citations plus the aggregated set.

    A collapsed finding cites a handful of representatives inline and carries the
    rest in ``detail.affected_claim_ids``. Scoring only the inline citations would
    mark a correct aggregated finding as missing the claim the key names.
    """
    ids = set(finding.get("claim_ids") or [])
    detail = finding.get("detail") or {}
    ids |= set(detail.get("affected_claim_ids") or [])
    ids |= set(detail.get("declared_by") or [])
    return ids


def _must_not_flag_claims(answer_key: dict) -> tuple[set, int]:
    """Claims a key says are correct and must not be flagged.

    Accepts either a list of claim ids or a list of objects carrying ``claim_ids``,
    because both shapes appear in practice. Entries with no claim ids cannot be
    scored — they describe a negative in prose only — and are counted so the gap is
    visible rather than silently treated as zero violations.
    """
    entries = answer_key.get("must_not_flag") or []
    claims: set = set()
    unresolved = 0
    for entry in entries:
        if isinstance(entry, str):
            claims.add(entry)
            continue
        if isinstance(entry, dict):
            ids = entry.get("claim_ids") or []
            if ids:
                claims.update(str(i) for i in ids)
            else:
                unresolved += 1
            continue
        unresolved += 1
    return claims, unresolved


def matches(finding: dict, defect: dict) -> bool:
    """Strict match: the family must agree, then the check id or a claim must."""
    if finding.get("family") != defect.get("family"):
        return False
    return localises(finding, defect)


def localises(finding: dict, defect: dict) -> bool:
    """Family-agnostic match: did the engine point at the right thing at all?

    Scored separately from :func:`matches` so a correct detection filed under a
    different family taxonomy is visible as such rather than counted as both a
    false positive and a miss.
    """
    expected = expected_check_ids(defect)
    if expected and finding.get("check_id") in expected:
        return True
    defect_claims = set(defect.get("claim_ids") or [])
    if defect_claims and (finding_claim_ids(finding) & defect_claims):
        return True
    return False


#: Tiers whose findings assert that something in the document is wrong. Tier B is
#: defined by the engine as "a coverage or hygiene gap, not a wrong number" — an
#: honest note that a figure could not be reached, or that a detector did not apply.
#: Scoring those as false positives against a key of planted *defects* is a category
#: error: it penalises the engine for reporting its own coverage. They are counted and
#: listed separately instead, and the primary precision is over defect claims.
DEFECT_TIERS = {"C", "D"}


def is_defect_claim(finding: dict) -> bool:
    tier = finding.get("tier")
    if tier is None:
        return True
    return tier in DEFECT_TIERS


def score(findings_doc: dict, answer_key: Optional[dict]) -> dict:
    findings = findings_doc.get("findings", [])
    coverage = findings_doc.get("coverage", {})
    headline = findings_doc.get("headline", {})

    result: dict = {
        "headline": {
            "tier_d_defects": headline.get("tier_d_defects"),
            "tier_d_per_100_claims": headline.get("tier_d_per_100_claims"),
            "checkable_fraction_extractor": coverage.get("extractor_checkable_fraction"),
            "checkable_fraction_engine": coverage.get("engine_checkable_fraction"),
            "claims_in_ledger": coverage.get("claims_in_ledger"),
            "findings_total": len(findings),
            "note": "The defect count is only readable next to the checkable fraction: "
            "N contradictions in the share of the document assessable without live sources.",
        },
        "findings_truncated": findings_doc.get("findings_truncated", False),
    }

    if answer_key is None:
        result["scored"] = False
        result["reason"] = "no answer key supplied; headline numbers only"
        return result

    problems = validate_answer_key(answer_key)
    if problems:
        result["scored"] = False
        result["answer_key_problems"] = problems
        return result

    defects = answer_key["planted_defects"]
    families = sorted(set(FAMILIES) | {f.get("family") for f in findings if f.get("family")})
    scores = {family: FamilyScore(family=family) for family in families if family}

    for defect in defects:
        family = defect["family"]
        scores.setdefault(family, FamilyScore(family=family)).planted += 1

    unmatched_findings = []
    coverage_notes = [f for f in findings if not is_defect_claim(f)]
    for finding in findings:
        if not is_defect_claim(finding):
            continue
        family = finding.get("family") or "unknown"
        bucket = scores.setdefault(family, FamilyScore(family=family))
        bucket.findings += 1
        hits = [d for d in defects if matches(finding, d)]
        if hits:
            bucket.true_positives += 1
            for hit in hits:
                bucket.matched_defects.add(hit["defect_id"])
        else:
            unmatched_findings.append(
                {
                    "check_id": finding.get("check_id"),
                    "family": family,
                    "severity": finding.get("severity"),
                    "claim_ids": finding.get("claim_ids"),
                    "statement": finding.get("statement"),
                }
            )

    matched_ids = {d for bucket in scores.values() for d in bucket.matched_defects}
    missed = [
        {
            "defect_id": d["defect_id"],
            "family": d["family"],
            "check_id": d.get("check_id"),
            "claim_ids": d.get("claim_ids"),
            "description": d.get("description"),
        }
        for d in defects
        if d["defect_id"] not in matched_ids
    ]

    total_findings = sum(b.findings for b in scores.values())
    total_tp = sum(b.true_positives for b in scores.values())
    total_planted = len(defects)

    # A second, family-agnostic pass. Answer keys and engines can disagree about
    # which family owns a dual-nature defect — a share that misses 100 because a
    # part was rounded up is arguably arithmetic and arguably rounding — and that
    # disagreement should be visible as a taxonomy difference, not counted as both a
    # false positive and a miss. The strict numbers stay primary.
    localised_ids = set()
    localised_findings = 0
    defect_claims = [f for f in findings if is_defect_claim(f)]
    for finding in defect_claims:
        if any(localises(finding, d) for d in defects):
            localised_findings += 1
    for defect in defects:
        if any(localises(f, defect) for f in findings):
            localised_ids.add(defect["defect_id"])

    # Claims the key says must not be flagged at all. A hit here is an unambiguous
    # false positive: the key author looked at that figure and confirmed it correct.
    must_not_flag, unresolved_negatives = _must_not_flag_claims(answer_key)
    forbidden_hits = []
    if must_not_flag:
        for finding in findings:
            overlap = finding_claim_ids(finding) & must_not_flag
            if overlap:
                forbidden_hits.append(
                    {
                        "check_id": finding.get("check_id"),
                        "family": finding.get("family"),
                        "claim_ids": sorted(overlap),
                        "statement": finding.get("statement"),
                    }
                )

    result["scored"] = True
    result["per_family"] = {
        family: bucket.to_dict()
        for family, bucket in sorted(scores.items())
        if bucket.findings or bucket.planted
    }
    # Two precisions, always together. The defect-claim number measures detection;
    # the product number measures what a user actually sees, because a coverage note
    # still occupies a line on the screen. Reporting only the first would flatter the
    # engine; reporting only the second would punish it for honest coverage. Neither
    # is the number on its own.
    shown = len(findings)
    result["micro"] = {
        "precision": (total_tp / total_findings) if total_findings else None,
        "precision_over_all_findings_shown": (total_tp / shown) if shown else None,
        "findings_shown": shown,
        "precision_note": "precision is over defect claims (tier C and D); "
        "precision_over_all_findings_shown is over every item a user sees, coverage "
        "notes included. Quote both.",
        "recall": (len(matched_ids) / total_planted) if total_planted else None,
        "findings": total_findings,
        "planted_defects": total_planted,
        "true_positives": total_tp,
        "matched_defects": len(matched_ids),
    }
    measured = [
        b for b in scores.values() if b.precision is not None or b.recall is not None
    ]
    precisions = [b.precision for b in measured if b.precision is not None]
    recalls = [b.recall for b in measured if b.recall is not None]
    result["macro"] = {
        "precision": (sum(precisions) / len(precisions)) if precisions else None,
        "recall": (sum(recalls) / len(recalls)) if recalls else None,
        "families_with_findings": len(precisions),
        "families_with_planted_defects": len(recalls),
    }
    result["localisation"] = {
        "note": "Family-agnostic: did the engine point at the right figure or run the "
        "right check, ignoring which family it filed the finding under. Read next to "
        "the strict numbers to separate a detection failure from a taxonomy difference.",
        "precision": (localised_findings / total_findings) if total_findings else None,
        "recall": (len(localised_ids) / total_planted) if total_planted else None,
        "localised_defects": len(localised_ids),
        "planted_defects": total_planted,
        "defects_localised_but_filed_under_another_family": sorted(
            localised_ids - matched_ids
        ),
    }
    # A defect that only a tier-B note touches is not "missed" in the same sense as
    # one nothing saw. The engine noticed the figure and said, truthfully, that it
    # could not be settled without the source. Naming that state separately keeps the
    # miss list honest in both directions.
    noted_only = []
    for defect in defects:
        if defect["defect_id"] in matched_ids:
            continue
        if any(localises(f, defect) for f in coverage_notes):
            noted_only.append(defect["defect_id"])

    result["coverage_notes"] = {
        "note": "Tier-B findings: coverage and hygiene observations, not claims that a "
        "figure is wrong. Excluded from precision because the key lists defects, and "
        "penalising honest coverage reporting would reward silence.",
        "count": len(coverage_notes),
        "check_ids": sorted({str(f.get("check_id")) for f in coverage_notes}),
        "defects_noted_but_not_claimed": sorted(noted_only),
    }
    result["must_not_flag"] = {
        "claims_listed": len(must_not_flag),
        "entries_without_claim_ids": unresolved_negatives,
        "violations": forbidden_hits,
        "violation_count": len(forbidden_hits),
    }
    result["missed_defects"] = missed
    result["unmatched_findings"] = unmatched_findings
    return result


def _pct(value: Optional[float]) -> str:
    return "  n/a " if value is None else f"{100.0 * value:5.1f}%"


def render(report: dict) -> str:
    lines = []
    head = report["headline"]
    lines.append("Headline — never one number without the other")
    lines.append(
        f"  tier-D defects: {head['tier_d_defects']} "
        f"({_fmt_num(head['tier_d_per_100_claims'])} per 100 claims over "
        f"{head['claims_in_ledger']} claims)"
    )
    lines.append(
        f"  checkable fraction: {_pct(head['checkable_fraction_extractor']).strip()} as reported by "
        f"the extractor; {_pct(head['checkable_fraction_engine']).strip()} actually reached by a check"
    )
    lines.append(f"  all findings: {head['findings_total']}")
    lines.append("")

    if not report.get("scored"):
        lines.append(f"Not scored: {report.get('reason', 'answer key unusable')}")
        for problem in report.get("answer_key_problems", []):
            lines.append(f"  - {problem}")
        return "\n".join(lines)

    lines.append("Per family")
    lines.append(
        f"  {'family':22} {'found':>6} {'planted':>8} {'TP':>4} {'FP':>4} {'miss':>5} "
        f"{'precision':>10} {'recall':>8}"
    )
    for family, bucket in report["per_family"].items():
        lines.append(
            f"  {family:22} {bucket['findings']:>6} {bucket['planted_defects']:>8} "
            f"{bucket['true_positives']:>4} {bucket['false_positives']:>4} {bucket['missed']:>5} "
            f"{_pct(bucket['precision']):>10} {_pct(bucket['recall']):>8}"
        )
    lines.append("")
    micro, macro = report["micro"], report["macro"]
    lines.append(
        f"  micro precision {_pct(micro['precision']).strip()} over defect claims, "
        f"{_pct(micro.get('precision_over_all_findings_shown')).strip()} over all "
        f"{micro.get('findings_shown')} findings shown"
    )
    lines.append(
        f"  micro recall {_pct(micro['recall']).strip()} "
        f"({micro['matched_defects']}/{micro['planted_defects']} planted defects found)"
    )
    lines.append(
        f"  macro precision {_pct(macro['precision']).strip()}, "
        f"macro recall {_pct(macro['recall']).strip()}"
    )
    notes = report.get("coverage_notes") or {}
    if notes.get("count"):
        lines.append(
            f"  of which {notes['count']} are tier-B coverage notes, not defect claims, "
            f"and are excluded from precision"
        )
        if notes.get("defects_noted_but_not_claimed"):
            lines.append(
                f"    noticed only as a coverage note, not claimed as a defect: "
                f"{', '.join(notes['defects_noted_but_not_claimed'])}"
            )
    loc = report.get("localisation")
    if loc:
        lines.append(
            f"  localisation precision {_pct(loc['precision']).strip()}, "
            f"localisation recall {_pct(loc['recall']).strip()} "
            f"({loc['localised_defects']}/{loc['planted_defects']} pointed at, family ignored)"
        )
        if loc["defects_localised_but_filed_under_another_family"]:
            lines.append(
                f"    filed under a different family than the key: "
                f"{', '.join(loc['defects_localised_but_filed_under_another_family'])}"
            )
    mnf = report.get("must_not_flag") or {}
    if mnf.get("claims_listed") or mnf.get("entries_without_claim_ids"):
        lines.append(
            f"  must-not-flag: {mnf.get('claims_listed', 0)} claims listed, "
            f"{mnf.get('violation_count', 0)} violated"
            + (
                f"; {mnf['entries_without_claim_ids']} key entries carry no claim ids and "
                f"could not be scored"
                if mnf.get("entries_without_claim_ids")
                else ""
            )
        )
        for hit in mnf.get("violations", [])[:5]:
            lines.append(f"    - {hit['check_id']} on {', '.join(hit['claim_ids'])}")
    if report["missed_defects"]:
        lines.append("")
        lines.append("Missed planted defects")
        for defect in report["missed_defects"]:
            lines.append(
                f"  - {defect['defect_id']} [{defect['family']}] {defect.get('description') or ''}"
            )
    return "\n".join(lines)


def _fmt_num(value: Optional[float]) -> str:
    return "unknown" if value is None else f"{value:.2f}"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="python -m coldverify.score",
        description="Score cold-verify findings against a sealed answer key. Offline.",
    )
    parser.add_argument("--findings", required=True, help="findings JSON from coldverify.run")
    parser.add_argument("--answer-key", help="sealed answer key JSON; omit for headline numbers only")
    parser.add_argument("--out", help="write the score report as JSON")
    parser.add_argument("--quiet", action="store_true")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        with open(args.findings, "r", encoding="utf-8") as handle:
            findings_doc = json.load(handle)
    except (OSError, json.JSONDecodeError) as exc:
        print(f"coldverify.score: could not read {args.findings}: {exc}", file=sys.stderr)
        return 2

    answer_key = None
    if args.answer_key:
        try:
            with open(args.answer_key, "r", encoding="utf-8") as handle:
                answer_key = json.load(handle)
        except (OSError, json.JSONDecodeError) as exc:
            print(f"coldverify.score: could not read {args.answer_key}: {exc}", file=sys.stderr)
            return 2

    report = score(findings_doc, answer_key)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as handle:
            json.dump(report, handle, indent=2)
            handle.write("\n")
    if not args.quiet:
        print(render(report))
    if answer_key is not None and not report.get("scored"):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
