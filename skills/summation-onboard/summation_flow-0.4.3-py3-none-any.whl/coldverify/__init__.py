"""coldverify — a local, deterministic cold-verification engine over a claim ledger.

No network. No platform call. Standard library plus ``jsonschema``.

    from coldverify import load_ledger, run_checks

    result = run_checks(load_ledger("ledger.json"))
    print(result.tier_d_per_100_claims, result.engine_checkable_fraction)
"""

from .engine import ENGINE_NAME, ENGINE_VERSION, RunResult, run_checks
from .findings import FAMILIES, REGISTRY, Finding
from .ledger import Ledger, load_ledger, ledger_from_dict, validate_ledger

__all__ = [
    "ENGINE_NAME",
    "ENGINE_VERSION",
    "FAMILIES",
    "Finding",
    "Ledger",
    "REGISTRY",
    "RunResult",
    "ledger_from_dict",
    "load_ledger",
    "run_checks",
    "validate_ledger",
]
