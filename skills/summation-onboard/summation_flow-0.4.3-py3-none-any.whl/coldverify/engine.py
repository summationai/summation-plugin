"""The engine: run every registered check over a ledger and record every outcome.

Three properties this module guarantees, because the spec requires each of them:

* **Offline.** Nothing in this package imports a network library. There is no
  socket, no subprocess, no platform call. ``reports verify`` is a chat wrapper
  and is not the engine.
* **Deterministic.** Checks run in sorted ``check_id`` order and findings are
  sorted by a stable key. The same ledger gives byte-identical findings apart
  from the two recorded timings.
* **Negatives recorded.** Every registered check lands in ``checks_run`` with an
  outcome of ``found``, ``found_nothing`` or ``error``. Spec §0.2: a detector that
  found nothing and a detector that never ran are different states.
"""

from __future__ import annotations

import re
import time
import traceback
from dataclasses import dataclass, field
from typing import Optional

from . import checks as _checks  # noqa: F401  (registers every check)
from .findings import FAMILIES, REGISTRY, CheckContext, Finding, SEVERITY_TIER
from .ledger import Ledger

ENGINE_NAME = "coldverify"
ENGINE_VERSION = "1.0.0"


@dataclass
class RunResult:
    ledger: Ledger
    findings: list[Finding] = field(default_factory=list)
    checks_run: list[dict] = field(default_factory=list)
    skipped: list[dict] = field(default_factory=list)
    elapsed_ms: int = 0
    time_to_first_finding_ms: Optional[int] = None
    checked_claim_ids: set = field(default_factory=set)
    collapsed: list[dict] = field(default_factory=list)

    # -- headline numbers --------------------------------------------------
    @property
    def tier_d_findings(self) -> list[Finding]:
        return [f for f in self.findings if f.tier == "D"]

    @property
    def tier_d_per_100_claims(self) -> Optional[float]:
        total = self.ledger.claims_found
        if not total:
            return None
        return 100.0 * len(self.tier_d_findings) / total

    @property
    def engine_checkable_fraction(self) -> Optional[float]:
        """Share of claims at least one check could actually reach.

        Reported alongside the extractor's own ``checkable_fraction`` rather than
        instead of it: the extractor answers "could a checker see this number",
        the engine answers "did a check in fact reach it".
        """
        total = len(self.ledger.claims)
        if not total:
            return None
        return len(self.checked_claim_ids) / total

    def by_family(self) -> dict[str, list[Finding]]:
        out: dict[str, list[Finding]] = {family: [] for family in FAMILIES}
        for finding in self.findings:
            out.setdefault(finding.family, []).append(finding)
        return out

    def to_dict(self, cap: Optional[int] = None) -> dict:
        findings = self.findings if cap is None else self.findings[:cap]
        return {
            "engine": {
                "name": ENGINE_NAME,
                "version": ENGINE_VERSION,
                "offline": True,
                "checks_registered": len(REGISTRY),
                "families": sorted(FAMILIES),
            },
            "source": {
                "path": self.ledger.source.get("path"),
                "format": self.ledger.source_format,
                "sha256": self.ledger.source.get("sha256"),
                "period_label": self.ledger.source_period_label or None,
            },
            "timings": {
                "elapsed_ms": self.elapsed_ms,
                "time_to_first_finding_ms": self.time_to_first_finding_ms,
            },
            "coverage": {
                "claims_in_ledger": len(self.ledger.claims),
                "claims_found_reported": self.ledger.claims_found,
                "claims_reached_by_a_check": len(self.checked_claim_ids),
                "engine_checkable_fraction": self.engine_checkable_fraction,
                "extractor_checkable_fraction": self.ledger.checkable_fraction,
                "checks_registered": len(REGISTRY),
                "checks_with_findings": sum(
                    1 for c in self.checks_run if c["outcome"] == "found"
                ),
                "checks_found_nothing": sum(
                    1 for c in self.checks_run if c["outcome"] == "found_nothing"
                ),
                "checks_errored": sum(1 for c in self.checks_run if c["outcome"] == "error"),
                "flood_threshold": FLOOD_THRESHOLD,
                "findings_collapsed": self.collapsed,
            },
            "headline": {
                "tier_definition": {
                    "D": "high severity: an internal contradiction the document cannot explain away",
                    "C": "medium severity: a defect that needs an author decision or a source to settle",
                    "B": "low severity: a coverage or hygiene gap, not a wrong number",
                    "note": "SPEC.md item 4.8 names 'tier-D defects' without defining the scale; "
                    "this mapping is the engine's stated definition.",
                },
                "tier_d_defects": len(self.tier_d_findings),
                "tier_d_per_100_claims": self.tier_d_per_100_claims,
                "findings_total": len(self.findings),
                "findings_by_tier": {
                    tier: sum(1 for f in self.findings if f.tier == tier)
                    for tier in sorted(set(SEVERITY_TIER.values()))
                },
                "findings_by_family": {
                    family: len(items) for family, items in sorted(self.by_family().items())
                },
            },
            "findings": [f.to_dict() for f in findings],
            "findings_truncated": (cap is not None and len(self.findings) > cap),
            "checks_run": self.checks_run,
            "not_checkable": self.skipped,
        }


def run_checks(
    ledger: Ledger,
    only_families: Optional[set] = None,
    only_checks: Optional[set] = None,
) -> RunResult:
    """Execute the registered checks over one ledger."""
    context = CheckContext(ledger=ledger)
    result = RunResult(ledger=ledger)
    started = time.perf_counter()
    first_finding_at: Optional[float] = None

    for check_id in sorted(REGISTRY):
        spec = REGISTRY[check_id]
        if only_families and spec.family not in only_families:
            result.checks_run.append(
                {
                    "check_id": check_id,
                    "family": spec.family,
                    "outcome": "not_selected",
                    "count": 0,
                    "elapsed_ms": 0,
                }
            )
            continue
        if only_checks and check_id not in only_checks:
            result.checks_run.append(
                {
                    "check_id": check_id,
                    "family": spec.family,
                    "outcome": "not_selected",
                    "count": 0,
                    "elapsed_ms": 0,
                }
            )
            continue

        check_started = time.perf_counter()
        try:
            produced = spec.fn(context) or []
        except Exception:  # a broken check must not hide the other 50
            result.checks_run.append(
                {
                    "check_id": check_id,
                    "family": spec.family,
                    "outcome": "error",
                    "count": 0,
                    "elapsed_ms": int((time.perf_counter() - check_started) * 1000),
                    "detail": traceback.format_exc(limit=3),
                }
            )
            continue

        elapsed = int((time.perf_counter() - check_started) * 1000)
        if produced and first_finding_at is None:
            first_finding_at = time.perf_counter()
        result.findings.extend(produced)
        result.checks_run.append(
            {
                "check_id": check_id,
                "family": spec.family,
                "outcome": "found" if produced else "found_nothing",
                "count": len(produced),
                "elapsed_ms": elapsed,
                "description": spec.description,
            }
        )

    result.findings = suppress_redundant(result.findings)
    result.findings, result.collapsed = collapse_floods(result.findings)
    result.findings.sort(key=lambda f: f.sort_key())
    result.skipped = context.skipped
    result.checked_claim_ids = context.checked_claim_ids
    result.elapsed_ms = int((time.perf_counter() - started) * 1000)
    if first_finding_at is not None:
        result.time_to_first_finding_ms = int((first_finding_at - started) * 1000)
    return result


#: When the left check fires on a claim set, the right checks add nothing a reader
#: needs. Spec item 4.12 makes the size of the first-run finding list a product
#: decision, so redundancy is removed rather than shown twice.
SUPPRESSION_RULES: list[tuple[str, str]] = [
    ("ari_total_footing", "ari_total_footing_precision"),
    ("ari_total_footing_precision", "rnd_precision_exceeds_components"),
    ("ari_total_footing", "rnd_precision_exceeds_components"),
    ("dir_moved_but_zero", "rnd_delta_below_resolution"),
    ("uni_percent_vs_points", "uni_unit_form_mismatch"),
    ("ari_unparseable_value", "rnd_precision_indeterminable"),
    ("uni_scale_not_honoured", "rnd_display_disagrees_with_value"),
    ("tpl_spreadsheet_error_value", "ari_unparseable_value"),
    ("tpl_empty_value_rendered", "ari_unparseable_value"),
    ("tpl_stale_period_reference", "gnd_prose_number_not_extracted"),
    ("rnd_threshold_crossing", "rnd_display_disagrees_with_value"),
    ("uni_scale_not_honoured", "uni_magnitude_vs_declared_scale"),
    ("ari_delta_direction_vs_levels", "ari_delta_consistency"),
    # A wrong share cell shows up three ways: the share does not divide, the shares do
    # not sum to 100, and the share column does not foot. One wrong number, one fix,
    # so the reader is shown the view that names the arithmetic.
    ("ari_percent_of_total", "ari_shares_sum_to_100"),
    ("ari_percent_of_total", "ari_total_footing"),
    ("ari_percent_of_total", "ari_total_footing_precision"),
]


def _subject(finding: Finding) -> tuple[frozenset, Optional[str]]:
    """What a finding is *about*, for redundancy matching.

    Includes ``detail.affected_claim_ids`` as well as the inline citations. An
    aggregated finding cites five representatives, so matching on those alone let a
    weaker view of the same claims survive alongside the stronger one.
    """
    ids = set(finding.claim_ids)
    ids |= set(finding.detail.get("affected_claim_ids") or [])
    return frozenset(ids), finding.detail.get("block_id")


def suppress_redundant(findings: list[Finding]) -> list[Finding]:
    """Drop the weaker of two findings that describe the same defect.

    Spec item 4.12 makes the size of the first-run finding list a product
    decision. Two rows for one root cause spends that budget twice.
    """
    dominant: dict[str, list[tuple[frozenset, Optional[str]]]] = {}
    for finding in findings:
        dominant.setdefault(finding.check_id, []).append(_subject(finding))

    suppressed_ids = set()
    for winner, loser in SUPPRESSION_RULES:
        winner_subjects = dominant.get(winner, [])
        if not winner_subjects:
            continue
        for index, finding in enumerate(findings):
            if finding.check_id != loser:
                continue
            claims, block = _subject(finding)
            for won_claims, won_block in winner_subjects:
                if claims and (claims & won_claims):
                    suppressed_ids.add(index)
                    break
                if block is not None and block == won_block:
                    suppressed_ids.add(index)
                    break
    return [f for index, f in enumerate(findings) if index not in suppressed_ids]


# ---------------------------------------------------------------------------
# Flood collapse
# ---------------------------------------------------------------------------

#: Above this many findings from one check, the engine stops treating them as
#: independent defects. A defect present on more than a handful of a document's
#: figures is a systematic property of the document — one editorial decision, one
#: extractor bug, one mislabelled column — and it has one fix. Reporting it once
#: per figure buries every other finding and, when an answer key cites the source
#: of the property rather than everything downstream of it, scores one correct
#: detection as hundreds of false positives.
#:
#: This is a *reporting* rule, not a detection rule: nothing is discarded. The full
#: affected set is carried in `detail.affected_claim_ids` and the collapse itself is
#: recorded in `coverage.findings_collapsed`, so no coverage is silently lost.
FLOOD_THRESHOLD = 10

#: How many claim ids a collapsed finding cites inline.
REPRESENTATIVE_CLAIMS = 5


def _flood_group(finding: Finding) -> str:
    """The signature findings are grouped by when a check floods.

    A check may name its own grouping through ``detail["aggregate_key"]``. Failing
    that, findings are grouped by the shape of their statement with the numbers
    stripped out, so "renders as −4.5% but rounds to 4.5" and "renders as −3.7% but
    rounds to 3.7" collapse together while a structurally different statement does
    not.
    """
    declared = finding.detail.get("aggregate_key")
    if declared is not None:
        return str(declared)
    return re.sub(r"[-+−0-9][0-9,.\u2212]*", "#", finding.statement)


def collapse_floods(
    findings: list[Finding], threshold: int = FLOOD_THRESHOLD
) -> tuple[list[Finding], list[dict]]:
    """Collapse any check that reported more findings than the flood threshold."""
    by_check: dict[str, list[Finding]] = {}
    for finding in findings:
        by_check.setdefault(finding.check_id, []).append(finding)

    kept: list[Finding] = []
    collapsed_report: list[dict] = []
    for check_id, group in by_check.items():
        if len(group) <= threshold:
            kept.extend(group)
            continue
        buckets: dict[str, list[Finding]] = {}
        for finding in group:
            buckets.setdefault(_flood_group(finding), []).append(finding)
        for signature, bucket in sorted(buckets.items()):
            if len(bucket) == 1:
                kept.extend(bucket)
                continue
            kept.append(_merge(bucket))
            collapsed_report.append(
                {
                    "check_id": check_id,
                    "findings_merged": len(bucket),
                    "affected_claim_count": len(
                        {cid for f in bucket for cid in f.claim_ids}
                    ),
                    "reason": "more than the flood threshold of findings from one check; "
                    "reported once as a systematic property with the full affected set "
                    "in detail.affected_claim_ids",
                }
            )
    return kept, collapsed_report


def _merge(bucket: list[Finding]) -> Finding:
    """One finding standing for a whole flood, keeping the worst of everything."""
    order = {"high": 0, "medium": 1, "low": 2}
    worst = min(bucket, key=lambda f: order[f.severity])
    confidence_order = {"low": 0, "medium": 1, "high": 2}
    weakest = min((f.confidence for f in bucket), key=lambda c: confidence_order[c])
    affected: list[str] = []
    for finding in bucket:
        for cid in finding.claim_ids:
            if cid not in affected:
                affected.append(cid)
    detail = dict(worst.detail)
    detail["affected_claim_count"] = len(affected)
    detail["affected_claim_ids"] = affected[:200]
    detail["findings_merged"] = len(bucket)
    detail["examples"] = [f.statement for f in bucket[:3]]
    return Finding(
        check_id=worst.check_id,
        family=worst.family,
        severity=worst.severity,
        statement=(
            f"{len(bucket)} figures share this defect, so it is one systematic issue "
            f"rather than {len(bucket)} independent ones. For example: {worst.statement}"
        ),
        claim_ids=affected[:REPRESENTATIVE_CLAIMS],
        confidence=weakest,
        overturnable_by=worst.overturnable_by,
        evidence_class=worst.evidence_class,
        tier=worst.tier,
        location=worst.location,
        detail=detail,
    )
