"""Finding record, confidence derivation and the check registry.

Two rules this module exists to enforce:

1. **Confidence is derived, never declared.** A check states which claims it
   touched and what kind of comparison it made. This module turns that into a
   confidence level from the evidence class of those claims. No check may pass a
   confidence string in.
2. **Negatives are recorded.** Every registered check appears in the run report
   with an outcome, including ``found_nothing``. Spec §0.2: "Ran the detector,
   found nothing" and "never ran the detector" are different states.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Iterable, Optional

from .ledger import CONFIDENCE_ORDER, Claim, Ledger, downgrade, worst_confidence

FAMILIES = {
    "internal_arithmetic": "ari",
    "direction_polarity": "dir",
    "ungrounded_claims": "gnd",
    "units_scale": "uni",
    "rounding": "rnd",
    "period_integrity": "per",
    "selection_honesty": "sel",
    "template_hygiene": "tpl",
}

PREFIX_TO_FAMILY = {v: k for k, v in FAMILIES.items()}

SEVERITIES = ["low", "medium", "high"]

#: Severity -> tier. SPEC.md asks for "tier-D defects per 100 claims" (item 4.8)
#: but never defines the tier scale, so the engine defines it explicitly here and
#: says so in the README. Tier D is the headline defect count: an internal
#: contradiction the document cannot explain away.
SEVERITY_TIER = {"high": "D", "medium": "C", "low": "B"}

#: Comparison classes a check can declare. Each one caps the confidence a finding
#: can carry, because some comparisons are structurally weaker evidence than
#: others regardless of how good the claims are.
EVIDENCE_CLASS_CAP = {
    "structural": "high",      # the ledger contradicts itself with no numeric slack
    "arithmetic": "high",      # band test outside the propagated envelope
    "display": "high",         # the rendered glyphs disagree with the parsed value
    "textual": "medium",       # depends on reading prose words
    "declared_metadata": "medium",  # depends on a declared_* field being accurate
    "heuristic": "low",        # pattern match that a human should confirm
    "coverage": "low",         # a gap in what could be checked, not a defect
}


@dataclass
class Finding:
    check_id: str
    family: str
    severity: str
    statement: str
    claim_ids: list[str] = field(default_factory=list)
    confidence: str = "low"
    overturnable_by: Optional[str] = None
    evidence_class: str = "heuristic"
    tier: str = "B"
    location: Optional[str] = None
    detail: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "check_id": self.check_id,
            "family": self.family,
            "severity": self.severity,
            "tier": self.tier,
            "confidence": self.confidence,
            "overturnable_by": self.overturnable_by,
            "evidence_class": self.evidence_class,
            "claim_ids": list(self.claim_ids),
            "statement": self.statement,
            "location": self.location,
            "detail": self.detail,
        }

    def sort_key(self) -> tuple:
        return (
            -SEVERITIES.index(self.severity),
            self.family,
            self.check_id,
            tuple(self.claim_ids),
            self.statement,
        )


def derive_confidence(
    claims: Iterable[Claim],
    evidence_class: str,
    scale_sensitive: bool = False,
    precision_sensitive: bool = False,
) -> str:
    """Confidence for a finding, from evidence class only.

    Steps, in order:

    1. Start from the weakest participating claim's evidence basis
       (``structured_cell`` > ``prose_parsed`` > ``ocr``/``chart_estimate``).
    2. Cap it at whatever the check's own comparison class can support.
    3. Downgrade one step when the check leans on a field that is itself shaky:
       an unknown display precision for an arithmetic check, or an inferred or
       absent scale for a scale-sensitive one.
    """
    claims = list(claims)
    cap = EVIDENCE_CLASS_CAP.get(evidence_class, "low")
    if not claims:
        # A document-level finding has no claim to inherit an evidence basis from,
        # so the comparison class is the whole of its evidence.
        return cap
    level = worst_confidence([c.evidence_confidence for c in claims])

    if CONFIDENCE_ORDER.index(level) > CONFIDENCE_ORDER.index(cap):
        level = cap

    if precision_sensitive and any(c.displayed_precision is None for c in claims):
        level = downgrade(level)
    if scale_sensitive and any(
        (c.scale_source in (None, "inferred_from_magnitude", "absent"))
        or c.scale in (None, "unknown")
        for c in claims
    ):
        level = downgrade(level)
    return level


def make_finding(
    check_id: str,
    claims: Iterable[Claim],
    severity: str,
    statement: str,
    evidence_class: str,
    overturnable_by: Optional[str] = None,
    scale_sensitive: bool = False,
    precision_sensitive: bool = False,
    detail: Optional[dict] = None,
    location: Optional[str] = None,
) -> Finding:
    claims = list(claims)
    family = FAMILY_OVERRIDES.get(check_id) or PREFIX_TO_FAMILY.get(check_id.split("_", 1)[0])
    if family is None:
        raise ValueError(f"check_id {check_id!r} has no registered family prefix")
    if severity not in SEVERITIES:
        raise ValueError(f"unknown severity {severity!r}")
    if evidence_class not in EVIDENCE_CLASS_CAP:
        raise ValueError(f"unknown evidence class {evidence_class!r}")
    confidence = derive_confidence(
        claims,
        evidence_class,
        scale_sensitive=scale_sensitive,
        precision_sensitive=precision_sensitive,
    )
    return Finding(
        check_id=check_id,
        family=family,
        severity=severity,
        statement=statement,
        claim_ids=[c.claim_id for c in claims],
        confidence=confidence,
        overturnable_by=overturnable_by,
        evidence_class=evidence_class,
        tier=SEVERITY_TIER[severity],
        location=(location if location is not None else (claims[0].where() if claims else None)),
        detail=detail or {},
    )


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------


@dataclass
class CheckSpec:
    check_id: str
    family: str
    description: str
    fn: Callable[["CheckContext"], list[Finding]]
    overturnable_by: Optional[str] = None


REGISTRY: dict[str, CheckSpec] = {}

#: check_id -> family, including any explicit override. Read by ``make_finding`` so a
#: finding is filed under the same family the registry reports.
FAMILY_OVERRIDES: dict[str, str] = {}


def check(
    check_id: str,
    description: str,
    overturnable_by: Optional[str] = None,
    family: Optional[str] = None,
):
    """Register a check.

    The ``check_id`` prefix supplies the family by default, which keeps ids readable.
    ``family`` overrides it where the two genuinely differ: a declared-scale
    contradiction is a units-and-scale defect however it is prefixed, and the id must
    stay stable because the platform runner keys off it (spec item 4.13).
    """

    def decorator(fn):
        resolved = family or PREFIX_TO_FAMILY.get(check_id.split("_", 1)[0])
        if resolved is None:
            raise ValueError(f"check_id {check_id!r} has no registered family prefix")
        if resolved not in FAMILIES:
            raise ValueError(f"unknown family {resolved!r} for check {check_id!r}")
        FAMILY_OVERRIDES[check_id] = resolved
        if check_id in REGISTRY:
            raise ValueError(f"duplicate check_id {check_id!r}")
        REGISTRY[check_id] = CheckSpec(
            check_id=check_id,
            family=resolved,
            description=description,
            fn=fn,
            overturnable_by=overturnable_by,
        )
        return fn

    return decorator


@dataclass
class CheckContext:
    """Everything a check may read, plus a place to record what it skipped."""

    ledger: Ledger
    skipped: list[dict] = field(default_factory=list)
    checked_claim_ids: set = field(default_factory=set)
    notes: list[str] = field(default_factory=list)

    def touched(self, *claims: Claim) -> None:
        for c in claims:
            if c is not None:
                self.checked_claim_ids.add(c.claim_id)

    def skip(self, check_id: str, reason: str, claim_ids: list[str]) -> None:
        self.skipped.append(
            {"check_id": check_id, "reason": reason, "claim_ids": list(claim_ids)}
        )
