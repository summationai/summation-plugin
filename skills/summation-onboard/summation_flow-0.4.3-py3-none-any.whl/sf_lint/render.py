"""Post-run render check — does the produced document actually show its tables?

Lint runs before deploy, on the bundle. There, table configs and their data are produced at
run time, so lint can only warn about them — it cannot prove a file that does not exist yet.
That leaves a hole: the platform runs the bundle, produces a document, and nothing checks that
the tables in that FINISHED document resolve to data. U16 fell straight through it — every
<cell/> traced, verification passed 80/80, and all six tables rendered empty because their
`dataframe_path` pointed at snapshot files the run never saved.

This closes the hole. Given the produced document's file inventory and a reader, it follows
each `<table src=.../>` to its config and the config's `dataframe_path`, and fails when that
path resolves to nothing. It is deliberately injectable — a fake inventory + reader for tests,
the platform's own file list + download at run time — the same shape as the lint query runner.
"""
from __future__ import annotations

import json
import posixpath
import re
from typing import Callable, Iterable

from sf_findings import ERROR, WARNING, Finding, FindingSet

TABLE_TAG = re.compile(r"<table\b[^>]*\bsrc=\"([^\"]+)\"", re.IGNORECASE)
TABLE_TAG_NO_SRC = re.compile(r"<table\b(?![^>]*\bsrc=)[^>]*>", re.IGNORECASE)
COMMENT = re.compile(r"<!--.*?-->", re.DOTALL)


def _norm(path: str) -> str:
    """Collapse ./ and ../ so 'tables/../snapshots/x.json' == 'snapshots/x.json'."""
    return posixpath.normpath(path.lstrip("/"))


def _index(files: Iterable[str]) -> set[str]:
    """The produced document's paths, normalised and also indexed by basename.

    The platform reports files by a path or sometimes just a name; a table config that resolves
    to `snapshots/20_group_rollup.json` should match whether the inventory carries the full path
    or the bare `20_group_rollup.json`, so both are indexed.
    """
    out: set[str] = set()
    for f in files:
        n = _norm(f)
        out.add(n)
        out.add(posixpath.basename(n))
    return out


def check_rendered(
    document: str,
    files: Iterable[str],
    read_file: Callable[[str], str | None],
) -> FindingSet:
    """Verify every table in `document` resolves to data present in `files`.

    document   — the document.xml (or .sdoc body) text to scan for <table> tags.
    files      — the produced document's file inventory (paths or names).
    read_file  — fetch a config's text by its src path; None if it cannot be read.
    """
    fs = FindingSet()
    present = _index(files)
    text = COMMENT.sub("", document)

    for m in TABLE_TAG_NO_SRC.finditer(text):
        line = text.count("\n", 0, m.start()) + 1
        fs.add(Finding(
            code="render.table.no_src", severity=ERROR, line=line,
            message="a <table/> in the produced document has no `src` — it renders empty.",
        ))

    tags = list(TABLE_TAG.finditer(text))
    if not tags:
        return fs

    for m in tags:
        src = m.group(1)
        line = text.count("\n", 0, m.start()) + 1
        cfg_key = _norm(src)

        if cfg_key not in present and posixpath.basename(cfg_key) not in present:
            fs.add(Finding(
                code="render.config.absent", severity=ERROR, file=src, line=line,
                message=(f"<table src=\"{src}\"> — the config is not in the produced document, "
                         f"so the table has no formatting or data and renders empty."),
            ))
            continue

        raw = read_file(src)
        if not raw:
            fs.add(Finding(
                code="render.config.unreadable", severity=ERROR, file=src, line=line,
                message=f"<table src=\"{src}\"> — its config could not be read from the document.",
            ))
            continue
        try:
            cfg = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            fs.add(Finding(
                code="render.config.malformed", severity=ERROR, file=src, line=line,
                message=f"<table src=\"{src}\"> — its config is not valid JSON.",
            ))
            continue

        dfp = cfg.get("dataframe_path")
        if not dfp:
            fs.add(Finding(
                code="render.dataframe.missing_key", severity=ERROR, file=src, line=line,
                message=f"the config for {src} has no `dataframe_path`; the table renders empty.",
            ))
            continue

        # dataframe_path is relative to the config's own location (that is what the platform
        # renderer resolves), so join against the config dir before normalising.
        joined = _norm(posixpath.join(posixpath.dirname(cfg_key), dfp))
        if joined not in present and posixpath.basename(joined) not in present:
            fs.add(Finding(
                code="render.dataframe.absent", severity=ERROR, file=src, line=line,
                message=(f"<table src=\"{src}\"> points at data `{dfp}` which is NOT in the "
                         f"produced document. The query ran, but its result was never saved as "
                         f"the snapshot the table reads — the table renders empty. This is the "
                         f"U16 failure: a config without its data file."),
                detail={"dataframe_path": dfp, "resolved": joined},
            ))

    real = fs.of(ERROR)
    if not real:
        fs.add(Finding(
            code="render.ok", severity=WARNING,
            message=f"all {len(tags)} table(s) in the document resolve to data present in it.",
        ))
    return fs
