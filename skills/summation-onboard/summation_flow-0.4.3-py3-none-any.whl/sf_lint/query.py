"""The warehouse boundary.

Lint has to prove a query runs, and it must do that without importing the
platform. So the contract is one callable:

    runner(sql: str) -> object      # rows, anything truthy-shaped
    runner(sql: str) -> raises      # any exception means "this SQL is broken"

That is the entire interface. ``FakeQueryRunner`` implements it for tests;
``SumcliQueryRunner`` implements it against a real read-only ``sumcli``, and is
never the default — a lint run that silently reaches a warehouse is a lint run
nobody can reproduce.
"""

from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Callable, Optional


class QueryError(Exception):
    """Raised by a runner when the warehouse rejects the SQL."""


# ---------------------------------------------------------------------------
# fakes, for tests
# ---------------------------------------------------------------------------

@dataclass
class FakeQueryRunner:
    """A warehouse that never existed.

    ``fail_on`` maps a substring to the error text the warehouse would return.
    ``calls`` records every statement, so a test can assert that lint actually
    substituted parameters before executing rather than sending a template.
    """

    fail_on: dict = field(default_factory=dict)
    rows: list = field(default_factory=lambda: [{"ok": 1}])
    calls: list = field(default_factory=list)

    def __call__(self, sql: str):
        self.calls.append(sql)
        for needle, message in self.fail_on.items():
            if needle in sql:
                raise QueryError(message)
        return list(self.rows)


class RefusingQueryRunner:
    """Fails everything. For proving lint reports a dead warehouse honestly."""

    def __init__(self, message: str = "connection refused") -> None:
        self.message = message
        self.calls: list = []

    def __call__(self, sql: str):
        self.calls.append(sql)
        raise QueryError(self.message)


# ---------------------------------------------------------------------------
# the real one
# ---------------------------------------------------------------------------

_WRITE = re.compile(
    r"\b(insert|update|delete|drop|truncate|alter|create|grant|revoke|merge|copy|vacuum)\b",
    re.IGNORECASE,
)


class SumcliQueryRunner:
    """Read-only execution through ``sumcli queries run``.

    Two guards, both deliberate. It refuses anything that looks like a write
    before the statement leaves the process, and it caps the row count so a dry
    run cannot pull a table across the wire. Neither guard is a substitute for
    a read-only credential; both are there because lint runs unattended.

    The statement is sent **as written**. An earlier version wrapped it in a
    ``SELECT * FROM (...) LIMIT n`` subquery, which is a worse dry run: it
    changes the SQL under test, so a query that fails only at top level passes
    and a query the wrapper breaks fails for a reason that is not the bundle's
    fault. The row cap goes through ``--limit`` instead, which the CLI applies
    without rewriting the text.
    """

    def __init__(self, profile: str, limit: int = 1, timeout: int = 60,
                 binary: str = "sumcli") -> None:
        self.profile = profile
        self.limit = limit
        self.timeout = timeout
        self.binary = binary
        self.calls: list = []

    def _guard(self, sql: str) -> None:
        stripped = re.sub(r"--[^\n]*", " ", sql)
        stripped = re.sub(r"/\*.*?\*/", " ", stripped, flags=re.DOTALL)
        m = _WRITE.search(stripped)
        if m:
            raise QueryError(
                f"refused to execute: the statement contains `{m.group(0).upper()}`, "
                f"and lint only ever runs read-only SELECTs."
            )

    def __call__(self, sql: str):
        self._guard(sql)
        if shutil.which(self.binary) is None:
            raise QueryError(f"`{self.binary}` is not on PATH")
        self.calls.append(sql)
        proc = subprocess.run(
            [self.binary, "queries", "run",
             "--sql", sql.rstrip().rstrip(";"),
             "--profile", self.profile,
             "--limit", str(self.limit)],
            capture_output=True, text=True, timeout=self.timeout,
        )
        if proc.returncode != 0:
            raise QueryError((proc.stderr or proc.stdout or "").strip()[:800]
                             or f"sumcli exited {proc.returncode}")
        try:
            payload = json.loads(proc.stdout or "[]")
        except json.JSONDecodeError:
            return proc.stdout
        # The CLI reports failure in-band as well as by exit status. Trusting
        # the exit code alone would let a failed query read as a clean dry run,
        # which is the one outcome this whole check exists to prevent.
        if isinstance(payload, dict):
            if payload.get("ok") is False:
                err = payload.get("error") or {}
                raise QueryError(str(err.get("message") or err or payload)[:800])
            status = (payload.get("result", {}) or {}).get("query", {}).get("status")
            if status and status not in ("succeeded", "success", "completed"):
                raise QueryError(f"query status `{status}`")
        return payload


def null_runner(_sql: str):  # pragma: no cover - trivial
    """A runner that does nothing and reports nothing. Never used by default."""
    return []


Runner = Callable[[str], object]
