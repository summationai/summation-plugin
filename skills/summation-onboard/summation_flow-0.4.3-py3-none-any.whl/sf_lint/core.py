"""Bundle access and the check registry.

Everything a check needs to name a file and a line lives here, so no individual
check has to think about paths, encodings or line numbers. A check that cannot
say *where* is a check nobody will act on.
"""

from __future__ import annotations

import fnmatch
import os
import re
from dataclasses import dataclass, field
from typing import Callable, Iterable, Iterator, Optional

from sf_findings import Finding, FindingSet

# ---------------------------------------------------------------------------
# bundle
# ---------------------------------------------------------------------------

_XML_COMMENT = re.compile(rb"<!--.*?-->", re.DOTALL)
_XML_COMMENT_T = re.compile(r"<!--.*?-->", re.DOTALL)


class Bundle:
    """A ``.spb`` directory on disk, read-only.

    Paths handed to and returned from this class are always *relative to the
    bundle root*, because that is what a finding should print: a person reading
    ``templates/report.smd/document.xml:37`` can find it, and an absolute path
    from someone else's laptop is noise.
    """

    def __init__(self, root: str) -> None:
        self.root = os.path.abspath(root)
        self.name = os.path.basename(self.root.rstrip(os.sep))
        self._cache: dict[str, str] = {}

    # -- existence ----------------------------------------------------------
    def abspath(self, rel: str) -> str:
        return os.path.join(self.root, rel)

    def exists(self, rel: str) -> bool:
        return os.path.exists(self.abspath(rel))

    def isdir(self, rel: str = "") -> bool:
        return os.path.isdir(self.abspath(rel))

    # -- listing ------------------------------------------------------------
    def walk(self) -> Iterator[str]:
        """Every file in the bundle, relative, sorted, skipping noise."""
        out = []
        for dirpath, dirnames, filenames in os.walk(self.root):
            dirnames[:] = [d for d in dirnames
                           if d not in {"__pycache__", ".git", ".pytest_cache"}]
            for fn in filenames:
                if fn == ".DS_Store" or fn.endswith(".pyc"):
                    continue
                out.append(os.path.relpath(os.path.join(dirpath, fn), self.root))
        return iter(sorted(out))

    def glob(self, pattern: str) -> list[str]:
        """Match a glob against every relative path in the bundle."""
        return [p for p in self.walk() if fnmatch.fnmatch(p, pattern)]

    # -- reading ------------------------------------------------------------
    def read(self, rel: str) -> str:
        if rel not in self._cache:
            with open(self.abspath(rel), encoding="utf-8", errors="replace") as fh:
                self._cache[rel] = fh.read()
        return self._cache[rel]

    def read_stripped(self, rel: str) -> str:
        """File text with XML/HTML comments blanked out, line numbers preserved.

        Load-bearing. The bundle template's ``document.xml`` opens with a
        comment that *says* ``<table/>`` while explaining the rule about table
        tags; a check that regexes the raw text flags the documentation as a
        defect. Comments are replaced with newline-preserving whitespace so
        every surviving offset still maps to its original line.
        """
        text = self.read(rel)

        def blank(m: re.Match) -> str:
            return re.sub(r"[^\n]", " ", m.group(0))

        return _XML_COMMENT_T.sub(blank, text)

    def lines(self, rel: str) -> list[str]:
        return self.read(rel).splitlines()

    # -- locating -----------------------------------------------------------
    def line_of_offset(self, rel: str, offset: int) -> int:
        return self.read(rel).count("\n", 0, offset) + 1

    def line_of(self, rel: str, needle: str, default: int = 1) -> int:
        """1-based line of the first occurrence of ``needle``."""
        try:
            text = self.read(rel)
        except OSError:
            return default
        idx = text.find(needle)
        if idx < 0:
            return default
        return text.count("\n", 0, idx) + 1

    def find_all_lines(self, rel: str, pattern: re.Pattern) -> list[tuple[int, re.Match]]:
        text = self.read(rel)
        return [(text.count("\n", 0, m.start()) + 1, m) for m in pattern.finditer(text)]


# ---------------------------------------------------------------------------
# context
# ---------------------------------------------------------------------------

@dataclass
class LintContext:
    """Everything the checks are allowed to know about.

    ``outputs`` is the *choice* made earlier in the flow (``--outputs``). It is
    ``None`` when no choice was supplied, and checks that compare the manifest
    against a choice must not invent one: a bundle authored before output
    targets existed is not thereby broken.
    """

    bundle: Bundle
    survey: Optional[dict] = None
    outputs: Optional[list[str]] = None
    accepted_literals: set = field(default_factory=set)
    accepted_by: Optional[str] = None
    query_runner: Optional[Callable] = None
    param_values: dict = field(default_factory=dict)
    manifest: Optional[dict] = None
    manifest_error: Optional[str] = None

    # -- convenience --------------------------------------------------------
    @property
    def parameters(self) -> list:
        m = self.manifest or {}
        p = m.get("parameters")
        return p if isinstance(p, list) else []

    def param_by_id(self, pid: str) -> Optional[dict]:
        for p in self.parameters:
            if isinstance(p, dict) and p.get("id") == pid:
                return p
        return None

    def survey_literals(self) -> list[dict]:
        s = self.survey or {}
        lits = s.get("literals")
        return [l for l in lits if isinstance(l, dict)] if isinstance(lits, list) else []

    def document_templates(self) -> list[str]:
        """S-Doc/S-Deck document templates: where the platform's tag rules apply."""
        out = [p for p in self.bundle.walk()
               if os.path.basename(p) == "document.xml" or p.endswith(".sdoc")]
        return sorted(out)

    def query_files(self) -> list[str]:
        return sorted(p for p in self.bundle.walk()
                      if p.endswith(".sql") and "queries" in p.split(os.sep))

    def script_files(self) -> list[str]:
        return sorted(p for p in self.bundle.walk() if p.endswith(".py"))


# ---------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------

CheckFn = Callable[[LintContext], Iterable[Finding]]
_REGISTRY: list[tuple[str, CheckFn]] = []


def check(name: str):
    """Register a check. ``name`` is the family, e.g. ``manifest``."""

    def deco(fn: CheckFn) -> CheckFn:
        _REGISTRY.append((name, fn))
        return fn

    return deco


def registered() -> list[tuple[str, CheckFn]]:
    return list(_REGISTRY)


def run_checks(ctx: LintContext) -> FindingSet:
    """Run every registered check. A check that raises is itself a finding."""
    fs = FindingSet()
    for name, fn in _REGISTRY:
        try:
            fs.extend(fn(ctx) or [])
        except Exception as exc:  # a broken check must not hide the others
            fs.add(Finding(
                code=f"{name}.check_crashed", severity="error",
                message=(f"the `{name}` check raised {type(exc).__name__}: {exc}. "
                         f"This is a defect in lint, not necessarily in the bundle."),
                detail={"exception": type(exc).__name__, "args": [str(a) for a in exc.args]},
            ))
    return fs
