"""`<table/>` tags: every one must resolve to a config, never to a snapshot.

The platform rule this enforces: a ``<table/>`` points at ``tables/<name>.json``
— a table *config* carrying ``dataframe_path`` and ``columns`` — and never at a
raw ``snapshots/*.json``. Pointing it at a snapshot renders an empty table, and
it renders empty on the platform after a clean local run, which is the worst
way to find out.

Three resolutions, deliberately distinguished:

* **static** — the config is a file in the bundle. Fully checkable; its shape
  is validated.
* **generated** — the bundle's own ``scripts/prepare.py`` writes that config at
  run time. Lint cannot execute prepare (it needs the warehouse), so this is
  reported with the generating line named and does not fail the gate.
* **dangling** — neither. This fails.
"""

from __future__ import annotations

import json
import os
import re

from sf_findings import ERROR, WARNING, Finding
from ..core import LintContext, check

# src="..." on a <table/> tag, and the HTML data-table-config equivalent.
TABLE_TAG = re.compile(r"<table\b[^>]*?\bsrc\s*=\s*[\"']([^\"']+)[\"'][^>]*>", re.IGNORECASE)
TABLE_TAG_NO_SRC = re.compile(r"<table\b(?![^>]*\bsrc\s*=)[^>]*/?>", re.IGNORECASE)
# A path a script writes into, e.g. "tables/%s.json" or 'tables/' + name.
GENERATOR = re.compile(r"[\"']tables/[^\"']*\.json[\"']|[\"']tables/[\"']")
TEMPLATED = re.compile(r"\{[^}]+\}")


def _generators(ctx: LintContext) -> list[tuple[str, int, str]]:
    """(file, line, text) for every place a script writes a tables/*.json path."""
    out = []
    for rel in ctx.script_files():
        try:
            for line, m in ctx.bundle.find_all_lines(rel, GENERATOR):
                out.append((rel, line, m.group(0)))
        except OSError:
            continue
    return out


@check("table")
def table_refs_resolve(ctx: LintContext):
    b = ctx.bundle
    gens = _generators(ctx)

    for rel in ctx.document_templates():
        text = b.read_stripped(rel)  # comments blanked: a documented example is not a defect

        for m in TABLE_TAG_NO_SRC.finditer(text):
            line = text.count("\n", 0, m.start()) + 1
            yield Finding(
                code="table.src.missing", severity=ERROR, file=rel, line=line,
                message=("a <table/> tag carries no `src`; it has nothing to render and the "
                         "section comes out blank."),
                detail={"tag": m.group(0)[:120]},
            )

        for m in TABLE_TAG.finditer(text):
            src = m.group(1)
            line = text.count("\n", 0, m.start()) + 1

            if "snapshots/" in src:
                yield Finding(
                    code="table.src.raw_snapshot", severity=ERROR, file=rel, line=line,
                    message=(f"<table src=\"{src}\"> points at a raw snapshot. A <table/> must "
                             f"point at a tables/*.json config; a snapshot has no column "
                             f"formatting and renders nothing."),
                    detail={"src": src},
                )
                continue

            if not src.startswith("tables/"):
                yield Finding(
                    code="table.src.not_a_config", severity=ERROR, file=rel, line=line,
                    message=(f"<table src=\"{src}\"> does not point into tables/; table configs "
                             f"live at tables/<name>.json."),
                    detail={"src": src},
                )
                continue

            if TEMPLATED.search(src):
                match = [g for g in gens if "tables/" in g[2]]
                if match:
                    g = match[0]
                    yield Finding(
                        code="table.src.generated", severity=WARNING, file=rel, line=line,
                        message=(f"<table src=\"{src}\"> is templated, so lint cannot resolve it "
                                 f"statically; {g[0]}:{g[1]} writes table configs at run time. "
                                 f"Its shape is unproven until the bundle runs."),
                        detail={"src": src, "generator": f"{g[0]}:{g[1]}"},
                    )
                else:
                    yield Finding(
                        code="table.src.dangling", severity=ERROR, file=rel, line=line,
                        message=(f"<table src=\"{src}\"> is templated but no script in the bundle "
                                 f"writes a tables/*.json config, so nothing will ever fill it."),
                        detail={"src": src},
                    )
                continue

            if b.exists(src):
                yield from _check_config(ctx, rel, line, src)
                continue

            match = [g for g in gens if "tables/" in g[2]]
            if match:
                g = match[0]
                yield Finding(
                    code="table.src.generated", severity=WARNING, file=rel, line=line,
                    message=(f"<table src=\"{src}\"> has no config in the bundle; {g[0]}:{g[1]} "
                             f"writes table configs at run time, so this is expected to be "
                             f"produced rather than shipped. Its shape is unproven until the "
                             f"bundle runs."),
                    detail={"src": src, "generator": f"{g[0]}:{g[1]}"},
                )
            else:
                yield Finding(
                    code="table.src.dangling", severity=ERROR, file=rel, line=line,
                    message=(f"<table src=\"{src}\"> resolves to nothing: there is no such file in "
                             f"the bundle and no script writes one."),
                    detail={"src": src},
                )


def _check_config(ctx: LintContext, doc: str, line: int, src: str):
    """A shipped table config must carry dataframe_path and columns."""
    b = ctx.bundle
    try:
        cfg = json.loads(b.read(src))
    except json.JSONDecodeError as e:
        yield Finding(
            code="table.config.malformed", severity=ERROR, file=src, line=e.lineno,
            message=f"the table config is not valid JSON: {e.msg} at line {e.lineno}.",
            detail={"referenced_by": f"{doc}:{line}"},
        )
        return
    except OSError as e:
        yield Finding(
            code="table.config.malformed", severity=ERROR, file=src,
            message=f"the table config could not be read: {e}.",
        )
        return

    if not isinstance(cfg, dict):
        yield Finding(
            code="table.config.malformed", severity=ERROR, file=src,
            message=f"the table config is a {type(cfg).__name__}, not an object.",
            detail={"referenced_by": f"{doc}:{line}"},
        )
        return

    if not cfg.get("dataframe_path"):
        yield Finding(
            code="table.config.dataframe_path", severity=ERROR, file=src,
            line=b.line_of(src, "dataframe_path"),
            message=("the table config has no `dataframe_path`, so it points at no data and "
                     "the table renders empty."),
            detail={"referenced_by": f"{doc}:{line}"},
        )
    else:
        target = cfg["dataframe_path"]
        candidate = target if not os.path.isabs(target) else None
        if candidate and not b.exists(candidate) and not b.exists(os.path.join(os.path.dirname(src), target)):
            # A snapshot produced at run time is normal; say so without failing.
            yield Finding(
                code="table.config.dataframe_missing", severity=WARNING, file=src,
                line=b.line_of(src, "dataframe_path"),
                message=(f"`dataframe_path` points at `{target}`, which is not in the bundle; "
                         f"it must be produced by the run before the table renders."),
                detail={"dataframe_path": target},
            )

    cols = cfg.get("columns")
    if not cols:
        yield Finding(
            code="table.config.columns", severity=ERROR, file=src,
            line=b.line_of(src, "columns"),
            message=("the table config has no `columns`, so the table has no headers or "
                     "formatting and renders as raw values."),
            detail={"referenced_by": f"{doc}:{line}"},
        )
    elif not isinstance(cols, list):
        yield Finding(
            code="table.config.columns", severity=ERROR, file=src,
            line=b.line_of(src, "columns"),
            message=f"`columns` must be a list, got {type(cols).__name__}.",
        )
