"""SQL templates: substitute, then actually run them.

The rule this enforces is the one that costs the most when it is skipped —
*every SQL template is dry-run before it ships*. The usual offenders (``ORDER
BY`` after ``UNION ALL``, ``CAST`` mismatches, an alias used inside ``HAVING``)
all parse fine to the eye and fail on the platform.

Substitution comes first and is its own check. A template still carrying
``{{WEEK}}`` cannot be dry-run, and sending it to a warehouse would produce a
syntax error that blames the wrong thing. So an unsubstituted placeholder is
reported as itself, and that file is skipped for the dry run rather than
failed twice.
"""

from __future__ import annotations

import re

from sf_findings import ERROR, INFO, WARNING, Finding
from ..core import LintContext, check

PLACEHOLDER = re.compile(r"\{\{([A-Z0-9_]+)\}\}")

# Parameter types that make the run period-dependent, and therefore require a
# discovery query that asks the table what the latest loaded period is.
DATE_TYPES = {"date", "datetime", "period", "week", "month"}
DATE_ID_HINT = re.compile(r"(date|week|month|period|quarter|year|day)", re.IGNORECASE)

# A discovery query asks the data which period exists. Two shapes count — a
# MAX over a date-like column, or a descending single-row pick of one — but
# both only count when the query does NOT itself filter on a period. A query
# that consumes `{{WEEK}}` is asking about a period somebody already chose; it
# cannot be the thing that discovers which period is live. That distinction is
# load-bearing: without it every aggregate containing a MAX() reads as a
# discovery query and the check never fires.
DATE_COL = r"(?:date|week|period|month|day|quarter|year|dt)"
DISCOVERY_MAX = re.compile(rf"\bMAX\s*\(\s*[\w.\"']*{DATE_COL}[\w.\"']*\s*\)", re.IGNORECASE)
DISCOVERY_ORDER = re.compile(
    rf"ORDER\s+BY\b[^;]*?{DATE_COL}[^;]*?\bDESC\b[^;]*?\bLIMIT\s+1",
    re.IGNORECASE | re.DOTALL)
CONSUMES_PERIOD = re.compile(
    r"\{\{[A-Z0-9_]*(?:WEEK|DATE|PERIOD|MONTH|DAY|QUARTER|YEAR)[A-Z0-9_]*\}\}")


def _substitutions(ctx: LintContext) -> dict:
    """Placeholder name -> value.

    Manifest defaults are matched to placeholders case-insensitively, because a
    manifest declares ``id: week_ending`` and the template writes
    ``{{WEEK_ENDING}}``. Explicit values passed to lint always win.
    """
    subs = {}
    for p in ctx.parameters:
        if not isinstance(p, dict):
            continue
        pid, default = p.get("id"), p.get("default")
        if pid and default is not None:
            subs[str(pid).upper()] = default
    for k, v in (ctx.param_values or {}).items():
        subs[str(k).upper()] = v
    return subs


def _placeholder_filler(ctx: LintContext) -> str:
    """``file:line`` of a script that substitutes ``{{...}}`` placeholders, if any.

    A bundle may be two-stage: the manifest's typed parameters go to
    ``scripts/prepare.py``, which resolves them into the many more placeholders
    the SQL actually carries. Knowing whether such a stage exists is the
    difference between "nothing will ever fill this" and "lint cannot fill this
    itself".
    """
    pat = re.compile(r"\{\{|\{\{%s\}\}")
    for rel in ctx.script_files():
        try:
            hits = ctx.bundle.find_all_lines(rel, pat)
        except OSError:
            continue
        if hits:
            return f"{rel}:{hits[0][0]}"
    return ""


def substitute(sql: str, subs: dict) -> tuple[str, list[str]]:
    """Fill placeholders. Returns the SQL and the names still unfilled."""
    def repl(m: re.Match) -> str:
        name = m.group(1)
        return str(subs[name]) if name in subs else m.group(0)

    out = PLACEHOLDER.sub(repl, sql)
    left = sorted({m.group(1) for m in PLACEHOLDER.finditer(out)})
    return out, left


@check("query")
def queries_substitute_and_run(ctx: LintContext):
    b = ctx.bundle
    subs = _substitutions(ctx)
    files = ctx.query_files()

    if not files:
        yield Finding(
            code="query.absent", severity=WARNING,
            message="the bundle contains no SQL under templates/queries/; it reads no data.",
        )
        return

    runnable: list[tuple[str, str]] = []
    for rel in files:
        try:
            sql = b.read(rel)
        except OSError as e:
            yield Finding(code="query.unreadable", severity=ERROR, file=rel,
                          message=f"the query could not be read: {e}.")
            continue

        filled, left = substitute(sql, subs)
        if left:
            filler = _placeholder_filler(ctx)
            for name in left:
                if filler:
                    # A two-stage bundle: prepare.py computes these at run time
                    # from the manifest parameters and the config side-files
                    # (a buyer list resolved from buyer_areas.json, a week
                    # resolved by the anchor query). That is the right design,
                    # not a defect — but lint cannot execute prepare, so the
                    # query stays unproven and says so.
                    yield Finding(
                        code="query.unsubstituted.deferred", severity=WARNING, file=rel,
                        line=b.line_of(rel, "{{%s}}" % name),
                        message=(f"`{{{{{name}}}}}` is filled at run time by {filler}, not by a "
                                 f"manifest parameter, so lint cannot dry-run this query. Pass "
                                 f"--param {name}=<value> to prove it."),
                        detail={"placeholder": name, "filler": filler, "known": sorted(subs)},
                    )
                else:
                    yield Finding(
                        code="query.unsubstituted", severity=ERROR, file=rel,
                        line=b.line_of(rel, "{{%s}}" % name),
                        message=(f"`{{{{{name}}}}}` has no value and nothing in the bundle fills "
                                 f"it: it is not a manifest parameter default, no script "
                                 f"substitutes placeholders, and it was not supplied to lint. "
                                 f"This query can never run."),
                        detail={"placeholder": name, "known": sorted(subs)},
                    )
            continue
        runnable.append((rel, filled))

    if ctx.query_runner is None:
        if runnable:
            yield Finding(
                code="query.dryrun.skipped", severity=WARNING,
                message=(f"{len(runnable)} query template(s) substituted cleanly but were not "
                         f"executed: no warehouse was connected to this lint run. Their SQL is "
                         f"unproven."),
                detail={"queries": [r for r, _ in runnable]},
            )
        return

    for rel, filled in runnable:
        try:
            ctx.query_runner(filled)
        except Exception as exc:
            yield Finding(
                code="query.dryrun", severity=ERROR, file=rel, line=1,
                message=(f"the query failed against the connected warehouse: "
                         f"{str(exc).strip()[:400]}"),
                detail={"error": str(exc)[:1000], "type": type(exc).__name__},
            )
        else:
            yield Finding(
                code="query.dryrun.ok", severity=INFO, file=rel,
                message="dry-run succeeded against the connected warehouse.",
            )


@check("query")
def discovery_query_exists(ctx: LintContext):
    """A period-parameterised playbook needs a query that finds the live period.

    Without it the platform agent queries whatever period the parameter
    defaults to, which on a Monday is frequently a week the ETL has not landed,
    and the run produces an empty report with no error.
    """
    b = ctx.bundle
    date_params = []
    for p in ctx.parameters:
        if not isinstance(p, dict):
            continue
        ptype, pid = p.get("type"), str(p.get("id") or "")
        if ptype in DATE_TYPES or DATE_ID_HINT.search(pid):
            date_params.append(pid or "<unnamed>")
    if not date_params:
        return

    for rel in ctx.query_files():
        try:
            sql = b.read(rel)
        except OSError:
            continue
        if CONSUMES_PERIOD.search(sql):
            continue  # filters on a period rather than discovering one
        if DISCOVERY_MAX.search(sql) or DISCOVERY_ORDER.search(sql):
            yield Finding(
                code="discovery.query.ok", severity=INFO, file=rel,
                message=(f"this is the discovery query for {', '.join(date_params)}: it asks the "
                         f"table which period actually has data."),
                detail={"date_parameters": date_params},
            )
            return

    yield Finding(
        code="discovery.query", severity=ERROR, file="templates/queries",
        message=(f"the playbook has date or period parameter(s) ({', '.join(date_params)}) but no "
                 f"discovery query. Nothing asks the table which period has landed, so a run for "
                 f"an unloaded period returns an empty report and no error."),
        detail={"date_parameters": date_params},
    )
