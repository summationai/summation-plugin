"""Everything the run needs lives inside the bundle.

The platform agent can run ``scripts/prepare.py``. What it cannot do is reach
outside the folder that was uploaded: no path on somebody's laptop, no `sm` or
`sumcli` shelling out, no parent-directory escape. Each of those passes locally
and fails on the platform, which is the worst way to find out.
"""

from __future__ import annotations

import os
import re

from sf_findings import ERROR, WARNING, Finding
from ..core import LintContext, check

HOME_PATH = re.compile(r"(/Users/[A-Za-z0-9._-]+|/home/[A-Za-z0-9._-]+|[A-Z]:\\\\Users\\\\)")
ABS_PATH = re.compile(r"(?<![\w.])(/(?:Users|home|tmp|var|opt|etc|private)/[^\s\"'`)>\]]+)")
# A quoted relative path with at least one `../`. Whether it actually escapes
# depends on how deep the referencing file sits — see below.
ESCAPE = re.compile(r"[\"'](((?:\.\./)+)[^\"']*)[\"']")
# `sumcli --profile x queries run ...` — flags and their values may sit between
# the binary and the subcommand, so the gap is matched loosely, but it may not
# cross a line, a quote or a statement boundary.
EXTERNAL_TOOL = re.compile(
    r"(?<![\w-])(sumcli|sm)\s+[^\n;'\"]{0,80}?\b"
    r"(queries|push|pull|auth|files|reports|tables|config|catalog|init|delete)\b")

# Text files worth scanning. Binary and data-heavy files are skipped.
SCANNED = (".py", ".sql", ".yaml", ".yml", ".xml", ".md", ".json", ".tmpl",
           ".html", ".sdoc", ".csv", ".txt", ".sh")


def _scannable(ctx: LintContext) -> list[str]:
    return [p for p in ctx.bundle.walk() if p.endswith(SCANNED)]


@check("path")
def no_paths_outside_the_bundle(ctx: LintContext):
    b = ctx.bundle
    for rel in _scannable(ctx):
        try:
            text = b.read(rel)
        except OSError:
            continue

        for line, m in b.find_all_lines(rel, HOME_PATH):
            yield Finding(
                code="path.absolute.home", severity=ERROR, file=rel, line=line,
                message=(f"`{m.group(0)}` is a path on somebody's laptop. The platform agent "
                         f"cannot reach it, so this passes locally and fails on the platform."),
                detail={"path": m.group(0)},
            )

        seen_lines = {line for line, _ in b.find_all_lines(rel, HOME_PATH)}
        for line, m in b.find_all_lines(rel, ABS_PATH):
            if line in seen_lines:
                continue  # already reported as a home path
            yield Finding(
                code="path.absolute", severity=ERROR, file=rel, line=line,
                message=(f"`{m.group(1)}` is an absolute path outside the bundle; nothing outside "
                         f"the uploaded folder exists at run time."),
                detail={"path": m.group(1)},
            )

        # `../` only escapes when it climbs above the bundle root. A table
        # config at tables/x.json legitimately points at ../data/x.json, and
        # flagging that would fail every correctly-built bundle. So the test is
        # arithmetic: leading `../` segments against the depth of the file
        # holding the reference. Only a definite escape is reported.
        depth = rel.count(os.sep)
        for line, m in b.find_all_lines(rel, ESCAPE):
            ups = m.group(2).count("../")
            if ups <= depth:
                continue
            yield Finding(
                code="path.escapes_bundle", severity=ERROR, file=rel, line=line,
                message=(f"`{m.group(1)}` climbs {ups} level(s) up from a file {depth} level(s) "
                         f"deep, so it resolves outside the bundle; the run only has the folder "
                         f"that was uploaded."),
                detail={"path": m.group(1), "levels_up": ups, "file_depth": depth},
            )

        for line, m in b.find_all_lines(rel, EXTERNAL_TOOL):
            yield Finding(
                code="path.external_tool", severity=ERROR, file=rel, line=line,
                message=(f"this shells out to `{m.group(1)}`, which does not exist on the "
                         f"platform. Everything the run needs must be inside the bundle."),
                detail={"tool": m.group(1)},
            )


# A "does every referenced side-file exist" check was written here and removed.
# It grepped every quoted .json/.csv literal in the bundle's scripts and
# complained when no such file was shipped. On the real bundle it fired four
# times and was wrong four times: three of the names are files prepare.py
# *writes* into the output at run time, and the fourth is a snapshot the run
# produces. Distinguishing a read from a write by regex is not something this
# check can do honestly, and a gate that cries wolf gets switched off. The
# requirement it was reaching for — nothing resolves outside the bundle — is
# covered above by the absolute-path, escape and external-tool checks.
