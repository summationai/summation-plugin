"""manifest.yaml: does it parse, is it typed, does it declare its outputs."""

from __future__ import annotations

from sf_findings import ERROR, INFO, WARNING, Finding
from ..core import LintContext, check

MANIFEST = "manifest.yaml"

# The platform's parameter types. `select` additionally requires options,
# because a select with no options renders an empty dropdown and the run
# cannot start.
PARAM_TYPES = {"string", "text", "number", "integer", "date", "select",
               "multiselect", "boolean", "table", "file"}

OUTPUT_FORMATS = {"sdoc", "sdeck", "html"}

# The flow speaks in formats — `sdoc`, `sdeck`, `html` — and the platform's manifest speaks in
# artifact kinds. `create_playbook.py` scaffolds `outputs:` as a list of objects with an `id`, a
# `kind` of report/deck/html, a title and a template path, and that shape is what drives the
# per-artifact email controls in the schedule wizard. A lint that only accepted a list of format
# strings would have failed every bundle written the way the platform's own skill writes them,
# which is the one shape this block exists to produce.
KIND_TO_FORMAT = {"report": "sdoc", "deck": "sdeck", "html": "html",
                  "sdoc": "sdoc", "sdeck": "sdeck"}


def declared_formats(declared) -> tuple[list[str], list[str]]:
    """Normalise an `outputs:` block to format names. Returns (formats, unreadable entries).

    Accepts both shapes deliberately. An entry nobody can read — neither a format name nor an
    object naming a kind — comes back in the second list rather than being dropped, because a
    silently ignored output is a schedule control the person never sees.
    """
    formats, unreadable = [], []
    for entry in declared or []:
        if isinstance(entry, str):
            fmt = KIND_TO_FORMAT.get(entry.strip().lower(), entry.strip())
            formats.append(fmt)
        elif isinstance(entry, dict):
            kind = str(entry.get("kind") or "").strip().lower()
            if kind in KIND_TO_FORMAT:
                formats.append(KIND_TO_FORMAT[kind])
            else:
                unreadable.append(str(entry.get("id") or entry.get("kind") or entry))
        else:
            unreadable.append(str(entry))
    return formats, unreadable


@check("manifest")
def manifest_parses(ctx: LintContext):
    b = ctx.bundle
    if not b.exists(MANIFEST):
        yield Finding(
            code="manifest.missing", severity=ERROR, file=MANIFEST,
            message="the bundle has no manifest.yaml, so the platform cannot show it a Run button.",
        )
        return
    if ctx.manifest_error:
        yield Finding(
            code="manifest.parse", severity=ERROR, file=MANIFEST,
            message=f"manifest.yaml is not valid YAML: {ctx.manifest_error}",
        )
        return
    if not isinstance(ctx.manifest, dict):
        yield Finding(
            code="manifest.parse", severity=ERROR, file=MANIFEST,
            message=(f"manifest.yaml parses to {type(ctx.manifest).__name__}, "
                     f"not a mapping of settings."),
        )


@check("manifest")
def manifest_title(ctx: LintContext):
    if not isinstance(ctx.manifest, dict):
        return
    title = ctx.manifest.get("title")
    if not title or not str(title).strip():
        yield Finding(
            code="manifest.title", severity=ERROR, file=MANIFEST,
            line=ctx.bundle.line_of(MANIFEST, "title:"),
            message="manifest.yaml has no title; the playbook would be unnamed in their workspace.",
        )


@check("manifest")
def manifest_parameters_typed(ctx: LintContext):
    if not isinstance(ctx.manifest, dict):
        return
    b = ctx.bundle
    params = ctx.manifest.get("parameters")
    if params is None:
        yield Finding(
            code="manifest.parameters.absent", severity=WARNING, file=MANIFEST,
            message=("manifest.yaml declares no parameters; the playbook can only ever run "
                     "one way, which is rarely what the artifact was."),
        )
        return
    if not isinstance(params, list):
        yield Finding(
            code="manifest.parameters.typed", severity=ERROR, file=MANIFEST,
            line=b.line_of(MANIFEST, "parameters:"),
            message=f"`parameters` must be a list, got {type(params).__name__}.",
        )
        return

    seen: set = set()
    for i, p in enumerate(params):
        loc = f"parameters[{i}]"
        if not isinstance(p, dict):
            yield Finding(
                code="manifest.parameters.typed", severity=ERROR, file=MANIFEST,
                line=b.line_of(MANIFEST, "parameters:"),
                message=f"{loc} is {type(p).__name__}, not a parameter definition.",
            )
            continue
        pid = p.get("id")
        line = b.line_of(MANIFEST, f"id: {pid}") if pid else b.line_of(MANIFEST, "parameters:")
        if not pid:
            yield Finding(
                code="manifest.parameters.typed", severity=ERROR, file=MANIFEST, line=line,
                message=f"{loc} has no `id`, so nothing can reference it.",
            )
            continue
        if pid in seen:
            yield Finding(
                code="manifest.parameters.duplicate", severity=ERROR, file=MANIFEST, line=line,
                message=f"parameter `{pid}` is declared twice; the second silently wins.",
                detail={"id": pid},
            )
        seen.add(pid)

        ptype = p.get("type")
        if not ptype:
            yield Finding(
                code="manifest.parameters.typed", severity=ERROR, file=MANIFEST, line=line,
                message=f"parameter `{pid}` has no `type`; the platform cannot render an input for it.",
                detail={"id": pid},
            )
        elif ptype not in PARAM_TYPES:
            yield Finding(
                code="manifest.parameters.typed", severity=ERROR, file=MANIFEST, line=line,
                message=(f"parameter `{pid}` has type `{ptype}`, which is not one of "
                         f"{', '.join(sorted(PARAM_TYPES))}."),
                detail={"id": pid, "type": ptype},
            )
        if not p.get("label"):
            yield Finding(
                code="manifest.parameters.label", severity=WARNING, file=MANIFEST, line=line,
                message=f"parameter `{pid}` has no `label`; the person sees the raw id.",
                detail={"id": pid},
            )
        if ptype in ("select", "multiselect"):
            opts = p.get("options")
            if not opts or not isinstance(opts, list):
                yield Finding(
                    code="manifest.parameters.options", severity=ERROR, file=MANIFEST, line=line,
                    message=(f"parameter `{pid}` is a {ptype} with no options; it renders an "
                             f"empty dropdown and the run cannot start."),
                    detail={"id": pid},
                )
            else:
                for o in opts:
                    if not isinstance(o, dict) or "value" not in o:
                        yield Finding(
                            code="manifest.parameters.options", severity=ERROR,
                            file=MANIFEST, line=line,
                            message=(f"parameter `{pid}` has an option with no `value`: "
                                     f"{o!r}."),
                            detail={"id": pid, "option": str(o)},
                        )
                        break
                values = [o.get("value") for o in opts if isinstance(o, dict)]
                default = p.get("default")
                if default is not None and values and default not in values:
                    yield Finding(
                        code="manifest.parameters.default", severity=ERROR,
                        file=MANIFEST, line=line,
                        message=(f"parameter `{pid}` defaults to `{default}`, which is not one "
                                 f"of its options; the form opens in an invalid state."),
                        detail={"id": pid, "default": default, "options": values},
                    )


@check("manifest")
def manifest_outputs(ctx: LintContext):
    """`outputs:` must match the choice made in the flow.

    When no choice was supplied there is nothing to compare against, and an
    absent block is reported as a note rather than a failure — bundles authored
    before output targets existed are not retrospectively broken. When a choice
    *was* supplied, the manifest must carry it exactly: this block is what
    drives the per-artifact schedule controls, so a mismatch is a control the
    person will never see.
    """
    if not isinstance(ctx.manifest, dict):
        return
    b = ctx.bundle
    declared = ctx.manifest.get("outputs")
    line = b.line_of(MANIFEST, "outputs:")

    formats: list[str] = []
    if declared is not None:
        if not isinstance(declared, list):
            yield Finding(
                code="manifest.outputs.malformed", severity=ERROR, file=MANIFEST, line=line,
                message=(f"`outputs` must be a list — of format names, or of the platform's "
                         f"artifact objects — got {type(declared).__name__}."),
                detail={"outputs": str(declared)},
            )
            return
        formats, unreadable = declared_formats(declared)
        if unreadable:
            yield Finding(
                code="manifest.outputs.malformed", severity=ERROR, file=MANIFEST, line=line,
                message=(f"`outputs` carries {len(unreadable)} entry/entries that name no format "
                         f"and no `kind`: {', '.join(unreadable)}. An output nobody can read is a "
                         f"schedule control the person never sees."),
                detail={"unreadable": unreadable},
            )
            return
        unknown = [x for x in formats if x not in OUTPUT_FORMATS]
        if unknown:
            yield Finding(
                code="manifest.outputs.unknown", severity=ERROR, file=MANIFEST, line=line,
                message=(f"`outputs` names {', '.join(unknown)}, which the flow does not "
                         f"offer; choose from {', '.join(sorted(OUTPUT_FORMATS))}."),
                detail={"unknown": unknown},
            )

    if ctx.outputs is None:
        if declared is None:
            yield Finding(
                code="manifest.outputs.absent", severity=INFO, file=MANIFEST,
                message=("manifest.yaml declares no `outputs:` block. Nothing was chosen for "
                         "this lint run, so this is a note: pass --outputs to require it."),
            )
        return

    chosen = sorted(set(ctx.outputs))
    if declared is None:
        yield Finding(
            code="manifest.outputs", severity=ERROR, file=MANIFEST,
            message=(f"the flow chose outputs {', '.join(chosen)} but manifest.yaml declares no "
                     f"`outputs:` block; the per-artifact schedule controls depend on it."),
            detail={"chosen": chosen, "declared": None},
        )
        return
    if sorted(set(formats)) != chosen:
        yield Finding(
            code="manifest.outputs", severity=ERROR, file=MANIFEST, line=line,
            message=(f"manifest.yaml declares outputs {', '.join(sorted(set(formats)))} but the "
                     f"flow chose {', '.join(chosen)}."),
            detail={"chosen": chosen, "declared": sorted(set(formats))},
        )
