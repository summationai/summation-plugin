"""`.sdeck` output: slides.json is present, complete, and its references resolve.

Only runs when ``sdeck`` is among the chosen outputs. A bundle that was never
going to produce a deck is not failed for having no slides.
"""

from __future__ import annotations

import json
import os
import re

from sf_findings import ERROR, WARNING, Finding
from ..core import LintContext, check

CANDIDATES = ("slides.json", "templates/slides.json", "templates/deck/slides.json")
TABLE_REF = re.compile(r"table:([A-Za-z0-9_./-]+)")
METRIC_REF = re.compile(r"metric:([A-Za-z0-9_.-]+)")


def _survey_metrics(ctx: LintContext) -> set:
    """Metric names the survey knows about, from its tables and literals."""
    names: set = set()
    s = ctx.survey or {}
    for m in s.get("metrics", []) or []:
        if isinstance(m, str):
            names.add(m)
        elif isinstance(m, dict) and m.get("name"):
            names.add(m["name"])
    for lit in ctx.survey_literals():
        if lit.get("column"):
            names.add(lit["column"])
    for t in s.get("tables", []) or []:
        if isinstance(t, dict) and t.get("columns"):
            names.update(str(c) for c in t["columns"])
    return names


@check("sdeck")
def slides_present_and_resolvable(ctx: LintContext):
    if not ctx.outputs or "sdeck" not in ctx.outputs:
        return

    b = ctx.bundle
    path = next((c for c in CANDIDATES if b.exists(c)), None)
    if path is None:
        found = [p for p in b.walk() if os.path.basename(p) == "slides.json"]
        path = found[0] if found else None
    if path is None:
        yield Finding(
            code="sdeck.slides.missing", severity=ERROR, file="slides.json",
            message=("`sdeck` was chosen as an output but the bundle has no slides.json, so there "
                     "is no deck to build."),
        )
        return

    try:
        data = json.loads(b.read(path))
    except json.JSONDecodeError as e:
        yield Finding(
            code="sdeck.slides.malformed", severity=ERROR, file=path, line=e.lineno,
            message=f"slides.json is not valid JSON: {e.msg} at line {e.lineno}.",
        )
        return
    except OSError as e:
        yield Finding(code="sdeck.slides.malformed", severity=ERROR, file=path,
                      message=f"slides.json could not be read: {e}.")
        return

    slides = data.get("slides") if isinstance(data, dict) else data
    if not isinstance(slides, list) or not slides:
        yield Finding(
            code="sdeck.slides.empty", severity=ERROR, file=path,
            message="slides.json declares no slides.",
        )
        return

    metrics = _survey_metrics(ctx)

    for i, slide in enumerate(slides):
        line = b.line_of(path, json.dumps(slide.get("title"))) if isinstance(slide, dict) else 1
        if not isinstance(slide, dict):
            yield Finding(
                code="sdeck.slide.malformed", severity=ERROR, file=path, line=1,
                message=f"slides[{i}] is a {type(slide).__name__}, not a slide.",
            )
            continue
        if not str(slide.get("title") or "").strip():
            yield Finding(
                code="sdeck.slide.title", severity=ERROR, file=path, line=line,
                message=f"slides[{i}] has no title; the deck renders a blank header.",
                detail={"index": i},
            )
        content = slide.get("content")
        if content is None or (isinstance(content, (list, str, dict)) and not content):
            yield Finding(
                code="sdeck.slide.content", severity=ERROR, file=path, line=line,
                message=(f"slides[{i}] (`{slide.get('title', '')}`) has no content; the slide "
                         f"renders empty."),
                detail={"index": i, "title": slide.get("title")},
            )
            continue

        blob = content if isinstance(content, str) else json.dumps(content)

        for m in TABLE_REF.finditer(blob):
            target = m.group(1)
            candidate = target if target.startswith("tables/") else f"tables/{target}"
            if not candidate.endswith(".json"):
                candidate += ".json"
            generated = any("tables/" in b.read(s) for s in ctx.script_files()
                            if b.exists(s))
            if not b.exists(candidate) and not generated:
                yield Finding(
                    code="sdeck.ref.table", severity=ERROR, file=path, line=line,
                    message=(f"slides[{i}] references `table:{target}`, which resolves to no "
                             f"table config in the bundle."),
                    detail={"index": i, "ref": target},
                )

        for m in METRIC_REF.finditer(blob):
            name = m.group(1)
            if metrics and name not in metrics:
                yield Finding(
                    code="sdeck.ref.metric", severity=WARNING, file=path, line=line,
                    message=(f"slides[{i}] references `metric:{name}`, which the fanout survey "
                             f"does not know about."),
                    detail={"index": i, "ref": name, "known": sorted(metrics)[:20]},
                )
