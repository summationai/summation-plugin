"""Importing this package registers every check.

Order of import is the order findings are produced for a clean run, so the
manifest comes first: when the manifest is broken, the reader wants to see that
before a cascade of downstream complaints.
"""

from . import manifest  # noqa: F401
from . import tables  # noqa: F401
from . import queries  # noqa: F401
from . import literals  # noqa: F401
from . import paths  # noqa: F401
from . import cells  # noqa: F401
from . import sdeck  # noqa: F401
