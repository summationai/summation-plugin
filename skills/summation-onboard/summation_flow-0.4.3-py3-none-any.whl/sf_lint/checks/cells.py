"""Numbers are never written into the document.

Section templates carry ``<cell/>`` placeholders that ``save.py`` hydrates and
traces. A numeral typed straight into the prose is untraceable by construction:
it will not move when the data moves, and no verification pass can source it.

**What counts as a hardcoded number, and what does not.** This check flags
numerals in *value positions* — a figure presented as a measurement — and
leaves definitional prose alone. ``"the same seven days 364 days earlier"`` in a
Definitions block is an explanation of method, not a figure that will go stale;
flagging it would train people to ignore the check. So the test is the shape of
the numeral: currency-prefixed, percent- or points-suffixed, thousands-grouped,
or a decimal with a magnitude suffix. A bare integer in a sentence is not
flagged.
"""

from __future__ import annotations

import re

from sf_findings import ERROR, WARNING, Finding
from ..core import LintContext, check

CELL = re.compile(r"<cell\b", re.IGNORECASE)

# A numeral presented as a measurement.
MEASUREMENT = re.compile(
    r"""(
        [$£€¥]\s?\d[\d,]*(?:\.\d+)?          # $1,234.56
      | \d[\d,]*(?:\.\d+)?\s?%               # 12.3%
      | \d[\d,]*(?:\.\d+)?\s?(?:pts|bps|pp)\b  # 1.2 pts
      | \d{1,3}(?:,\d{3})+(?:\.\d+)?         # 1,234,567
      | \d+(?:\.\d+)?\s?(?:[KMB]|million|billion|thousand)\b  # 1.2M
    )""",
    re.VERBOSE,
)

# Text between tags. Attribute values are configuration, not prose.
TEXT_NODE = re.compile(r">([^<>]+)<")


@check("cell")
def cells_present_and_numbers_traced(ctx: LintContext):
    b = ctx.bundle
    docs = ctx.document_templates()
    if not docs:
        return

    for rel in docs:
        text = b.read_stripped(rel)  # comments are documentation, not content

        if not CELL.search(text):
            yield Finding(
                code="cell.absent", severity=ERROR, file=rel, line=1,
                message=("this document template carries no <cell/> placeholders, so no figure in "
                         "it can be traced to a snapshot. Every number must be a <cell/>."),
            )

        for m in TEXT_NODE.finditer(text):
            chunk = m.group(1)
            if not chunk.strip():
                continue
            for hit in MEASUREMENT.finditer(chunk):
                line = text.count("\n", 0, m.start(1) + hit.start()) + 1
                yield Finding(
                    code="cell.hardcoded_number", severity=ERROR, file=rel, line=line,
                    message=(f"`{hit.group(0).strip()}` is written straight into the document. A "
                             f"figure in a value position must be a <cell/> carrying its snapshot, "
                             f"or it goes stale silently and cannot be verified."),
                    detail={"value": hit.group(0).strip(), "context": chunk.strip()[:160]},
                )


@check("cell")
def cell_sources_are_snapshots(ctx: LintContext):
    """A <cell/> must name the snapshot it came from, and a path within it."""
    b = ctx.bundle
    tag = re.compile(r"<cell\b([^>]*)>", re.IGNORECASE)
    src_attr = re.compile(r"\bsrc\s*=\s*[\"']([^\"']*)[\"']")
    path_attr = re.compile(r"\bpath\s*=\s*[\"']([^\"']*)[\"']")

    for rel in ctx.document_templates():
        text = b.read_stripped(rel)
        for m in tag.finditer(text):
            attrs = m.group(1)
            line = text.count("\n", 0, m.start()) + 1
            s = src_attr.search(attrs)
            p = path_attr.search(attrs)
            if not s or not s.group(1).strip():
                yield Finding(
                    code="cell.src.missing", severity=ERROR, file=rel, line=line,
                    message="a <cell/> carries no `src`, so its figure has no traceable source.",
                    detail={"tag": m.group(0)[:120]},
                )
                continue
            if not p or not p.group(1).strip():
                yield Finding(
                    code="cell.path.missing", severity=ERROR, file=rel, line=line,
                    message=(f"the <cell/> pointing at `{s.group(1)}` names no `path`, so it does "
                             f"not say which field of the snapshot it renders."),
                    detail={"src": s.group(1)},
                )
            src = s.group(1)
            if not src.startswith("snapshots/"):
                yield Finding(
                    code="cell.src.not_a_snapshot", severity=WARNING, file=rel, line=line,
                    message=(f"the <cell/> src `{src}` does not point into snapshots/; traced "
                             f"figures come from query snapshots."),
                    detail={"src": src},
                )
