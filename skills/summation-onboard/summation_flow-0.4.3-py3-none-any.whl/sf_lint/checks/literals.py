"""Every literal the fanout survey flagged is parameterised, or explicitly accepted.

The survey records the values the customer had hardcoded in their own SQL — a
planner code, a buyer list, a week. Carrying those straight into the bundle
reproduces the thing the flow exists to fix: a playbook that only ever runs for
one person.

Scope matters and is deliberate. The check looks at **query templates and
document templates** — the places a literal makes the playbook single-purpose.
It does not look at ``manifest.yaml`` (a value appearing there as a parameter
default or a select option *is* the parameterisation) and it does not look at
config side-files such as ``buyer_areas.json`` (a lookup table keyed by code is
data, not a hardcoded filter).
"""

from __future__ import annotations

import re

from sf_findings import ERROR, INFO, Finding
from ..core import LintContext, check


def _scoped_files(ctx: LintContext) -> list[str]:
    files = set(ctx.query_files()) | set(ctx.document_templates())
    files |= {p for p in ctx.bundle.walk()
              if p.endswith((".html.tmpl", ".html", ".sdeck")) and p.startswith("templates")}
    return sorted(files)


@check("literal")
def survey_literals_parameterised(ctx: LintContext):
    if not ctx.survey:
        yield Finding(
            code="literal.survey.absent", severity=INFO,
            message=("no fanout survey was supplied, so lint cannot tell which literals the "
                     "customer had hardcoded. Pass --survey to enable the check."),
        )
        return

    lits = ctx.survey_literals()
    if not lits:
        return

    b = ctx.bundle
    files = _scoped_files(ctx)

    for lit in lits:
        value = lit.get("value")
        if value is None or str(value) == "":
            continue
        value = str(value)
        column = lit.get("column") or "?"

        if value in ctx.accepted_literals:
            who = ctx.accepted_by or "unrecorded"
            yield Finding(
                code="literal.accepted", severity=INFO,
                message=(f"the literal `{value}` ({column}) stays hardcoded by explicit "
                         f"acceptance, recorded against {who}."),
                detail={"value": value, "column": column, "accepted_by": who},
            )
            continue

        pattern = re.compile(r"(?<![A-Za-z0-9_])" + re.escape(value) + r"(?![A-Za-z0-9_])")
        for rel in files:
            try:
                text = b.read(rel)
            except OSError:
                continue
            for line, _m in b.find_all_lines(rel, pattern):
                yield Finding(
                    code="literal.hardcoded", severity=ERROR, file=rel, line=line,
                    message=(f"`{value}` is hardcoded here, but the fanout survey flagged it as a "
                             f"{column} literal from the customer's own SQL. Turn it into a "
                             f"parameter, or accept it with --accept-literal {value}."),
                    detail={"value": value, "column": column,
                            "seen_at": lit.get("seen_at", [])},
                )
                break  # one finding per file; the first line is enough to act on
