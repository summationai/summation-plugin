"""``python -m sf_lint <bundle-dir> [--survey survey.json] [--outputs sdoc,html,sdeck]``

Exits non-zero on any error-severity finding.

The warehouse dry run is off unless a warehouse is named. ``--profile`` binds a
real read-only ``sumcli``; without it, queries that substitute cleanly are
reported as unproven rather than silently treated as fine.
"""

from __future__ import annotations

import argparse
import sys

from sf_findings import ERROR, Finding, FindingSet

from . import check_names, lint_bundle, load_survey
from .query import SumcliQueryRunner


def _params(pairs) -> dict:
    out = {}
    for raw in pairs or []:
        if "=" not in raw:
            raise SystemExit(f"--param expects NAME=VALUE, got {raw!r}")
        k, v = raw.split("=", 1)
        out[k.strip()] = v
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="sf_lint",
        description="The deterministic gate on an authored playbook bundle.",
    )
    ap.add_argument("bundle", nargs="?", help="path to the .spb directory")
    ap.add_argument("--survey", help="fanout survey JSON, for the hardcoded-literal check")
    ap.add_argument("--outputs", help="comma-separated output formats chosen in the flow "
                                      "(sdoc, sdeck, html)")
    ap.add_argument("--accept-literal", action="append", default=[], metavar="VALUE",
                    help="allow a surveyed literal to stay hardcoded; repeatable")
    ap.add_argument("--accepted-by", default=None,
                    help="who accepted the literals, recorded in the finding")
    ap.add_argument("--param", action="append", default=[], metavar="NAME=VALUE",
                    help="value for a query placeholder, beyond the manifest defaults")
    ap.add_argument("--profile", default=None,
                    help="sumcli profile for the read-only query dry run; omit to skip it")
    ap.add_argument("--json", action="store_true", dest="as_json", help="emit findings as JSON")
    ap.add_argument("--list-checks", action="store_true", help="print the check families and exit")
    args = ap.parse_args(argv)

    if args.list_checks:
        for n in check_names():
            print(n)
        return 0
    if not args.bundle:
        ap.error("a bundle directory is required")

    survey, survey_err = load_survey(args.survey)
    outputs = [o.strip() for o in args.outputs.split(",") if o.strip()] if args.outputs else None
    runner = SumcliQueryRunner(args.profile) if args.profile else None

    findings = lint_bundle(
        args.bundle,
        survey=survey,
        outputs=outputs,
        accepted_literals=args.accept_literal,
        accepted_by=args.accepted_by,
        query_runner=runner,
        param_values=_params(args.param),
    )
    if survey_err:
        findings.add(survey_err)

    if args.as_json:
        print(findings.to_json())
    else:
        print(findings.render())
        verdict = "PASS" if findings.ok else "FAIL"
        print(f"\n{findings.summary()} — lint {verdict}")
    return findings.exit_code


if __name__ == "__main__":
    sys.exit(main())
