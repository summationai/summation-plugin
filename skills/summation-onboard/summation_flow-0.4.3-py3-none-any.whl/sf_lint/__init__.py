"""The deterministic gate on an authored bundle.

    from sf_lint import lint_bundle
    findings = lint_bundle("Owner 07 Weekly Recap.spb",
                           survey=survey_dict,
                           outputs=["sdoc"],
                           query_runner=runner)
    if not findings.ok:
        print(findings.render())

Every finding names a file and, where the defect has one, a line. Nothing here
raises on bad input: a bundle that cannot be read is a bundle with findings.
"""

from __future__ import annotations

import json
import os
from typing import Callable, Iterable, Optional

from sf_findings import ERROR, Finding, FindingSet

from .core import Bundle, LintContext, registered, run_checks
from . import checks as _checks  # noqa: F401  (import registers the checks)

__all__ = ["lint_bundle", "Bundle", "LintContext", "load_survey", "check_names"]


def check_names() -> list[str]:
    """The registered check families, for tests and for `--list-checks`."""
    return sorted({name for name, _ in registered()})


def load_survey(path: Optional[str]) -> tuple[Optional[dict], Optional[Finding]]:
    if not path:
        return None, None
    if not os.path.exists(path):
        return None, Finding(code="survey.missing", severity=ERROR, file=path,
                             message=f"no survey at `{path}`.")
    try:
        with open(path) as fh:
            return json.load(fh), None
    except json.JSONDecodeError as e:
        return None, Finding(code="survey.malformed", severity=ERROR, file=path, line=e.lineno,
                             message=f"the survey is not valid JSON: {e.msg}.")


def _load_manifest(bundle: Bundle) -> tuple[Optional[dict], Optional[str]]:
    if not bundle.exists("manifest.yaml"):
        return None, None
    try:
        import yaml
    except ImportError:  # pragma: no cover - environment guard
        return None, "PyYAML is not installed, so the manifest cannot be parsed"
    try:
        return yaml.safe_load(bundle.read("manifest.yaml")), None
    except yaml.YAMLError as e:
        return None, str(e).replace("\n", " ")[:300]
    except OSError as e:  # pragma: no cover
        return None, str(e)


def lint_bundle(
    path: str,
    *,
    survey: Optional[dict] = None,
    outputs: Optional[Iterable[str]] = None,
    accepted_literals: Optional[Iterable[str]] = None,
    accepted_by: Optional[str] = None,
    query_runner: Optional[Callable] = None,
    param_values: Optional[dict] = None,
) -> FindingSet:
    """Lint a ``.spb`` bundle directory. Returns findings; never raises."""
    fs = FindingSet()

    if not os.path.isdir(path):
        fs.add(Finding(
            code="bundle.missing", severity=ERROR, file=path,
            message=f"`{path}` is not a bundle directory.",
        ))
        return fs

    bundle = Bundle(path)
    manifest, manifest_error = _load_manifest(bundle)

    ctx = LintContext(
        bundle=bundle,
        survey=survey,
        outputs=sorted(set(outputs)) if outputs else None,
        accepted_literals=set(accepted_literals or ()),
        accepted_by=accepted_by,
        query_runner=query_runner,
        param_values=dict(param_values or {}),
        manifest=manifest,
        manifest_error=manifest_error,
    )
    return fs.extend(run_checks(ctx))
