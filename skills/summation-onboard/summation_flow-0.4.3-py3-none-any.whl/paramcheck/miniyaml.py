"""A YAML subset parser, standard library only.

Scope is deliberately narrow: enough to read a playbook manifest. Block
mappings, block sequences, folded (``>``) and literal (``|``) scalars,
quoted and plain scalars, comments, and the handful of scalar types a
manifest uses. No anchors, aliases, tags, flow collections, multi-document
streams or merge keys — if one appears, this raises rather than guessing,
because a manifest silently half-parsed is worse than one that fails loudly.

`paramcheck` refuses third-party dependencies, so PyYAML is not importable
here. It *is* used in the test suite as an oracle: `test_miniyaml.py` parses
the real manifest with both and asserts the results are identical, skipping
if PyYAML is absent. That keeps the hand-rolled parser honest without making
the tool depend on it.
"""

from __future__ import annotations

import re


class YamlError(ValueError):
    """Raised when the input uses YAML this parser will not guess at."""


_UNSUPPORTED = re.compile(r"^\s*(?:%YAML|---\s*\S|&\w+|\*\w+|!!|\?\s)")
# Anchors/aliases in value position: "key: &name value", "key: *name".
_ANCHOR_RE = re.compile(r"^[&*]\w")

_TRUE = {"true", "yes", "on"}
_FALSE = {"false", "no", "off"}
_NULL = {"", "~", "null", "none"}
_INT_RE = re.compile(r"^[+-]?\d+$")
_FLOAT_RE = re.compile(r"^[+-]?(?:\d+\.\d*|\.\d+|\d+)(?:[eE][+-]?\d+)?$")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class _Line:
    __slots__ = ("indent", "text", "no")

    def __init__(self, indent, text, no):
        self.indent = indent
        self.text = text
        self.no = no

    def __repr__(self):  # pragma: no cover - debugging aid
        return f"{self.no}:{self.indent}:{self.text!r}"


def _strip_comment(raw: str) -> str:
    """Remove a trailing comment, respecting quotes."""
    out = []
    quote = None
    i = 0
    while i < len(raw):
        ch = raw[i]
        if quote:
            out.append(ch)
            if ch == "\\" and quote == '"' and i + 1 < len(raw):
                out.append(raw[i + 1])
                i += 2
                continue
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
            out.append(ch)
        elif ch == "#" and (not out or out[-1] in " \t"):
            break
        else:
            out.append(ch)
        i += 1
    return "".join(out).rstrip()


def _scan(text: str):
    lines = []
    for no, raw in enumerate(text.splitlines(), 1):
        if _UNSUPPORTED.match(raw):
            raise YamlError(
                f"line {no}: unsupported YAML construct: {raw.strip()!r}. "
                f"This parser handles block mappings, block sequences and "
                f"scalars only.")
        if raw.strip() in ("---", "..."):
            continue
        stripped = _strip_comment(raw)
        if not stripped.strip():
            continue
        lead = raw[:len(raw) - len(raw.lstrip(" \t"))]
        if "\t" in lead:
            raise YamlError(
                f"line {no}: tab in indentation. YAML forbids tabs for "
                f"indentation and the meaning is ambiguous; use spaces.")
        indent = len(lead)
        lines.append(_Line(indent, stripped.strip(), no))
    return lines


def _raw_lines(text: str):
    """Original lines, needed to reconstruct block scalars verbatim."""
    return text.splitlines()


def parse_scalar(token: str):
    """Convert a plain or quoted scalar token to a Python value."""
    t = token.strip()
    if len(t) >= 2 and t[0] == t[-1] and t[0] in "\"'":
        body = t[1:-1]
        if t[0] == '"':
            body = (body.replace('\\"', '"').replace("\\n", "\n")
                        .replace("\\t", "\t").replace("\\\\", "\\"))
        else:
            body = body.replace("''", "'")
        return body
    low = t.lower()
    if low in _NULL:
        return None
    if low in _TRUE:
        return True
    if low in _FALSE:
        return False
    if _INT_RE.match(t):
        return int(t)
    if _DATE_RE.match(t):
        return t          # keep dates as strings; callers compare verbatim
    if _FLOAT_RE.match(t) and not _INT_RE.match(t):
        try:
            return float(t)
        except ValueError:
            return t
    return t


def _split_key(text):
    """Split ``key: value`` respecting quotes. Returns (key, rest) or None."""
    quote = None
    i = 0
    while i < len(text):
        ch = text[i]
        if quote:
            if ch == "\\" and quote == '"':
                i += 2
                continue
            if ch == quote:
                quote = None
        elif ch in "\"'":
            quote = ch
        elif ch == ":":
            after = text[i + 1:i + 2]
            if after in ("", " "):
                key = text[:i].strip()
                if len(key) >= 2 and key[0] == key[-1] and key[0] in "\"'":
                    key = key[1:-1]
                return key, text[i + 1:].strip()
        i += 1
    return None


class _Parser:
    def __init__(self, text):
        self.text = text
        self.raw = _raw_lines(text)
        self.lines = _scan(text)
        self.i = 0

    def peek(self):
        return self.lines[self.i] if self.i < len(self.lines) else None

    def parse(self):
        if not self.lines:
            return {}
        value = self.parse_node(self.lines[0].indent)
        if self.i < len(self.lines):
            ln = self.lines[self.i]
            raise YamlError(f"line {ln.no}: unexpected content {ln.text!r}")
        return value

    def parse_node(self, indent):
        ln = self.peek()
        if ln is None or ln.indent < indent:
            return None
        if ln.text.startswith("- ") or ln.text == "-":
            return self.parse_sequence(indent)
        return self.parse_mapping(indent)

    def parse_sequence(self, indent):
        out = []
        while True:
            ln = self.peek()
            if ln is None or ln.indent != indent:
                break
            if not (ln.text.startswith("- ") or ln.text == "-"):
                break
            body = ln.text[2:].strip() if ln.text != "-" else ""
            item_col = ln.indent + 2
            self.i += 1
            if not body:
                out.append(self.parse_node(item_col))
                continue
            kv = _split_key(body)
            if kv is None:
                out.append(self._scalar_or_block(body, item_col))
                continue
            # Inline first key of a mapping item; the rest follows indented.
            item = {}
            self._assign(item, kv[0], kv[1], item_col)
            nxt = self.peek()
            while nxt is not None and nxt.indent == item_col and \
                    not nxt.text.startswith("- "):
                kv2 = _split_key(nxt.text)
                if kv2 is None:
                    raise YamlError(
                        f"line {nxt.no}: expected 'key: value' inside a "
                        f"sequence item, got {nxt.text!r}")
                self.i += 1
                self._assign(item, kv2[0], kv2[1], item_col)
                nxt = self.peek()
            out.append(item)
        return out

    def parse_mapping(self, indent):
        out = {}
        while True:
            ln = self.peek()
            if ln is None or ln.indent != indent:
                break
            if ln.text.startswith("- "):
                break
            kv = _split_key(ln.text)
            if kv is None:
                raise YamlError(
                    f"line {ln.no}: expected 'key: value', got {ln.text!r}")
            self.i += 1
            self._assign(out, kv[0], kv[1], indent)
        return out

    def _assign(self, mapping, key, rest, indent):
        if key in mapping:
            raise YamlError(f"duplicate key {key!r}")
        mapping[key] = self._scalar_or_block(rest, indent, nested=True)

    def _scalar_or_block(self, rest, indent, nested=False):
        if rest in (">", "|", ">-", "|-", ">+", "|+"):
            return self._block_scalar(rest, indent)
        if rest == "":
            if not nested:
                return None
            nxt = self.peek()
            if nxt is not None and nxt.indent > indent:
                return self.parse_node(nxt.indent)
            if nxt is not None and nxt.indent == indent and \
                    nxt.text.startswith("- "):
                return self.parse_sequence(indent)
            return None
        if rest.startswith("[") or rest.startswith("{"):
            raise YamlError(
                f"flow collections are not supported: {rest!r}. Rewrite as a "
                f"block sequence or mapping.")
        if _ANCHOR_RE.match(rest):
            raise YamlError(
                f"anchors and aliases are not supported: {rest!r}. Resolving "
                f"them wrongly would silently change a parameter value.")
        return parse_scalar(rest)

    def _block_scalar(self, style, indent):
        folded = style[0] == ">"
        chomp = style[1:] if len(style) > 1 else ""
        body = []
        while self.i < len(self.lines):
            ln = self.lines[self.i]
            if ln.indent <= indent:
                break
            body.append(ln)
            self.i += 1
        if not body:
            return ""
        base = min(l.indent for l in body)
        # Re-read from the raw source so comment-like '#' inside prose and
        # interior blank lines survive.
        first, last = body[0].no, body[-1].no
        raw = [self.raw[n - 1] for n in range(first, last + 1)]
        stripped = [r[base:] if len(r) >= base else r.strip() for r in raw]
        if folded:
            out, para = [], []
            for line in stripped:
                if line.strip() == "":
                    out.append(" ".join(para))
                    para = []
                    out.append("")
                else:
                    para.append(line.strip())
            if para:
                out.append(" ".join(para))
            text = "\n".join(out)
        else:
            text = "\n".join(stripped)
        if chomp == "-":
            return text.rstrip("\n")
        if chomp == "+":
            return text + "\n"
        return text.rstrip("\n") + "\n"


def safe_load(text: str):
    """Parse a YAML subset. Raises YamlError on anything unsupported."""
    return _Parser(text).parse()


def load_file(path: str):
    with open(path, encoding="utf-8") as fh:
        return safe_load(fh.read())
