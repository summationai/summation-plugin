"""Client-side parameter validation (SPEC stage 10.5).

Exists because the platform validates nothing. `LEDGER.md` R-025 proved it
live against the real recap playbook: a bogus value, a label sent in place of
its value, and an omitted required parameter were **all accepted**, each
creating a live schedule that would run and produce a wrong or empty report
with no error anywhere.

So this runs before anything is sent. Every rejection names the parameter and
says what to send instead, because the caller here is usually an agent that
read the manifest and drew a reasonable but wrong conclusion.
"""

from __future__ import annotations

import difflib
import re
from datetime import date, datetime

# --- finding codes ---------------------------------------------------------
MISSING_REQUIRED = "missing_required"
NOT_AN_OPTION = "not_an_option"
LABEL_USED_AS_VALUE = "label_used_as_value"
CASE_MISMATCH = "option_case_mismatch"
TYPE_MISMATCH = "type_mismatch"
EMPTY_VALUE = "empty_value"
UNDECLARED_PARAMETER = "undeclared_parameter"
KEY_TRANSFORM_HAZARD = "key_transform_hazard"
CROSS_PARAM_INCONSISTENT = "cross_parameter_inconsistent"
DEFAULT_APPLIED = "default_applied"
OPEN_LIST_UNDECLARED = "option_list_assumed_closed"
UNCHECKED_CONSTRAINT = "constraint_not_checked"

_SNAKE_RE = re.compile(r"_([a-z0-9])")
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_SEPARATORS = (" — ", " – ", " - ", " -- ")


def camelize(key: str) -> str:
    """The transform the platform applies to `config.params` keys (R-024)."""
    return _SNAKE_RE.sub(lambda m: m.group(1).upper(), key)


class Finding(dict):
    def __init__(self, code, severity, parameter, message, **extra):
        super().__init__(code=code, severity=severity, parameter=parameter,
                         message=message, **extra)


def _is_blank(v):
    return v is None or (isinstance(v, str) and v.strip() == "")


def _type_ok(spec, value):
    """Returns (ok, expected_description, coerced_value)."""
    t = spec.type
    if t in ("select", "string", "text", ""):
        if isinstance(value, bool):
            return False, "string", None
        return isinstance(value, (str, int, float)), "string", (
            value if isinstance(value, str) else str(value))
    if t in ("number", "float"):
        if isinstance(value, bool):
            return False, "number", None
        if isinstance(value, (int, float)):
            return True, "number", value
        if isinstance(value, str):
            try:
                return True, "number", float(value)
            except ValueError:
                return False, "number", None
        return False, "number", None
    if t == "integer":
        if isinstance(value, bool):
            return False, "integer", None
        if isinstance(value, int):
            return True, "integer", value
        if isinstance(value, str) and re.fullmatch(r"[+-]?\d+", value.strip()):
            return True, "integer", int(value)
        if isinstance(value, float) and float(value).is_integer():
            return True, "integer", int(value)
        return False, "integer", None
    if t in ("date", "datetime"):
        if isinstance(value, (date, datetime)):
            return True, "date (YYYY-MM-DD)", value.isoformat()[:10]
        if isinstance(value, str) and _DATE_RE.match(value.strip()):
            try:
                datetime.strptime(value.strip(), "%Y-%m-%d")
            except ValueError:
                return False, "date (YYYY-MM-DD)", None
            return True, "date (YYYY-MM-DD)", value.strip()
        return False, "date (YYYY-MM-DD)", None
    if t in ("boolean", "bool"):
        if isinstance(value, bool):
            return True, "boolean", value
        if isinstance(value, str) and value.strip().lower() in (
                "true", "false", "yes", "no"):
            return True, "boolean", value.strip().lower() in ("true", "yes")
        return False, "boolean", None
    # Unknown declared type: accept, but do not pretend it was checked.
    return True, t, value


def _suggest(value, candidates, n=2):
    if not isinstance(value, str):
        return []
    strs = [c for c in candidates if isinstance(c, str)]
    return difflib.get_close_matches(value, strs, n=n, cutoff=0.6)


def _label_prefix(label):
    for sep in _SEPARATORS:
        if sep in label:
            return label.split(sep, 1)[0].strip()
    return None


def validate(manifest, params, apply_defaults=False):
    """Validate ``params`` against ``manifest``.

    Returns a JSON-serialisable result dict. ``ok`` is False when any finding
    has severity ``error``.
    """
    findings = []
    normalised = {}
    declared = {p.id: p for p in manifest.parameters}

    if not isinstance(params, dict):
        findings.append(Finding(
            "params_not_an_object", "error", None,
            f"params must be a JSON object, got {type(params).__name__}"))
        return _result(manifest, findings, {}, params)

    # --- 5. anything the manifest does not declare -------------------------
    for key in params:
        if key in declared:
            continue
        hit = next((d for d in declared if camelize(d) == key), None)
        if hit:
            findings.append(Finding(
                UNDECLARED_PARAMETER, "error", key,
                f"'{key}' is not declared. It is the camelCase form of "
                f"'{hit}' — send the manifest's own id, '{hit}'. "
                f"(The platform camelCases keys in transit; that is its bug "
                f"to undo, not something to pre-apply. See LEDGER R-024.)",
                did_you_mean=hit))
            continue
        near = _suggest(key, list(declared))
        findings.append(Finding(
            UNDECLARED_PARAMETER, "warning", key,
            f"'{key}' is not declared in the manifest and will be ignored "
            f"or silently stored." +
            (f" Did you mean '{near[0]}'?" if near else ""),
            did_you_mean=near[0] if near else None))

    # --- per declared parameter -------------------------------------------
    for spec in manifest.parameters:
        present = spec.id in params
        value = params.get(spec.id)

        # 1. required and missing
        if not present or _is_blank(value):
            reason = ("omitted entirely" if not present else
                      "present but empty")
            if spec.required:
                if apply_defaults and spec.default is not None:
                    normalised[spec.id] = spec.default
                    findings.append(Finding(
                        DEFAULT_APPLIED, "warning", spec.id,
                        f"required parameter '{spec.id}' was {reason}; "
                        f"filled from the manifest default "
                        f"{spec.default!r} because --apply-defaults was set."))
                else:
                    hint = ""
                    if spec.default is not None:
                        hint = (f" The manifest declares a default of "
                                f"{spec.default!r} — send it explicitly "
                                f"rather than relying on the platform to "
                                f"apply it, which it does not do reliably.")
                    findings.append(Finding(
                        MISSING_REQUIRED, "error", spec.id,
                        f"required parameter '{spec.id}' "
                        f"({spec.label or spec.type}) is {reason}." + hint,
                        default=spec.default))
            elif present:
                findings.append(Finding(
                    EMPTY_VALUE, "warning", spec.id,
                    f"optional parameter '{spec.id}' is present but empty; "
                    f"omit it instead of sending a blank."))
            continue

        # 4. declared type
        ok, expected, coerced = _type_ok(spec, value)
        if not ok:
            findings.append(Finding(
                TYPE_MISMATCH, "error", spec.id,
                f"'{spec.id}' expects {expected}, got "
                f"{type(value).__name__} {value!r}.",
                expected_type=expected, got=value))
            continue

        # 2 and 3. option membership, and the label-for-value trap
        if spec.is_select and spec.options:
            if spec.option_by_value(coerced) is not None:
                normalised[spec.id] = coerced
                continue

            by_label = spec.options_by_label(coerced if isinstance(coerced, str)
                                             else str(coerced))
            if by_label:
                opt = by_label[0]
                extra = ""
                if len(by_label) > 1:
                    extra = (f" (that label is shared by "
                             f"{len(by_label)} options: "
                             f"{', '.join(repr(o.value) for o in by_label)})")
                findings.append(Finding(
                    LABEL_USED_AS_VALUE,
                    "error" if not spec.allow_custom else "warning",
                    spec.id,
                    f"'{coerced}' is the label of option {opt.value!r} — "
                    f"send the value, not the label." + extra,
                    got=coerced, send_instead=opt.value,
                    option_label=opt.label_text))
                continue

            ci = spec.option_by_value_ci(coerced)
            if ci is not None:
                findings.append(Finding(
                    CASE_MISMATCH, "error", spec.id,
                    f"'{coerced}' differs from declared option "
                    f"{ci.value!r} only in case or surrounding whitespace. "
                    f"Option values are matched exactly — send {ci.value!r}.",
                    got=coerced, send_instead=ci.value))
                continue

            if spec.allow_custom:
                normalised[spec.id] = coerced
                findings.append(Finding(
                    NOT_AN_OPTION, "warning", spec.id,
                    f"'{coerced}' is not one of the {len(spec.options)} "
                    f"declared options, but the manifest sets allowCustom, "
                    f"so it is permitted."))
                continue

            near = _suggest(coerced, spec.option_values())
            label_near = _suggest(coerced, [o.label_text for o in spec.options])
            hint = ""
            if near:
                hint = f" Did you mean {near[0]!r}?"
            elif label_near:
                match = spec.options_by_label(label_near[0])
                if match:
                    hint = (f" The closest label is {label_near[0]!r}, whose "
                            f"value is {match[0].value!r}.")
            closed_note = ""
            if not spec.allow_custom_declared:
                closed_note = (" (The manifest does not state allowCustom; "
                               "an option list is treated as closed.)")
            findings.append(Finding(
                NOT_AN_OPTION, "error", spec.id,
                f"'{coerced}' is not one of the {len(spec.options)} declared "
                f"options for '{spec.id}'." + hint + closed_note,
                got=coerced,
                valid_values=[o.value for o in spec.options]))
            continue

        normalised[spec.id] = coerced

    # A constraint we do not enforce must be announced, never ignored: a
    # caller reading "no errors" would otherwise assume it was checked.
    for spec in manifest.parameters:
        if spec.unchecked_constraints and spec.id in normalised:
            findings.append(Finding(
                UNCHECKED_CONSTRAINT, "warning", spec.id,
                f"'{spec.id}' declares "
                f"{', '.join(spec.unchecked_constraints)}, which this "
                f"validator does not enforce. The value was NOT checked "
                f"against it — verify by hand before sending.",
                constraints=spec.unchecked_constraints))

    findings.extend(_cross_parameter(manifest, normalised))
    findings.extend(_transport_hazards(manifest, normalised))
    if any(not p.allow_custom_declared and p.options
           for p in manifest.parameters):
        undeclared = [p.id for p in manifest.parameters
                      if p.options and not p.allow_custom_declared]
        findings.append(Finding(
            OPEN_LIST_UNDECLARED, "info", None,
            f"{len(undeclared)} parameter(s) declare an option list without "
            f"stating allowCustom: {', '.join(undeclared)}. Treated as "
            f"closed lists.", parameters=undeclared))

    return _result(manifest, findings, normalised, params)


def _cross_parameter(manifest, normalised):
    """Option labels of the form 'OWNER — thing' encode a relationship.

    In the recap manifest every `area_of_business` label is prefixed with the
    planner it belongs to, using the planner's *label* (so `HWENDEL` appears
    as "TARLOWE"). Sending a valid planner with another planner's area passes
    every per-field rule and still produces the wrong report.

    This is a convention read off the manifest, not a declared constraint, so
    it warns rather than rejects.
    """
    out = []
    selects = [p for p in manifest.parameters if p.is_select and p.options]
    for spec in selects:
        chosen = normalised.get(spec.id)
        if chosen is None:
            continue
        opt = spec.option_by_value(chosen)
        if opt is None or opt.label is None:
            continue
        prefix = _label_prefix(opt.label_text)
        if not prefix:
            continue
        for other in selects:
            if other.id == spec.id:
                continue
            labels = {o.label_text for o in other.options}
            if prefix not in labels:
                continue
            other_val = normalised.get(other.id)
            if other_val is None:
                continue
            other_opt = other.option_by_value(other_val)
            if other_opt is None:
                continue
            if other_opt.label_text != prefix:
                out.append(Finding(
                    CROSS_PARAM_INCONSISTENT, "warning", spec.id,
                    f"'{spec.id}' = {chosen!r} is labelled "
                    f"{opt.label_text!r}, which belongs to "
                    f"{other.id} = {prefix!r}. But {other.id} was sent as "
                    f"{other_val!r} (labelled {other_opt.label_text!r}). "
                    f"These two are inconsistent; the run would produce a "
                    f"report for a combination the manifest does not pair.",
                    related_parameter=other.id,
                    expected_related_label=prefix))
    return out


def _transport_hazards(manifest, normalised):
    """R-024: `config.params` keys are camelCased in transit."""
    out = []
    hazard = []
    for spec in manifest.parameters:
        if spec.id not in normalised:
            continue
        wire = camelize(spec.id)
        if wire != spec.id:
            hazard.append({"declared": spec.id, "arrives_as": wire})
    if hazard:
        pairs = ", ".join(f"{h['declared']} -> {h['arrives_as']}"
                          for h in hazard)
        out.append(Finding(
            KEY_TRANSFORM_HAZARD, "warning", None,
            f"{len(hazard)} parameter key(s) will not survive transit as "
            f"declared: {pairs}. The platform camelCases config.params keys, "
            f"so the playbook receives a key its manifest does not declare "
            f"and the value is silently dropped (LEDGER R-024). Read the "
            f"created object back and assert the keys before trusting the "
            f"run.", keys=hazard))
    return out


def _result(manifest, findings, normalised, params):
    errors = [f for f in findings if f["severity"] == "error"]
    warnings = [f for f in findings if f["severity"] == "warning"]
    infos = [f for f in findings if f["severity"] == "info"]
    return {
        "ok": not errors,
        "manifest": {
            "path": manifest.path,
            "title": manifest.title,
            "parameters_declared": manifest.ids(),
            "required": [p.id for p in manifest.parameters if p.required],
        },
        "params_received": params,
        "normalised_params": normalised if not errors else None,
        "counts": {"errors": len(errors), "warnings": len(warnings),
                   "info": len(infos)},
        "errors": errors,
        "warnings": warnings,
        "info": infos,
        "transport": {
            "camel_case_hazard": next(
                (f["keys"] for f in findings
                 if f["code"] == KEY_TRANSFORM_HAZARD), []),
            "note": "Keys must arrive exactly as declared. Verify by reading "
                    "the created object back; do not pre-camelCase.",
        },
    }
