"""Playbook manifest -> normalised parameter specs.

Manifests in the wild spell the same idea several ways (`is_required` /
`required` / `isRequired`, `allowCustom` / `allow_custom`), so every field is
read through an alias list. Anything genuinely absent stays absent; nothing
is invented.

One default is asserted rather than read: a `select` whose manifest does not
mention `allowCustom` is treated as **closed**. That is the safe reading — an
option list means nothing if an undeclared value is admissible — and it
matches how the recap manifest is meant to behave. `ParameterSpec.
allow_custom_declared` records whether the manifest actually said so, so the
assumption is visible rather than silent.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional

from . import miniyaml

REQUIRED_ALIASES = ("is_required", "required", "isRequired", "mandatory")
ALLOW_CUSTOM_ALIASES = ("allowCustom", "allow_custom", "allowCustomValues",
                        "allow_custom_values", "custom_allowed")
ID_ALIASES = ("id", "name", "key", "parameter_id")
TYPE_ALIASES = ("type", "kind", "param_type")
LABEL_ALIASES = ("label", "title", "display_name")
DEFAULT_ALIASES = ("default", "default_value", "defaultValue")
OPTIONS_ALIASES = ("options", "choices", "values", "enum")

KNOWN_TYPES = {"select", "string", "text", "number", "integer", "float",
               "date", "datetime", "boolean", "bool", "multiselect"}

# Constraint keys a manifest may declare that this validator does not yet
# enforce. Listed so their presence is reported instead of ignored.
CONSTRAINT_KEYS = ("min", "max", "minimum", "maximum", "pattern", "regex",
                   "minLength", "maxLength", "min_length", "max_length",
                   "step", "multiple_of", "format")


def _first(mapping, aliases, fallback=None):
    for a in aliases:
        if isinstance(mapping, dict) and a in mapping and mapping[a] is not None:
            return mapping[a]
    return fallback


@dataclass
class Option:
    value: Any
    label: Optional[str] = None

    @property
    def label_text(self):
        return self.label if self.label is not None else str(self.value)


@dataclass
class ParameterSpec:
    id: str
    type: str = "string"
    label: Optional[str] = None
    description: Optional[str] = None
    required: bool = False
    default: Any = None
    options: list = field(default_factory=list)
    allow_custom: bool = False
    allow_custom_declared: bool = False
    unchecked_constraints: list = field(default_factory=list)
    raw: dict = field(default_factory=dict)

    @property
    def is_select(self):
        return self.type in ("select", "multiselect")

    def option_values(self):
        return [o.value for o in self.options]

    def option_by_value(self, value):
        for o in self.options:
            if o.value == value:
                return o
        return None

    def options_by_label(self, label):
        return [o for o in self.options if o.label_text == label]

    def option_by_value_ci(self, value):
        """Case-insensitive / whitespace-tolerant value match."""
        if not isinstance(value, str):
            return None
        key = value.strip().casefold()
        for o in self.options:
            if isinstance(o.value, str) and o.value.strip().casefold() == key:
                return o
        return None


@dataclass
class Manifest:
    path: str
    title: Optional[str]
    parameters: list
    raw: dict

    def by_id(self, pid):
        for p in self.parameters:
            if p.id == pid:
                return p
        return None

    def ids(self):
        return [p.id for p in self.parameters]


class ManifestError(ValueError):
    pass


def _coerce_option(raw):
    if isinstance(raw, dict):
        value = _first(raw, ("value", "id", "key"), None)
        label = _first(raw, ("label", "name", "title", "display"), None)
        if value is None and label is not None:
            value = label
        return Option(value=value, label=label)
    return Option(value=raw, label=None)


def parse_parameter(raw, index):
    if not isinstance(raw, dict):
        raise ManifestError(
            f"parameters[{index}] is {type(raw).__name__}, expected a mapping")
    pid = _first(raw, ID_ALIASES)
    if pid is None:
        raise ManifestError(
            f"parameters[{index}] has no id (looked for {', '.join(ID_ALIASES)})")
    ptype = str(_first(raw, TYPE_ALIASES, "string")).strip().lower()
    opts_raw = _first(raw, OPTIONS_ALIASES, []) or []
    if not isinstance(opts_raw, list):
        raise ManifestError(f"parameter {pid!r}: options must be a list")
    options = [_coerce_option(o) for o in opts_raw]

    allow_declared = any(a in raw for a in ALLOW_CUSTOM_ALIASES)
    allow_custom = bool(_first(raw, ALLOW_CUSTOM_ALIASES, False))
    if not allow_declared and options:
        # A closed list is the safe default: see module docstring.
        allow_custom = False

    # Constraints this validator does not model. Recorded so an unchecked
    # rule is visible rather than silently ignored.
    unchecked = [k for k in CONSTRAINT_KEYS if k in raw and raw[k] is not None]

    return ParameterSpec(
        id=str(pid),
        type=ptype,
        unchecked_constraints=unchecked,
        label=_first(raw, LABEL_ALIASES),
        description=_first(raw, ("description", "help", "hint")),
        required=bool(_first(raw, REQUIRED_ALIASES, False)),
        default=_first(raw, DEFAULT_ALIASES),
        options=options,
        allow_custom=allow_custom,
        allow_custom_declared=allow_declared,
        raw=raw,
    )


def load(path):
    try:
        doc = miniyaml.load_file(path)
    except miniyaml.YamlError as exc:
        raise ManifestError(f"{path}: {exc}") from exc
    except OSError as exc:
        raise ManifestError(f"cannot read {path}: {exc}") from exc
    if not isinstance(doc, dict):
        raise ManifestError(f"{path}: top level is not a mapping")
    params_raw = doc.get("parameters")
    if params_raw is None:
        raise ManifestError(
            f"{path}: no 'parameters:' section. Nothing can be validated, "
            f"which is not the same as everything being valid.")
    if not isinstance(params_raw, list):
        raise ManifestError(f"{path}: 'parameters' is not a list")
    params = [parse_parameter(p, i) for i, p in enumerate(params_raw)]
    seen = set()
    for p in params:
        if p.id in seen:
            raise ManifestError(f"{path}: duplicate parameter id {p.id!r}")
        seen.add(p.id)
    return Manifest(path=path, title=doc.get("title"), parameters=params,
                    raw=doc)
