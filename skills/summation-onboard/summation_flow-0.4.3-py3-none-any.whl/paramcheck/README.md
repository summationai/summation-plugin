# paramcheck — client-side parameter validator (SPEC stage 10.5)

Validates playbook parameters **before** they are sent. Mandatory because the
platform validates nothing: `LEDGER.md` R-025 proved live that a bogus value,
a label sent in place of its value, and an omitted required parameter are all
**accepted**, each creating a real schedule that runs and produces a wrong or
empty report with no error at any layer.

Standard library only. No PyYAML — the manifest is read by a hand-rolled YAML
subset parser (`miniyaml.py`), which the test suite cross-checks against
PyYAML as an oracle.

**This tool makes no network calls and creates nothing.** It reads a manifest
and a JSON object and prints a verdict.

*Last updated: 2026-08-05. Every number and transcript below is real output.*

---

## Run it

```bash
python3 -m paramcheck.validate \
  --manifest tests/paramcheck/fixtures/recap-manifest.yaml \
  --params-json '{"planner_nm":"TARLOWE","area_of_business":"Hype"}'
```

```
REJECT  [label_used_as_value] planner_nm
          'TARLOWE' is the label of option 'HWENDEL' — send the value, not the label.

errors 1  warnings 1  info 1
VERDICT  : DO NOT SEND
```

| flag | |
|---|---|
| `--manifest / -m` | playbook `manifest.yaml` |
| `--params / -p` | JSON file of parameters (`-` for stdin) |
| `--params-json` | inline JSON string |
| `--json` | machine-readable result on stdout |
| `--out PATH` | also write the JSON result to a file |
| `--apply-defaults` | fill a missing required parameter from the manifest default and downgrade to a warning, instead of rejecting |

**Exit codes:** `0` no errors · `1` one or more rejections, do not send ·
`2` usage error, unreadable manifest, or unparseable params.

---

## The four cases the platform accepted

R-025's live test, replayed through this validator. All four created real
schedules on the platform; three should never have been accepted.

| Sent | Platform | paramcheck |
|---|---|---|
| `planner_nm: DVANLEER` | ACCEPTED | **exit 0** — safe to send |
| `planner_nm: TYPO_NOT_AN_OPTION` | ACCEPTED | **exit 1** `not_an_option` |
| `planner_nm: TARLOWE` (label of `HWENDEL`) | ACCEPTED | **exit 1** `label_used_as_value` |
| required parameter omitted | ACCEPTED | **exit 1** `missing_required` ×2 |

Each is a test in `tests/test_platform_accepted_cases.py`.

### The label-for-value substitution gets its own diagnosis

This is the realistic failure. An agent reads the manifest and sends the
human-readable label, which is exactly what a human would type — and the
recap manifest deliberately carries `value ≠ label` pairs.

```
'TARLOWE' is the label of option 'HWENDEL' — send the value, not the label.
'BREYNE'  is the label of option 'AMONTELLIO' — send the value, not the label.
```

It is reported as `label_used_as_value`, **not** as a generic unknown value,
and carries `send_instead` so a caller can correct itself without re-reading
the manifest. A test asserts the generic `not_an_option` code is *not* also
emitted, because "that is not a valid option" would send the caller looking
for a typo it does not have.

It fires on the area parameter too, where every one of the 14 labels differs
from its value:

```
'RQUINTAL — NHL ADULT Apparel, Jerseys, & Headwear' is the label of option
'NHL ADULT Apparel, Jerseys, & Headwear' — send the value, not the label.
```

### A default does not excuse an omission

`planner_nm` is required *and* declares `default: DVANLEER`. Omitting it is
still a rejection, because relying on an unvalidating platform to apply a
default is the failure mode itself:

```
required parameter 'planner_nm' (Planner) is omitted entirely. The manifest
declares a default of 'DVANLEER' — send it explicitly rather than relying on
the platform to apply it, which it does not do reliably.
```

`--apply-defaults` opts into filling it, downgraded to a warning. Never
silent.

---

## The camelCase hazard (R-024)

`config.params` keys are camelCased in transit, so `planner_nm` arrives as
`plannerNm` — a key the playbook does not declare. Two distinct things follow,
and conflating them would make the tool wrong in opposite directions:

**1. Declared keys that will not survive — a warning, not a rejection.** The
payload is correct as written; the platform breaks it downstream.

```
2 parameter key(s) will not survive transit as declared:
  planner_nm -> plannerNm, area_of_business -> areaOfBusiness.
Read the created object back and assert the keys before trusting the run.
```

Also emitted structurally as `result.transport.camel_case_hazard`.

**2. A caller that pre-camelCases — a rejection.** Compensating for the bug
client-side drops the real key:

```
'plannerNm' is not declared. It is the camelCase form of 'planner_nm' —
send the manifest's own id, 'planner_nm'. (The platform camelCases keys in
transit; that is its bug to undo, not something to pre-apply.)
```

Without that distinction an agent reading R-024 would "fix" the problem by
sending `plannerNm`, and land in the same silent failure by another route.

---

## Everything it checks

| code | severity | what |
|---|---|---|
| `missing_required` | error | required parameter omitted or blank |
| `not_an_option` | error | value outside a closed `select` list, with a near-miss suggestion |
| `label_used_as_value` | error | the label was sent instead of the value |
| `option_case_mismatch` | error | differs from a declared option only by case or whitespace |
| `type_mismatch` | error | fails the declared `string` / `number` / `integer` / `date` / `boolean` type |
| `undeclared_parameter` | error / warning | error when it is the camelCase form of a declared id, warning otherwise |
| `params_not_an_object` | error | params is not a JSON object |
| `key_transform_hazard` | warning | declared keys that will be mutated in transit |
| `cross_parameter_inconsistent` | warning | valid values that name different owners |
| `empty_value` | warning | optional parameter present but blank |
| `default_applied` | warning | `--apply-defaults` filled a required parameter |
| `constraint_not_checked` | warning | manifest declares `min`/`max`/`pattern` etc. that this validator does not enforce |
| `option_list_assumed_closed` | info | option list present, `allowCustom` unstated |

### Cross-parameter consistency — the failure every per-field rule misses

`planner_nm: RQUINTAL` and `area_of_business: SOCCER` are both perfectly
valid values. Together they are wrong, and the run would produce a report for
a pairing the manifest never makes:

```
'area_of_business' = 'SOCCER' is labelled 'BRENO — SOCCER', which belongs to
planner_nm = 'BRENO'. But planner_nm was sent as 'RQUINTAL'. These two are
inconsistent.
```

This is read off a convention in the manifest — area labels are prefixed with
the owning planner — rather than a declared constraint, so it **warns** and
never rejects.

The check resolves value → label before comparing, which matters precisely
where the traps are: `HWENDEL`'s label is `TARLOWE`, and its area is labelled
`"TARLOWE — MLB ADULT…"`. Comparing raw values would flag that correct pairing
as an error. Two tests pin the clean cases (`HWENDEL`/MLB and
`AMONTELLIO`/COLLEGE) so the trap cannot become a false positive.

---

## `allowCustom` is assumed, and says so

The real manifest **never states `allowCustom`** — R-025 describes the
parameter as `allowCustom: false`, but that is not in the file. A `select`
with an option list and no `allowCustom` is therefore treated as **closed**,
which is the only safe reading: an option list means nothing if undeclared
values are admissible.

The assumption is never silent. `ParameterSpec.allow_custom_declared` records
that the manifest did not say so, every `not_an_option` message appends *"(The
manifest does not state allowCustom; an option list is treated as closed.)"*,
and an `option_list_assumed_closed` info finding names the affected
parameters. When a manifest does set `allowCustom: true`, an undeclared value
passes with a warning.

---

## The YAML parser

`paramcheck` may not take a third-party dependency, so `miniyaml.py` reads the
subset a manifest needs: block mappings and sequences, folded (`>`) and
literal (`|`) scalars, quoted and plain scalars, comments, and scalar typing.

It **raises rather than guesses** on anchors, aliases, flow collections,
tags, tab indentation and duplicate keys. A manifest half-parsed into a
missing option list would make this tool approve a value it should reject, so
failing loudly is the only safe behaviour.

Honesty check: `tests/test_miniyaml.py` parses the real manifest with both
miniyaml and PyYAML and asserts the results are identical, skipping if PyYAML
is absent. One deliberate difference — PyYAML resolves a bare `2026-03-25`
into `datetime.date`; miniyaml keeps the verbatim string, because manifest
values are identifiers to be sent unchanged. The oracle test normalises dates
before comparing and the divergence is documented here rather than hidden.

---

## Tests

```bash
python3 -m pytest tests/paramcheck -q
```

```
.................................................................        [100%]
65 passed in 0.10s
```

Covering: all four R-025 cases; both `value ≠ label` traps
(`HWENDEL`/`TARLOWE`, `AMONTELLIO`/`BREYNE`) plus the area-label variant; 13
parametrised type cases; the camelCase hazard in both directions; correct
pairings through the label traps not warning; `allowCustom` declared and
assumed; all three `required` alias spellings; every CLI exit code; and the
parser oracle.

Two parser bugs were found by these tests and fixed: value-position anchors
(`key: &a 1`) were not rejected, and tab indentation was silently accepted
because the indent width was measured with `lstrip(" ")`.

---

## Design notes

**A payload is never offered for parameters that were rejected.**
`normalised_params` is `null` whenever there is an error, so a caller cannot
half-read the result and send something that failed validation.

**Warnings never block.** A stray undeclared key, an inconsistent pairing and
the transport hazard are all real signals, but none makes the payload
malformed, so they leave exit 0. Only rejections stop a send.

**Unknown declared types are accepted, not pretended to be checked.** If a
manifest declares a type this tool does not model, the value passes and the
type name is echoed rather than a check being claimed.

---

## Not done

* **No platform calls of any kind** — no schedules created, nothing sent.
  Pure local validation, as briefed.
* **`multiselect` is typed but not list-validated.** It is accepted as a
  select and its single value is checked against the option list; an array of
  values is not yet split and checked element by element. The real manifest
  has no multiselect, so this is untested against a live example and should
  not be trusted until it is.
* **No `min` / `max` / `pattern` enforcement** — but no longer silent. A
  manifest declaring one gets a `constraint_not_checked` warning naming it
  and stating the value was **not** checked against it, so "no errors" can
  never be misread as "everything was verified". The real manifest declares
  none; a test asserts that, and another proves the warning fires on a
  synthetic manifest that does.
