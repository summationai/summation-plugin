"""CLI: ``python -m paramcheck.validate --manifest <m.yaml> --params <p.json>``

Exit codes
    0  no errors (warnings may still be present)
    1  one or more rejections — do not send these parameters
    2  usage error, unreadable manifest, or unparseable params
"""

from __future__ import annotations

import argparse
import json
import sys

from .engine import validate
from .manifest import ManifestError, load

SEVERITY_MARK = {"error": "REJECT ", "warning": "warn   ", "info": "note   "}


def _load_params(path, inline):
    if inline is not None:
        text = inline
        where = "--params-json"
    elif path == "-":
        text = sys.stdin.read()
        where = "stdin"
    else:
        with open(path, encoding="utf-8") as fh:
            text = fh.read()
        where = path
    try:
        return json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{where}: not valid JSON: {exc}") from exc


def render_human(result):
    out = []
    m = result["manifest"]
    out.append(f"manifest : {m['path']}")
    if m.get("title"):
        out.append(f"playbook : {m['title']}")
    out.append(f"declared : {', '.join(m['parameters_declared']) or '(none)'}")
    out.append(f"required : {', '.join(m['required']) or '(none)'}")
    out.append("")
    rows = result["errors"] + result["warnings"] + result["info"]
    if not rows:
        out.append("no findings")
    for f in rows:
        who = f.get("parameter") or "-"
        out.append(f"{SEVERITY_MARK[f['severity']]} [{f['code']}] {who}")
        out.append(f"          {f['message']}")
    out.append("")
    c = result["counts"]
    out.append(f"errors {c['errors']}  warnings {c['warnings']}  "
               f"info {c['info']}")
    if result["ok"]:
        out.append("VERDICT  : safe to send")
        out.append("payload  : " + json.dumps(result["normalised_params"],
                                              ensure_ascii=False))
    else:
        out.append("VERDICT  : DO NOT SEND")
    return "\n".join(out)


def main(argv=None):
    ap = argparse.ArgumentParser(
        prog="paramcheck.validate",
        description="Validate playbook parameters before sending them. "
                    "The platform validates nothing (LEDGER R-025), so this "
                    "runs client-side.")
    ap.add_argument("--manifest", "-m", required=True,
                    help="playbook manifest.yaml")
    group = ap.add_mutually_exclusive_group(required=True)
    group.add_argument("--params", "-p",
                       help="JSON file of parameters ('-' for stdin)")
    group.add_argument("--params-json", help="inline JSON string")
    ap.add_argument("--json", action="store_true",
                    help="machine-readable output")
    ap.add_argument("--out", help="write the JSON result here as well")
    ap.add_argument("--apply-defaults", action="store_true",
                    help="fill a missing required parameter from the "
                         "manifest default and downgrade to a warning, "
                         "instead of rejecting")
    args = ap.parse_args(argv)

    try:
        man = load(args.manifest)
    except ManifestError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    try:
        params = _load_params(args.params, args.params_json)
    except (OSError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    result = validate(man, params, apply_defaults=args.apply_defaults)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(result, fh, indent=2, ensure_ascii=False)
            fh.write("\n")

    if args.json:
        json.dump(result, sys.stdout, indent=2, ensure_ascii=False)
        print()
    else:
        print(render_human(result))

    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
