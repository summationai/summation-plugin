"""Validate a claim ledger: schema first, then the invariants schema cannot express.

Two passes, deliberately separate.

**Schema** answers "is this the right shape". Its errors are reported with the
offending field named, not as a wall of jsonschema prose, because the caller is
often an agent that has just written the ledger and needs to know which key to
fix.

**Consistency** answers "does it contradict itself". These are the checks a
JSON Schema cannot carry: equality between a count and an array length,
uniqueness of an id, a reference that has to resolve, arithmetic that has to
foot. They are reported as findings, never raised — a ledger with a dangling
reference is a ledger with a defect in it, and the point of this module is to
say so precisely rather than to die.

Severity, and why:

* ``error``   the pipeline would produce wrong output, or silently drop data.
* ``warning`` a real risk that a human should see, but the pipeline can run.
* ``info``    provenance and coverage notes.
"""

from __future__ import annotations

import json
import os
from typing import Any, Optional

from sf_findings import ERROR, INFO, WARNING, Finding, FindingSet

#: The published contract, resolved from inside the package rather than from a
#: sibling directory of the source tree. It has to survive installation: an agent
#: is told to write a ledger against this file and is given the path, so the path
#: must exist on the machine it is given on. `coldverify` and `extractor` each
#: resolve their own schema this way, for the same reason.
SCHEMA_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "schemas",
    "ledger.schema.json",
)

# Units whose values may legitimately be summed down a table column. Summing a
# margin percentage or a weeks-of-supply ratio down a column is meaningless, so
# the footing check must not attempt it.
_ADDITIVE_UNITS = {"currency", "units", "count"}


def load_schema(path: str = SCHEMA_PATH) -> dict:
    with open(path) as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# schema pass
# ---------------------------------------------------------------------------

def _pointer(path_parts) -> str:
    out = ""
    for p in path_parts:
        out += f"/{p}"
    return out or "/"


def _named_field(err) -> Optional[str]:
    """The specific field an error is about, when one can be named."""
    if err.validator == "required":
        # "'claims' is a required property"
        msg = err.message
        if "'" in msg:
            return msg.split("'")[1]
        return None
    if err.validator == "additionalProperties":
        # "Additional properties are not allowed ('foo', 'bar' were unexpected)"
        import re

        return ", ".join(re.findall(r"'([^']+)'", err.message)) or None
    if err.path:
        last = list(err.path)[-1]
        return last if isinstance(last, str) else None
    return None


def validate_schema_only(ledger: Any, schema: Optional[dict] = None) -> FindingSet:
    """Schema conformance, with the offending field named in every finding."""
    fs = FindingSet()
    try:
        from jsonschema import Draft202012Validator
    except ImportError:  # pragma: no cover - environment guard
        fs.add(Finding(
            code="LDG000", severity=ERROR,
            message="jsonschema is not installed, so the ledger contract cannot be enforced.",
        ))
        return fs

    if not isinstance(ledger, dict):
        fs.add(Finding(
            code="LDG001", severity=ERROR, pointer="/",
            message=f"the ledger must be a JSON object, got {type(ledger).__name__}.",
        ))
        return fs

    schema = schema if schema is not None else load_schema()
    validator = Draft202012Validator(schema)
    for err in sorted(validator.iter_errors(ledger), key=lambda e: list(e.path)):
        pointer = _pointer(list(err.path))
        field = _named_field(err)
        where = f"field `{field}`" if field else f"`{pointer}`"
        fs.add(Finding(
            code="LDG001",
            severity=ERROR,
            message=f"{where} at `{pointer}` does not match the ledger contract: {err.message}",
            pointer=pointer,
            detail={
                "field": field,
                "validator": err.validator,
                "schema_path": "/".join(str(p) for p in err.schema_path),
            },
        ))
    return fs


# ---------------------------------------------------------------------------
# consistency pass
# ---------------------------------------------------------------------------

def _claims(ledger) -> list:
    c = ledger.get("claims")
    return c if isinstance(c, list) else []


def _tables(ledger) -> list:
    t = ledger.get("tables")
    return t if isinstance(t, list) else []


def _blocks(ledger) -> list:
    b = ledger.get("prose_blocks")
    return b if isinstance(b, list) else []


def _cid(claim, idx) -> str:
    v = claim.get("claim_id") if isinstance(claim, dict) else None
    return v if isinstance(v, str) else f"<claims[{idx}]>"


def _envelope(claim) -> float:
    v = claim.get("rounding_envelope")
    return float(v) if isinstance(v, (int, float)) else 0.0


def check_consistency(ledger: Any) -> FindingSet:
    """Cross-record invariants. Survives a ledger that failed the schema pass."""
    fs = FindingSet()
    if not isinstance(ledger, dict):
        return fs

    claims = _claims(ledger)
    tables = _tables(ledger)
    blocks = _blocks(ledger)
    report = ledger.get("extraction_report") if isinstance(ledger.get("extraction_report"), dict) else {}

    by_id: dict[str, dict] = {}
    seen: dict[str, int] = {}

    # -- LDG002 duplicate claim ids -----------------------------------------
    for i, c in enumerate(claims):
        if not isinstance(c, dict):
            continue
        cid = c.get("claim_id")
        if not isinstance(cid, str):
            continue
        if cid in seen:
            fs.add(Finding(
                code="LDG002", severity=ERROR, pointer=f"/claims/{i}/claim_id",
                message=(f"claim id `{cid}` is used twice (claims[{seen[cid]}] and "
                         f"claims[{i}]); findings that cite it are ambiguous."),
                detail={"claim_id": cid, "first_index": seen[cid], "duplicate_index": i},
            ))
        else:
            seen[cid] = i
            by_id[cid] = c

    known_ids = set(by_id)
    table_ids = {t.get("table_id") for t in tables if isinstance(t, dict)}
    tables_by_id = {t.get("table_id"): t for t in tables if isinstance(t, dict)}

    # -- LDG003 positions referencing a table that does not exist -----------
    for i, c in enumerate(claims):
        if not isinstance(c, dict):
            continue
        loc = c.get("location")
        if not isinstance(loc, dict):
            continue
        tid = loc.get("table_id")
        if tid and tid not in table_ids:
            fs.add(Finding(
                code="LDG003", severity=ERROR, pointer=f"/claims/{i}/location/table_id",
                message=(f"claim `{_cid(c, i)}` is positioned in table `{tid}`, which is not "
                         f"in the ledger's tables list; its row and column labels cannot be resolved."),
                detail={"claim_id": _cid(c, i), "table_id": tid,
                        "known_tables": sorted(x for x in table_ids if x)},
            ))

    # -- LDG004 dangling claim references -----------------------------------
    def _ref_check(holder_idx, holder_id, refs, pointer, kind):
        for ref in refs or []:
            if isinstance(ref, str) and ref not in known_ids:
                fs.add(Finding(
                    code="LDG004", severity=ERROR, pointer=pointer,
                    message=(f"{kind} on `{holder_id}` points at claim `{ref}`, "
                             f"which does not exist in this ledger."),
                    detail={"holder": holder_id, "missing_claim_id": ref, "relation": kind},
                ))

    for i, c in enumerate(claims):
        if not isinstance(c, dict):
            continue
        cid = _cid(c, i)
        _ref_check(i, cid, c.get("aggregates_claims"),
                   f"/claims/{i}/aggregates_claims", "aggregates_claims")
        df = c.get("derived_from")
        if isinstance(df, dict):
            _ref_check(i, cid, df.get("operands"),
                       f"/claims/{i}/derived_from/operands", "derived_from.operands")
            _ref_check(i, cid, df.get("weights"),
                       f"/claims/{i}/derived_from/weights", "derived_from.weights")
            # -- LDG005 a claim derived from itself ------------------------
            if isinstance(df.get("operands"), list) and cid in df["operands"]:
                fs.add(Finding(
                    code="LDG005", severity=ERROR, pointer=f"/claims/{i}/derived_from/operands",
                    message=(f"claim `{cid}` lists itself as an operand of its own "
                             f"derivation; the relation cannot be evaluated."),
                    detail={"claim_id": cid},
                ))
        comp = c.get("comparison")
        if isinstance(comp, dict) and comp.get("base_claim_id"):
            _ref_check(i, cid, [comp["base_claim_id"]],
                       f"/claims/{i}/comparison/base_claim_id", "comparison.base_claim_id")

    for i, b in enumerate(blocks):
        if not isinstance(b, dict):
            continue
        _ref_check(i, b.get("block_id", f"<prose_blocks[{i}]>"), b.get("claim_ids"),
                   f"/prose_blocks/{i}/claim_ids", "prose_blocks.claim_ids")

    # -- LDG006 extraction_report counts vs actual array lengths ------------
    for key, actual, label in (
        ("claims_found", len(claims), "claims"),
        ("tables_found", len(tables), "tables"),
        ("prose_blocks_found", len(blocks), "prose_blocks"),
    ):
        stated = report.get(key)
        if isinstance(stated, int) and stated != actual:
            fs.add(Finding(
                code="LDG006", severity=ERROR, pointer=f"/extraction_report/{key}",
                message=(f"extraction_report.{key} says {stated} but the ledger carries "
                         f"{actual} {label}; the report is what a person is shown."),
                detail={"field": key, "stated": stated, "actual": actual},
            ))

    # -- LDG007 derived counters vs what the claims actually say ------------
    # Warnings, not errors: these are parser bookkeeping and a model-extracted
    # ledger may reasonably not track them cell by cell.
    for key, pred, label in (
        ("unit_unknown", lambda c: c.get("unit") == "unknown", "claims with unit unknown"),
        ("precision_indeterminable", lambda c: c.get("displayed_precision") is None,
         "claims with indeterminable precision"),
        ("scale_inferred", lambda c: c.get("scale_source") == "inferred_from_magnitude",
         "claims with an inferred scale"),
    ):
        stated = report.get(key)
        if isinstance(stated, int):
            actual = sum(1 for c in claims if isinstance(c, dict) and pred(c))
            if stated != actual:
                fs.add(Finding(
                    code="LDG007", severity=WARNING, pointer=f"/extraction_report/{key}",
                    message=(f"extraction_report.{key} says {stated} but {actual} "
                             f"{label} are present."),
                    detail={"field": key, "stated": stated, "actual": actual},
                ))

    # -- LDG008 / LDG009 footing --------------------------------------------
    fs.extend(_check_footing(claims, by_id, tables_by_id))

    # -- LDG010 row/column position outside the table it names --------------
    for i, c in enumerate(claims):
        if not isinstance(c, dict):
            continue
        loc = c.get("location")
        if not isinstance(loc, dict):
            continue
        t = tables_by_id.get(loc.get("table_id"))
        if not isinstance(t, dict):
            continue
        rc, ci = t.get("row_count"), loc.get("column_index")
        ri = loc.get("row_index")
        cols = t.get("column_labels")
        if isinstance(rc, int) and isinstance(ri, int) and ri >= rc:
            fs.add(Finding(
                code="LDG010", severity=WARNING, pointer=f"/claims/{i}/location/row_index",
                message=(f"claim `{_cid(c, i)}` sits at row {ri} of table "
                         f"`{t.get('table_id')}`, which declares only {rc} rows."),
                detail={"claim_id": _cid(c, i), "row_index": ri, "row_count": rc},
            ))
        if isinstance(cols, list) and isinstance(ci, int) and ci >= len(cols):
            fs.add(Finding(
                code="LDG010", severity=WARNING, pointer=f"/claims/{i}/location/column_index",
                message=(f"claim `{_cid(c, i)}` sits at column {ci} of table "
                         f"`{t.get('table_id')}`, which declares only {len(cols)} columns."),
                detail={"claim_id": _cid(c, i), "column_index": ci, "column_count": len(cols)},
            ))

    # -- LDG011 currency without an explicit denomination -------------------
    # The schema defaults denomination to `major` and coldverify reads the
    # absent field as `major`, so a sub-unit figure is silently read as whole
    # currency. The extractor never writes the field, so this fires on every
    # real ledger today. Reported once, aggregated, so it informs without
    # drowning the output.
    missing = [(_cid(c, i), i) for i, c in enumerate(claims)
               if isinstance(c, dict) and c.get("unit") == "currency"
               and not c.get("denomination")]
    if missing:
        fs.add(Finding(
            code="LDG011", severity=WARNING, pointer="/claims",
            message=(f"{len(missing)} currency claim(s) carry no explicit `denomination`; "
                     f"consumers read an absent value as `major`, so a sub-unit figure "
                     f"(e.g. \"34 cents\" parsed as 34.0) is read as whole currency and is "
                     f"wrong by 100x with no symptom."),
            detail={"count": len(missing), "first_examples": [m[0] for m in missing[:5]]},
        ))

    # -- LDG012 provenance ---------------------------------------------------
    method = ledger.get("extraction_method")
    if not method:
        fs.add(Finding(
            code="LDG012", severity=INFO, pointer="/extraction_method",
            message=("the ledger does not say whether it was produced by a parser or by a "
                     "model; downstream findings cannot carry the model-extraction caveat."),
        ))
    elif method in ("model", "hybrid"):
        fs.add(Finding(
            code="LDG012", severity=INFO, pointer="/extraction_method",
            message=(f"extraction was `{method}`: every finding built on this ledger inherits "
                     f"the caveat that a wrong extraction can produce a wrong finding."),
            detail={"extraction_method": method},
        ))

    # -- LDG013 coverage -----------------------------------------------------
    if claims and report.get("checkable_fraction", "missing") is None:
        fs.add(Finding(
            code="LDG013", severity=WARNING, pointer="/extraction_report/checkable_fraction",
            message=(f"checkable_fraction is null while {len(claims)} claims are present; "
                     f"the person cannot be told how much of their document was checked."),
        ))

    return fs


def _check_footing(claims, by_id, tables_by_id) -> FindingSet:
    """Totals against their components, two ways.

    **Both are warnings, and that is a correction to an earlier judgement here.**
    They were errors, on the reasoning that a declared arithmetic relation which
    does not hold is unambiguous. It is unambiguous about the arithmetic and
    silent about the cause: a total that does not foot is either a reader who
    miscopied a component, or a document that does not add up. Those are not
    distinguishable from inside the ledger, and the second one is *the product* —
    the clean-room document's team subtotal is out by $10,001 on purpose, and
    cold verify's arithmetic family exists to find exactly that and tier it.

    Failing intake on it made a faithful reading of that document unusable, and
    left an agent one escape: drop ``aggregates_claims``, or move a number. A
    gate whose only exit is to falsify the record is worse than no gate. So the
    finding stays, says which of the two it might be, and lets the stage whose
    job this is adjudicate it.

    ``LDG008`` uses the ledger's own declared composition (``aggregates_claims``
    or a ``derived_from`` sum).

    ``LDG009`` is structural: within one table column, a ``total`` or
    ``subtotal`` cell against the ``component`` cells of the same column. This
    catches the common case — no real ledger produced so far links its totals,
    because the demo document has no total rows at all — but it can only be
    attempted on columns that are additive, fully parsed, and carry exactly one
    total. Anything ambiguous is skipped rather than guessed at.
    """
    fs = FindingSet()

    # -- declared composition ------------------------------------------------
    for i, c in enumerate(claims):
        if not isinstance(c, dict):
            continue
        parts = c.get("aggregates_claims")
        df = c.get("derived_from")
        if not parts and isinstance(df, dict) and df.get("operation") == "sum":
            parts = df.get("operands")
        if not parts or not isinstance(parts, list):
            continue
        total = c.get("value_parsed")
        if not isinstance(total, (int, float)):
            continue
        vals, ok = [], True
        for p in parts:
            comp = by_id.get(p)
            v = comp.get("value_parsed") if isinstance(comp, dict) else None
            if not isinstance(v, (int, float)):
                ok = False
                break
            vals.append((v, _envelope(comp)))
        if not ok or not vals:
            continue
        s = sum(v for v, _ in vals)
        tol = _envelope(c) + sum(e for _, e in vals) + 1e-9
        if abs(s - total) > tol:
            fs.add(Finding(
                code="LDG008", severity=WARNING, pointer=f"/claims/{i}",
                message=(f"claim `{_cid(c, i)}` is declared as the sum of {len(parts)} claims "
                         f"but they add to {s:g}, not {total:g} (difference {s - total:+g}, "
                         f"outside the combined rounding envelope of {tol:g}). Either a "
                         f"component was misread, or the document does not foot — check the "
                         f"components against the page before assuming which."),
                detail={"claim_id": _cid(c, i), "stated_total": total, "component_sum": s,
                        "difference": s - total, "tolerance": tol, "components": list(parts)},
            ))

    # -- structural, per table column ----------------------------------------
    columns: dict[tuple, dict] = {}
    for i, c in enumerate(claims):
        if not isinstance(c, dict):
            continue
        loc = c.get("location")
        if not isinstance(loc, dict) or not loc.get("table_id"):
            continue
        col = loc.get("column_index")
        if col is None:
            col = loc.get("column_label")
        if col is None:
            continue
        key = (loc["table_id"], col)
        bucket = columns.setdefault(key, {"totals": [], "components": [], "units": set()})
        role = c.get("role")
        if role in ("total", "subtotal"):
            bucket["totals"].append((i, c))
        elif role == "component":
            bucket["components"].append((i, c))
        bucket["units"].add(c.get("unit"))

    for (tid, col), bucket in sorted(columns.items(), key=lambda kv: (str(kv[0][0]), str(kv[0][1]))):
        totals, comps = bucket["totals"], bucket["components"]
        # One total, at least two components, one additive unit, everything
        # parsed. Any other shape is not safely footable and is left alone.
        if len(totals) != 1 or len(comps) < 2:
            continue
        units = {u for u in bucket["units"] if u is not None}
        if not units or not units <= _ADDITIVE_UNITS:
            continue
        ti, tclaim = totals[0]
        total = tclaim.get("value_parsed")
        if not isinstance(total, (int, float)):
            continue
        # A claim already checked by its own declared composition is not
        # re-checked structurally; one defect, one finding.
        if tclaim.get("aggregates_claims"):
            continue
        vals = [(c.get("value_parsed"), _envelope(c)) for _, c in comps]
        if any(not isinstance(v, (int, float)) for v, _ in vals):
            continue
        s = sum(v for v, _ in vals)
        tol = _envelope(tclaim) + sum(e for _, e in vals) + 1e-9
        if abs(s - total) > tol:
            fs.add(Finding(
                code="LDG009", severity=WARNING, pointer=f"/claims/{ti}",
                message=(f"in table `{tid}` column `{col}`, the {tclaim.get('role')} reads "
                         f"{total:g} but its {len(comps)} rows add to {s:g} "
                         f"(difference {s - total:+g}, outside the combined rounding "
                         f"envelope of {tol:g}). Either a row was misread, or the table does "
                         f"not foot — check the rows against the page before assuming which."),
                detail={"claim_id": _cid(tclaim, ti), "table_id": tid, "column": col,
                        "stated_total": total, "row_sum": s, "difference": s - total,
                        "tolerance": tol, "row_count": len(comps)},
            ))
    return fs


# ---------------------------------------------------------------------------
# entry points
# ---------------------------------------------------------------------------

def validate_ledger(ledger: Any, schema: Optional[dict] = None) -> FindingSet:
    """Schema pass then consistency pass, always both.

    The consistency pass still runs after schema failures: a ledger with an
    unknown extra key can still have a dangling reference, and reporting both
    in one go is the difference between one round trip and four.
    """
    fs = validate_schema_only(ledger, schema)
    fs.extend(check_consistency(ledger))
    return fs


def validate_file(path: str, schema: Optional[dict] = None) -> FindingSet:
    """Read and validate a ledger file. Unreadable input is a finding, not a crash."""
    fs = FindingSet()
    if not os.path.exists(path):
        fs.add(Finding(code="LDG000", severity=ERROR, file=path,
                       message=f"no ledger at `{path}`."))
        return fs
    try:
        with open(path) as fh:
            ledger = json.load(fh)
    except json.JSONDecodeError as e:
        fs.add(Finding(
            code="LDG000", severity=ERROR, file=path, line=e.lineno,
            message=f"the ledger is not valid JSON: {e.msg} at line {e.lineno}, column {e.colno}.",
            detail={"error": e.msg},
        ))
        return fs
    except OSError as e:  # pragma: no cover - environment guard
        fs.add(Finding(code="LDG000", severity=ERROR, file=path,
                       message=f"the ledger could not be read: {e}."))
        return fs

    for f in validate_ledger(ledger, schema):
        fs.add(Finding(code=f.code, severity=f.severity, message=f.message,
                       file=path, line=f.line, pointer=f.pointer, detail=f.detail))
    return fs
