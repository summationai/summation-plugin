"""``python -m sf_ledger <ledger.json> [--json] [--schema PATH]``

Exits non-zero on any error-severity finding.
"""

from __future__ import annotations

import argparse
import sys

from .validate import SCHEMA_PATH, load_schema, validate_file


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        prog="sf_ledger",
        description="Validate a claim ledger against the contract and its own internals.",
    )
    ap.add_argument("ledger", help="path to ledger.json")
    ap.add_argument("--schema", default=SCHEMA_PATH, help="override the schema path")
    ap.add_argument("--json", action="store_true", dest="as_json",
                    help="emit findings as JSON")
    args = ap.parse_args(argv)

    findings = validate_file(args.ledger, load_schema(args.schema))

    if args.as_json:
        print(findings.to_json())
    else:
        print(findings.render())
        print(f"\n{findings.summary()} — ledger {'ACCEPTED' if findings.ok else 'REJECTED'}")
    return findings.exit_code


if __name__ == "__main__":
    sys.exit(main())
