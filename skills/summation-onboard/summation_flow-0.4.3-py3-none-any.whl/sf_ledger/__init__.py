"""The ledger contract and its validator.

``sf_ledger`` owns one question: *is this ledger something the deterministic
pipeline can safely run on?* It answers in findings, never in exceptions.

    from sf_ledger import validate_file
    findings = validate_file("artifacts/ledger.json")
    if not findings.ok:
        print(findings.render())
"""

from .validate import (  # noqa: F401
    SCHEMA_PATH,
    load_schema,
    validate_ledger,
    validate_schema_only,
    check_consistency,
    validate_file,
)

__all__ = [
    "SCHEMA_PATH",
    "load_schema",
    "validate_ledger",
    "validate_schema_only",
    "check_consistency",
    "validate_file",
]
