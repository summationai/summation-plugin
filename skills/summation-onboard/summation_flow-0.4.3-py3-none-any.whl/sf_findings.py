"""Structured findings shared by ``sf_ledger`` and ``sf_lint``.

One vocabulary for both gates. A finding is a machine-addressable defect with a
stable ``code``, a ``severity`` that decides the exit status, and enough
location to point a person at the exact byte that is wrong.

Nothing here raises. Both gates are expected to survive malformed input and
*report* it; a traceback is a failure of the gate, not a finding about the
input.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from typing import Any, Iterable, Iterator, Optional

ERROR = "error"
WARNING = "warning"
INFO = "info"

_RANK = {ERROR: 3, WARNING: 2, INFO: 1}


@dataclass(frozen=True)
class Finding:
    """One defect.

    ``code``     stable identifier, e.g. ``LDG001`` or ``manifest.title``.
                 Tests assert on this, never on the message text.
    ``severity`` ``error`` fails the gate; ``warning`` and ``info`` do not.
    ``message``  one sentence, addressed to a person, naming the actual values.
    ``file``     path as given by the caller (relative to the bundle where
                 there is one), or ``None`` for whole-artifact findings.
    ``line``     1-based line number, or ``None`` when the defect has no line
                 (a missing file, a cross-record inconsistency).
    ``pointer``  JSON pointer or dotted field path into the artifact.
    ``detail``   free-form extras: expected/actual, the offending text.
    """

    code: str
    severity: str
    message: str
    file: Optional[str] = None
    line: Optional[int] = None
    pointer: Optional[str] = None
    detail: dict = field(default_factory=dict)

    @property
    def where(self) -> str:
        if self.file and self.line:
            return f"{self.file}:{self.line}"
        if self.file:
            return self.file
        return self.pointer or "<artifact>"

    def __str__(self) -> str:
        return f"[{self.severity.upper():7}] {self.code:<28} {self.where}: {self.message}"

    def to_dict(self) -> dict:
        return asdict(self)


class FindingSet:
    """An ordered collection of findings with an exit status."""

    def __init__(self, findings: Iterable[Finding] = ()) -> None:
        self._items: list[Finding] = list(findings)

    def add(self, *findings: Finding) -> "FindingSet":
        self._items.extend(findings)
        return self

    def extend(self, other: Iterable[Finding]) -> "FindingSet":
        self._items.extend(other)
        return self

    def __iter__(self) -> Iterator[Finding]:
        return iter(self._items)

    def __len__(self) -> int:
        return len(self._items)

    def __bool__(self) -> bool:
        # Truthiness follows "are there findings", not "did it pass".
        return bool(self._items)

    def of(self, severity: str) -> list[Finding]:
        return [f for f in self._items if f.severity == severity]

    def codes(self) -> list[str]:
        return [f.code for f in self._items]

    def has(self, code: str) -> bool:
        return any(f.code == code for f in self._items)

    @property
    def errors(self) -> list[Finding]:
        return self.of(ERROR)

    @property
    def ok(self) -> bool:
        """True when nothing fails the gate. Warnings and info do not fail."""
        return not self.errors

    @property
    def exit_code(self) -> int:
        return 1 if self.errors else 0

    def sorted(self) -> list[Finding]:
        """Worst first, then by file and line, so the top of the output matters."""
        return sorted(
            self._items,
            key=lambda f: (-_RANK.get(f.severity, 0), f.file or "", f.line or 0, f.code),
        )

    def render(self) -> str:
        if not self._items:
            return "no findings"
        return "\n".join(str(f) for f in self.sorted())

    def to_json(self, **kw: Any) -> str:
        return json.dumps([f.to_dict() for f in self.sorted()], indent=2, **kw)

    def summary(self) -> str:
        e, w, i = len(self.of(ERROR)), len(self.of(WARNING)), len(self.of(INFO))
        return f"{e} error(s), {w} warning(s), {i} note(s)"
