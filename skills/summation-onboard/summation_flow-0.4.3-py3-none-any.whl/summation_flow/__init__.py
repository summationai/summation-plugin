"""summation-flow — walk a hand-built artifact through Summation onboarding.

The package is self-contained: it imports no source tree, resolves its own data through
``importlib.resources``, and keeps every machine-specific answer in :mod:`summation_flow.settings`.
"""
from __future__ import annotations

__version__ = "0.4.3"
