"""App URL templates, derived from the web-app routes.

BUILD-SPEC §3 gives this a 45-minute time-box: a stub that prints the URL is acceptable,
a guessed URL that 404s in front of a human is not. Each template records how it was derived
so a reader can tell evidence from inference.

A cold replication test caught this module printing a URL on a host that does not exist
(`staging-app-fanatics.summation.com`, NXDOMAIN). Deriving the *path* from a real route is
only half the job — the host was assumed, never checked, and the whole point of these URLs is
that a human opens one to confirm something is real. So the host is now derived from the
profile's own API base URL and can be resolved before we call it evidence.
"""
import os
import socket
from urllib.parse import urlsplit

from . import settings

#: The app host is the API host with the `api-` segment removed. Verified by DNS on two tenants:
#: staging-api-fanatics → staging-fanatics, and api-fanatics → fanatics. The hosts this module
#: used to hard-code (`staging-app-fanatics`, `app-fanatics`) do not resolve at all —
#: substituting `api`→`app` produced names that were never registered.
#:
#: Derivation only works on a per-tenant host, because a shared one (staging-api.summation.com)
#: has no `api-` segment to remove. Shared hosts therefore need an explicit, proven mapping. The
#: ALG staging pair below was opened object-by-object with the customer on 2026-08-11; it is not
#: an inferred hostname. Unknown shared hosts still remain unknown rather than borrowing another
#: tenant's app.
SHARED_API_BASE = {
    "staging-api.summation.com": "https://staging-explore.summation.com",
}

FALLBACK_BASE = {"fanatics_staging": "https://staging-fanatics.summation.com",
                 "fanatics-prod":    "https://fanatics.summation.com"}

TEMPLATES = {
    # Confirmed against origin/main's file-based routes and opened successfully in the staging
    # app on 2026-08-11. Keep these exact: browser evidence is only useful when it lands on the
    # object named in the conversation.
    "playbook": ("/playbooks/playbook/{project_id}/{playbook_id}", "confirmed-live"),
    "project":  ("/projects/{project_id}", "confirmed-live"),
    "file":     ("/projects/{project_id}/files/{file_id}", "confirmed-live"),
    "report":   ("/projects/{project_id}/files/{file_id}", "confirmed-live"),
    # Sharing is a modal on the project page, not a route of its own. The caller must tell the
    # person to click Share rather than inventing a /settings/sharing URL.
    "sharing":  ("/projects/{project_id}", "confirmed-live; click Share"),
    # Schedule details are tenant-level. The project and originating chat stay in the query so
    # the shell opens the right workspace/chat alongside the selected schedule.
    "schedules": ("/schedules?scheduleId={schedule_id}&chat={chat_id}&project={project_id}",
                  "confirmed-live"),
}


def app_base(profile: str | None = None) -> str:
    """The app host for a profile, derived from that profile's API host.

    Deriving beats hard-coding here: the profile already knows which tenant and environment
    it points at, so a new tenant works without editing this file, and a renamed host cannot
    leave a stale constant behind. Returns "" when the answer is genuinely unknown.
    """
    profile = settings.resolve_profile(profile)
    override = os.environ.get("SF_APP_URL")
    if override:
        return override.rstrip("/")
    try:
        from .platform import base_url_for            # local import: keeps urls.py importable alone
        api = base_url_for(profile)
    except Exception:
        api = None
    if api:
        host = urlsplit(api).hostname or ""
        if host in SHARED_API_BASE:
            return SHARED_API_BASE[host]
        # `staging-api-fanatics` → `staging-fanatics`;  `api-fanatics` → `fanatics`
        app = host.replace("api-", "", 1) if "api-" in host else host
        if app and app != host:
            return f"https://{app}"
    return FALLBACK_BASE.get(profile, "")


def _base_is_explicitly_trusted(base: str) -> bool:
    """Whether DNS is allowed to be unavailable without suppressing the browser handoff.

    Cold-room hosts can reach the Summation API while their sandboxed Python process cannot do a
    raw DNS lookup. An explicit operator-provided URL and the app origins already opened in the
    route-proof exercise are stronger evidence than that unavailable preflight.
    """
    return bool(os.environ.get("SF_APP_URL")) or base in {
        *SHARED_API_BASE.values(), *FALLBACK_BASE.values(),
    }


def host_resolves(u: str) -> bool:
    """Does this URL's host exist in DNS?

    Cheap, and it is the exact check that would have caught the NXDOMAIN host before it was
    printed to a human as the one externally verifiable artifact in the flow.
    """
    host = urlsplit(u).hostname
    if not host:
        return False
    try:
        socket.getaddrinfo(host, 443)
        return True
    except socket.gaierror:
        return False


def url(kind: str, profile: str | None = None, **kw) -> tuple[str, str]:
    if kind not in TEMPLATES:
        raise SystemExit(f"unknown object kind '{kind}' — known: {sorted(TEMPLATES)}")
    profile = settings.resolve_profile(profile)
    path, provenance = TEMPLATES[kind]
    base = app_base(profile)
    try:
        suffix = path.format(**kw)
    except KeyError as e:
        raise SystemExit(f"{kind} url needs {e}")
    if not base:
        # Say "I do not know" rather than print a link on somebody else's tenant. The provenance
        # is deliberately not `derived-from-route`, so `open` prints instead of launching it.
        return (f"<app host unknown for profile '{profile}'>{suffix}",
                "app host unknown — set SF_APP_URL to the tenant's App URL")
    u = base + suffix
    if not _base_is_explicitly_trusted(base) and not host_resolves(u):
        # Say so rather than presenting an unreachable link as evidence.
        return u, f"{provenance}, HOST DOES NOT RESOLVE"
    return u, provenance
