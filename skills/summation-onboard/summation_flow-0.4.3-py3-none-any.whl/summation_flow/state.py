"""Run state. One directory per run; every stage writes an artifact and a status.

The files are deliberately boring JSON, but they are also the boundary that lets a new agent
session resume without conversation memory.  Keep writes atomic and keep old state readable.
"""
from __future__ import annotations
import json, hashlib, os, subprocess, time
from dataclasses import dataclass, field, asdict
from pathlib import Path

from . import settings

#: A per-user data directory, not the source tree. `SF_ROOT` still overrides, so a test room can
#: point the whole tool at somewhere disposable.
ROOT = settings.root()
RUNS = ROOT / "runs"
CURRENT_SCHEMA_VERSION = 3

#: `scaffold` and `lint` sit either side of the part nobody can automate. The skeleton is
#: deterministic, the authoring is the agent's, and the gate is deterministic again — so the
#: status list has to show all three, or a run stalled halfway through authoring looks identical
#: to one that never started building.
#: `verify-full` left this sequence in U14: the playbook verifies itself as it generates, so a
#: standalone second verification is not part of the flow (the code stays callable for internal
#: use). `verify-render` followed it out on 2026-08-11: it judged the produced document by the
#: project file listing, but the platform stores a produced .sdoc as a sealed entity whose inner
#: snapshots never appear in that listing — so every table-bearing report failed the gate even
#: when the rendered page was full of data (proven in room-002: gate red, markdown render green).
#: `verify-fidelity` is its successor: it judges the produced artifact against the
#: customer-approved fidelity contract, via an independent assessment — not a file listing.
STAGES = ["init","evidence","parse","fanout","verify-cold","request-access","detect","connect",
          "context","output-target","contract","scaffold","lint","build","deploy","params","run",
          "verify-fidelity","schedule","share","teardown"]


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def tree_key(d: Path) -> str:
    """Cache key for an input tree: git SHA if available, plus a hash of tracked file hashes.

    Both, because a git SHA alone misses uncommitted edits and file hashes alone are slow to
    explain. If either changes, the key changes and a cached fan-out is discarded.
    """
    sha = ""
    try:
        sha = subprocess.run(["git","-C",str(d),"rev-parse","HEAD"],
                             capture_output=True, text=True, timeout=10).stdout.strip()
    except Exception:
        pass
    files = sorted(p for p in d.rglob("*") if p.is_file() and ".git" not in p.parts)
    h = hashlib.sha256()
    for p in files:
        h.update(str(p.relative_to(d)).encode()); h.update(sha256_file(p).encode())
    return f"{sha[:12] or 'nogit'}-{h.hexdigest()[:16]}"


@dataclass
class Run:
    run_id: str
    schema_version: int = CURRENT_SCHEMA_VERSION
    #: A customer-facing handle for resumption.  The id remains the collision-proof identity;
    #: this is what an agent can say back without making someone remember ``sf-014``.
    name: str = ""
    input_dir: str = ""
    input_key: str = ""
    #: Where the code that builds this artifact lives — its queries, config, the skill that
    #: produces it. When a folder holds several processes, this scopes fanout/detect to the one
    #: the person chose, instead of scanning the whole tree. Empty means "same as input_dir".
    code_dir: str = ""
    project_id: str = ""
    profile: str = field(default_factory=settings.default_profile)
    stages: dict = field(default_factory=dict)   # stage -> {status, at, detail, artifact}
    created_objects: list = field(default_factory=list)
    revisions: dict = field(default_factory=dict)
    bindings: dict = field(default_factory=dict)
    #: Small pointers only. The versioned records themselves live under artifacts/records.
    artifact_refs: dict = field(default_factory=dict)
    capability_snapshot_digest: str = ""
    open_decision_ids: list[str] = field(default_factory=list)
    open_permission_ids: list[str] = field(default_factory=list)
    active_permission_ids: list[str] = field(default_factory=list)
    preview_receipt_digest: str = ""
    proof_packet_digest: str = ""
    #: Which tenant a person agreed this run may create things in, and how they said so. Written
    #: once by `init`; every writing stage checks the run has not since drifted onto another.
    tenant_ack: dict = field(default_factory=dict)
    updated_at: str = ""

    @property
    def dir(self) -> Path: return RUNS / self.run_id
    @property
    def artifacts(self) -> Path: return self.dir / "artifacts"
    @property
    def journal(self) -> Path: return self.dir / "events.jsonl"

    # ---- persistence ----
    @classmethod
    def load(cls, run_id: str | None = None) -> "Run":
        """Load a run. Prefer an explicit id: the CURRENT pointer is global to the machine, so a
        concurrent `init` — anyone's — moves it, and stages would then act on the wrong project.
        A replication test hit exactly this and would have torn down another run's objects."""
        rid = run_id or os.environ.get("SF_RUN") or current_run_id()
        if not rid: raise SystemExit("no active run — start one with: summation-flow init --input <dir>")
        f = RUNS / rid / "state.json"
        if not f.exists(): raise SystemExit(f"run {rid} has no state.json")
        loaded = cls(**json.loads(f.read_text()))
        loaded.schema_version = CURRENT_SCHEMA_VERSION
        return loaded

    def save(self) -> None:
        """Atomically save the checkpoint and select it as the current run.

        A process dying during ``write_text`` used to leave a truncated state file — exactly the
        moment checkpointing is supposed to protect.  ``os.replace`` makes the old or new JSON
        visible in full, never half of either.
        """
        self.artifacts.mkdir(parents=True, exist_ok=True)
        self.updated_at = time.strftime("%Y-%m-%dT%H:%M:%S")
        _atomic_write(self.dir / "state.json", json.dumps(asdict(self), indent=2) + "\n")
        set_current(self.run_id)

    # ---- stage bookkeeping ----
    def mark(self, stage: str, status: str, detail: str = "", artifact: str = "") -> None:
        assert status in ("done","degraded","blocked","failed","skipped","running")
        self.stages[stage] = {"status": status, "at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                              "detail": detail, "artifact": artifact}
        self.save()
        self.append_event("stage", stage=stage, state=status, detail=detail, artifact=artifact)

    def status_of(self, stage: str) -> str:
        return (self.stages.get(stage) or {}).get("status", "not-started")

    def require(self, stage: str) -> None:
        """Refuse to run a stage whose prerequisite has not succeeded — the demo's only guardrail
        against running things out of order."""
        if self.status_of(stage) not in ("done","degraded"):
            raise SystemExit(
                f"stage '{stage}' has not succeeded in run {self.run_id} "
                f"(currently: {self.status_of(stage)}).\n"
                f"    If you expected it to have run, check you are on the right run: "
                f"`summation-flow status` shows which one is active, and another `init` on this "
                f"machine moves it. Pass --run {self.run_id} to pin every command to this run.")

    def write(self, name: str, obj) -> Path:
        self.artifacts.mkdir(parents=True, exist_ok=True)
        p = self.artifacts / name
        p.write_text(json.dumps(obj, indent=2, default=str))
        return p

    def read(self, name: str):
        p = self.artifacts / name
        if not p.exists(): raise SystemExit(f"missing artifact {name} — run the earlier stage first")
        return json.loads(p.read_text())

    def record_object(self, kind: str, ident: str, note: str = "") -> None:
        self.created_objects.append({"kind": kind, "id": ident, "note": note,
                                     "at": time.strftime("%Y-%m-%dT%H:%M:%S")})
        self.save()

    def invalidate_from(self, stage: str, reason: str) -> None:
        """Reopen ``stage`` and everything after it without pretending progress is monotonic."""
        if stage not in STAGES:
            raise ValueError(f"unknown stage {stage}")
        affected = STAGES[STAGES.index(stage):]
        changed = [name for name in affected if name in self.stages]
        if not changed:
            return
        for name in affected:
            self.stages.pop(name, None)
        self.revisions[stage] = int(self.revisions.get(stage, 0)) + 1
        self.save()
        self.append_event("invalidation", from_stage=stage, affected=changed, reason=reason,
                          revision=self.revisions[stage] + 1)

    def append_event(self, event_type: str, **fields) -> dict:
        """Append one non-secret fact to the run journal and flush it before returning."""
        self.dir.mkdir(parents=True, exist_ok=True)
        event = {"event": event_type, "at": time.strftime("%Y-%m-%dT%H:%M:%S"),
                 "run_id": self.run_id, **fields}
        encoded = (json.dumps(event, sort_keys=True, default=str) + "\n").encode()
        fd = os.open(self.journal, os.O_APPEND | os.O_CREAT | os.O_WRONLY, 0o600)
        try:
            os.write(fd, encoded)
            os.fsync(fd)
        finally:
            os.close(fd)
        return event

    def events(self) -> list[dict]:
        if not self.journal.exists():
            return []
        out = []
        for line in self.journal.read_text().splitlines():
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                # Preserve every earlier durable event if the final append was interrupted.
                continue
        return out


def current_run_id() -> str | None:
    f = RUNS / "CURRENT"
    return f.read_text().strip() if f.exists() else None


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    try:
        tmp.write_text(text)
        os.replace(tmp, path)
    finally:
        if tmp.exists():
            tmp.unlink()


def set_current(run_id: str) -> None:
    """Select a run without rewriting its checkpoint or changing its update time."""
    _atomic_write(RUNS / "CURRENT", run_id + "\n")


def all_runs() -> list[Run]:
    """Return every readable run, most recently checkpointed first.

    A damaged unrelated run should not prevent discovery of the healthy run somebody wants to
    resume.  Its directory remains untouched for diagnosis.
    """
    found = []
    if not RUNS.exists():
        return found
    for state_file in RUNS.glob("sf-*/state.json"):
        try:
            loaded = Run(**json.loads(state_file.read_text()))
            loaded.schema_version = CURRENT_SCHEMA_VERSION
            found.append(loaded)
        except (OSError, TypeError, ValueError, json.JSONDecodeError):
            continue
    return sorted(found, key=lambda r: (r.updated_at, r.run_id), reverse=True)


def new_run() -> Run:
    RUNS.mkdir(parents=True, exist_ok=True)
    n = 1 + max([int(p.name.split("-")[-1]) for p in RUNS.glob("sf-*") if p.name.split("-")[-1].isdigit()] or [0])
    r = Run(run_id=f"sf-{n:03d}"); r.save(); return r
