"""Mine the unstructured context a customer already has, and structure it.

The premise: by the time someone asks us to automate a report, they have already written down
most of what makes it correct — in notes to self, in dbt `meta:` blocks, in SQL comments, in the
corrective turns of past agent sessions. It is just not in a form anything can use. It is prose,
scattered, undated in places, and it contradicts itself.

This module turns that into structured items, and — the part that earns its keep — surfaces the
**conflicts**. A metric defined one way in dbt and another way in the analyst's own notes is not a
formatting problem, it is the reason two dashboards disagree. Finding those is worth more than
tidying the prose.

Deterministic on purpose. Which definition *wins* is a judgement that belongs to the person, so
this only reports that a conflict exists, with both sides and where each came from. Nothing here
resolves anything.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from pathlib import Path

#: A dated line in a notes file: "2026-02-28 — Weeks of supply was wrong. ..."
DATED = re.compile(r"^(\d{4}-\d{2}-\d{2})\s*[—–-]\s*(.+)$")

#: An expression worth capturing: anything inside backticks that looks like arithmetic over columns.
EXPR = re.compile(r"`([^`]*\b(?:sum|avg|count|nullif)\s*\([^`]*)`", re.I)

#: Phrases that mark an item as a warning rather than a definition.
REJECTED = re.compile(r"\b(do not|don't|never|stopped|abandoned|tried .{0,40}\bdo not)\b", re.I)
UNRESOLVED = re.compile(r"\b(todo|have not worked out|haven't worked out|not sure why|unresolved)\b", re.I)

#: Metric names we can recognise across sources, so a conflict can be detected at all. Matching on
#: a normalised name rather than exact text: "weeks_of_supply", "Weeks of supply" and
#: "weeks of supply" are the same metric to a human and must be to us.
def norm_metric(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", (name or "").strip().lower()).strip("_")


@dataclass
class Item:
    """One piece of recovered context, always carrying where it came from."""
    kind: str                      # definition | rule | known_issue | rejected | note
    subject: str                   # the metric or topic it is about
    text: str                      # what it says, in the author's own words
    source: str                    # path:line
    dated: str | None = None       # ISO date when the author recorded it
    expression: str | None = None  # a formula, when one was stated

    def as_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None}


@dataclass
class Mined:
    items: list[Item] = field(default_factory=list)
    conflicts: list[dict] = field(default_factory=list)
    sources_read: list[str] = field(default_factory=list)
    sources_skipped: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- subject guessing
#: Known metric vocabulary. Deliberately small: a wrong subject is worse than "general", because it
#: files a rule under a metric it does not govern.
SUBJECTS = [
    ("weeks_of_supply", re.compile(r"\bweeks?\s+of\s+supply\b|\bweeks_of_supply\b|\bwos\b", re.I)),
    ("year_over_year", re.compile(r"\byear[- ]over[- ]year\b|\byoy\b", re.I)),
    ("revenue", re.compile(r"\brevenue\b|\bnet\s+demand\b", re.I)),
    ("units", re.compile(r"\bunits\b", re.I)),
    ("on_hand", re.compile(r"\bon[- ]hand\b|\bonhand\b", re.I)),
    ("sell_through", re.compile(r"\bsell[- ]through\b", re.I)),
]


def guess_subject(text: str) -> str:
    for name, pat in SUBJECTS:
        if pat.search(text):
            return name
    return "general"


def classify(text: str) -> str:
    if UNRESOLVED.search(text):
        return "known_issue"
    if REJECTED.search(text):
        return "rejected"
    if EXPR.search(text):
        return "definition"
    if re.search(r"\bshift\b|\bmust\b|\balways\b|\bhas to be\b|\bnot\b\s+\d{3}\b", text, re.I):
        return "rule"
    return "note"


# --------------------------------------------------------------------------- source readers
def from_notes(path: Path, rel: str) -> list[Item]:
    """Dated prose notes — the richest source, and the one nothing else reads.

    An entry runs until the next dated line, not to the end of its own line. People wrap. Reading
    only the first line dropped every formula and every TODO in the fixture, because those sat on
    the continuation — which silently turned the single most valuable finding, a metric defined
    two different ways, into two unrelated notes.
    """
    out: list[Item] = []
    date: str | None = None
    start = 0
    buf: list[str] = []

    def flush():
        if not date or not buf:
            return
        body = " ".join(x.strip() for x in buf if x.strip()).strip()
        if not body:
            return
        expr = EXPR.search(body)
        out.append(Item(
            kind=classify(body), subject=guess_subject(body), text=body,
            source=f"{rel}:{start}", dated=date,
            expression=expr.group(1).strip() if expr else None,
        ))

    for i, raw in enumerate(path.read_text().splitlines(), 1):
        m = DATED.match(raw.strip())
        if m:
            flush()
            date, start, buf = m.group(1), i, [m.group(2)]
        elif date is not None:
            buf.append(raw)
    flush()
    return out


def from_dbt(path: Path, rel: str) -> list[Item]:
    """dbt metric blocks. Parsed line-wise rather than with a YAML library: these files are
    frequently mid-edit and a hard parse failure would lose the whole source. Losing one metric is
    better than losing the file."""
    out: list[Item] = []
    name: str | None = None
    for i, raw in enumerate(path.read_text().splitlines(), 1):
        line = raw.strip()
        m = re.match(r"-?\s*name:\s*(.+)$", line)
        if m:
            name = m.group(1).strip().strip("\"'")
            continue
        m = re.match(r"expression:\s*(.+)$", line)
        if m and name:
            out.append(Item(
                kind="definition", subject=norm_metric(name),
                text=f"{name} is defined in dbt as {m.group(1).strip()}",
                source=f"{rel}:{i}", expression=m.group(1).strip().strip("\"'"),
            ))
        m = re.match(r"(?:#\s*)?(?:note|NOTE):\s*(.+)$", line)
        if m and name:
            body = m.group(1).strip().strip("\"'")
            out.append(Item(kind=classify(body), subject=norm_metric(name),
                            text=body, source=f"{rel}:{i}"))
    return out


def from_sql_comments(path: Path, rel: str) -> list[Item]:
    """`--` comments that state a rule rather than describe a line of SQL."""
    out: list[Item] = []
    for i, raw in enumerate(path.read_text().splitlines(), 1):
        m = re.match(r"\s*--\s*(.+)$", raw)
        if not m:
            continue
        body = m.group(1).strip()
        # Skip section dividers and one-word labels; they carry no rule.
        if len(body) < 25 or set(body) <= set("-= "):
            continue
        kind = classify(body)
        if kind == "note":
            continue
        out.append(Item(kind=kind, subject=guess_subject(body), text=body, source=f"{rel}:{i}"))
    return out


def from_session_jsonl(path: Path, rel: str, limit: int = 400) -> list[Item]:
    """Corrective turns from a past agent session — "no, weeks of supply means ...".

    Only the human's own messages are read, and only those that read as a correction. An agent's
    output is not evidence of what the business means; the person's correction of it is.
    """
    out: list[Item] = []
    correction = re.compile(
        r"\b(no,|not |actually|should be|has to be|it'?s not|wrong|instead of|we define|means)\b", re.I)
    try:
        lines = path.read_text(errors="replace").splitlines()[:limit]
    except OSError:
        return out
    for i, raw in enumerate(lines, 1):
        try:
            rec = json.loads(raw)
        except (ValueError, TypeError):
            continue
        if (rec.get("type") or rec.get("role")) not in ("user", "human"):
            continue
        msg = rec.get("message") or rec.get("content") or ""
        if isinstance(msg, dict):
            msg = msg.get("content") or ""
        if isinstance(msg, list):
            msg = " ".join(str(p.get("text", "")) for p in msg if isinstance(p, dict))
        msg = str(msg).strip()
        if not (30 < len(msg) < 600) or not correction.search(msg):
            continue
        expr = EXPR.search(msg)
        out.append(Item(kind=classify(msg), subject=guess_subject(msg), text=msg,
                        source=f"{rel}:{i}",
                        expression=expr.group(1).strip() if expr else None))
    return out


# --------------------------------------------------------------------------- conflicts
def find_conflicts(items: list[Item]) -> list[dict]:
    """Two sources stating different formulas for the same metric.

    This is the finding worth having. A definition that disagrees with itself across the stack is
    why two dashboards show different numbers, and nobody notices until someone asks which is
    right. Comparison is on normalised expression text — whitespace and case differ constantly and
    mean nothing.
    """
    def norm_expr(e: str) -> str:
        return re.sub(r"\s+", "", (e or "").lower())

    by_subject: dict[str, list[Item]] = {}
    for it in items:
        if it.kind == "definition" and it.expression:
            by_subject.setdefault(it.subject, []).append(it)

    out = []
    for subject, defs in sorted(by_subject.items()):
        seen: dict[str, Item] = {}
        for d in defs:
            seen.setdefault(norm_expr(d.expression or ""), d)
        if len(seen) < 2:
            continue
        variants = list(seen.values())
        out.append({
            "subject": subject,
            "variants": [
                {"expression": v.expression, "source": v.source, "dated": v.dated} for v in variants
            ],
            "statement": (
                f"{subject.replace('_', ' ')} is defined {len(variants)} different ways: "
                + "; and ".join(f"{v.expression!r} at {v.source}" for v in variants)
                + ". Which one is right is a decision, not a lookup."
            ),
        })
    return out


# --------------------------------------------------------------------------- entry point
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}


def mine(root: Path, session_dirs: list[Path] | None = None) -> Mined:
    """Read everything worth reading under `root`, plus any session directories explicitly given.

    Session history is opt-in by parameter, never discovered automatically. Reading a person's
    whole agent history is not something to do because it happened to be on the disk.
    """
    res = Mined()
    for p in sorted(root.rglob("*")):
        if not p.is_file() or any(part in SKIP_DIRS for part in p.parts):
            continue
        rel = str(p.relative_to(root))
        try:
            if p.name.endswith((".md", ".markdown")) and "note" in p.name.lower():
                res.items += from_notes(p, rel)
            elif p.suffix in (".yml", ".yaml"):
                res.items += from_dbt(p, rel)
            elif p.suffix == ".sql":
                res.items += from_sql_comments(p, rel)
            else:
                continue
            res.sources_read.append(rel)
        except (OSError, UnicodeDecodeError) as e:
            res.sources_skipped.append(f"{rel}: {type(e).__name__}")

    for d in session_dirs or []:
        for p in sorted(Path(d).rglob("*.jsonl"))[:20]:
            try:
                res.items += from_session_jsonl(p, str(p))
                res.sources_read.append(str(p))
            except (OSError, UnicodeDecodeError) as e:
                res.sources_skipped.append(f"{p}: {type(e).__name__}")

    res.conflicts = find_conflicts(res.items)
    return res


# --------------------------------------------------------------------------- rendering
HEADINGS = [
    ("definition", "Metric definitions", "How each number is calculated, in the words of whoever decided it."),
    ("rule", "Rules that must hold", "Constraints that are not optional and are easy to break silently."),
    ("known_issue", "Known and unresolved", "Written down, never solved. Worth checking whether they still bite."),
    ("rejected", "Approaches already rejected", "Tried, and abandoned for a reason. Do not rediscover these."),
    # Everything that did not sort into a category still gets written out. Recovering an item and
    # then dropping it from the document is worse than not recovering it: the run reports a count
    # that the file does not contain, so nobody notices the loss.
    ("note", "Everything else they wrote down",
     "Uncategorised, and still the reason somebody did something. Kept verbatim."),
]


def render_knowledge(m: Mined, title: str) -> str:
    """One markdown file, in the shape the platform recognises as project knowledge.

    Every item keeps its citation. Context without a source is folklore — a reader has to be able
    to go and check who said it and when.
    """
    out = [f"# {title} — recovered context", ""]
    out += [
        "Recovered from the material that already existed: notes, dbt metadata, SQL comments"
        + (", and past agent sessions." if any("jsonl" in s for s in m.sources_read) else "."),
        "Every line cites where it came from. Nothing here was invented, and nothing was resolved —",
        "where two sources disagree, both are kept and the disagreement is stated.",
        "",
    ]

    if m.conflicts:
        out += ["## Conflicts — read these first", ""]
        for c in m.conflicts:
            out.append(f"- **{c['subject'].replace('_', ' ')}** — {c['statement']}")
        out.append("")

    for kind, heading, blurb in HEADINGS:
        got = [i for i in m.items if i.kind == kind]
        if not got:
            continue
        out += [f"## {heading}", "", blurb, ""]
        for i in sorted(got, key=lambda x: (x.subject, x.dated or "")):
            when = f" _(recorded {i.dated})_" if i.dated else ""
            out.append(f"- **{i.subject.replace('_', ' ')}** — {i.text}{when}  \n  `{i.source}`")
            if i.expression:
                out.append(f"  - formula: `{i.expression}`")
        out.append("")

    out += ["## Where this came from", ""]
    for s in m.sources_read:
        out.append(f"- `{s}`")
    if m.sources_skipped:
        out += ["", "Could not read:"] + [f"- `{s}`" for s in m.sources_skipped]
    return "\n".join(out) + "\n"
