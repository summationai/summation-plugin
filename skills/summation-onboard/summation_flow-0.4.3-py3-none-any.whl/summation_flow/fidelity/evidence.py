"""Deterministic, non-semantic evidence collection for source packages."""

from __future__ import annotations

import hashlib
import json
import mimetypes
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

EVIDENCE_VERSION = "artifact-evidence/v1"

_IGNORED_DIRS = {
    ".git",
    ".hg",
    ".svn",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".venv",
    "__pycache__",
    "node_modules",
}


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_sha256(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return _sha256_bytes(encoded)


def _visible_text(parts: list[str]) -> str:
    return " ".join(" ".join(parts).split())


class _HtmlObservations(HTMLParser):
    """Collect literal structure from HTML without assigning business meaning."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tag_counts: Counter[str] = Counter()
        self.headings: list[dict[str, Any]] = []
        self.tables: list[dict[str, Any]] = []
        self.assets = {
            "images": 0,
            "links": 0,
            "inline_style_blocks": 0,
            "stylesheets": 0,
            "scripts": 0,
        }
        self._hidden_depth = 0
        self._visible_parts: list[str] = []
        self._heading: dict[str, Any] | None = None
        self._heading_parts: list[str] = []
        self._table: dict[str, Any] | None = None
        self._row_cells: list[str] | None = None
        self._cell_parts: list[str] | None = None

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag = tag.lower()
        self.tag_counts[tag] += 1
        attrs_dict = {key.lower(): value for key, value in attrs}

        if tag in {"script", "style"}:
            self._hidden_depth += 1
        if tag == "script":
            self.assets["scripts"] += 1
        elif tag == "style":
            self.assets["inline_style_blocks"] += 1
        elif tag == "img":
            self.assets["images"] += 1
        elif tag == "a" and attrs_dict.get("href"):
            self.assets["links"] += 1
        elif tag == "link" and "stylesheet" in (attrs_dict.get("rel") or "").lower():
            self.assets["stylesheets"] += 1

        if tag in {"h1", "h2", "h3", "h4", "h5", "h6"}:
            self._heading = {"level": int(tag[1])}
            self._heading_parts = []
        elif tag == "table":
            self._table = {"index": len(self.tables) + 1, "headers": [], "rows": []}
        elif tag == "tr" and self._table is not None:
            self._row_cells = []
        elif tag in {"th", "td"} and self._row_cells is not None:
            self._cell_parts = []

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        if tag in {"script", "style"} and self._hidden_depth:
            self._hidden_depth -= 1

        if self._heading is not None and tag == f"h{self._heading['level']}":
            self._heading["text"] = _visible_text(self._heading_parts)
            self.headings.append(self._heading)
            self._heading = None
            self._heading_parts = []
        elif tag in {"th", "td"} and self._cell_parts is not None and self._row_cells is not None:
            value = _visible_text(self._cell_parts)
            self._row_cells.append(value)
            if tag == "th" and self._table is not None:
                self._table["headers"].append(value)
            self._cell_parts = None
        elif tag == "tr" and self._row_cells is not None and self._table is not None:
            if self._row_cells and not self._table["headers"]:
                self._table["rows"].append(self._row_cells)
            elif self._row_cells and self._row_cells != self._table["headers"]:
                self._table["rows"].append(self._row_cells)
            self._row_cells = None
        elif tag == "table" and self._table is not None:
            row_widths = [len(row) for row in self._table["rows"]]
            self.tables.append(
                {
                    "index": self._table["index"],
                    "headers": self._table["headers"],
                    "column_count": max([len(self._table["headers"]), *row_widths], default=0),
                    "body_row_count": len(self._table["rows"]),
                }
            )
            self._table = None

    def handle_data(self, data: str) -> None:
        if self._hidden_depth == 0 and data.strip():
            self._visible_parts.append(data)
            if self._heading is not None:
                self._heading_parts.append(data)
            if self._cell_parts is not None:
                self._cell_parts.append(data)

    def as_dict(self) -> dict[str, Any]:
        visible = _visible_text(self._visible_parts)
        return {
            "collector": "html-observables/v1",
            "headings": self.headings,
            "tables": self.tables,
            "tag_counts": dict(sorted(self.tag_counts.items())),
            "assets": self.assets,
            "visible_text_sha256": _sha256_bytes(visible.encode("utf-8")),
            "visible_text_bytes": len(visible.encode("utf-8")),
            "limitations": [
                "Records rendered source structure, not business meaning.",
                "Does not execute scripts, load remote assets, or measure browser layout.",
            ],
        }


def _format_observations(artifact: Path, data: bytes) -> dict[str, Any]:
    if artifact.suffix.lower() not in {".html", ".htm"}:
        return {
            "collector": "file-observables/v1",
            "limitations": ["No format-specific collector is installed for this artifact."],
        }
    parser = _HtmlObservations()
    parser.feed(data.decode("utf-8", errors="replace"))
    parser.close()
    return parser.as_dict()


def _package_files(root: Path, max_files: int) -> tuple[list[dict[str, Any]], bool]:
    files: list[dict[str, Any]] = []
    truncated = False
    for path in sorted(root.rglob("*")):
        if not path.is_file() or _IGNORED_DIRS.intersection(path.relative_to(root).parts):
            continue
        if len(files) >= max_files:
            truncated = True
            break
        data = path.read_bytes()
        files.append(
            {
                "path": path.relative_to(root).as_posix(),
                "suffix": path.suffix.lower(),
                "bytes": len(data),
                "sha256": _sha256_bytes(data),
            }
        )
    return files, truncated


def collect_tree_manifest(root: str | Path, *, max_files: int = 5_000) -> dict[str, Any]:
    """Fingerprint every supplied file under one declared package root.

    This is public separately from :func:`collect_package_evidence` because an
    onboarding run may receive the reference artifact and its producing code as
    two distinct roots.  The caller gives those roots meaning (``artifact`` or
    ``code``); this function only records their literal contents.
    """

    resolved = Path(root).expanduser().resolve()
    if not resolved.is_dir():
        raise NotADirectoryError(resolved)
    if max_files < 1:
        raise ValueError("max_files must be at least 1")
    files, truncated = _package_files(resolved, max_files)
    return {
        "files": files,
        "file_count": len(files),
        "truncated": truncated,
        "sha256": _canonical_sha256(files),
    }


def collect_package_evidence(
    package_root: str | Path,
    artifact: str | Path | None,
    *,
    max_files: int = 5_000,
    artifact_only: bool = False,
) -> dict[str, Any]:
    """Collect reproducible facts about a package and one chosen artifact.

    ``artifact`` may be relative to ``package_root``, an absolute path inside
    it, or ``None`` when the customer is starting from code/conversation alone.
    Paths recorded in the evidence stay package-relative so fingerprints do not
    depend on which machine performs the intake.
    """

    root = Path(package_root).expanduser().resolve()
    if not root.is_dir():
        raise NotADirectoryError(root)
    if max_files < 1:
        raise ValueError("max_files must be at least 1")
    package_manifest = collect_tree_manifest(root, max_files=max_files)
    if artifact is None:
        return {
            "evidence_version": EVIDENCE_VERSION,
            "source": {
                "path": None,
                "name": None,
                "format": "none",
                "mime_type": None,
                "bytes": 0,
                "sha256": None,
            },
            "package": package_manifest,
            "observations": {
                "collector": "package-observables/v1",
                "limitations": ["No reference artifact was supplied; fidelity requirements must come from the customer conversation."],
            },
        }
    selected = Path(artifact).expanduser()
    selected = selected.resolve() if selected.is_absolute() else (root / selected).resolve()
    try:
        relative = selected.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"artifact {selected} is outside package root {root}") from exc
    if selected.is_dir():
        # Summation's document/deck artifacts are directory packages (`.sdoc`, `.sdeck`).
        # Treating one as an ordinary parent directory recorded `format: none` and told the
        # independent verifier that no produced artifact had been selected, even though the
        # exact package was the argument to `verify --fidelity --output`.
        fmt = selected.suffix.lower().lstrip(".") or "directory"
        total_bytes = sum(int(item.get("bytes") or 0) for item in package_manifest["files"])
        return {
            "evidence_version": EVIDENCE_VERSION,
            "source": {
                "path": relative.as_posix(),
                "name": selected.name,
                "format": fmt,
                "mime_type": "inode/directory",
                "bytes": total_bytes,
                "sha256": package_manifest["sha256"],
            },
            "package": package_manifest,
            "observations": {
                "collector": f"{fmt}-package-observables/v1",
                "file_count": package_manifest["file_count"],
                "limitations": [
                    "Records the complete directory package and its files, not its rendered visual or semantic meaning."
                ],
            },
        }
    if not selected.is_file():
        raise FileNotFoundError(selected)

    artifact_data = selected.read_bytes()
    if artifact_only:
        only = [{
            "path": relative.as_posix(),
            "suffix": selected.suffix.lower(),
            "bytes": len(artifact_data),
            "sha256": _sha256_bytes(artifact_data),
        }]
        package_manifest = {
            "files": only,
            "file_count": 1,
            "truncated": False,
            "sha256": _canonical_sha256(only),
        }
    mime, _ = mimetypes.guess_type(selected.name)
    return {
        "evidence_version": EVIDENCE_VERSION,
        "source": {
            "path": relative.as_posix(),
            "name": selected.name,
            "format": selected.suffix.lower().lstrip(".") or "unknown",
            "mime_type": mime or "application/octet-stream",
            "bytes": len(artifact_data),
            "sha256": _sha256_bytes(artifact_data),
        },
        "package": package_manifest,
        "observations": _format_observations(selected, artifact_data),
    }


def evidence_fingerprint(evidence: dict[str, Any]) -> str:
    """Return the stable identity a fidelity contract pins itself to."""

    return _canonical_sha256(evidence)
