"""Format-neutral evidence and customer-approved fidelity contracts.

The boundary in this package is intentional:

* :mod:`summation_flow.fidelity.evidence` records observable facts.  A format
  collector may count elements and preserve verbatim text, but it does not
  decide what those elements mean.
* :mod:`summation_flow.fidelity.contracts` validates the reconstruction
  contract authored by the conducting agent and approved by the customer.

Keeping those responsibilities separate prevents an HTML parser (or any later
PDF, workbook, or deck collector) from quietly becoming the product's source
of semantic truth.
"""

from .contracts import (
    CONTRACT_VERSION,
    contract_template,
    load_contract,
    readiness_findings,
    validate_contract,
)
from .assessments import (
    ASSESSMENT_VERSION,
    assessment_findings,
    assessment_template,
    compare_observations,
    contract_fingerprint,
    load_assessment,
    validate_assessment,
)
from .evidence import (
    EVIDENCE_VERSION,
    collect_package_evidence,
    collect_tree_manifest,
    evidence_fingerprint,
)
from .handoffs import PACKET_VERSION, render_verification_request, verification_packet

__all__ = [
    "CONTRACT_VERSION",
    "EVIDENCE_VERSION",
    "ASSESSMENT_VERSION",
    "assessment_findings",
    "assessment_template",
    "collect_package_evidence",
    "collect_tree_manifest",
    "compare_observations",
    "contract_template",
    "contract_fingerprint",
    "evidence_fingerprint",
    "PACKET_VERSION",
    "render_verification_request",
    "verification_packet",
    "load_contract",
    "load_assessment",
    "readiness_findings",
    "validate_assessment",
    "validate_contract",
]
