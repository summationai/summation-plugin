"""Bound post-run assessments for a customer-approved fidelity contract.

The assessment is intentionally a handoff between two kinds of work:

* deterministic code pins the exact contract, output evidence, and observable
  source/output diff, and proves that every requirement has exactly one result;
* an independent verifier supplies the visual and semantic judgments that a
  format parser cannot honestly make.

The gate below validates the handoff.  It does not pretend that validating a
JSON shape is the same thing as independently judging the artifact.
"""

from __future__ import annotations

import hashlib
import json
from importlib.resources import files
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .evidence import evidence_fingerprint

ASSESSMENT_VERSION = "fidelity-assessment/v1"
SCHEMA_PATH = Path(str(files("summation_flow.fidelity"))) / "schemas" / "fidelity-assessment.schema.json"


def _canonical_sha256(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def contract_fingerprint(contract: dict[str, Any]) -> str:
    return _canonical_sha256(contract)


def compare_observations(source: dict[str, Any], output: dict[str, Any]) -> dict[str, Any]:
    """Record literal format/structure differences without adjudicating them."""

    source_obs = source.get("observations") or {}
    output_obs = output.get("observations") or {}
    fields = ("collector", "headings", "tables", "tag_counts", "assets", "visible_text_sha256")
    differences = []
    if (source.get("source") or {}).get("format") != (output.get("source") or {}).get("format"):
        differences.append({
            "path": "/source/format",
            "source": (source.get("source") or {}).get("format"),
            "output": (output.get("source") or {}).get("format"),
        })
    for field in fields:
        if source_obs.get(field) != output_obs.get(field):
            differences.append({
                "path": f"/observations/{field}",
                "source": source_obs.get(field),
                "output": output_obs.get(field),
            })
    result = {
        "comparison_version": "observable-diff/v1",
        "source_evidence_sha256": evidence_fingerprint(source),
        "output_evidence_sha256": evidence_fingerprint(output),
        "differences": differences,
    }
    result["sha256"] = _canonical_sha256(result)
    return result


def load_assessment(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def validate_assessment(assessment: Any) -> list[str]:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    errors = []
    for error in sorted(Draft202012Validator(schema).iter_errors(assessment), key=lambda item: list(item.path)):
        pointer = "/" + "/".join(str(part) for part in error.path) if error.path else "/"
        errors.append(f"{pointer}: {error.message}")
    if errors or not isinstance(assessment, dict):
        return errors
    ids = [item["requirement_id"] for item in assessment["results"]]
    duplicates = sorted({value for value in ids if ids.count(value) > 1})
    if duplicates:
        errors.append(f"/results: duplicate requirement_id(s): {', '.join(duplicates)}")
    return errors


def assessment_template(
    contract: dict[str, Any],
    output_evidence: dict[str, Any],
    observation_diff: dict[str, Any],
) -> dict[str, Any]:
    """Create the evidence-bound worksheet an independent verifier fills."""

    return {
        "assessment_version": ASSESSMENT_VERSION,
        "contract_sha256": contract_fingerprint(contract),
        "output_evidence_sha256": evidence_fingerprint(output_evidence),
        "observation_diff_sha256": observation_diff["sha256"],
        "results": [
            {
                "requirement_id": requirement["id"],
                "method": requirement["verification"]["method"],
                "status": "pending",
                "verifier": "independent_agent",
                "verified_by": "",
                "verified_at": "",
                "evidence": "",
                "notes": "",
            }
            for requirement in contract["requirements"]
        ],
        "unexplained_differences": [],
    }


def assessment_findings(
    assessment: Any,
    contract: dict[str, Any],
    output_evidence: dict[str, Any],
    observation_diff: dict[str, Any],
) -> list[str]:
    """Return every reason this assessment cannot release the artifact."""

    errors = validate_assessment(assessment)
    if errors:
        return errors
    findings = []
    if assessment["contract_sha256"] != contract_fingerprint(contract):
        findings.append("the fidelity contract changed after this assessment was authored")
    if assessment["output_evidence_sha256"] != evidence_fingerprint(output_evidence):
        findings.append("the produced artifact changed after this assessment was authored")
    if assessment["observation_diff_sha256"] != observation_diff["sha256"]:
        findings.append("the source/output observation diff changed after this assessment was authored")

    expected = {item["id"]: item for item in contract["requirements"]}
    actual = {item["requirement_id"]: item for item in assessment["results"]}
    missing = sorted(set(expected) - set(actual))
    unknown = sorted(set(actual) - set(expected))
    if missing:
        findings.append(f"requirements without a verification result: {', '.join(missing)}")
    if unknown:
        findings.append(f"verification results for unknown requirements: {', '.join(unknown)}")
    for requirement_id in sorted(set(expected) & set(actual)):
        requirement = expected[requirement_id]
        result = actual[requirement_id]
        method = requirement["verification"]["method"]
        if result["method"] != method:
            findings.append(
                f"{requirement_id} was assessed as {result['method']}, but the approved contract requires {method}"
            )
        if result["status"] != "pass":
            findings.append(f"{requirement_id} is {result['status']}: {result['notes'] or 'no explanation supplied'}")
        elif not result["verified_by"]:
            findings.append(f"{requirement_id} passed without naming who or what verified it")
        elif not result["verified_at"]:
            findings.append(f"{requirement_id} passed without recording when it was verified")
        elif not result["evidence"]:
            findings.append(f"{requirement_id} passed without evidence")
    for difference in assessment["unexplained_differences"]:
        findings.append(f"unexplained difference {difference['id']}: {difference['statement']}")
    return findings
