"""Validation and release readiness for agent-authored fidelity contracts."""

from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from .evidence import evidence_fingerprint

CONTRACT_VERSION = "fidelity-contract/v1"
SCHEMA_PATH = Path(str(files("summation_flow.fidelity"))) / "schemas" / "fidelity-contract.schema.json"


def _schema() -> dict[str, Any]:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def load_contract(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def validate_contract(contract: Any) -> list[str]:
    """Return structural contract errors as stable, human-readable strings."""

    validator = Draft202012Validator(_schema())
    errors: list[str] = []
    for error in sorted(validator.iter_errors(contract), key=lambda item: list(item.path)):
        pointer = "/" + "/".join(str(part) for part in error.path) if error.path else "/"
        errors.append(f"{pointer}: {error.message}")
    if errors or not isinstance(contract, dict):
        return errors

    for collection, identity in (
        ("parameters", "name"),
        ("requirements", "id"),
        ("source_findings", "id"),
    ):
        values = [item[identity] for item in contract[collection]]
        duplicates = sorted({value for value in values if values.count(value) > 1})
        if duplicates:
            errors.append(f"/{collection}: duplicate {identity}(s): {', '.join(duplicates)}")
    return errors


def contract_template(evidence: dict[str, Any], *, name: str, target_format: str) -> dict[str, Any]:
    """Create an empty handoff for the agent; deliberately infer no requirements."""

    return {
        "contract_version": CONTRACT_VERSION,
        "source_evidence_sha256": evidence_fingerprint(evidence),
        "artifact": {"name": name, "purpose": "", "target_format": target_format},
        "parameters": [],
        "requirements": [],
        "source_findings": [],
        "approval": {"status": "pending", "approved_by": "", "approved_at": ""},
    }


def readiness_findings(contract: Any, evidence: dict[str, Any]) -> list[str]:
    """Explain why a structurally valid contract may not gate a build yet."""

    errors = validate_contract(contract)
    if errors:
        return errors

    findings: list[str] = []
    expected = evidence_fingerprint(evidence)
    if contract["source_evidence_sha256"] != expected:
        findings.append("source evidence changed after the contract was authored")
    if evidence.get("package", {}).get("truncated"):
        findings.append("package evidence was truncated, so the contract does not account for every supplied file")
    if not contract["requirements"]:
        findings.append("the agent has not authored any fidelity requirements")
    approval = contract["approval"]
    if approval["status"] != "approved":
        findings.append("the customer has not approved the fidelity contract")
    if approval["status"] == "approved" and (not approval["approved_by"] or not approval["approved_at"]):
        findings.append("an approved contract must record who approved it and when")

    for finding in contract["source_findings"]:
        disposition = finding["disposition"]
        if disposition == "pending":
            findings.append(f"{finding['id']} has no customer decision")
        elif disposition == "block":
            findings.append(f"{finding['id']} deliberately blocks automation: {finding['resolution']}")
        elif not finding["resolution"]:
            findings.append(f"{finding['id']} has a decision but no resolution")
        elif not finding["approved_by"]:
            findings.append(f"{finding['id']} has a decision but no approver")
    return findings
