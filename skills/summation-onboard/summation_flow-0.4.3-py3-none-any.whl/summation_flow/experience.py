"""Durable customer-experience records layered on the onboarding run.

The stage graph remains the execution model.  This module owns the smaller set of facts a host
needs to orient a customer, record a scoped permission, promote an exact candidate, and explain
what the independent fidelity assessment proved.  Every record is content-addressed; the stable
artifact name is only a pointer to the latest immutable revision.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import time
from pathlib import Path
from typing import Any

from . import settings
from .operations import latest as latest_operations
from .state import Run, _atomic_write, sha256_file


PRODUCT_MAP_CHECKED_AT = "2026-07-30"
RECORDS_VERSION = "journey-records/v1"


def canonical_sha256(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"),
                         ensure_ascii=False, default=str).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _without_sha(payload: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in payload.items() if key != "sha256"}


def record_sha256(payload: dict[str, Any]) -> str:
    return canonical_sha256(_without_sha(payload))


def write_record(run: Run, name: str, payload: dict[str, Any], *, event: str | None = None) -> dict:
    """Write a stable record plus an immutable revision and update the small run snapshot."""

    body = dict(payload)
    body.setdefault("record_version", RECORDS_VERSION)
    body["sha256"] = record_sha256(body)
    stable = run.artifacts / name
    revision = run.artifacts / "records" / Path(name).stem / f"{body['sha256']}.json"
    encoded = json.dumps(body, indent=2, sort_keys=True, default=str) + "\n"
    if not revision.exists():
        _atomic_write(revision, encoded)
    _atomic_write(stable, encoded)

    refs = dict(getattr(run, "artifact_refs", {}) or {})
    previous = refs.get(name)
    refs[name] = {
        "sha256": body["sha256"],
        "path": str(revision.relative_to(run.dir)),
    }
    run.artifact_refs = refs
    run.save()
    if event and (not previous or previous.get("sha256") != body["sha256"]):
        run.append_event(event, artifact=name, sha256=body["sha256"],
                         supersedes=(previous or {}).get("sha256"))
    return body


def read_record(run: Run, name: str) -> dict[str, Any]:
    body = run.read(name)
    digest = record_sha256(body)
    if body.get("sha256") != digest:
        raise SystemExit(f"{name} changed after it was recorded; regenerate it before continuing")
    ref = (getattr(run, "artifact_refs", {}) or {}).get(name) or {}
    if ref and ref.get("sha256") != digest:
        raise SystemExit(f"{name} no longer matches the run checkpoint; regenerate it")
    return body


def _profile_readiness(profile: str) -> dict[str, Any]:
    cfg = settings.profile_config(profile)
    configured = bool(cfg.get("base_url"))
    authenticated = bool(
        cfg.get("device_login_credential") or cfg.get("access_token")
        or (cfg.get("client_id") and cfg.get("client_secret"))
    )
    return {
        "profile": profile,
        "base_url_configured": configured,
        "credential_configured": authenticated,
        "remote_availability": "unknown" if configured and authenticated else "unavailable",
        "evidence": "local Summation profile configuration only; no remote capability was assumed",
    }


def capability_preflight(run: Run) -> dict[str, Any]:
    """Describe product maturity separately from what this tenant has proven available."""

    readiness = _profile_readiness(run.profile)
    remote = readiness["remote_availability"]
    checked_at = time.strftime("%Y-%m-%dT%H:%M:%S")
    capabilities = [
        {
            "key": "reports", "maturity": "SHIPPED", "tenant_availability": remote,
            "invocation": ["CLI", "REST", "MCP"],
            "fallback": "Build and assess the local candidate before a platform report is available.",
        },
        {
            "key": "skills", "maturity": "SHIPPED", "tenant_availability": "available",
            "invocation": ["agent skill"],
            "fallback": "Use the supplied code and resources directly when no reusable skill exists.",
        },
        {
            "key": "report-verification", "maturity": "SHIPPED for reports",
            "tenant_availability": remote, "invocation": ["CLI", "REST", "MCP"],
            "fallback": "Use this flow's independent artifact-fidelity assessment and name the mechanism.",
        },
        {
            "key": "scheduling-delivery", "maturity": "SHIPPED",
            "tenant_availability": remote, "invocation": ["REST", "MCP"],
            "fallback": "Leave a completion receipt and scheduling instructions; sumcli has no schedule group.",
        },
        {
            "key": "playbook-ui", "maturity": "GATED", "tenant_availability": "unknown",
            "invocation": ["UI", "REST", "agent tool"],
            "fallback": "Use the confirmed API/agent path and do not promise UI review.",
        },
        {
            "key": "connectors", "maturity": "SHIPPED; UI gated; provisioning dependent",
            "tenant_availability": "unknown", "invocation": ["CLI", "REST", "MCP", "UI"],
            "fallback": "Reuse saved access, request an export, or continue with a data-free draft.",
        },
        {
            "key": "knowledge-ui", "maturity": "GATED", "tenant_availability": "unknown",
            "invocation": ["UI", "agent read tools"],
            "fallback": "Use a clearly named project-file knowledge folder; do not call it publication to Knowledge.",
        },
        {
            "key": "sharing-invites", "maturity": "GATED", "tenant_availability": "unknown",
            "invocation": ["UI"],
            "fallback": "Open the real Share surface and ask the customer to complete sharing in the app.",
        },
    ]
    payload = {
        "preflight_version": "capability-preflight/v1",
        "checked_at": checked_at,
        "product_map_checked_at": PRODUCT_MAP_CHECKED_AT,
        "profile_readiness": readiness,
        "capabilities": capabilities,
        "warnings": [
            "Remote tenant availability is not proven until the named invocation path succeeds.",
            "This run resumes on the same machine and flow-state directory, not on another device.",
        ],
    }
    saved = write_record(run, "preflight.json", payload, event="capability.preflighted")
    run.capability_snapshot_digest = saved["sha256"]
    run.save()
    return saved


def journey_plan(run: Run, preflight: dict[str, Any]) -> dict[str, Any]:
    meta = run.read("input.json")
    evidence = run.read("evidence.json")
    source = evidence.get("source") or {}
    payload = {
        "plan_version": "journey-plan/v1",
        "outcome": {
            "name": run.name,
            "statement": f"Recreate {run.name} as a repeatable Summation playbook and prove the finished output against the approved fidelity contract.",
        },
        "known_inputs": {
            "reference_artifact": source.get("name"),
            "reference_format": source.get("format") or meta.get("format"),
            "package_file_count": (evidence.get("package") or {}).get("file_count", 0),
            "code_supplied_separately": bool(evidence.get("supplemental_packages")),
        },
        "phases": [
            {"number": 1, "title": "Define the outcome"},
            {"number": 2, "title": "Understand the source"},
            {"number": 3, "title": "Resolve data and knowledge"},
            {"number": 4, "title": "Agree on fidelity"},
            {"number": 5, "title": "Build the playbook"},
            {"number": 6, "title": "Ship, run, and verify"},
            {"number": 7, "title": "Automate and hand off"},
        ],
        "first_useful_result": "A source map and independent cold assessment before live data access is required.",
        "possible_platform_changes": [
            "create or reuse the named project", "create or reuse read-only data access",
            "upload project files used as knowledge context", "deploy the approved playbook candidate",
            "run it once", "offer a schedule", "open the in-app sharing handoff",
        ],
        "permission_groups": ["Data", "Promote", "Automate"],
        "resume_scope": "same-machine",
        "capability_snapshot_sha256": preflight["sha256"],
        "assumptions": [],
        "out_of_scope": ["Cross-device continuation before a server-backed canonical run exists."],
    }
    return write_record(run, "journey-plan.json", payload, event="journey.planned")


def source_map(run: Run) -> dict[str, Any]:
    evidence = run.read("evidence.json")
    meta = run.read("input.json")
    optional: dict[str, Any] = {}
    for name, key in (("ledger.json", "ledger"), ("survey.json", "survey"),
                      ("findings.json", "cold_assessment")):
        try:
            optional[key] = run.read(name)
        except SystemExit:
            pass
    survey = optional.get("survey") or {}
    ledger = optional.get("ledger") or {}
    payload = {
        "source_map_version": "source-map/v1",
        "source_evidence_sha256": canonical_sha256(evidence),
        "reference_artifact": meta.get("document"),
        "extraction": meta.get("extraction"),
        "package": {
            "file_count": (evidence.get("package") or {}).get("file_count", 0),
            "truncated": (evidence.get("package") or {}).get("truncated", False),
            "supplemental": sorted((evidence.get("supplemental_packages") or {}).keys()),
        },
        "requirements_found": len(ledger.get("claims") or ledger.get("requirements") or []),
        "tables_found": [item.get("name") for item in survey.get("tables") or []],
        "literal_count": len(survey.get("literals") or []),
        "available_evidence": sorted(optional),
    }
    return write_record(run, "source-map.json", payload, event="source.mapped")


def create_front_door(run: Run) -> tuple[dict, dict, dict]:
    preflight = capability_preflight(run)
    plan = journey_plan(run, preflight)
    mapped = source_map(run)
    return preflight, plan, mapped


def render_front_door(run: Run) -> str:
    plan = read_record(run, "journey-plan.json")
    preflight = read_record(run, "preflight.json")
    inputs = plan["known_inputs"]
    readiness = preflight["profile_readiness"]
    access = ("configured; availability will be confirmed before a write"
              if readiness["remote_availability"] == "unknown"
              else "not configured yet; live access can wait until Phase 3")
    return "\n".join((
        f"Journey — {plan['outcome']['name']}",
        f"Outcome: {plan['outcome']['statement']}",
        "Stages: Define → Understand → Resolve data → Agree on fidelity → Build → Ship and verify → Automate and hand off",
        f"First useful result: {plan['first_useful_result']}",
        f"Starting evidence: {inputs['package_file_count']} supplied file(s); profile access is {access}",
        "Permissions: connect, upload, deploy, and first run require recorded scoped approval; scheduling and sharing remain explicit customer handoffs.",
        "Resume: progress is saved after every stage and can be resumed on this machine.",
    ))


def _latest_event(run: Run, event: str, *, key: str | None = None,
                  value: str | None = None) -> dict[str, Any] | None:
    matches = [item for item in run.events() if item.get("event") == event]
    if key is not None:
        matches = [item for item in matches if item.get(key) == value]
    return matches[-1] if matches else None


def record_decision(run: Run, *, kind: str, question: str, choices: list[str],
                    recommendation: str, binding: dict[str, Any], choice: str | None,
                    actor: str | None = None) -> dict[str, Any]:
    if choice is not None and choice not in choices:
        raise SystemExit(f"{choice!r} is not a valid choice for {kind}: {', '.join(choices)}")
    decision_id = "dec-" + canonical_sha256({"kind": kind, "binding": binding})[:16]
    record_name = f"decision-{decision_id}.json"
    try:
        existing = read_record(run, record_name)
    except SystemExit:
        existing = None
    if (existing and existing.get("state") == "answered"
            and existing.get("choice") == choice
            and (not actor or existing.get("actor") == actor)):
        return existing
    previous = _latest_event(run, "decision.requested", key="decision_id", value=decision_id)
    if not previous:
        run.append_event("decision.requested", decision_id=decision_id, kind=kind,
                         question=question, choices=choices, recommendation=recommendation,
                         binding_sha256=canonical_sha256(binding))
    body = {
        "decision_version": "journey-decision/v1", "decision_id": decision_id,
        "kind": kind, "question": question, "choices": choices,
        "recommendation": recommendation, "binding": binding,
        "state": "answered" if choice else "open", "choice": choice,
        "actor": actor, "answered_at": time.strftime("%Y-%m-%dT%H:%M:%S") if choice else None,
    }
    write_record(run, record_name, body)
    open_ids = list(getattr(run, "open_decision_ids", []) or [])
    if choice:
        open_ids = [value for value in open_ids if value != decision_id]
        run.append_event("decision.answered", decision_id=decision_id, kind=kind,
                         choice=choice, actor=actor or "customer via conducting agent",
                         binding_sha256=canonical_sha256(binding))
    elif decision_id not in open_ids:
        open_ids.append(decision_id)
    run.open_decision_ids = open_ids
    run.save()
    return body


def permission_scope(run: Run, group: str) -> dict[str, Any]:
    target = (getattr(run, "bindings", {}) or {}).get("project_target")
    if not target:
        target = f"project:{run.project_id}" if run.project_id else f"create:onboarding-{run.run_id}"
    if target.startswith("project:") and run.project_id and target != f"project:{run.project_id}":
        target = f"project:{run.project_id}"
    elif target.startswith("create:") and run.project_id:
        created_here = any(item.get("kind") == "project" and item.get("id") == run.project_id
                           for item in (getattr(run, "created_objects", []) or []))
        if not created_here:
            # A logical permission to create onboarding-X may follow the project it created. It
            # may not be silently redirected to some other project id later.
            target = f"unbound-project:{run.project_id}"
    # A profile name and API host are not a stable tenant boundary: browser login can replace
    # the credential under that profile with one for a different organization. Once whoami has
    # identified the tenant, every later permission is bound to its immutable id as well.
    tenant_ack = getattr(run, "tenant_ack", {}) or {}
    common = {
        "profile": run.profile,
        "base_url": settings.base_url(run.profile),
        "tenant_id": tenant_ack.get("tenant_id"),
        "tenant_name": tenant_ack.get("tenant_name"),
        "org_id": tenant_ack.get("org_id"),
        "target_project": target,
    }
    if group == "data":
        request = run.read("access-request.json")
        choice = request.get("choice")
        actions = ["create project if needed", "upload reviewed context as project files"]
        if choice == "connect":
            actions.insert(1, "reuse or create read-only data access")
        elif choice == "export":
            actions.insert(1, "use only the customer-provided export")
        elif choice == "skip":
            actions.insert(1, "continue without live data and mark dependent results unverified")
        scope = {
            **common, "group": "data", "source_sha256": canonical_sha256(run.read("evidence.json")),
            "access_choice": choice,
            "actions": actions,
        }
        if choice == "export":
            try:
                scope["export_sha256"] = run.read("data-export-evidence.json")["evidence_sha256"]
            except SystemExit:
                scope["export_sha256"] = None
        return scope
    if group == "promote":
        preview = read_record(run, "preview-receipt.json")
        return {
            **common, "group": "promote", "candidate_sha256": preview["candidate"]["sha256"],
            "preview_sha256": preview["sha256"], "contract_sha256": preview["contract_sha256"],
            "actions": ["deploy this exact candidate", "run it once"],
        }
    raise SystemExit(f"unknown permission group {group!r}")


def request_permission(run: Run, group: str) -> dict[str, Any]:
    scope = permission_scope(run, group)
    permission_id = "grant-" + canonical_sha256(scope)[:16]
    record_name = f"permission-{permission_id}.json"
    if permission_id in (getattr(run, "active_permission_ids", []) or []):
        return read_record(run, record_name)
    current = _latest_event(run, "permission.requested", key="permission_id", value=permission_id)
    if not current:
        run.append_event("permission.requested", permission_id=permission_id, group=group,
                         scope_sha256=canonical_sha256(scope))
    body = {
        "permission_version": "journey-permission/v1", "permission_id": permission_id,
        "group": group, "scope": scope, "state": "requested", "actor": None,
        "granted_at": None, "expiry": "when any bound scope value changes",
    }
    write_record(run, record_name, body)
    open_ids = list(getattr(run, "open_permission_ids", []) or [])
    if permission_id not in open_ids:
        open_ids.append(permission_id)
    run.open_permission_ids = open_ids
    run.save()
    return body


def grant_permission(run: Run, group: str, actor: str | None = None) -> dict[str, Any]:
    actor = (actor or "").strip()
    if not actor:
        if group == "data":
            # Saying "connect", "export", or "skip" in the active onboarding session is the
            # approval. The scoped grant and timestamp are the useful audit evidence; asking the
            # same person to type their name adds friction without adding authority.
            actor = "customer via current session"
        else:
            raise SystemExit("--by must name the person who approved this permission")
    requested = request_permission(run, group)
    if requested.get("state") == "granted":
        return requested
    requested.update(state="granted", actor=actor.strip(),
                     granted_at=time.strftime("%Y-%m-%dT%H:%M:%S"))
    write_record(run, f"permission-{requested['permission_id']}.json", requested)
    run.append_event("permission.granted", permission_id=requested["permission_id"],
                     group=group, actor=actor.strip(),
                     scope_sha256=canonical_sha256(requested["scope"]))
    run.open_permission_ids = [value for value in (getattr(run, "open_permission_ids", []) or [])
                               if value != requested["permission_id"]]
    active = list(getattr(run, "active_permission_ids", []) or [])
    if requested["permission_id"] not in active:
        active.append(requested["permission_id"])
    run.active_permission_ids = active
    run.save()
    return requested


def grant_low_risk_data_choice(run: Run) -> dict[str, Any] | None:
    """Turn a customer's data-path choice into its matching low-risk grant.

    This shortcut is intentionally narrow: a newly created onboarding project plus read-only
    connect/skip. Existing projects and exports still use the explicit permission command because
    their visibility or exact file binding is not known at choice time.
    """
    request = run.read("access-request.json")
    if request.get("choice") not in {"connect", "skip"}:
        return None
    scope = permission_scope(run, "data")
    if not str(scope.get("target_project") or "").startswith("create:"):
        return None
    return grant_permission(run, "data")


def require_permission(run: Run, group: str) -> dict[str, Any]:
    requested = request_permission(run, group)
    if requested["permission_id"] not in (getattr(run, "active_permission_ids", []) or []):
        label = "data access and reviewed context" if group == "data" else "the exact reviewed candidate"
        command = (f"summation-flow permit data --run {run.run_id}" if group == "data" else
                   f"summation-flow permit promote --by <name> --run {run.run_id}")
        raise SystemExit(
            f"paused for customer permission: {label} is ready, but no current {group} grant covers it.\n"
            f"    After the customer approves, record it with: {command}")
    body = read_record(run, f"permission-{requested['permission_id']}.json")
    if body.get("state") != "granted" or body.get("scope") != requested["scope"]:
        raise SystemExit(f"the saved {group} permission is stale; ask again for the current scope")
    return body


def tree_sha256(root: str | Path) -> str:
    base = Path(root)
    digest = hashlib.sha256()
    for path in sorted(item for item in base.rglob("*") if item.is_file()):
        rel = path.relative_to(base).as_posix().encode("utf-8")
        digest.update(len(rel).to_bytes(4, "big")); digest.update(rel)
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1 << 20), b""):
                digest.update(chunk)
    return digest.hexdigest()


def _seal_tree(run: Run, bundle: Path, digest: str) -> Path:
    root = run.artifacts / "candidates" / digest
    sealed = root / bundle.name
    if sealed.exists():
        if tree_sha256(sealed) != digest:
            raise SystemExit(f"the sealed candidate {digest[:12]} is corrupt; rebuild it")
        return sealed
    root.parent.mkdir(parents=True, exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix=f".{digest[:12]}-", dir=root.parent))
    try:
        copied = temp / bundle.name
        shutil.copytree(bundle, copied)
        if tree_sha256(copied) != digest:
            raise SystemExit("candidate changed while it was being sealed; run build again")
        os.replace(temp, root)
    finally:
        if temp.exists():
            shutil.rmtree(temp)
    for path in sorted(root.rglob("*"), reverse=True):
        try:
            path.chmod(0o555 if path.is_dir() else 0o444)
        except OSError:
            pass
    return sealed


def create_preview(run: Run, bundle: str | Path) -> dict[str, Any]:
    source = Path(bundle).resolve()
    digest = tree_sha256(source)
    sealed = _seal_tree(run, source, digest)
    contract = run.read("fidelity-contract.json")
    try:
        lint = run.read("lint.json")
    except SystemExit:
        lint = {"findings": [], "dry_run": {"state": "not recorded"}}
    payload = {
        "preview_version": "candidate-preview/v1",
        "candidate": {
            "sha256": digest, "build_revision": int((run.revisions or {}).get("build", 0)) + 1,
            "source_path": str(source), "sealed_path": str(sealed),
        },
        "source_evidence_sha256": canonical_sha256(run.read("evidence.json")),
        "contract_sha256": canonical_sha256(contract),
        "outputs": (run.read("build.json") if (run.artifacts / "build.json").exists() else {}).get("formats", []),
        "checks": {
            "lint_ok": not bool(lint.get("findings")),
            "finding_count": len(lint.get("findings") or []),
            "dry_run": lint.get("dry_run"),
        },
        "target": {"profile": run.profile,
                   "project": getattr(run, "project_id", "") or f"new project onboarding-{run.run_id}"},
        "proposed_changes": ["create the target project if needed", "upload one playbook bundle",
                             "register the playbook", "run it once"],
        "limitations": ["This is a sealed local candidate, not a separate Summation preview environment.",
                        "Platform-only checks remain pending until promotion and the first run."],
    }
    previous = getattr(run, "preview_receipt_digest", "")
    saved = write_record(run, "preview-receipt.json", payload, event="preview.ready")
    run.preview_receipt_digest = saved["sha256"]
    if previous and previous != saved["sha256"]:
        run.append_event("permission.superseded", group="promote", reason="candidate changed",
                         previous_preview_sha256=previous, preview_sha256=saved["sha256"])
    run.save()
    request_permission(run, "promote")
    return saved


def require_preview(run: Run) -> tuple[dict[str, Any], Path]:
    preview = read_record(run, "preview-receipt.json")
    source = Path(preview["candidate"]["source_path"])
    sealed = Path(preview["candidate"]["sealed_path"])
    expected = preview["candidate"]["sha256"]
    if not source.exists() or tree_sha256(source) != expected:
        raise SystemExit("the authored bundle changed after preview; rebuild and approve the new candidate")
    if not sealed.exists() or tree_sha256(sealed) != expected:
        raise SystemExit("the sealed preview candidate is missing or changed; rebuild it")
    return preview, sealed


def _proof_result(assessment: dict[str, Any]) -> str:
    statuses = {item.get("status") for item in assessment.get("results") or []}
    if "fail" in statuses or assessment.get("unexplained_differences"):
        return "fail"
    if statuses == {"pass"}:
        return "pass"
    return "inconclusive"


def proof_packet(run: Run) -> dict[str, Any]:
    """Compose the existing fidelity evidence into one auditable, format-neutral packet."""

    contract = run.read("fidelity-contract.json")
    source = run.read("evidence.json")
    output = run.read("output-evidence.json")
    diff = run.read("observable-diff.json")
    assessment = run.read("fidelity-assessment.json")
    handoff = run.read("independent-verification.json")
    try:
        data_export = run.read("data-export-evidence.json")
    except SystemExit:
        data_export = {}
    result_rows = assessment.get("results") or []
    actual = {item.get("requirement_id"): item for item in result_rows if item.get("requirement_id")}
    expected_ids = {item["id"] for item in contract.get("requirements") or []}
    result_ids = [item.get("requirement_id") for item in result_rows]
    integrity_findings = []
    duplicates = sorted({value for value in result_ids if value and result_ids.count(value) > 1})
    unknown = sorted(set(actual) - expected_ids)
    if duplicates:
        integrity_findings.append(f"duplicate assessment results: {', '.join(duplicates)}")
    if unknown:
        integrity_findings.append(f"assessment results for unknown requirements: {', '.join(unknown)}")
    requirements = []
    for expected in contract.get("requirements") or []:
        result = actual.get(expected["id"]) or {
            "requirement_id": expected["id"], "status": "inconclusive", "method": "not run",
            "verified_by": "", "verified_at": "", "evidence": "", "notes": "missing result",
        }
        requirements.append({
            "id": expected["id"], "statement": expected["statement"],
            "critical": expected["critical"], "approved_method": expected["verification"]["method"],
            "status": result.get("status"), "verifier": result.get("verifier"),
            "verified_by": result.get("verified_by"), "verified_at": result.get("verified_at"),
            "evidence": result.get("evidence"), "notes": result.get("notes"),
        })
        if result.get("method") != expected["verification"]["method"]:
            integrity_findings.append(
                f"{expected['id']} used {result.get('method') or 'no method'}, not the approved "
                f"{expected['verification']['method']} method"
            )
    overall = _proof_result(assessment)
    if integrity_findings and overall == "pass":
        overall = "inconclusive"
    try:
        preview = read_record(run, "preview-receipt.json")
        candidate_sha256 = preview["candidate"]["sha256"]
        preview_sha256 = preview["sha256"]
    except SystemExit:
        # Earlier/fixture runs can reach fidelity without the new promotion boundary. Preserve
        # their assessment, but say exactly what the packet is bound to instead of fabricating
        # a preview receipt.
        candidate_sha256 = canonical_sha256(output)
        preview_sha256 = None
    try:
        deployment = run.read("deploy.json")
    except SystemExit:
        deployment = {}
    try:
        platform_run = run.read("run.json")
    except SystemExit:
        platform_run = {}
    provenance_limitations = sorted(set(
        list(deployment.get("not_proven") or []) + list(platform_run.get("not_proven") or [])
    ))
    simulated_boundaries = sorted(set(filter(None, (
        deployment.get("test_boundary"), platform_run.get("test_boundary")
    ))))
    if simulated_boundaries or provenance_limitations:
        description = ", ".join(provenance_limitations) or "platform execution"
        integrity_findings.append(
            f"platform provenance is not proven ({description}); boundary: "
            f"{', '.join(simulated_boundaries) or 'unspecified'}"
        )
        if overall == "pass":
            overall = "inconclusive"
    payload = {
        "proof_version": "artifact-fidelity-proof/v1", "overall_result": overall,
        "mechanism": "Independent requirement-by-requirement artifact-fidelity assessment bound to deterministic source and output evidence.",
        "references": {
            "run_id": run.run_id, "profile": run.profile, "project_id": run.project_id or None,
            "playbook_id": deployment.get("playbook_id"), "platform_run": platform_run,
        },
        "verification": {
            "assessment_version": assessment.get("assessment_version"),
            "handoff_version": handoff.get("packet_version"),
            "verified_by": sorted({item.get("verified_by") for item in result_rows
                                   if item.get("verified_by")}),
            "verified_at": sorted({item.get("verified_at") for item in result_rows
                                   if item.get("verified_at")}),
        },
        "provenance": {
            "boundaries": simulated_boundaries,
            "not_proven": provenance_limitations,
            "candidate_deployment_recorded": bool(deployment.get("playbook_id")),
            "platform_run_recorded": bool(platform_run),
        },
        "bindings": {
            "source_evidence_sha256": canonical_sha256(source),
            "data_export_sha256": data_export.get("evidence_sha256"),
            "contract_sha256": canonical_sha256(contract),
            "candidate_sha256": candidate_sha256,
            "preview_receipt_sha256": preview_sha256,
            "output_evidence_sha256": canonical_sha256(output),
            "observable_diff_sha256": canonical_sha256(diff),
            "assessment_sha256": canonical_sha256(assessment),
            "independent_handoff_sha256": handoff.get("sha256"),
        },
        "requirements": requirements,
        "discrepancies": list(assessment.get("unexplained_differences") or []),
        "integrity_findings": integrity_findings,
        "checks_not_run": [item["id"] for item in requirements if item["status"] != "pass"],
        "evidence_files": {
            "source": "evidence.json", "contract": "fidelity-contract.json",
            "output": "output-evidence.json", "observable_diff": "observable-diff.json",
            "assessment": "fidelity-assessment.json", "verifier_handoff": "independent-verification.json",
            "deployment": "deploy.json", "platform_run": "run.json",
        },
    }
    if data_export:
        payload["evidence_files"]["data_export"] = "data-export-evidence.json"
    saved = write_record(run, "proof-packet.json", payload, event="verification.completed")
    validate_proof(saved)
    run.proof_packet_digest = saved["sha256"]
    run.save()
    _atomic_write(run.artifacts / "proof-receipt.md", render_proof_receipt(saved) + "\n")
    return saved


def validate_proof(packet: dict[str, Any]) -> None:
    ids = [item.get("id") for item in packet.get("requirements") or []]
    if not ids or len(ids) != len(set(ids)):
        raise SystemExit("proof packet must contain every requirement exactly once")
    statuses = [item.get("status") for item in packet["requirements"]]
    if packet.get("overall_result") == "pass" and (
            any(status != "pass" for status in statuses) or packet.get("discrepancies")
            or packet.get("integrity_findings")):
        raise SystemExit("proof packet cannot pass while a requirement or discrepancy is unresolved")


def require_proof_pass(run: Run) -> dict[str, Any]:
    packet = read_record(run, "proof-packet.json")
    validate_proof(packet)
    if packet.get("overall_result") != "pass":
        raise SystemExit(
            f"the fidelity proof is {packet.get('overall_result')}; scheduling remains blocked until it passes")
    return packet


def render_proof_receipt(packet: dict[str, Any]) -> str:
    verification = packet.get("verification") or {}
    verified_by = ", ".join(verification.get("verified_by") or []) or "not recorded"
    lines = [
        "# Artifact fidelity proof receipt", "",
        f"**Result:** {packet['overall_result'].upper()}",
        f"**Mechanism:** {packet['mechanism']}",
        f"**Run:** `{packet['references']['run_id']}`",
        f"**Proof:** `{packet['sha256']}`",
        f"**Verified by:** {verified_by}", "", "## Requirements", "",
    ]
    for item in packet["requirements"]:
        evidence = item.get("evidence") or item.get("notes") or "No evidence recorded"
        lines.append(f"- **{item['id']} — {str(item['status']).upper()}**: {item['statement']} — {evidence}")
    if packet.get("discrepancies"):
        lines.extend(("", "## Unresolved discrepancies", ""))
        lines.extend(f"- {item.get('statement') or item}" for item in packet["discrepancies"])
    if packet.get("integrity_findings"):
        lines.extend(("", "## Proof integrity findings", ""))
        lines.extend(f"- {item}" for item in packet["integrity_findings"])
    provenance = packet.get("provenance") or {}
    if provenance.get("not_proven") or provenance.get("boundaries"):
        lines.extend(("", "## Provenance limitations", ""))
        lines.extend(f"- Not proven: {item}" for item in provenance.get("not_proven") or [])
        lines.extend(f"- Boundary: `{item}`" for item in provenance.get("boundaries") or [])
    export_binding = (packet.get("bindings") or {}).get("data_export_sha256")
    if export_binding:
        lines.extend(("", "## Customer data export", "", f"- Bound export: `{export_binding}`"))
    lines.extend((
        "",
        "The proof packet records digests for the source, any customer data export, contract, sealed candidate, output evidence, and independent assessment. Those bindings prevent substitution; they do not by themselves prove that a platform run produced the output, so any provenance limitation is listed above.",
    ))
    return "\n".join(lines)


def changes_view(run: Run) -> dict[str, Any]:
    """Reviewable local, decision, permission, object, and operation changes—never payloads."""

    local = []
    for name, ref in sorted((getattr(run, "artifact_refs", {}) or {}).items()):
        if name == "changeset.json":
            continue
        local.append({"artifact": name, "sha256": ref.get("sha256"), "path": ref.get("path")})
    referenced = {item["artifact"] for item in local}
    if run.artifacts.exists():
        for path in sorted(item for item in run.artifacts.rglob("*") if item.is_file()):
            relative = path.relative_to(run.artifacts)
            if (relative.parts[0] in {"records", "candidates"}
                    or relative.as_posix() == "changeset.json"
                    or relative.as_posix() in referenced):
                continue
            local.append({"artifact": relative.as_posix(), "sha256": sha256_file(path),
                          "path": str(path.relative_to(run.dir))})
    decisions = [{key: event.get(key) for key in
                  ("decision_id", "kind", "choice", "actor", "binding_sha256")}
                 for event in run.events() if event.get("event") == "decision.answered"]
    permissions = [{key: event.get(key) for key in
                    ("permission_id", "group", "actor", "scope_sha256")}
                   for event in run.events() if event.get("event") == "permission.granted"]
    operations = []
    for event in latest_operations(run).values():
        operations.append({key: event.get(key) for key in
                           ("operation_id", "stage", "action", "summary", "state",
                            "profile", "project_id", "object_ids")})
    return {
        "local_artifacts": local,
        "decisions": decisions,
        "permissions": permissions,
        "summation_objects": list(getattr(run, "created_objects", []) or []),
        "operations": sorted(operations, key=lambda item: item.get("operation_id") or ""),
    }


def write_changeset(run: Run) -> dict[str, Any]:
    return write_record(
        run,
        "changeset.json",
        {"changeset_version": "journey-changeset/v1", **changes_view(run)},
        event="changes.changed",
    )


def journey_facts(run: Run) -> dict[str, Any]:
    """Small, failure-tolerant projection used by every status renderer."""

    facts: dict[str, Any] = {
        "outcome": run.name, "plan_revision": 1, "capability_warnings": [],
        "current_decision": None, "permission_required": None,
        "preview": None, "proof": None, "resume_scope": "same-machine",
        "changes": changes_view(run),
    }
    try:
        plan = read_record(run, "journey-plan.json")
        facts["outcome"] = plan["outcome"]["name"]
        facts["resume_scope"] = plan.get("resume_scope", "same-machine")
    except SystemExit:
        pass
    try:
        facts["capability_warnings"] = read_record(run, "preflight.json").get("warnings") or []
    except SystemExit:
        pass
    open_decisions = getattr(run, "open_decision_ids", []) or []
    if open_decisions:
        try:
            facts["current_decision"] = read_record(run, f"decision-{open_decisions[-1]}.json")
        except SystemExit:
            pass
    open_permissions = getattr(run, "open_permission_ids", []) or []
    if open_permissions:
        try:
            facts["permission_required"] = read_record(run, f"permission-{open_permissions[-1]}.json")
        except SystemExit:
            pass
    try:
        preview = read_record(run, "preview-receipt.json")
        facts["preview"] = {"sha256": preview["sha256"],
                            "candidate_sha256": preview["candidate"]["sha256"]}
    except SystemExit:
        pass
    try:
        proof = read_record(run, "proof-packet.json")
        facts["proof"] = {"sha256": proof["sha256"], "result": proof["overall_result"]}
    except SystemExit:
        pass
    return facts
