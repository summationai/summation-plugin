"""One local owner for a run at a time.

The current checkpoint is intentionally portable between Claude and Codex on the same machine.
An advisory filesystem lock prevents both from advancing it simultaneously; the kernel releases
the lock if its process dies, so there is no stale lock to clean up by hand.
"""
from __future__ import annotations

import fcntl
import json
import os
import socket
import time
import uuid

from .state import Run


class RunBusy(RuntimeError):
    pass


class RunLease:
    def __init__(self, run: Run):
        self.run = run
        self.path = run.dir / "lease.json"
        self.file = None
        self.token = uuid.uuid4().hex

    def __enter__(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open("a+")
        try:
            fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            self.file.seek(0)
            try:
                owner = json.loads(self.file.read() or "{}").get("owner", "another agent")
            except json.JSONDecodeError:
                owner = "another agent"
            self.file.close()
            self.file = None
            raise RunBusy(
                f"run {self.run.run_id} is already active in {owner}. "
                "Its checkpoint is safe; wait for that operation to finish before resuming here."
            ) from exc
        owner = f"{socket.gethostname()}:{os.getpid()}"
        body = {"run_id": self.run.run_id, "token": self.token, "owner": owner,
                "acquired_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        self.file.seek(0)
        self.file.truncate()
        self.file.write(json.dumps(body, indent=2) + "\n")
        self.file.flush()
        os.fsync(self.file.fileno())
        self.run.append_event("lease", state="acquired", token=self.token, owner=owner)
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.file is not None:
            self.run.append_event("lease", state="released", token=self.token)
            fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
            self.file.close()
            self.file = None
        return False
