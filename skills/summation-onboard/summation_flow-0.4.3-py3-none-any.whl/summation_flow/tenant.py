"""Who are we about to create things for, and does the run have approval for it?

The old guard asked the wrong question. It asked whether the HOST looked like staging, which is
answerable but not useful: a real customer's tenant is production, so a host allowlist blocks
every customer it is supposed to serve, and the only way through it was a bare `SF_ALLOW_HOST`
that acknowledged nothing in particular.

The boundary worth preserving is the exact tenant:

  * stages that only read are not gated at all — `parse`, `fanout`, `verify --cold`, `detect`,
    `advise`, `context`, `doctor`, `status` create nothing and should not need ceremony;
  * normal Data and Promote grants bind the verified tenant id as soon as one is available;
  * a write outside a current scoped grant falls back to an explicit tenant acknowledgement;
  * the acknowledgement is re-checked before every writing stage, and a run whose tenant has
    moved underneath it stops. Tenant surprise was the original incident, not production.

The non-interactive form names what it authorises. `SF_ACK_TENANT=alg-testing` acknowledges
`alg-testing` and nothing else; there is deliberately no switch that means "whatever is
configured", because that is the failure being designed out.
"""
from __future__ import annotations

import os
import sys
import time
from dataclasses import dataclass, asdict

from . import settings

#: Names exactly one profile, for CI and scored runs. An ack that does not say what it
#: acknowledges is the `SF_ALLOW_HOST` mistake wearing a different name.
ACK_ENV = "SF_ACK_TENANT"

#: Retired. Aliasing it would keep its meaning — "this host is fine" — which is the thing that
#: could not distinguish a customer's tenant from a stranger's.
RETIRED_ENV = "SF_ALLOW_HOST"


class TenantRefused(SystemExit):
    """Carries an actionable message; `cli.main` prints it and exits non-zero."""


class TenantNeedsAck(TenantRefused):
    """Not a failure — a question awaiting a human.

    The gate refuses to create things in a tenant nobody has confirmed. When it refuses because
    it *cannot ask* (non-interactive shell, no `SF_ACK_TENANT`), the old code raised a plain
    refusal that surfaced as `Error: Exit code 1` — a permission prompt wearing an error's
    clothes (U4). This subclass lets `cli.main` tell the two apart: a needs-ack pause prints
    calmly and exits 2, so an agent driving the flow reads "waiting on you", not "broken".

    Still a subclass of `TenantRefused`, so every `except TenantRefused` site — and the tests —
    keep catching it. The safety is unchanged: a human must still acknowledge the tenant.
    """

    #: `cli.main` returns this. 2 means "awaiting your confirmation"; 1 stays "failed".
    exit_code = 2

    def __init__(self, message: str):
        self.message = message
        super().__init__(message)


@dataclass(frozen=True)
class Tenant:
    profile: str
    base_url: str
    tenant_name: str = ""
    tenant_id: str = ""
    org_id: str = ""
    user_id: str = ""
    auth_mode: str = ""
    #: False when the profile came from the config file's `active_profile` rather than from the
    #: person. Worth saying out loud: on a machine whose active profile is a production tenant,
    #: an inherited profile is exactly how something gets created somewhere nobody chose.
    explicit: bool = True

    @property
    def label(self) -> str:
        return self.tenant_name or self.profile


def _explicit(profile_arg: str | None) -> bool:
    """Did a person name this tenant, or did it come from the config file?

    Note this must be asked of the RAW argument. `cli.main` resolves `--profile` early so every
    stage prints the same answer, and asking the resolved value made an inherited production
    profile indistinguishable from a chosen one — which is the exact case the banner exists for.
    """
    return bool(profile_arg) or bool(os.environ.get("SF_PROFILE"))


def resolve(profile_arg: str | None) -> Tenant:
    """Ask the platform who we are, rather than reading it off a config file.

    A config file says which credential to send. It cannot say which tenant that credential
    turns out to belong to, and that is the fact a person needs before agreeing to anything.
    """
    if os.environ.get(RETIRED_ENV):
        raise TenantRefused(
            f"{RETIRED_ENV} is retired. It named a host, which could not tell a customer's own "
            f"tenant apart from a stranger's.\n"
            f"    Name the tenant instead:  {ACK_ENV}=<profile> summation-flow ...")

    profile = settings.resolve_profile(profile_arg)
    base_url = settings.base_url(profile)
    if not base_url:
        raise TenantRefused(
            f"profile '{profile}' has no base_url in {settings.config_path()}.\n"
            f"    Set one with:  sumcli config set-profile {profile} --base-url <host>")

    ident: dict = {}
    auth_mode = ""
    try:
        from . import platform as P
        who = P.cli("auth", "whoami", profile=profile, timeout=60)
        ident = who.get("identity") or {}
        auth_mode = who.get("auth_mode") or ""
    except Exception:
        # Not fatal here. `doctor` is the place that reports a broken session; refusing to name
        # the tenant because whoami is down would block a run for the wrong reason.
        pass

    return Tenant(profile=profile, base_url=base_url,
                  tenant_name=str(ident.get("tenant_name") or ""),
                  tenant_id=str(ident.get("tenant_id") or ""),
                  org_id=str(ident.get("org_id") or ""),
                  user_id=str(ident.get("user_id") or ""),
                  auth_mode=auth_mode, explicit=_explicit(profile_arg))


# --------------------------------------------------------------------------- presentation
def banner(t: Tenant, action: str = "This run will create objects in") -> str:
    """Prominent on purpose. A person has to read the tenant's name before agreeing to it."""
    width = 74
    rule = "─" * width
    lines = [
        "",
        f"  ┌{rule}┐",
        f"  │ {action:<{width - 2}} │",
        f"  │ {'':<{width - 2}} │",
        f"  │ {('TENANT    ' + t.label):<{width - 2}} │",
        f"  │ {('PROFILE   ' + t.profile):<{width - 2}} │",
        f"  │ {('API       ' + t.base_url):<{width - 2}} │",
    ]
    if t.user_id:
        who = f"{t.user_id}" + (f"  ({t.auth_mode})" if t.auth_mode else "")
        lines.append(f"  │ {('IDENTITY  ' + who):<{width - 2}} │")
    else:
        lines.append(f"  │ {'IDENTITY  unknown — `sumcli auth whoami` did not answer':<{width - 2}} │")
    lines.append(f"  └{rule}┘")
    if not t.explicit:
        lines += [
            "",
            f"  ! You did not choose this tenant. It is the `active_profile` in",
            f"    {settings.config_path()}, which means it can change without you.",
            f"    Pass --profile {t.profile} to say it on purpose.",
        ]
    lines.append("")
    return "\n".join(lines)


# --------------------------------------------------------------------------- the gate
def acknowledge(t: Tenant) -> dict:
    """Get a human yes for this tenant, and return what to record.

    Typing the profile name rather than "y": the point is that the words are read. A y/N prompt
    is answered the same way whichever tenant is named, which is how the wrong answer stays
    available.
    """
    print(banner(t), file=sys.stderr)
    if not t.tenant_id:
        raise TenantRefused(
            f"cannot verify which tenant profile '{t.profile}' is authenticated to because "
            "`sumcli auth whoami` did not return a tenant id. Nothing will be created.\n"
            f"    Sign in with:  summation-flow login --profile {t.profile}\n"
            "    Then repeat the command; the banner must name the actual tenant before a write.")

    named = (os.environ.get(ACK_ENV) or "").strip()
    if named:
        accepted = {t.tenant_id, t.tenant_name}
        if t.profile == t.tenant_name:
            accepted.add(t.profile)
        if named not in accepted:
            raise TenantRefused(
                f"{ACK_ENV}={named!r} does not acknowledge the tenant returned by whoami: "
                f"'{t.label}' ({t.tenant_id}). The local profile is only named '{t.profile}'.\n"
                f"    Authenticate that profile to the intended tenant, or acknowledge this exact "
                f"tenant with {ACK_ENV}={t.tenant_name or t.tenant_id!r}.")
        return _record(t, how=f"{ACK_ENV}={named}")

    if not sys.stdin.isatty():
        raise TenantNeedsAck(
            f"Waiting for you to confirm the tenant. This run would create objects in "
            f"'{t.label}' ({t.base_url}), and stdin is not a terminal, so it cannot ask you here.\n"
            f"    This is a question, not an error. Once you have confirmed that is the right "
            f"tenant, set {ACK_ENV}={t.tenant_name or t.tenant_id!r} and run the same command again:\n"
            f"        {ACK_ENV}={t.tenant_name or t.tenant_id!r} summation-flow ...\n"
            f"    (exit code 2 means 'awaiting your confirmation', not 'failed'.)")

    try:
        typed = input(f"  type the tenant name to create things in {t.label} ({t.tenant_id}): ").strip()
    except (EOFError, KeyboardInterrupt):
        print(file=sys.stderr)
        raise TenantRefused("cancelled — nothing was created")
    if typed not in {t.tenant_name, t.tenant_id}:
        raise TenantRefused(
            f"got {typed!r}, expected {t.tenant_name or t.tenant_id!r} — cancelled, nothing was created")
    return _record(t, how="typed at init")


def _record(t: Tenant, how: str) -> dict:
    d = asdict(t)
    d["acknowledged_how"] = how
    d["acknowledged_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    return d


def acknowledge_from_permission(t: Tenant, permission: dict) -> dict:
    """Reuse an exact scoped approval as the tenant acknowledgement.

    A permission can replace a separate tenant prompt only when it is bound to the immutable
    tenant id, or on the first login when the actual tenant name exactly matches the profile the
    customer chose. A profile label and API host alone do not identify a tenant: browser login can
    authorize a different organization under the same local profile.
    """
    scope = permission.get("scope") or {}
    if permission.get("state") != "granted":
        raise TenantRefused("the tenant cannot be acknowledged from an ungranted permission")
    if not t.tenant_id:
        raise TenantRefused(
            "the tenant cannot be acknowledged because whoami did not return a tenant id; "
            "sign in and retry before any platform write")
    if scope.get("profile") != t.profile or scope.get("base_url") != t.base_url:
        raise TenantRefused(
            "the approved scope no longer matches the current tenant; ask again for the changed "
            "profile or API host")
    approved_tenant_id = scope.get("tenant_id")
    if approved_tenant_id and approved_tenant_id != t.tenant_id:
        raise TenantRefused(
            f"REFUSING: profile '{t.profile}' is now authenticated to {t.label} "
            f"({t.tenant_id}), not the approved tenant ({approved_tenant_id}). Nothing was created.")
    if not approved_tenant_id and scope.get("profile") != t.tenant_name:
        raise TenantRefused(
            f"REFUSING: the selected profile is named '{scope.get('profile')}', but browser login "
            f"authorized the actual tenant '{t.label}' ({t.tenant_id}). Nothing was created.\n"
            "    Sign out and authorize the intended workspace, then retry. A profile name is "
            "not proof of tenant identity.")
    return _record(t, how=f"scoped permission {permission.get('permission_id', 'unknown')}")


def require(run, profile_arg: str | None, stage: str) -> None:
    """Refuse a writing stage whose tenant is not the one that was acknowledged.

    This deliberately calls whoami before every writing stage. A profile and API host are not a
    tenant boundary: the credential stored under that profile can be replaced by browser login.
    If identity cannot be verified, the write pauses instead of making a promise it cannot keep.
    """
    ack = getattr(run, "tenant_ack", None) or {}
    if not ack:
        raise TenantRefused(
            f"run {run.run_id} has no acknowledged tenant, so '{stage}' will not write to one.\n"
            f"    This run predates the tenant gate. Start a new one:  summation-flow init "
            f"--input <dir>")

    current = resolve(profile_arg or ack.get("profile"))
    if not current.tenant_id:
        raise TenantRefused(
            f"REFUSING: '{stage}' cannot verify the current tenant for profile "
            f"'{current.profile}'. Nothing was written. Sign in again and retry.")
    if not ack.get("tenant_id"):
        raise TenantRefused(
            f"REFUSING: run {run.run_id} was acknowledged before tenant IDs were recorded, so "
            f"'{stage}' cannot safely write. Reconfirm the actual tenant in a new run.")
    if (current.profile == ack.get("profile") and current.base_url == ack.get("base_url")
            and current.tenant_id == ack.get("tenant_id")):
        return

    raise TenantRefused(
        f"REFUSING: '{stage}' would write to a different tenant than run {run.run_id} agreed to.\n"
        f"    agreed:  {ack.get('tenant_name') or ack.get('profile')}  "
        f"[{ack.get('profile')}]  {ack.get('base_url')}\n"
        f"    now:     {current.label}  [{current.profile}]  {current.base_url}  "
        f"({current.tenant_id or 'identity unknown'})\n"
        f"    Browser login can replace the credential under the same profile. Authenticate "
        f"profile '{ack.get('profile')}' to the agreed tenant before resuming.")
