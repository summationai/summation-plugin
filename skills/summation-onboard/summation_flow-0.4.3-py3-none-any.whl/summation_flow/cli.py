"""summation-flow — the thick CLI half of the onboarding flow.

Every subcommand is idempotent, writes an artifact, updates run state, and exits non-zero
with an actionable message. It never prompts and never prints a secret: judgment and
conversation belong to the skill (BUILD-SPEC §1.2).
"""
from __future__ import annotations
import argparse, difflib, os, sys, traceback
from . import __version__, experience, journey, settings, stages, tenant
from .lease import RunBusy, RunLease
from .state import Run


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="summation-flow",
                                description="Walk an artifact through onboarding, one stage per command.")
    # `--version` prints the package version and nothing else. Without it, `summation-flow
    # --version` fell through to the full usage block (U7) — and worse, the version string never
    # changing is why `uv tool install` reused a cached wheel across source edits.
    p.add_argument("--version", action="version", version=f"summation-flow {__version__}")
    p.add_argument("--profile", default=None,
                   help="which Summation profile to use. Defaults to SF_PROFILE, then the "
                        "config file's active_profile. Stages that create or destroy things "
                        "verify and bind the actual tenant id returned by whoami; an ambiguous "
                        "unapproved write asks for SF_ACK_TENANT=<actual tenant>.")
    p.add_argument("--run", default=None,
                   help="operate on this run id (e.g. sf-003). Without it, the most recent run "
                        "started on this machine is used — which another `init` can move.")
    # `--run` is accepted both before and after the subcommand, because either is a reasonable
    # guess and getting it wrong silently operates on someone else's run.
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--run", default=None, help="operate on this run id, e.g. sf-003")
    common.add_argument("--profile", default=None, help=argparse.SUPPRESS)
    sub = p.add_subparsers(dest="cmd", required=True)

    sub.add_parser("login", parents=[common],
                   help="open the device-login page and wait for browser approval")
    dr = sub.add_parser("doctor", parents=[common], help="check prerequisites before you begin")
    dr.add_argument("--config-file", default=None, help="connection file to validate (never printed)")
    i = sub.add_parser("init", parents=[common], help="start a run")
    i.add_argument("--input", required=True,
                   help="the report to onboard: a folder, a repo, or a single file in any "
                        "format. `demo` is the complex packaged fixture; `tiny` is the fast "
                        "end-to-end fixture.")
    artifact = i.add_mutually_exclusive_group()
    artifact.add_argument("--artifact", default=None,
                          help="primary reference artifact inside --input. Required when the "
                               "package contains several possible artifacts; no format is preferred.")
    artifact.add_argument("--no-artifact", action="store_true",
                          help="declare that the package contains resources/code but no reference "
                               "artifact; requirements will come from the customer conversation.")
    i.add_argument("--code", default=None,
                   help="the folder whose queries/config/skill BUILD this artifact. Use it when a "
                        "folder holds several processes: --input names the chosen report, --code "
                        "names its code, so the flow onboards that one process. Defaults to the "
                        "input folder.")
    i.add_argument("--project", help="existing project id; created if omitted")
    i.add_argument("--name", default=None,
                   help="customer-friendly name used in checkpoints and resume prompts")
    st = sub.add_parser("status", parents=[common], help="show where this run is")
    st.add_argument("--format", choices=("card", "detail", "json"), default="card")
    rs = sub.add_parser("runs", parents=[common], help="list saved onboarding runs")
    rs.add_argument("action", nargs="?", choices=("list",), default="list")
    rs.add_argument("--all", action="store_true", help="include completed and torn-down runs")
    sub.add_parser("resume", parents=[common],
                   help="select an unfinished run and show its saved checkpoint")
    sub.add_parser("evidence", parents=[common],
                   help="fingerprint the supplied artifact, code and package contents")
    pr = sub.add_parser("parse", parents=[common], help="document -> claim ledger")
    pr.add_argument("--from-ledger", dest="from_ledger", metavar="FILE",
                    help="accept a claim ledger written by the conducting agent, for an artifact "
                         "the deterministic parser cannot read. Validated against the shipped "
                         "contract before anything downstream may run on it.")
    f = sub.add_parser("fanout", parents=[common], help="survey + metric layer"); f.add_argument("--live", action="store_true")
    v = sub.add_parser("verify", parents=[common], help="run checks")
    g = v.add_mutually_exclusive_group(required=True)
    g.add_argument("--cold", action="store_true"); g.add_argument("--full", action="store_true")
    g.add_argument("--render", action="store_true",
                   help="check the produced report's tables actually resolve to data")
    g.add_argument("--fidelity", action="store_true",
                   help="compare a produced artifact against the approved fidelity contract")
    v.add_argument("--output", default=None,
                   help="local produced artifact or package to assess with --fidelity")
    v.add_argument("--assessment", default=None,
                   help="independent verifier assessment JSON to validate with --fidelity")
    ra = sub.add_parser("request-access", parents=[common],
                        help="render the evidenced access request")
    ra.add_argument("--choose", choices=["connect", "export", "skip"],
                    help="record which of the three offers the customer took")
    ra.add_argument("--by", default=None,
                    help=argparse.SUPPRESS)  # accepted for compatibility; never required
    pe = sub.add_parser("permit", parents=[common],
                        help="record a customer permission for an exact, current scope")
    pe.add_argument("group", choices=("data", "promote"))
    pe.add_argument("--by", default=None,
                    help="person who approved promotion; optional for data access")
    sub.add_parser("detect", parents=[common], help="find local metric layers and pre-fill a connection config")
    c = sub.add_parser("connect", parents=[common], help="reuse existing access, or create, test, attach, wait")
    source = c.add_mutually_exclusive_group()
    source.add_argument(
        "--config-file",
        default=None,
        help="warehouse connection config. Omit it when the required table is already queryable "
             "through the customer's saved Summation profile.",
    )
    source.add_argument(
        "--export-file",
        default=None,
        help="customer-provided file or directory for the export path. The first call fingerprints "
             "it locally; Data permission is then bound to that exact digest.",
    )
    o = sub.add_parser("output-target", parents=[common],
                       help="choose what the playbook produces: document, deck, page")
    o.add_argument("--format", action="append", choices=["sdoc", "sdeck", "html"],
                   help="repeatable — a playbook can produce more than one from the same data")
    # `--target` is the flag an agent reaches for, because the subcommand is `output-target`
    # (U8). It writes the same list as `--format`, so both may be mixed freely.
    o.add_argument("--target", action="append", dest="format", choices=["sdoc", "sdeck", "html"],
                   help=argparse.SUPPRESS)
    o.add_argument("--slides-file",
                   help="JSON slide plan, required for sdeck unless the input is already a deck")
    ct = sub.add_parser("contract", parents=[common],
                        help="create or validate the customer-approved fidelity contract")
    ct.add_argument("--from", dest="contract_file", default=None,
                    help="contract JSON authored after the customer review")
    sub.add_parser("scaffold", parents=[common],
                   help="create the empty .spb skeleton for the agent to author")
    ln = sub.add_parser("lint", parents=[common],
                        help="the deterministic gate on the authored bundle")
    ln.add_argument("--accept-literal", action="append", default=[], metavar="VALUE",
                    help="allow a surveyed literal to stay hardcoded — a decision about their "
                         "business, so it needs --accepted-by. Repeatable, and remembered.")
    ln.add_argument("--accepted-by", default=None,
                    help="who accepted those literals; recorded in the run")
    ln.add_argument("--param", action="append", default=[], metavar="NAME=VALUE",
                    help="a value for a query placeholder the manifest has no default for. "
                         "Queries that substitute cleanly are dry-run read-only.")
    ln.add_argument("--no-dry-run", action="store_true", dest="no_dry_run",
                    help="check the bundle without executing any SQL")
    b = sub.add_parser("build", parents=[common],
                       help="scaffold if needed, then lint; clean lint is the exit condition")
    b.add_argument("--param", action="append", default=None,
                     help="NAME=VALUE dry-run substitution, remembered from lint")
    b.add_argument("--from-template", action="store_true", dest="from_template",
                   help="copy the packaged demo bundle instead of building from their artifact. "
                        "For the eval baseline only — the output is labelled as the demo's.")
    # `build` deliberately carries none of lint's flags. Accepting a literal is a decision
    # somebody makes in the middle of the authoring loop, and the loop is `lint`.
    sub.add_parser("preview", parents=[common],
                   help="seal the exact built candidate and show the promotion boundary")
    sub.add_parser("deploy", parents=[common], help="upload the bundle, manifest last")
    sub.add_parser("run", parents=[common], help="trigger a platform-side run")
    pa = sub.add_parser("params", parents=[common], help="validate parameters against the manifest")
    pa.add_argument("--check", action="store_true", default=True)
    sc = sub.add_parser("schedule", parents=[common],
                        help="put the playbook on a schedule and leave it there")
    sc.add_argument("--cadence", default="weekly", choices=("weekly", "daily"))
    sc.add_argument("--day", default="MONDAY", help="weekly only")
    sc.add_argument("--at", default="09:00", help="HH:MM in --timezone")
    sc.add_argument("--timezone", default="America/New_York")
    sc.add_argument("--recipients", default=None, help="comma-separated email addresses")
    sc.add_argument("--recipients-from", default=None,
                    help="a CSV with an email column — often their own distribution list")
    sub.add_parser("share", parents=[common],
                   help="open the in-app sharing handoff without changing visibility")
    sub.add_parser("receipt", parents=[common],
                   help="show the current artifact-fidelity proof receipt")
    op = sub.add_parser("open", parents=[common], help="open an app object as evidence")
    op.add_argument("kind"); op.add_argument("--id", default=None)
    adv = sub.add_parser("advise", parents=[common],
                         help="what you do by hand repeatedly that should be a playbook")
    adv.add_argument("--top", type=int, default=5, help="how many candidates to show")
    adv.add_argument("--limit", type=int, default=300, help="how many recent sessions to read")
    ctx = sub.add_parser("context", parents=[common],
                         help="recover the context they already wrote down")
    ctx.add_argument("--sessions", action="store_true",
                     help="also read past Claude/Codex sessions (off by default)")
    ctx.add_argument("--upload", action="store_true",
                     help="put the recovered context into the project as knowledge")
    ctx.add_argument("--as-file", dest="as_file", default=None,
                     help="markdown filename inside /knowledge (default recovered-context.md)")
    rst = sub.add_parser("reset", parents=[common],
                         help="return the environment to a clean pre-run state")
    rst.add_argument("--yes", action="store_true",
                     help="skip the confirmation prompt (required to run non-interactively)")
    orp = sub.add_parser("orphans", parents=[common],
                         help="list connections teardown could not remove")
    orp.add_argument("--delete", action="store_true",
                     help="remove the ones with no dataset attached")
    td = sub.add_parser("teardown", parents=[common], help="remove everything this run created")
    td.add_argument("--yes", action="store_true",
                    help="skip the confirmation prompt (required to run non-interactively)")
    # Kept so a usage error can print ONE subcommand's options instead of all of them (U8).
    p._sf_sub = sub
    return p


def _usage_error(parser, args, extras: list[str]) -> int:
    """One subcommand's usage, not all 24, when a flag is unrecognised (U8).

    argparse's own behaviour on an unknown argument is to dump the whole program's usage block —
    every subcommand — for a one-word slip. That is what taught an agent nothing when it typed a
    near-miss flag. Here we name the failing subcommand, show only its options, and — where the
    stray flag is close to a real one — say which one it probably meant.
    """
    cmd = getattr(args, "cmd", None)
    subparser = getattr(parser, "_sf_sub", None)
    sp = (subparser.choices.get(cmd) if subparser and cmd else None)
    stray = extras[0]
    print(f"  ✗ unrecognized option {stray!r} for `{cmd or 'summation-flow'}`", file=sys.stderr)
    if sp is not None:
        # Suggest the closest real flag when the stray one is an obvious near-miss.
        options = [s for a in sp._actions for s in a.option_strings]
        near = difflib.get_close_matches(stray, options, n=1, cutoff=0.6)
        if near:
            print(f"    did you mean {near[0]}?", file=sys.stderr)
        print(sp.format_usage(), file=sys.stderr, end="")
    else:
        print(f"    run `summation-flow {cmd or ''} --help` for its options", file=sys.stderr)
    return 2


DISPATCH = {
    "login": stages.login, "doctor": stages.doctor, "init": stages.init, "status": stages.status,
    "runs": stages.runs, "resume": stages.resume,
    "evidence": stages.evidence,
    "parse": stages.parse, "fanout": stages.fanout, "verify": stages.verify,
    "request-access": stages.request_access, "detect": stages.detect,
    "permit": stages.permit,
    "connect": stages.connect, "output-target": stages.output_target,
    "contract": stages.contract,
    "scaffold": stages.scaffold, "lint": stages.lint,
    "build": stages.build, "preview": stages.preview, "deploy": stages.deploy, "run": stages.run,
    "params": stages.params, "schedule": stages.schedule, "share": stages.share,
    "receipt": stages.receipt,
    "advise": stages.advise, "context": stages.context,
    "open": stages.open_obj, "orphans": stages.orphans, "reset": stages.reset,
    "teardown": stages.teardown,
}

# Commands that advance durable onboarding state.  Read-only discovery and browser evidence do
# not need exclusive ownership; two agents must never advance the same run simultaneously.
LEASED_COMMANDS = {
    "evidence", "parse", "fanout", "verify", "request-access", "permit", "detect", "connect",
    "context", "output-target", "contract", "scaffold", "lint", "build", "deploy",
    "preview", "params", "run", "schedule", "share",
}
SIGNPOSTED_COMMANDS = LEASED_COMMANDS | {"init"}


def main(argv=None) -> int:
    parser = build_parser()
    argv = list(argv if argv is not None else sys.argv[1:])
    # `parse_known_args` so an unrecognised flag becomes a targeted, one-subcommand message
    # rather than argparse's full-program usage dump (U8). Invalid choices and missing required
    # arguments still error inside their own subparser, which already prints the right usage.
    args, extras = parser.parse_known_args(argv)
    if extras:
        return _usage_error(parser, args, extras)
    # argparse writes the subcommand's value over the global one; restore the global if the
    # subcommand's is empty so `--run X status` and `status --run X` behave identically.
    if getattr(args, "run", None) is None:
        for i, a in enumerate(argv):
            if a == "--run" and i + 1 < len(argv): args.run = argv[i + 1]; break
    if getattr(args, "profile", None) is None:
        for i, a in enumerate(argv):
            if a == "--profile" and i + 1 < len(argv): args.profile = argv[i + 1]; break
    # One place decides the tenant, and it is decided here rather than fourteen times at the
    # call sites. Resolving it now also means every stage prints the same answer.
    #
    # `profile_given` is kept alongside, because "you chose this tenant" and "this tenant is
    # whatever your config file currently points at" are different facts and the tenant banner
    # has to be able to tell a person which one they are looking at. Resolving first and asking
    # afterwards made every profile look deliberate, including the inherited production one.
    args.profile_given = getattr(args, "profile", None)
    args.profile = settings.resolve_profile(args.profile_given)
    fn = DISPATCH[args.cmd]
    try:
        if os.environ.get(tenant.RETIRED_ENV):
            raise tenant.TenantRefused(
                f"{tenant.RETIRED_ENV} is retired. It named a host, which could not tell a "
                f"customer's own tenant apart from a stranger's.\n"
                f"    Name the tenant instead:  {tenant.ACK_ENV}=<profile> summation-flow ...")
        if args.cmd in LEASED_COMMANDS:
            locked_run = Run.load(getattr(args, "run", None))
            with RunLease(locked_run):
                rc = fn(args) or 0
        else:
            rc = fn(args) or 0
        if args.cmd in SIGNPOSTED_COMMANDS:
            checkpoint = Run.load(getattr(args, "run", None))
            experience.write_changeset(checkpoint)
            print("\n" + journey.render_card(checkpoint))
        return rc
    except RunBusy as e:
        print(f"\n  ⏸ {e}", file=sys.stderr)
        return 2
    except tenant.TenantNeedsAck as e:
        # A question awaiting a human, not a failure (U4). Calm glyph, distinct exit code 2.
        print(f"\n  ⏸ {e.message}", file=sys.stderr)
        return tenant.TenantNeedsAck.exit_code
    except SystemExit as e:
        # SystemExit carries our own actionable messages; print and keep the code.
        if e.code and not isinstance(e.code, int):
            print(f"\n  ✗ {e.code}", file=sys.stderr); return 1
        return int(e.code or 0)
    except Exception as e:
        print(f"\n  ✗ {type(e).__name__}: {e}", file=sys.stderr)
        if "-v" in sys.argv: traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
