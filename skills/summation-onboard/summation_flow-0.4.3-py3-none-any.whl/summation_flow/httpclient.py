"""A small HTTP client for sum-api, so nothing has to import the CLI from source.

This used to be a `sys.path.insert` at an absolute path into a monorepo checkout, followed by
`from sum_cli.client import Client`. That worked on exactly one machine, and upstream the
package has since moved repositories anyway.

The behaviour here is copied from the installed `summation-cli` (`sum_cli/auth.py`,
`sum_cli/client.py`), not guessed:

  * credentials come only from a profile in the shared config file — never from `SUM_API_*`
    environment variables, which are an input to `sumcli config import-env` and would otherwise
    let a stray `.env` hijack whichever profile you picked;
  * precedence is device-login credential, then a persisted M2M access token that has not
    expired, then a fresh M2M exchange;
  * a device-login credential is an opaque session bearer sent as-is — there is no exchange
    step and no local expiry, the server decides;
  * every request carries `Authorization: Bearer <token>` and nothing else.

One deliberate difference: a refreshed M2M token is NOT written back to the config file. sumcli
persists it; this tool treats the shared credential file as read-only, because it runs on other
people's machines and a tool that rewrites a file three programs share should be the one whose
job that is.

Standard library only. `httpx` would be one more thing to install on a cold machine for a client
that makes perhaps forty calls in a whole run.
"""
from __future__ import annotations

import json as jsonlib
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any

from . import settings

#: sumcli's own skew, so a token this client accepts is one sumcli would accept too.
TOKEN_SKEW_SECONDS = 60
DEFAULT_TIMEOUT = 30.0


class AuthError(RuntimeError):
    pass


class ApiError(RuntimeError):
    """Same message shape as sum_cli.client.ApiError.

    Callers match on the text — `upload_bundle` retries base64 when it sees "403", `teardown`
    treats "404" as already-gone — so the format is part of the contract, not cosmetic.
    """

    def __init__(self, status: int, body: Any, *, method: str | None = None,
                 url: str | None = None):
        super().__init__(f"sum-api {status}: {body!r}")
        self.status = status
        self.body = body
        self.method = method
        self.url = url


@dataclass(frozen=True)
class Config:
    profile: str
    base_url: str
    device_login_credential: str | None = None
    access_token: str | None = None
    token_expires_at: float | None = None
    client_id: str | None = None
    client_secret: str | None = None
    m2m_scope: str | None = None
    default_project: str | None = None

    @property
    def has_m2m(self) -> bool:
        return bool(self.client_id and self.client_secret)


def _float_or_none(raw: str | None) -> float | None:
    if not raw:
        return None
    try:
        return float(str(raw).strip())
    except ValueError:
        return None


def load(profile: str | None = None) -> Config:
    name = settings.resolve_profile(profile)
    values = settings.profile_config(name)
    return Config(
        profile=name,
        base_url=(values.get("base_url") or "").strip().rstrip("/"),
        device_login_credential=values.get("device_login_credential"),
        access_token=values.get("access_token"),
        token_expires_at=_float_or_none(values.get("token_expires_at")),
        client_id=values.get("client_id"),
        client_secret=values.get("client_secret"),
        m2m_scope=values.get("m2m_scope"),
        default_project=values.get("default_project"),
    )


# --------------------------------------------------------------------------- transport
class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Do not follow redirects, because httpx does not and sumcli uses httpx.

    urllib follows them by default, and on a 301/302/303 it rewrites a POST into a GET. A
    write that silently became a read, reporting 200, is the worst outcome available here.
    """

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_OPENER = urllib.request.build_opener(_NoRedirect)


def _query_value(v: Any) -> str:
    """Match httpx's encoding of booleans: `true`/`false`, not Python's `True`/`False`."""
    if isinstance(v, bool):
        return "true" if v else "false"
    return str(v)


def _request(method: str, url: str, *, headers: dict[str, str],
             body: bytes | None = None, timeout: float = DEFAULT_TIMEOUT) -> tuple[int, bytes]:
    req = urllib.request.Request(url, data=body, method=method.upper())
    for k, v in headers.items():
        req.add_header(k, v)
    try:
        with _OPENER.open(req, timeout=timeout) as resp:
            return resp.status, resp.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except urllib.error.URLError as e:
        raise ApiError(0, f"could not reach {url}: {e.reason}", method=method, url=url) from e


def _decode(raw: bytes) -> Any:
    if not raw:
        return None
    try:
        return jsonlib.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, jsonlib.JSONDecodeError):
        return raw.decode("utf-8", "replace")


def _exchange_m2m(cfg: Config) -> tuple[str, float]:
    """POST the client credentials, form-encoded, exactly as sumcli does."""
    payload = {"client_id": cfg.client_id or "", "client_secret": cfg.client_secret or ""}
    if cfg.m2m_scope:
        payload["scope"] = cfg.m2m_scope
    url = f"{cfg.base_url}/v1/auth/m2m/token"
    status, raw = _request(
        "POST", url,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        body=urllib.parse.urlencode(payload).encode(), timeout=15)
    body = _decode(raw)
    if status >= 400:
        raise AuthError(f"M2M token exchange failed ({status}): {body!r}")
    if not isinstance(body, dict) or not isinstance(body.get("access_token"), str):
        raise AuthError(f"M2M response missing access_token: {body!r}")
    expires_in = body.get("expires_in")
    try:
        ttl = float(expires_in) if expires_in is not None else 300.0
    except (TypeError, ValueError):
        ttl = 300.0
    return body["access_token"], time.time() + ttl


class Client:
    #: Process-wide, keyed the way sumcli keys it, so one run does not re-exchange per call.
    _tokens: dict[tuple, tuple[str, float]] = {}

    def __init__(self, cfg: Config):
        self.cfg = cfg

    @classmethod
    def clear_token_cache(cls) -> None:
        cls._tokens.clear()

    def token(self) -> str:
        cfg = self.cfg
        if cfg.device_login_credential:
            return cfg.device_login_credential
        if cfg.access_token and cfg.token_expires_at is not None:
            if time.time() < cfg.token_expires_at - TOKEN_SKEW_SECONDS:
                return cfg.access_token
        if not cfg.has_m2m:
            raise AuthError(
                f"no usable credential on profile '{cfg.profile}'. Sign in with:\n"
                f"    sumcli --profile {cfg.profile} auth login")
        key = ("m2m", cfg.profile, cfg.base_url, cfg.client_id, cfg.m2m_scope)
        cached = Client._tokens.get(key)
        if cached and time.time() < cached[1] - TOKEN_SKEW_SECONDS:
            return cached[0]
        tok, expires = _exchange_m2m(cfg)
        Client._tokens[key] = (tok, expires)
        return tok

    def request(self, method: str, path: str, *, params: dict[str, Any] | None = None,
                json: Any = None, headers: dict[str, str] | None = None,
                timeout: float = DEFAULT_TIMEOUT) -> Any:
        url = f"{self.cfg.base_url}{path}"
        if params:
            clean = [(k, _query_value(x)) for k, v in params.items() if v is not None
                     for x in (v if isinstance(v, (list, tuple)) else [v])]
            if clean:
                url = f"{url}?{urllib.parse.urlencode(clean)}"
        h = {"Authorization": f"Bearer {self.token()}", "Accept": "application/json"}
        body = None
        if json is not None:
            body = jsonlib.dumps(json).encode()
            h["Content-Type"] = "application/json"
        if headers:
            h.update(headers)
        status, raw = _request(method, url, headers=h, body=body, timeout=timeout)
        decoded = _decode(raw)
        if status >= 400:
            raise ApiError(status, decoded, method=method, url=url)
        if status == 204:
            return None
        return decoded
