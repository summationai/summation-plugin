"""Customer-facing journey state derived from the durable run checkpoint.

The CLI has many small, useful stages.  A customer should not have to understand that machinery
to know where they are.  This module is the one projection used by every host: seven phases, the
next action, what changed in Summation, and whether it is safe to leave.
"""
from __future__ import annotations

from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path

from .operations import unsafe as unsafe_operations
from .state import Run


@dataclass(frozen=True)
class Phase:
    number: int
    title: str
    stages: tuple[str, ...]
    activity: str


PHASES = (
    Phase(1, "Define the outcome", ("init", "evidence"),
          "saving the supplied artifact, skills, data, and other resources"),
    Phase(2, "Understand the source", ("parse", "fanout", "verify-cold"),
          "reading the source and identifying what the finished output must preserve"),
    Phase(3, "Resolve data and knowledge",
          ("request-access", "detect", "connect", "context"),
          "resolving data access, metric definitions, and reusable knowledge"),
    Phase(4, "Agree on fidelity", ("output-target", "contract"),
          "agreeing on the output and the requirements it must satisfy"),
    Phase(5, "Build the playbook", ("scaffold", "lint", "build"),
          "authoring and checking the repeatable playbook"),
    Phase(6, "Ship, run, and verify", ("deploy", "params", "run", "verify-fidelity"),
          "shipping the playbook, running it, and independently checking the result"),
    Phase(7, "Automate and hand off", ("schedule", "share"),
          "setting the cadence and handing off sharing in the app"),
)

FLOW_STAGES = tuple(stage for phase in PHASES for stage in phase.stages)
SUCCESS = {"done", "degraded", "skipped"}
ACTIVE = {"running", "blocked", "failed"}

STAGE_LABELS = {
    "init": "source package saved",
    "evidence": "source evidence fingerprinted",
    "parse": "artifact requirements extracted",
    "fanout": "source data and literals surveyed",
    "verify-cold": "original artifact reviewed independently",
    "request-access": "data-access path agreed",
    "detect": "existing integrations detected",
    "connect": "data access confirmed",
    "context": "project knowledge prepared",
    "output-target": "output format agreed",
    "contract": "fidelity contract approved",
    "scaffold": "playbook scaffolded",
    "lint": "playbook checks completed",
    "build": "playbook built",
    "deploy": "playbook deployed",
    "params": "parameters checked",
    "run": "first platform run completed",
    "verify-fidelity": "finished artifact independently verified",
    "schedule": "schedule created",
    "share": "sharing handoff completed",
}


@dataclass(frozen=True)
class JourneyView:
    run_id: str
    name: str
    profile: str
    project_id: str | None
    status: str
    phase_number: int
    phase_total: int
    phase_title: str
    current_stage: str | None
    completed: str
    now: str
    need_from_you: str
    next: str
    summation_changes: str
    safe_to_leave: bool
    resume_with: str
    updated_at: str
    experience: dict

    def to_dict(self) -> dict:
        return asdict(self)


def phase_for(stage: str | None) -> Phase:
    if stage:
        for phase in PHASES:
            if stage in phase.stages:
                return phase
    return PHASES[-1]


def current_stage(run: Run) -> str | None:
    """Return the stage a resuming agent must address, including a blocked stage.

    The old status implementation ignored ``blocked`` and pointed at the following not-started
    stage.  That made a contract awaiting approval look ready to build.
    """
    for stage in FLOW_STAGES:
        if run.status_of(stage) in ACTIVE or run.status_of(stage) == "not-started":
            return stage
    return None


def is_complete(run: Run) -> bool:
    return run.status_of("share") in SUCCESS


def is_resumable(run: Run) -> bool:
    return not is_complete(run) and run.status_of("teardown") not in SUCCESS


def display_name(run: Run) -> str:
    if run.name.strip():
        return run.name.strip()
    try:
        meta = run.read("input.json")
    except SystemExit:
        meta = {}
    document = meta.get("document")
    raw = Path(document).stem if document else Path(run.input_dir).name
    cleaned = " ".join(raw.replace("_", " ").replace("-", " ").split())
    return cleaned or run.run_id


def _last_completed(run: Run) -> str:
    completed = [stage for stage in FLOW_STAGES if run.status_of(stage) in SUCCESS]
    if not completed:
        return "Nothing yet"
    stage = completed[-1]
    label = STAGE_LABELS[stage]
    detail = (run.stages.get(stage) or {}).get("detail", "").strip()
    return f"{label} — {detail}" if detail and detail.lower() not in label.lower() else label


def _need_from_customer(stage: str | None, status: str) -> str:
    if stage == "contract":
        return "Review and approve or revise the fidelity contract"
    if stage == "request-access":
        return "Choose the appropriate data-access path"
    if stage == "output-target":
        return "Confirm which output format or formats you want"
    if stage == "schedule":
        return "Choose whether and when the workflow should run"
    if stage == "share":
        return "Use Share in the app when you are ready"
    if stage == "connect" and status in {"blocked", "failed"}:
        return "Complete or approve read-only data access"
    return "Nothing right now"


def _summation_changes(run: Run) -> str:
    if not run.created_objects:
        return "None recorded by this run"
    counts = Counter(str(obj.get("kind") or "object").replace("_", " ")
                     for obj in run.created_objects)
    return ", ".join(f"{count} {kind}{'' if count == 1 else 's'}" for kind, count in counts.items())


def view(run: Run) -> JourneyView:
    # Imported lazily so the experience layer can import Run without a module cycle.
    from .experience import journey_facts
    stage = current_stage(run)
    complete = is_complete(run)
    phase = phase_for(stage)
    stage_status = run.status_of(stage) if stage else "done"
    detail = ((run.stages.get(stage) or {}).get("detail", "").strip() if stage else "")

    if complete:
        status = "complete"
        now = "The workflow is built, verified, and handed off"
        next_text = "Return here to rerun it or make a change"
    elif stage_status == "blocked":
        status = "paused"
        now = f"Paused at {STAGE_LABELS[stage]}" + (f" — {detail}" if detail else "")
        next_text = f"Resolve {STAGE_LABELS[stage]}, then continue"
    elif stage_status == "failed":
        status = "needs-attention"
        now = f"Correcting {STAGE_LABELS[stage]}" + (f" — {detail}" if detail else "")
        next_text = f"Retry {STAGE_LABELS[stage]}"
    elif stage_status == "running":
        status = "working"
        now = f"Working on {STAGE_LABELS[stage]}" + (f" — {detail}" if detail else "")
        next_text = f"Finish {STAGE_LABELS[stage]}"
    else:
        status = "ready"
        now = phase.activity.capitalize()
        next_text = STAGE_LABELS.get(stage, "Finish the onboarding")

    uncertain = unsafe_operations(run)
    safe = stage_status != "running" and not uncertain
    if uncertain:
        status = "reconciling"
        summaries = ", ".join(event.get("summary", "platform operation") for event in uncertain)
        now = f"Reconciling an operation whose outcome is not yet known — {summaries}"
        next_text = "Confirm what Summation created before anything is repeated"
    name = display_name(run)
    revision = 1 + max((int(run.revisions.get(stage_name, 0))
                        for stage_name in phase.stages), default=0)
    phase_title = phase.title + (f" — revision {revision}" if revision > 1 else "")
    return JourneyView(
        run_id=run.run_id,
        name=name,
        profile=run.profile,
        project_id=run.project_id or None,
        status=status,
        phase_number=phase.number,
        phase_total=len(PHASES),
        phase_title=phase_title,
        current_stage=stage,
        completed=_last_completed(run),
        now=now,
        need_from_you=_need_from_customer(stage, stage_status),
        next=next_text,
        summation_changes=_summation_changes(run),
        safe_to_leave=safe,
        resume_with=f'Continue {name}',
        updated_at=run.updated_at,
        experience=journey_facts(run),
    )


def render_card(run: Run, *, welcome_back: bool = False) -> str:
    j = view(run)
    heading = f"Welcome back — {j.name}" if welcome_back else f"Checkpoint — {j.name}"
    if j.safe_to_leave:
        safe = "Yes — progress is saved"
    elif j.status == "reconciling":
        safe = "No — a Summation operation still needs reconciliation"
    else:
        safe = "Not yet — an operation is still in progress"
    lines = [
        heading,
        f"Workspace: {j.profile} · project {j.project_id or 'not created yet'}",
        f"Stage {j.phase_number} of {j.phase_total} — {j.phase_title}",
        f"Completed: {j.completed}",
        f"Now: {j.now}",
        f"Need from you: {j.need_from_you}",
        f"Next: {j.next}",
        f"Changes in Summation: {j.summation_changes}",
        f"Safe to leave: {safe}",
        f'Resume on this machine with: “{j.resume_with}”  ({j.run_id})',
    ]
    permission = j.experience.get("permission_required")
    if permission:
        lines.insert(-2, f"Permission: waiting for {permission['group']} approval")
    decision = j.experience.get("current_decision")
    if decision:
        choices = ", ".join(decision.get("choices") or [])
        lines.insert(-2, f"Decision: {decision['question']}")
        lines.insert(-2, f"Choices: {choices} · recommended: {decision['recommendation']}")
    preview = j.experience.get("preview")
    if preview:
        lines.insert(-2, f"Candidate: {preview['candidate_sha256'][:12]} (sealed local preview)")
    proof = j.experience.get("proof")
    if proof:
        lines.insert(-2, f"Fidelity proof: {proof['result'].upper()} ({proof['sha256'][:12]})")
    changes = j.experience.get("changes") or {}
    change_count = (len(changes.get("local_artifacts") or [])
                    + len(changes.get("decisions") or [])
                    + len(changes.get("permissions") or [])
                    + len(changes.get("operations") or []))
    if change_count:
        lines.insert(-2, f"Recorded changes: {change_count} — review changeset.json")
    return "\n".join(lines)
