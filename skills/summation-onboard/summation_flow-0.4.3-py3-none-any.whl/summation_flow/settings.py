"""Everything that used to be a constant on one laptop.

Four questions had fourteen hard-coded answers between them: which tenant, where runs live,
where the packaged data is, and which hosts are safe to talk to. Each of those is now asked
here, once, so a second machine needs no edit to any other module.

Resolution order is always the same and always stated: environment first, then the shared
Summation config file, then a safe default.
"""
from __future__ import annotations

import os
import tomllib
from pathlib import Path

#: The tenant used when nothing else says otherwise. Deliberately not a customer's: a wrong
#: default that reaches a real tenant is worse than one that reaches nothing.
FALLBACK_PROFILE = "alg-testing"

#: `[_meta] active_profile` — the same key sumcli reads, so `sumcli config use X` moves both.
META_SECTION = "_meta"
ACTIVE_PROFILE_KEY = "active_profile"

#: Canonical first. `config` is a legacy symlink on machines that have been through the
#: 2026-07 unification; on older ones it is the only file. Both are read, canonical wins.
CONFIG_FILENAMES = ("summation-config", "config")

#: Keys written before any `[section]`. The Addison plugin writes its credential there, and its
#: own reader treats them as the fallback under whichever profile is selected — so this does too.
ROOT_SECTION = "_root"

#: The Addison plugin writes THE SAME FILE with different key names.
#: `~/.summation/summation-config` is canonical for sumcli, for this tool, and for the plugin's
#: external build — but the plugin spells its keys `SUM_API_*` where sumcli spells them lower
#: case. A machine that signed in through the plugin therefore has a perfectly good credential
#: that this tool could not see, and reported as "no base_url", which points at the wrong thing.
#:
#: This is a read alias and nothing else. `SUM_API_*` values in the ENVIRONMENT stay ignored, for
#: the reason sumcli ignores them: they are an input to `sumcli config import-env`, and a stray
#: `.env` that can redirect a selected profile is how a tool ends up pointed at production.
PLUGIN_KEY_ALIASES = {
    "SUM_API_BASE_URL": "base_url",
    "SUM_API_DEVICE_LOGIN_CREDENTIAL": "device_login_credential",
    "SUM_API_ACCESS_TOKEN": "access_token",
    "SUM_API_CLIENT_ID": "client_id",
    "SUM_API_CLIENT_SECRET": "client_secret",
    "SUM_API_TOKEN_EXPIRES_AT": "token_expires_at",
}


# --------------------------------------------------------------------------- config file
def config_path() -> Path:
    """The shared Summation credential file this process should read."""
    override = os.environ.get("SUMMATION_CONFIG_FILE")
    if override:
        return Path(override).expanduser()
    d = Path.home() / ".summation"
    for name in CONFIG_FILENAMES:
        p = d / name
        if p.exists():
            return p
    return d / CONFIG_FILENAMES[0]


def read_config(path: Path | None = None) -> dict[str, dict[str, str]]:
    """Parse the config into ``{section: {key: value}}``.

    Values are coerced to strings because the file is shared with two other tools, and a quoted
    number in one of them must not change meaning here.

    Three programs read and write this one path and they do not agree on its syntax. sumcli and
    this tool parse it as TOML. The Addison plugin writes bare `KEY=value` lines, which TOML
    rejects outright — so a plugin-written file did not merely lose a key, it failed to parse,
    and every profile on the machine vanished at once. TOML first because that is what the file
    is meant to be; the lenient reader is the fallback rather than the rule, so a genuinely
    malformed TOML file is still read the way its author intended.
    """
    p = path or config_path()
    if not p.exists():
        return {}
    try:
        text = p.read_text(encoding="utf-8")
    except OSError:
        return {}
    try:
        raw = tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        return _read_loosely(text)
    out: dict[str, dict[str, str]] = {}
    for section, values in raw.items():
        if isinstance(values, dict):
            out[_section_name(str(section))] = {
                k: str(v) for k, v in values.items()
                if isinstance(v, (str, int, float, bool))}
        elif isinstance(values, (str, int, float, bool)):
            out.setdefault(ROOT_SECTION, {})[str(section)] = str(values)
    return out


def _section_name(raw: str) -> str:
    """`[profile.work]` is the plugin's spelling of what sumcli calls `[work]`."""
    return raw[len("profile."):] if raw.startswith("profile.") else raw


def _read_loosely(text: str) -> dict[str, dict[str, str]]:
    """The Addison plugin's own line format: `KEY=value`, optionally quoted, `[profile.X]`."""
    out: dict[str, dict[str, str]] = {}
    section = ROOT_SECTION
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("[") and stripped.endswith("]"):
            section = _section_name(stripped[1:-1].strip())
            out.setdefault(section, {})
            continue
        if stripped.startswith("export "):
            stripped = stripped[len("export "):].strip()
        if "=" not in stripped:
            continue
        k, v = stripped.split("=", 1)
        v = v.strip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "'\"":
            v = v[1:-1]
        out.setdefault(section, {})[k.strip()] = v
    return out


def _with_aliases(values: dict[str, str]) -> dict[str, str]:
    """Let sumcli's spelling win where both are present, so nothing already working changes."""
    out = dict(values)
    for plugin_key, canonical in PLUGIN_KEY_ALIASES.items():
        if values.get(plugin_key) and not out.get(canonical):
            out[canonical] = values[plugin_key]
    return out


def config_is_toml(path: Path | None = None) -> bool:
    """Is the shared config file parseable as TOML?

    Worth asking out loud, because this tool is the only one of the three that survives a `no`.
    sumcli calls `tomllib.load` with nothing around it, and half of this flow shells out to
    sumcli — so a file the Addison plugin wrote in its own format makes every one of those calls
    fail, somewhere well downstream of the cause. `doctor` reports it for that reason.
    """
    p = path or config_path()
    if not p.exists():
        return True
    try:
        tomllib.loads(p.read_text(encoding="utf-8"))
        return True
    except (tomllib.TOMLDecodeError, OSError):
        return False


def profile_config(profile: str, path: Path | None = None) -> dict[str, str]:
    """One profile's settings, with the unsectioned keys underneath it.

    Root-then-profile is the plugin's own precedence — its `setting()` reads the selected
    profile first and falls back to the top-level values — so a credential written by either
    tool resolves the same way whichever one reads it.
    """
    cfg = read_config(path)
    if profile == META_SECTION:
        return {}
    merged = {**cfg.get(ROOT_SECTION, {}), **cfg.get(profile, {})}
    return _with_aliases(merged)


# --------------------------------------------------------------------------- profile
def default_profile() -> str:
    """Which tenant this process talks to when no ``--profile`` is given.

    `fanatics_staging` used to be the answer in fourteen places, which is why a room built for
    another tenant had to rewrite the source to aim the tool. One place now, and the answer
    comes from the machine rather than from us.
    """
    env = os.environ.get("SF_PROFILE")
    if env:
        return env
    cfg = read_config()
    active = cfg.get(META_SECTION, {}).get(ACTIVE_PROFILE_KEY)
    if active:
        return active
    # A file written only by the Addison plugin has a credential and no profile name at all —
    # it has one environment and does not ask. Naming that section rather than falling through
    # to a tenant the plugin has never heard of.
    if _with_aliases(cfg.get(ROOT_SECTION, {})).get("device_login_credential"):
        return ROOT_SECTION
    return FALLBACK_PROFILE


def resolve_profile(profile: str | None) -> str:
    return profile or default_profile()


def base_url(profile: str) -> str:
    """The API base URL a profile resolves to, read from the config file."""
    return (profile_config(profile).get("base_url") or "").strip().rstrip("/")


# --------------------------------------------------------------------------- filesystem
def root() -> Path:
    """Where runs, artifacts and the fan-out cache live.

    A per-user data directory rather than the source tree, so the tool has somewhere to write
    that survives an upgrade and does not depend on where it was installed from.
    """
    return Path(os.environ.get("SF_ROOT") or (Path.home() / ".summation-flow")).expanduser()


def data_dir() -> Path:
    """The packaged data directory (bundle template, demo fixture).

    ``importlib.resources`` rather than ``__file__`` arithmetic, so the answer stays right if
    the package is installed somewhere unusual. Both trees contain non-Python files and are
    read as ordinary directories, which every wheel install gives us.
    """
    from importlib.resources import files
    return Path(str(files("summation_flow"))) / "data"


def demo_fixture() -> Path:
    return data_dir() / "demo-fixture"


def tiny_fixture() -> Path:
    """Small end-to-end fixture: one artifact, query, table, literal, and defect."""
    return data_dir() / "tiny-fixture"


def tiny_fixture_answers() -> Path:
    """Expected results kept outside the scanned customer fixture."""
    return data_dir() / "tiny-fixture-answers.json"


def bundle_template() -> Path:
    return data_dir() / "bundle-template" / "Owner 07 Weekly Recap.spb"
