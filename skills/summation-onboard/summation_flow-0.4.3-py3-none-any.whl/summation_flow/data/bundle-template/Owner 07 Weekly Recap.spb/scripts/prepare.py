#!/usr/bin/env python3
"""
prepare.py — phase 1 of the Owner 07 Weekly Recap.

Deterministic work only. This script NEVER touches the network: it emits .sql
files, and it reads snapshot JSON that somebody else executed. On the platform
the LLM runs the SQL; locally scripts/local_run.py does it with sumcli. Same
script either way, so a local run and a platform run cannot drift.

    prepare.py plan-scoreboard  --output <dir>.smd --planner OWNER_07 \\
                                --area "Segment Alpha & Beta" \\
                                [--week 2026-04-04]
    prepare.py plan-breakdowns  --output <dir>.smd
    prepare.py postprocess      --output <dir>.smd
    prepare.py render-html      --output <dir>.smd

Snapshot contract: snapshots/<name>.json == {"columns":[...], "data":[[...]]}.
Every value may arrive as a string (the platform SQL surface stringifies), so
everything is coerced on read.

Rounding: nowhere in here except the formatting helpers at the bottom, which
only ever run at print time.
"""

import argparse
import csv
import json
import os
import re
import sys
from datetime import datetime

HERE = os.path.dirname(os.path.abspath(__file__))
BUNDLE = os.path.dirname(HERE)
QUERY_TEMPLATES = os.path.join(BUNDLE, "templates", "queries")

TABLE = "analytics_core_current_assortment_wbr_snapshot_v"

# Consignment / marketplace. Out of every query. The customer's notes
# (2026-02-17) record that it moves every share number, and that the merch lead
# asked for the footnote explaining it to be removed — so it lives in the SQL
# only. Carried verbatim, and now also declared in manifest.yaml data_context.
HARD_EXCLUDE = "AND byr_nm != 'SPORTS MEM & MARKETPLACE'"

PLANNER_GUARD = 10          # distinct planners required before a week is "loaded"
DEFAULT_LEAGUE_FLOOR = 4000  # USD of this-year demand to earn a league section

# Vendor codes we buy and hold ourselves. 1P/3P is NOT a column and is NOT
# isdropship — drop-ship and 3P overlap but are not the same set. Sourced from
# the customer's OWNED_VENDOR_CODES, carried verbatim.
OWNED_VENDOR_CODES = [
    "AG0", "B8S", "BS4", "D9Z", "ELI", "FB3", "FBC", "FTF", "JAS", "JKP",
    "M1A", "MAJ", "NUT", "ORI", "PRL", "PT7", "RL1", "RUP", "S9G", "SK7",
    "TCR", "TOP", "TOT", "TP2", "TS4", "TSN", "TXC", "VF0", "VFI", "VFN",
    "WCR", "WIC", "WNC", "V118159", "MNC", "ESL",
]

SIGNAL_THRESHOLDS = {
    "MARKDOWN_WOS_MIN": 20,
    "MARKDOWN_OHR_MIN": 100000,
    "VELOCITY_WOS_MAX": 4,
    "MARGIN_SALES_MIN": 10000,
    "OO_RETAIL_MIN": 250000,
    "NO_PIPELINE_SALES_MIN": 5000,
    "PLAYER_SALES_MIN": 500,
}

SIGNAL_META = {
    "markdown_exposure": {
        "label": "Markdown exposure",
        "note": "High weeks of supply with demand falling. Candidate for a clearance review.",
        "sort_key": "oh_retail_ty", "sort_desc": True},
    "stockout_exposure": {
        "label": "Stockout on selling items (warehouse only)",
        "note": "Warehouse-stocked items with weekly demand and zero on hand. Dollars of demand at "
                "risk per week. Drop-ship and made-to-order are excluded by design.",
        "sort_key": "sales_ty", "sort_desc": True},
    "velocity_low_inventory": {
        "label": "Low inventory on a fast seller",
        "note": "Sell-through climbing on thin cover. Chase or accept the miss.",
        "sort_key": "sales_ty", "sort_desc": True},
    "margin_compression": {
        "label": "Margin compression",
        "note": "Gross margin down on real volume. Pricing or clearance mix.",
        "sort_key": "gm_delta_pts", "sort_desc": False},
    "oo_into_decline": {
        "label": "On order into falling demand",
        "note": "Receipts landing while demand falls. Third-party lines escalate to the buying "
                "team; we do not control those buys.",
        "sort_key": "oo_retail", "sort_desc": True},
    "no_pipeline": {
        "label": "No replenishment pipeline",
        "note": "Selling, holding stock, nothing on order.",
        "sort_key": "sales_ty", "sort_desc": True},
    "player_acceleration": {
        "label": "Player demand acceleration",
        "note": "Named-player demand growing fast enough to want more depth.",
        "sort_key": "yoy_pct", "sort_desc": True},
}

# The ten breakouts, in page order.
DIMENSIONS = [
    {"id": "teams", "label": "Teams", "noun": "teams",
     "expr": "team", "group": "team"},
    {"id": "departments", "label": "Departments", "noun": "departments",
     "expr": "mrch_dept_nm", "group": "mrch_dept_nm"},
    {"id": "classes", "label": "Classes", "noun": "classes",
     "expr": "merch_class_name", "group": "merch_class_name"},
    {"id": "one_p_three_p", "label": "First party vs third party", "noun": "sources",
     "expr": "__OWNED_CASE__", "group": "__OWNED_CASE__"},
    {"id": "vendors", "label": "Vendors", "noun": "vendors",
     "expr": "vendorname", "group": "vendorname"},
    {"id": "brands", "label": "Brands", "noun": "brands",
     "expr": "byr_brnd_nm", "group": "byr_brnd_nm"},
    {"id": "events", "label": "Events", "noun": "events",
     "expr": "byr_event_nm", "group": "byr_event_nm",
     "exclude": "AND byr_event_nm <> 'Unknown'"},
    {"id": "assortment_types", "label": "Assortment types", "noun": "types",
     "expr": "assortmenttype", "group": "assortmenttype",
     "exclude": "AND assortmenttype <> 'TBD'", "top_n": 20},
    {"id": "players", "label": "Players", "noun": "players",
     "expr": "byr_plyr_nm", "group": "byr_plyr_nm",
     "exclude": "AND byr_plyr_nm <> 'N/A'"},
    {"id": "styles", "label": "Styles", "noun": "styles",
     "expr": "stylename", "group": "stylename, team", "name2": "team"},
]

DEFAULT_TOP_N = 5


# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------

def owned_case():
    codes = ", ".join("'%s'" % c for c in OWNED_VENDOR_CODES)
    return "CASE WHEN vendorcode IN (%s) THEN '1P' ELSE '3P' END" % codes


def league_key(league):
    return re.sub(r"[^a-z0-9]+", "_", league.lower()).strip("_")


def read_template(name):
    with open(os.path.join(QUERY_TEMPLATES, name)) as fh:
        return fh.read()


def fill(text, subs):
    for k, v in subs.items():
        text = text.replace("{{%s}}" % k, str(v))
    left = re.findall(r"\{\{[A-Z0-9_]+\}\}", text)
    if left:
        raise SystemExit("unfilled placeholders in query template: %s" % sorted(set(left)))
    return text


def load_json(path, default=None):
    if not os.path.exists(path):
        if default is not None:
            return default
        raise SystemExit("missing required file: %s" % path)
    with open(path) as fh:
        return json.load(fh)


def write_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as fh:
        json.dump(obj, fh, indent=2)


def num(v):
    """Coerce a snapshot value to float or None. Platform returns strings."""
    if v is None or v == "" or v == "None":
        return None
    if isinstance(v, bool):
        return float(v)
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", ""))
    except ValueError:
        return None


def rows_of(snapshot):
    """snapshot {"columns":[...],"data":[[...]]} -> list of dicts."""
    cols = snapshot["columns"]
    return [dict(zip(cols, r)) for r in snapshot["data"]]


def load_snapshot(smd, name):
    return rows_of(load_json(os.path.join(smd, "snapshots", "%s.json" % name)))


def buyer_area(planner, area):
    cfg = load_json(os.path.join(BUNDLE, "buyer_areas.json"))
    entries = cfg.get(planner)
    if not entries:
        raise SystemExit("no such planner in buyer_areas.json: %s" % planner)
    for e in entries:
        if area is None or e["area"] == area:
            return e["area"], list(e["buyers"])
    raise SystemExit("planner %s has no area %r" % (planner, area))


def buyer_filter(buyers):
    return "AND byr_nm IN (%s)" % ", ".join("'%s'" % b for b in buyers)


def dimension_plan(planner, league):
    """Apply dimension_overrides.json. Returns the dimension list for this league."""
    ov = load_json(os.path.join(BUNDLE, "dimension_overrides.json")).get(planner, {})
    out, suppressed = [], []
    for d in DIMENSIONS:
        rule = ov.get(d["id"])
        if isinstance(rule, dict):
            only = [x.upper() for x in rule.get("only_for", [])]
            skip = [x.upper() for x in rule.get("skip_for", [])]
            if only and league.upper() not in only:
                suppressed.append((d["id"], "only_for %s" % only))
                continue
            if league.upper() in skip:
                suppressed.append((d["id"], "skip_for %s" % skip))
                continue
        out.append(d)
    return out, suppressed


def meta_path(smd):
    return os.path.join(smd, "_meta.json")


def require_smd(output):
    if not output.endswith(".smd") and not output.endswith(".sdoc"):
        raise SystemExit("--output must end in .smd or .sdoc (silent data loss otherwise)")
    os.makedirs(os.path.join(output, "queries"), exist_ok=True)
    os.makedirs(os.path.join(output, "snapshots"), exist_ok=True)
    return output


# --------------------------------------------------------------------------
# plan-scoreboard
# --------------------------------------------------------------------------

def cmd_plan_scoreboard(args):
    smd = require_smd(args.output)
    area, buyers = buyer_area(args.planner, args.area)
    if args.buyers:
        # Escape hatch for a known-stale hierarchy entry. Recorded in _meta.json
        # and printed, so an overridden run is never mistaken for a config run.
        buyers = [b.strip() for b in args.buyers.split(",") if b.strip()]
        print("BUYER OVERRIDE: using %s instead of buyer_areas.json" % ", ".join(buyers))
    qdir = os.path.join(smd, "queries")

    common = {"TABLE": TABLE, "PLANNER_GUARD": PLANNER_GUARD}

    # Step 0 — anchor week. Always emitted, even when --week is supplied, so the
    # run records what the table thought the newest loaded week was.
    with open(os.path.join(qdir, "01_anchor_week.sql"), "w") as fh:
        fh.write(fill(read_template("01_anchor_week.sql"), common))

    week = args.week
    if not week:
        # The anchor snapshot has to exist already on a second pass.
        snap = os.path.join(smd, "snapshots", "01_anchor_week.json")
        if os.path.exists(snap):
            week = rows_of(load_json(snap))[0]["periodending"][:10]
        else:
            write_json(meta_path(smd), {
                "state": "awaiting_anchor_week",
                "planner_nm": args.planner, "area_of_business": area,
                "buyers": buyers,
                "pending_queries": ["queries/01_anchor_week.sql"],
            })
            print("emitted queries/01_anchor_week.sql — run it, then re-run "
                  "plan-scoreboard to continue")
            return

    subs = dict(common, WEEK=week, PLANNER=args.planner,
                BUYER_FILTER=buyer_filter(buyers), HARD_EXCLUDE=HARD_EXCLUDE)

    with open(os.path.join(qdir, "00_freshness_check.sql"), "w") as fh:
        fh.write(fill(read_template("00_freshness_check.sql"), subs))

    # Buyer-code liveness probe. NOT in the customer's skill. It exists because
    # buyer_areas.json is hand-maintained and lags reorgs, and a dead code
    # removes that buyer's entire book from every number with no error at all.
    with open(os.path.join(qdir, "02_buyer_probe.sql"), "w") as fh:
        fh.write(
            "-- Does every buyer code in buyer_areas.json actually match rows?\n"
            "SELECT byr_nm AS name, COUNT(*) AS row_count, "
            "SUM(netdemand_l7) AS sales_ty\n"
            "FROM %s\nWHERE planner_nm = '%s'\n  %s\n  AND periodending = '%s'\n  %s\n"
            "GROUP BY byr_nm\nORDER BY sales_ty DESC\n;\n"
            % (TABLE, args.planner, buyer_filter(buyers), week, HARD_EXCLUDE))

    with open(os.path.join(qdir, "10_league_scoreboard.sql"), "w") as fh:
        fh.write(fill(read_template("10_league_scoreboard.sql"), subs))

    write_json(meta_path(smd), {
        "state": "awaiting_scoreboard",
        "planner_nm": args.planner,
        "area_of_business": area,
        "buyers": buyers,
        "week_ending": week,
        "week_pinned": bool(args.week),
        "league_floor_usd": args.league_floor,
        "buyer_code_validation": args.buyer_validation,
        "table": TABLE,
        "pending_queries": [
            "queries/00_freshness_check.sql",
            "queries/02_buyer_probe.sql",
            "queries/10_league_scoreboard.sql",
        ],
    })
    print("planned scoreboard for %s / %s / week %s" % (args.planner, area, week))


# --------------------------------------------------------------------------
# plan-breakdowns
# --------------------------------------------------------------------------

def cmd_plan_breakdowns(args):
    smd = require_smd(args.output)
    meta = load_json(meta_path(smd))
    qdir = os.path.join(smd, "queries")

    # --- gate 1: freshness -------------------------------------------------
    fresh = load_snapshot(smd, "00_freshness_check")[0]
    problems = []
    if not num(fresh["rows_this_week"]):
        problems.append("rows_this_week = 0 — the ETL has not landed this week")
    if str(fresh["latest_saturday"])[:10] != meta["week_ending"]:
        drift = ("latest_saturday %s != week asked for %s"
                 % (fresh["latest_saturday"], meta["week_ending"]))
        if meta.get("week_pinned"):
            # A pinned --week is an explicit historical / backfill run, so a
            # newer Saturday in the table is expected, not staleness.
            print("NOTE: %s — pinned week, treating as a historical run." % drift)
        else:
            problems.append(drift + " — the table is stale")
    if num(fresh["planners_this_week"]) < PLANNER_GUARD:
        problems.append("planners_this_week %s < %d — partial load, every share "
                        "number would be wrong" % (fresh["planners_this_week"], PLANNER_GUARD))
    if problems:
        raise SystemExit("FRESHNESS GATE FAILED:\n  - " + "\n  - ".join(problems))

    # --- gate 2: buyer-code liveness --------------------------------------
    live = {r["name"] for r in load_snapshot(smd, "02_buyer_probe")}
    dead = [b for b in meta["buyers"] if b not in live]
    meta["dead_buyer_codes"] = dead
    meta["live_buyer_codes"] = [b for b in meta["buyers"] if b in live]
    if dead:
        msg = ("BUYER-CODE GATE: %s matched zero rows in %s. buyer_areas.json is "
               "hand-maintained and lags reorgs. Every number on the page is "
               "missing that buyer's book, silently."
               % (", ".join(dead), meta["week_ending"]))
        if meta.get("buyer_code_validation", "strict") == "strict":
            raise SystemExit(msg + "\nRe-run with buyer_code_validation=warn to "
                                   "reproduce the customer's own number anyway.")
        print("WARNING: " + msg)

    # --- pick the leagues --------------------------------------------------
    floor = float(meta.get("league_floor_usd") or DEFAULT_LEAGUE_FLOOR)
    board = load_snapshot(smd, "10_league_scoreboard")
    leagues = [r["league"] for r in board
               if r["row_type"] == "league" and (num(r["sales_ty"]) or 0) >= floor]
    dropped = [r["league"] for r in board
               if r["row_type"] == "league" and (num(r["sales_ty"]) or 0) < floor]

    subs_common = {
        "TABLE": TABLE, "PLANNER": meta["planner_nm"],
        "BUYER_FILTER": buyer_filter(meta["buyers"]),
        "WEEK": meta["week_ending"], "HARD_EXCLUDE": HARD_EXCLUDE,
    }

    pending, plan = [], {}
    for league in leagues:
        lk = league_key(league)
        dims, suppressed = dimension_plan(meta["planner_nm"], league)
        plan[league] = {"key": lk,
                        "dimensions": [d["id"] for d in dims],
                        "suppressed": [{"dimension": s[0], "rule": s[1]} for s in suppressed]}
        for d in dims:
            expr = owned_case() if d["expr"] == "__OWNED_CASE__" else d["expr"]
            group = owned_case() if d["group"] == "__OWNED_CASE__" else d["group"]
            sql = fill(read_template("20_dimension_combined.sql"), dict(
                subs_common,
                LEAGUE=league,
                DIM_EXPR=expr,
                DIM_GROUP=group,
                NAME2_EXPR=(d["name2"] if d.get("name2") else "CAST(NULL AS VARCHAR)"),
                DIM_EXCLUDE=d.get("exclude", ""),
                TOP_N=d.get("top_n", DEFAULT_TOP_N),
                DIM_NOUN_PLURAL=d["noun"],
            ))
            name = "%s_%s" % (lk, d["id"])
            with open(os.path.join(qdir, name + ".sql"), "w") as fh:
                fh.write(sql)
            pending.append("queries/%s.sql" % name)

        sig = fill(read_template("30_action_signals.sql"),
                   dict(subs_common, LEAGUE=league, **SIGNAL_THRESHOLDS))
        with open(os.path.join(qdir, "%s_signals.sql" % lk), "w") as fh:
            fh.write(sig)
        pending.append("queries/%s_signals.sql" % lk)

    meta.update({
        "state": "awaiting_breakdowns",
        "leagues": leagues,
        "leagues_below_floor": dropped,
        "plan": plan,
        "pending_queries": pending,
        "dimension_top_n": {d["id"]: d.get("top_n", DEFAULT_TOP_N) for d in DIMENSIONS},
    })
    write_json(meta_path(smd), meta)
    print("planned %d queries across %d league(s): %s"
          % (len(pending), len(leagues), ", ".join(leagues)))
    if dropped:
        print("below the $%s floor, not broken out: %s" % (floor, ", ".join(dropped)))


# --------------------------------------------------------------------------
# postprocess — table configs, per-dimension data, action items, brief
# --------------------------------------------------------------------------

CURRENCY0 = {"format": "$", "decimal_places": 0}

COLUMN_SPECS = {
    "name":          {"headerName": "Name", "type": "string"},
    "name2":         {"headerName": "Team", "type": "string"},
    "sales_ty":      {"headerName": "Net demand TY", "format": "$", "decimal_places": 0},
    "sales_ly":      {"headerName": "Net demand LY", "format": "$", "decimal_places": 0},
    "yoy_pct":       {"headerName": "YoY", "format": "%:1", "show_sign": True},
    "share_pct":     {"headerName": "Share", "format": "%:1"},
    "gm_pct_ty":     {"headerName": "GM % TY", "format": "%:1"},
    "gm_delta_pts":  {"headerName": "GM move", "format": "pts:1", "show_sign": True},
    "aur_ty":        {"headerName": "AUR TY", "format": "$", "decimal_places": 2},
    "units_ty":      {"headerName": "Units TY", "format": "int"},
    "oh_retail_ty":  {"headerName": "On hand (retail)", "format": "$", "decimal_places": 0},
    "oo_retail":     {"headerName": "On order (retail)", "format": "$", "decimal_places": 0},
    "st_pct_ty":     {"headerName": "Sell-through", "format": "%:2"},
    "wos":           {"headerName": "Weeks of supply", "format": "pts:1"},
    "instock_pct":   {"headerName": "In stock", "format": "%:1"},
    "league":        {"headerName": "League", "type": "string"},
    "units_yoy_pct": {"headerName": "Units YoY", "format": "%:1", "show_sign": True},
}

DIM_TABLE_COLUMNS = ["name", "sales_ty", "sales_ly", "yoy_pct", "share_pct",
                     "gm_pct_ty", "gm_delta_pts", "units_ty", "oh_retail_ty"]
LEAGUE_TABLE_COLUMNS = ["league", "sales_ty", "sales_ly", "sales_yoy_pct", "units_ty",
                        "gm_pct_ty", "gm_delta_pts", "aur_ty", "oh_retail_ty", "oo_retail"]


def table_config(dataframe_path, columns, title):
    specs = []
    for c in columns:
        spec = dict(COLUMN_SPECS.get(c, {"headerName": c}))
        spec["field"] = c
        specs.append(spec)
    return {"title": title, "dataframe_path": dataframe_path, "columns": specs}


def cmd_postprocess(args):
    smd = require_smd(args.output)
    meta = load_json(meta_path(smd))
    tdir, ddir = os.path.join(smd, "tables"), os.path.join(smd, "data")
    os.makedirs(tdir, exist_ok=True)
    os.makedirs(ddir, exist_ok=True)

    dim_labels = {d["id"]: d["label"] for d in DIMENSIONS}
    dim_nouns = {d["id"]: d["noun"] for d in DIMENSIONS}

    # league scoreboard ----------------------------------------------------
    board = load_snapshot(smd, "10_league_scoreboard")
    write_json(os.path.join(ddir, "league_scoreboard.json"), board)
    # LEAGUE_TABLE_COLUMNS + sales_yoy_pct spec
    COLUMN_SPECS.setdefault("sales_yoy_pct", {"headerName": "YoY", "format": "%:1",
                                              "show_sign": True})
    write_json(os.path.join(tdir, "league_scoreboard.json"),
               table_config("../data/league_scoreboard.json", LEAGUE_TABLE_COLUMNS,
                            "League summary — week ending %s" % meta["week_ending"]))

    totals = next(r for r in board if r["row_type"] == "total")

    # dimensions -----------------------------------------------------------
    sections, foot_checks = {}, []
    for league, p in meta["plan"].items():
        lk = p["key"]
        sections[league] = []
        for dim_id in p["dimensions"]:
            rows = load_snapshot(smd, "%s_%s" % (lk, dim_id))
            write_json(os.path.join(ddir, "%s_%s.json" % (lk, dim_id)), rows)
            name = "%s_%s" % (lk, dim_id)
            top_n = meta["dimension_top_n"].get(dim_id, DEFAULT_TOP_N)
            tot = next((r for r in rows if r["row_type"] == "total"), None)
            cfg_cols = list(DIM_TABLE_COLUMNS)
            if any(r.get("name2") for r in rows):
                cfg_cols.insert(1, "name2")
            write_json(os.path.join(tdir, name + ".json"), table_config(
                "../data/%s.json" % name, cfg_cols,
                "%s — %s — top %d of %s %s" % (
                    dim_labels[dim_id], league, top_n,
                    (tot or {}).get("total_rows", "?"), dim_nouns[dim_id])))
            sections[league].append({"dimension": dim_id, "label": dim_labels[dim_id],
                                     "table": "tables/%s.json" % name,
                                     "snapshot": "snapshots/%s.json" % name,
                                     "rows": len(rows)})
            # footing check: top rows + tail must equal the total, exactly.
            if tot:
                parts = sum((num(r["sales_ty"]) or 0) for r in rows
                            if r["row_type"] in ("top", "tail"))
                diff = parts - (num(tot["sales_ty"]) or 0)
                foot_checks.append({"table": name, "diff": diff,
                                    "ok": abs(diff) < 0.01})

    # action signals --------------------------------------------------------
    actions = []
    for league, p in meta["plan"].items():
        raw = load_snapshot(smd, "%s_signals" % p["key"])
        by_sig = {}
        for r in raw:
            by_sig.setdefault(r["signal_id"], []).append(r)
        for sig_id, m in SIGNAL_META.items():
            got = by_sig.get(sig_id, [])
            for r in got:
                r["_sort"] = num(r.get(m["sort_key"]))
            got = [r for r in got if r["_sort"] is not None]
            got.sort(key=lambda r: r["_sort"], reverse=m["sort_desc"])
            actions.append({
                "signal_id": sig_id, "label": m["label"], "note": m["note"],
                "league": league,
                "fired": len(got) > 0,
                "rows": [{k: v for k, v in r.items() if k != "_sort"} for r in got[:5]],
            })
    write_json(os.path.join(smd, "_action_items.json"), actions)

    # analysis brief --------------------------------------------------------
    brief = [
        "# Analysis brief — %s, %s, week ending %s" % (
            meta["planner_nm"], meta["area_of_business"], meta["week_ending"]),
        "",
        "Buyers in scope: %s" % ", ".join(meta["buyers"]),
    ]
    if meta.get("dead_buyer_codes"):
        brief.append("**Dead buyer codes (matched zero rows): %s.** Every figure below "
                     "excludes their book." % ", ".join(meta["dead_buyer_codes"]))
    brief += [
        "",
        "Headline (from snapshots/10_league_scoreboard.json, row_type=total):",
        "- net demand TY %s, LY %s" % (totals["sales_ty"], totals["sales_ly"]),
        "- units TY %s, LY %s" % (totals["units_ty"], totals["units_ly"]),
        "- gross margin TY %s%%, move %s pts" % (totals["gm_pct_ty"], totals["gm_delta_pts"]),
        "",
        "Leagues broken out: %s" % ", ".join(meta["leagues"]),
        "Below the $%s floor: %s" % (meta.get("league_floor_usd") or DEFAULT_LEAGUE_FLOOR,
                                     ", ".join(meta["leagues_below_floor"]) or "none"),
        "",
        "## Suppressed dimensions (dimension_overrides.json)",
    ]
    for league, p in meta["plan"].items():
        for s in p["suppressed"]:
            brief.append("- %s / %s: %s" % (league, s["dimension"], s["rule"]))
    brief += ["", "## Footing checks (top rows + tail == total)"]
    for f in foot_checks:
        brief.append("- %s: %s (diff %s)" % (f["table"], "OK" if f["ok"] else "FAIL",
                                             f["diff"]))
    brief += ["", "## Signals that fired"]
    for a in actions:
        if a["fired"]:
            brief.append("- %s (%s): %d row(s)" % (a["label"], a["league"], len(a["rows"])))
    with open(os.path.join(smd, "_analysis_brief.md"), "w") as fh:
        fh.write("\n".join(brief) + "\n")

    meta["state"] = "postprocessed"
    meta["sections"] = sections
    meta["footing_checks"] = foot_checks
    write_json(meta_path(smd), meta)

    bad = [f for f in foot_checks if not f["ok"]]
    print("postprocess: %d table configs, %d action signals, %d footing checks (%d FAIL)"
          % (len(foot_checks) + 1, len(actions), len(foot_checks), len(bad)))
    for f in bad:
        print("  FOOTING FAIL: %s diff %s" % (f["table"], f["diff"]))


# --------------------------------------------------------------------------
# formatting — the ONLY place rounding happens
# --------------------------------------------------------------------------

def usd(v, dp=0, dash_zero=False):
    v = num(v)
    if v is None or (dash_zero and v == 0):
        # notes-to-self.md 2026-04-01: no last-year base prints an em dash,
        # never $0 and never -100%.
        return "&mdash;"
    return "$" + format(round(v, dp), ",.%df" % dp)


def usd_m(v, dp=2):
    v = num(v)
    return "&mdash;" if v is None else "$" + format(round(v / 1e6, dp), ",.%df" % dp) + "M"


def pct(v, dp=1, sign=False):
    v = num(v)
    if v is None:
        return "&mdash;"
    s = "+" if (sign and v > 0) else ("−" if v < 0 else "")
    return s + format(round(abs(v) if s else v, dp), ",.%df" % dp) + "%"


def pts(v, dp=1):
    v = num(v)
    if v is None:
        return "&mdash;"
    s = "+" if v > 0 else ("−" if v < 0 else "")
    return s + format(round(abs(v), dp), ",.%df" % dp) + " pts"


def cnt(v, dp=0):
    v = num(v)
    return "&mdash;" if v is None else format(round(v, dp), ",.%df" % dp)


def cls(v):
    v = num(v)
    return "" if v is None else (' class="up"' if v > 0 else ' class="dn"')


# --------------------------------------------------------------------------
# render-html — the customer's own template, filled deterministically
# --------------------------------------------------------------------------

def _traced(snapshot, path, rendered, klass=""):
    """Same contract as _cellspan, with a colour class on the span."""
    return ('<span class="num%s" data-src="%s" data-path="%s">%s</span>'
            % (klass, snapshot, path, rendered))


def _cellspan(value, snapshot, path, rendered):
    """Traceable figure. Mirrors the .sdoc <cell/> contract in HTML: the number
    is never a literal in the template, it carries the snapshot + row/column it
    came from, so a verifier can resolve it back."""
    return ('<span class="num" data-src="%s" data-path="%s">%s</span>'
            % (snapshot, path, rendered))


def cmd_render_html(args):
    smd = require_smd(args.output)
    meta = load_json(meta_path(smd))
    board = load_snapshot(smd, "10_league_scoreboard")
    total = next(r for r in board if r["row_type"] == "total")
    S_BOARD = "snapshots/10_league_scoreboard.json"

    def c(row_sel, col, rendered):
        return _cellspan(None, S_BOARD, "%s.%s" % (row_sel, col), rendered)

    # --- tiles ------------------------------------------------------------
    def tile(lab, val, cmp_html):
        return ('<div class="tile"><div class="lab">%s</div>'
                '<div class="val">%s</div><div class="cmp">%s</div></div>'
                % (lab, val, cmp_html))

    tiles = "".join([
        tile("Net demand", c("total", "sales_ty", usd(total["sales_ty"])),
             "vs %s last year &nbsp;<span%s>%s</span>"
             % (c("total", "sales_ly", usd(total["sales_ly"], dash_zero=True)),
                cls(total["sales_yoy_pct"]), _traced(S_BOARD, "total.sales_yoy_pct", pct(total["sales_yoy_pct"])))),
        tile("Units", c("total", "units_ty", cnt(total["units_ty"])),
             "vs %s last year &nbsp;<span%s>%s</span>"
             % (c("total", "units_ly", cnt(total["units_ly"])),
                cls(total["units_yoy_pct"]), _traced(S_BOARD, "total.units_yoy_pct", pct(total["units_yoy_pct"])))),
        tile("Gross margin", c("total", "gm_pct_ty", pct(total["gm_pct_ty"])),
             "%s last year &nbsp;<span%s>%s</span>"
             % (c("total", "gm_pct_ly", pct(total["gm_pct_ly"])),
                cls(total["gm_delta_pts"]), _traced(S_BOARD, "total.gm_delta_pts", pts(total["gm_delta_pts"])))),
        tile("Average unit retail", c("total", "aur_ty", usd(total["aur_ty"], 2)),
             "vs %s last year" % c("total", "aur_ly", usd(total["aur_ly"], 2))),
        tile("On-hand retail", c("total", "oh_retail_ty", usd_m(total["oh_retail_ty"])),
             "vs %s last year &nbsp;<span%s>%s</span>"
             % (c("total", "oh_retail_ly", usd_m(total["oh_retail_ly"])),
                cls(-(num(total["oh_chg_pct"]) or 0)), _traced(S_BOARD, "total.oh_chg_pct", pct(total["oh_chg_pct"])))),
        tile("On order (retail)", c("total", "oo_retail", usd_m(total["oo_retail"])),
             "%s units across all due buckets"
             % c("total", "oo_units", cnt(total["oo_units"]))),
        tile("Sell-through", c("total", "st_pct_ty", pct(total["st_pct_ty"], 2)),
             "%s last year &nbsp;<span%s>%s</span>"
             % (c("total", "st_pct_ly", pct(total["st_pct_ly"], 2)),
                cls(total["st_delta_pts"]), _traced(S_BOARD, "total.st_delta_pts", pts(total["st_delta_pts"], 2)))),
        tile("Weeks of supply", c("total", "wos", cnt(total["wos"], 1)),
             "on-hand units over the trailing four-week average"),
    ])

    # --- headline prose (deterministic; phase 2 replaces this) ------------
    delta = (num(total["sales_ty"]) or 0) - (num(total["sales_ly"]) or 0)
    verb = "gave back" if delta < 0 else "added"
    prose = (
        "<p>Demand closed the week at <strong>%s</strong> against <strong>%s</strong> "
        "a year ago, so we %s <strong>%s</strong>, or %s. Units moved %s and average "
        "unit retail was %s against %s.</p>"
        % (c("total", "sales_ty", usd(total["sales_ty"])),
           c("total", "sales_ly", usd(total["sales_ly"], dash_zero=True)),
           verb, '<span class="num" data-derived="total.sales_ty - total.sales_ly" '
        'data-src="%s">%s</span>' % (S_BOARD, usd(abs(delta))),
           pct(total["sales_yoy_pct"]),
           pct(total["units_yoy_pct"]),
           c("total", "aur_ty", usd(total["aur_ty"], 2)),
           c("total", "aur_ly", usd(total["aur_ly"], 2)))
        + "<p>Gross margin is %s, %s against last year. On-hand retail is %s against "
          "%s of on order.</p>"
          % (c("total", "gm_pct_ty", pct(total["gm_pct_ty"])),
             pts(total["gm_delta_pts"]),
             c("total", "oh_retail_ty", usd_m(total["oh_retail_ty"])),
             c("total", "oo_retail", usd_m(total["oo_retail"]))))

    # --- league table -----------------------------------------------------
    def league_row(r, i):
        klass = ' class="total"' if r["row_type"] == "total" else ""
        sel = "total" if r["row_type"] == "total" else "league[%d]" % i
        name = ("Total — %d league%s" % (len(meta["leagues"]),
                                         "" if len(meta["leagues"]) == 1 else "s")
                if r["row_type"] == "total" else r["league"])
        cells = [name,
                 c(sel, "sales_ty", usd(r["sales_ty"])),
                 c(sel, "sales_ly", usd(r["sales_ly"], dash_zero=True)),
                 _traced(S_BOARD, "%s.sales_yoy_pct" % sel, pct(r["sales_yoy_pct"]),
                         cls(r["sales_yoy_pct"]).replace(' class="', ' ').rstrip('"')),
                 c(sel, "units_ty", cnt(r["units_ty"])),
                 c(sel, "gm_pct_ty", pct(r["gm_pct_ty"])),
                 _traced(S_BOARD, "%s.gm_delta_pts" % sel, pts(r["gm_delta_pts"])),
                 c(sel, "aur_ty", usd(r["aur_ty"], 2)),
                 c(sel, "oh_retail_ty", usd(r["oh_retail_ty"])),
                 c(sel, "oo_retail", usd(r["oo_retail"]))]
        return "<tr%s>%s</tr>" % (klass, "".join("<td>%s</td>" % x for x in cells))

    hdr = ("<tr>" + "".join("<th>%s</th>" % h for h in
                            ["League", "Net demand TY", "Net demand LY", "YoY", "Units TY",
                             "GM % TY", "GM move", "AUR TY", "On hand (retail)",
                             "On order (retail)"]) + "</tr>")
    lrows = [league_row(r, i) for i, r in enumerate(
        [x for x in board if x["row_type"] == "league"])]
    lrows.append(league_row(total, 0))
    league_tbl = ('<table data-table-config="tables/league_scoreboard.json">'
                  '<caption>All leagues in the area, week ending %s. Leagues below $%s '
                  'of this-year demand are not broken out.</caption><thead>%s</thead>'
                  '<tbody>%s</tbody></table>'
                  % (meta["week_ending"],
                     cnt(meta.get("league_floor_usd") or DEFAULT_LEAGUE_FLOOR),
                     hdr, "".join(lrows)))

    # --- dimension sections ----------------------------------------------
    dim_labels = {d["id"]: d["label"] for d in DIMENSIONS}
    dim_nouns = {d["id"]: d["noun"] for d in DIMENSIONS}
    blocks = []
    for league, p in meta["plan"].items():
        if len(meta["leagues"]) > 1:
            blocks.append("<h2>%s</h2>" % league)
        for dim_id in p["dimensions"]:
            name = "%s_%s" % (p["key"], dim_id)
            rows = load_snapshot(smd, name)
            snap = "snapshots/%s.json" % name
            tot = next((r for r in rows if r["row_type"] == "total"), None)
            has2 = any(r.get("name2") for r in rows)
            cols = ["Name"] + (["Team"] if has2 else []) + [
                "Net demand TY", "Net demand LY", "YoY", "Share", "GM % TY",
                "GM move", "Units TY", "On hand (retail)"]
            body = []
            for i, r in enumerate(rows):
                klass = {"tail": ' class="tail"', "total": ' class="total"'}.get(
                    r["row_type"], "")
                sel = "row[%d]" % i
                label = ("Total — %s %s" % (cnt(r["total_rows"]), dim_nouns[dim_id])
                         if r["row_type"] == "total" else r["name"])
                cells = [label] + ([r.get("name2") or "&mdash;"] if has2 else []) + [
                    _cellspan(None, snap, "%s.sales_ty" % sel, usd(r["sales_ty"])),
                    _cellspan(None, snap, "%s.sales_ly" % sel, usd(r["sales_ly"], dash_zero=True)),
                    _traced(snap, "%s.yoy_pct" % sel, pct(r["yoy_pct"]),
                            cls(r["yoy_pct"]).replace(' class="', ' ').rstrip('"')),
                    _cellspan(None, snap, "%s.share_pct" % sel, pct(r["share_pct"])),
                    _cellspan(None, snap, "%s.gm_pct_ty" % sel, pct(r["gm_pct_ty"])),
                    # The customer prints no GM move on an aggregate "all other"
                    # row. Carried: a blended margin move over an arbitrary tail
                    # is not a number anybody should act on.
                    ("&mdash;" if r["row_type"] == "tail"
                     else _traced(snap, "%s.gm_delta_pts" % sel, pts(r["gm_delta_pts"]))),
                    _cellspan(None, snap, "%s.units_ty" % sel, cnt(r["units_ty"])),
                    _cellspan(None, snap, "%s.oh_retail_ty" % sel, usd(r["oh_retail_ty"])),
                ]
                body.append("<tr%s>%s</tr>" % (klass,
                                               "".join("<td>%s</td>" % x for x in cells)))
            top_n = meta["dimension_top_n"].get(dim_id, DEFAULT_TOP_N)
            blocks.append(
                '<h2>%s</h2><div class="scroll">'
                '<table data-table-config="tables/%s.json">'
                '<caption>Top %d of %s %s by net demand, highest first.</caption>'
                '<thead><tr>%s</tr></thead><tbody>%s</tbody></table></div>'
                % (dim_labels[dim_id], name, top_n,
                   cnt((tot or {}).get("total_rows")), dim_nouns[dim_id],
                   "".join("<th>%s</th>" % h for h in cols), "".join(body)))
        for s in p["suppressed"]:
            blocks.append('<p class="note">%s not broken out for %s — suppressed by '
                          'dimension_overrides.json (%s).</p>'
                          % (dim_labels[s["dimension"]], league, s["rule"]))

    # --- action signals ---------------------------------------------------
    actions = load_json(os.path.join(smd, "_action_items.json"))
    arows, n = [], 0
    for a in actions:
        if not a["fired"]:
            arows.append('<tr><td>&mdash;</td><td>%s</td><td colspan="3">No rows met '
                         'the threshold this week.</td></tr>' % a["label"])
            continue
        for r in a["rows"][:3]:
            n += 1
            snap = "snapshots/%s_signals.json" % meta["plan"][a["league"]]["key"]
            size = next((_cellspan(None, snap, "%s.%s" % (a["signal_id"], k), f(r[k]))
                         for k, f in (("oh_retail_ty", usd), ("oo_retail", usd),
                                      ("sales_ty", usd), ("gm_delta_pts", pts),
                                      ("wos", cnt))
                         if num(r.get(k)) is not None), "&mdash;")
            arows.append("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
                         % (n, a["label"], r["name"], size, a["note"]))
    actions_tbl = ('<table id="tbl-actions"><caption>Ranked action signals for the week. '
                   'Dollars are weekly unless stated.</caption><thead><tr>'
                   '<th>#</th><th>Signal</th><th>Where</th><th>Size</th><th>Action</th>'
                   '</tr></thead><tbody>%s</tbody></table>' % "".join(arows))

    # --- footnotes --------------------------------------------------------
    foot = ["Net demand and units are the trailing seven days closing on the Saturday "
            "named in the header.",
            "Year over year compares the trailing seven days with the same seven days "
            "364 days earlier, so the days of the week line up.",
            "Gross margin is (demand &minus; cost) &divide; demand. Movement is stated "
            "in points, never as a percent change.",
            "Sell-through is in-house units sold divided by (units sold + units still "
            "on hand).",
            "Weeks of supply is on-hand units divided by the trailing four-week average "
            "of weekly in-house units.",
            "In-stock rate is weighted by product page views.",
            "First party versus third party is a vendor-code classification, not a "
            "warehouse flag. Drop-ship and third party overlap but are not the same set."]
    for league, p in meta["plan"].items():
        for s in p["suppressed"]:
            foot.append("%s are not broken out for %s — suppressed in "
                        "dimension_overrides.json." % (dim_labels[s["dimension"]], league))
    if meta.get("dead_buyer_codes"):
        foot.append("Buyer code(s) %s matched no rows in this week and contribute "
                    "nothing to any figure on this page."
                    % ", ".join(meta["dead_buyer_codes"]))

    # --- fill the customer's template ------------------------------------
    with open(os.path.join(BUNDLE, "templates", "recap.html.tmpl")) as fh:
        html = fh.read()
    # Drop the customer's build-note comments. They document the old half-manual
    # render and would otherwise trip the unfilled-token assertion below.
    html = re.sub(r"<!--.*?-->", "", html, flags=re.S)
    recips = recipients_for(meta["area_of_business"])
    tokens = {
        "AREA": meta["area_of_business"],
        "WEEK_ENDING": meta["week_ending"],
        "PLANNER": meta["planner_nm"],
        "BUYERS": ", ".join(meta["buyers"]),
        "BUILT_AT": args.built_at or datetime.now().strftime("%A %d %B %Y, %H:%M"),
        "PLANNER_EMAIL": (recips[0]["email"] if recips else "the planner"),
        "TILES": tiles,
        "HEADLINE_PROSE": prose,
        "TABLE_LEAGUE": league_tbl,
        "DIMENSION_SECTIONS": "".join(blocks),
        "TABLE_ACTIONS": actions_tbl,
        "NEXT_WEEK": "same area, next Saturday's snapshot.",
        "FOOTNOTES": "<ol>%s</ol>" % "".join("<li>%s</li>" % f for f in foot),
    }
    for k, v in tokens.items():
        html = html.replace("__%s__" % k, str(v))
    left = re.findall(r"__[A-Z_]+__", html)
    if left:
        raise SystemExit("template still has unfilled tokens: %s" % sorted(set(left)))

    out = os.path.join(smd, "exports")
    os.makedirs(out, exist_ok=True)
    slug = (meta["area_of_business"].lower().replace(",", "")
            .replace("&", "and").replace(" ", "-"))
    slug = re.sub(r"-+", "-", slug)
    path = os.path.join(out, "%s-%s.html" % (meta["week_ending"], slug))
    with open(path, "w") as fh:
        fh.write(html)
    print("wrote", path)


def recipients_for(area):
    path = os.path.join(BUNDLE, "recipients.csv")
    if not os.path.exists(path):
        return []
    with open(path) as fh:
        return [r for r in csv.DictReader(fh)
                if r["area"] == area and r["active"] == "yes"]


# --------------------------------------------------------------------------


# --------------------------------------------------------------------------
# render-deck — one slide per thing the person said they present
# --------------------------------------------------------------------------
# A deck is a narrative somebody owns. This does not choose what goes on a slide, rank anything, or
# drop a slide that comes back thin — it renders exactly the plan in slides.json, every week, so the
# deck is comparable to last week's. The figures keep the same trace spans as the document, so a
# number on a slide can be followed back to the query that produced it.

DECK_CSS = """
body{margin:0;font:16px/1.5 -apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif;
  color:#17191e;background:#fff}
.slide{width:100%;min-height:100vh;padding:64px 72px;box-sizing:border-box;page-break-after:always}
h1{font-size:40px;letter-spacing:-.02em;margin:0 0 28px;line-height:1.1}
.row{display:flex;gap:44px;flex-wrap:wrap;margin:0 0 26px}
.metric .lab{font-size:14px;text-transform:uppercase;letter-spacing:.08em;color:#6b7280}
.metric .val{font-size:44px;font-weight:700;letter-spacing:-.03em;line-height:1.1}
table{border-collapse:collapse;font-size:18px;min-width:60%}
th,td{text-align:left;padding:9px 16px;border-bottom:1px solid #e4e1db}
th{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:#6b7280}
td.n,th.n{text-align:right;font-variant-numeric:tabular-nums}
p.note{font-size:20px;color:#374151;max-width:60ch}
"""


def _deck_metric(board, key):
    """One headline figure, traced like every other number we publish."""
    total = next(r for r in board if r["row_type"] == "total")
    S = "snapshots/10_league_scoreboard.json"
    known = {
        "revenue": ("Revenue", "sales_ty", lambda v: usd(v)),
        "units":   ("Units", "units_ty", lambda v: cnt(v)),
        "yoy":     ("vs last year", "sales_yoy_pct", lambda v: pct(v, sign=True)),
    }
    if key not in known:
        return None
    label, col, fmt = known[key]
    rendered = _cellspan(None, S, "total.%s" % col, fmt(total[col]))
    return ('<div class="metric"><div class="lab">%s</div><div class="val">%s</div></div>'
            % (label, rendered))


def _deck_table(smd, name):
    """A named snapshot as a slide table. Whole thing — trimming is the author's call, not ours."""
    # Check the file rather than catching: load_json raises SystemExit on a missing path, which no
    # `except OSError` will stop, so one slide naming a snapshot that is not there killed the whole
    # render and the deck came out short with no error the reader would see.
    path = os.path.join(smd, "snapshots", "%s.json" % name)
    if not os.path.exists(path):
        return ('<p class="note">No snapshot called <b>%s</b> in this run, so this slide has '
                'nothing to show. The slide is kept so the deck stays the same length '
                'week to week.</p>' % name)
    try:
        rows = load_snapshot(smd, name)
    except (ValueError, TypeError, KeyError) as e:
        return '<p class="note">Could not read %s: %s</p>' % (name, e)
    if not rows:
        return '<p class="note">%s returned no rows this week.</p>' % name
    cols = [c for c in rows[0] if not c.startswith("_")]
    head = "".join('<th%s>%s</th>' % (' class=n' if _numeric(rows, c) else '', c.replace("_", " "))
                   for c in cols)
    body = []
    for r in rows:
        cells = "".join('<td%s>%s</td>' % (' class=n' if _numeric(rows, c) else '', _cell(r[c]))
                        for c in cols)
        body.append("<tr>%s</tr>" % cells)
    return "<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>" % (head, "".join(body))


def _numeric(rows, col):
    return all(isinstance(r.get(col), (int, float)) or r.get(col) is None for r in rows)


def _cell(v):
    if v is None:
        return "&mdash;"
    if isinstance(v, float):
        return "%s" % usd(v) if abs(v) >= 1000 else "%.1f" % v
    if isinstance(v, int):
        return cnt(v)
    return str(v)


def cmd_render_deck(args):
    smd = require_smd(args.output)
    plan = load_json(os.path.join(os.path.dirname(os.path.dirname(
        os.path.abspath(__file__))), "slides.json"), default=None)
    if not plan or not plan.get("slides"):
        raise SystemExit("render-deck needs slides.json in the bundle — it is the plan the person "
                         "gave for what goes on each slide, and there is nothing to guess from.")
    board = load_snapshot(smd, "10_league_scoreboard")

    deck_dir = args.deck or (os.path.splitext(args.output)[0] + ".sdeck")
    slides_dir = os.path.join(deck_dir, "slides")
    os.makedirs(slides_dir, exist_ok=True)

    for i, sl in enumerate(plan["slides"], 1):
        parts, metrics = [], []
        for item in sl["content"]:
            if item.startswith("table:"):
                parts.append(_deck_table(smd, item.split(":", 1)[1]))
            elif item.startswith("text:"):
                parts.append('<p class="note">%s</p>' % item.split(":", 1)[1])
            else:
                m = _deck_metric(board, item)
                if m:
                    metrics.append(m)
                else:
                    parts.append('<p class="note">%s</p>' % item)
        if metrics:
            parts.insert(0, '<div class="row">%s</div>' % "".join(metrics))
        html = ("<!doctype html><meta charset=utf-8><style>%s</style>"
                '<section class="slide"><h1>%s</h1>%s</section>'
                % (DECK_CSS, sl["title"], "".join(parts)))
        with open(os.path.join(slides_dir, "%02d.html" % i), "w") as fh:
            fh.write(html)

    with open(os.path.join(deck_dir, "manifest.yaml"), "w") as fh:
        fh.write("title: %s\n" % os.path.basename(deck_dir).replace(".sdeck", ""))
    print("wrote %d slide(s) to %s" % (len(plan["slides"]), deck_dir))


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("plan-scoreboard")
    a.add_argument("--output", required=True)
    a.add_argument("--planner", required=True)
    a.add_argument("--area", required=True)
    a.add_argument("--week", default=None)
    a.add_argument("--league-floor", type=float, default=DEFAULT_LEAGUE_FLOOR)
    a.add_argument("--buyer-validation", default="strict", choices=["strict", "warn"])
    a.add_argument("--buyers", default=None,
                   help="comma-separated override for the buyer_areas.json list")
    a.set_defaults(fn=cmd_plan_scoreboard)

    for name, fn in (("plan-breakdowns", cmd_plan_breakdowns),
                     ("postprocess", cmd_postprocess)):
        s = sub.add_parser(name)
        s.add_argument("--output", required=True)
        s.set_defaults(fn=fn)

    r = sub.add_parser("render-html")
    r.add_argument("--output", required=True)
    r.add_argument("--built-at", default=None)
    r.set_defaults(fn=cmd_render_html)

    d = sub.add_parser("render-deck")
    d.add_argument("--output", required=True, help="the .sdoc/.smd the snapshots live in")
    d.add_argument("--deck", default=None, help="where to write the .sdeck (defaults alongside)")
    d.set_defaults(fn=cmd_render_deck)

    args = p.parse_args()
    args.fn(args)


if __name__ == "__main__":
    main()
