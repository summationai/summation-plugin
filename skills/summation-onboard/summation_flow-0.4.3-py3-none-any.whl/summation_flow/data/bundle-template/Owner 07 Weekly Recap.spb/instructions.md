# Owner 07 Weekly Recap — execution instructions

Two phases. Phase 1 is deterministic Python and produces every number. Phase 2
is you, writing narrative only. **You never compute a figure and you never type
one into prose as a literal.**

Parameters arrive from `manifest.yaml`: `planner_nm`, `area_of_business`, and
optionally `week_ending`, `league_floor_usd`, `buyer_code_validation`.

---

## Step 0 — resolve the anchor week. Do NOT use the calendar.

Run `queries/01_anchor_week.sql`. It returns the newest `periodending` carrying
at least 10 distinct planners. The ETL lands Sunday night, sometimes Monday,
sometimes Tuesday; the calendar has published a four-planner week before.

`periodending` is always a **Saturday**. A Friday or Monday value returns zero
rows and no error, which looks exactly like "no business this week".

Skip this only if `week_ending` was supplied, and even then run the query so the
run records what the table thought the newest loaded week was.

## Step 1 — plan the scoreboard

```
python3 scripts/prepare.py plan-scoreboard --output {smd_dir} \
    --planner {planner_nm} --area "{area_of_business}" [--week {week_ending}] \
    [--league-floor {league_floor_usd}] [--buyer-validation {strict|warn}]
```

Then execute every path in `_meta.json.pending_queries` with ONE glob call over
`{smd_dir}/queries/*.sql`, writing `snapshots/{name}.json` in the shape
`{"columns": [...], "data": [[...]]}`.

## Step 2 — plan the breakdowns

```
python3 scripts/prepare.py plan-breakdowns --output {smd_dir}
```

This enforces two gates before it will emit anything:

1. **Freshness.** Zero rows, a stale `latest_saturday` on an unpinned run, or
   fewer than 10 planners stops the run. Do not work around it. A partial load
   makes every share number wrong.
2. **Buyer-code liveness.** `buyer_areas.json` is hand-maintained and lags
   reorgs. A code that matches zero rows silently removes that buyer's entire
   book from every figure. `strict` stops; `warn` continues and footnotes it.
   If the gate fires, **tell the user the code and the dollars involved** — that
   is a more valuable finding than the recap.

Then execute the new `pending_queries` the same way.

## Step 3 — postprocess

```
python3 scripts/prepare.py postprocess --output {smd_dir}
```

Writes `tables/*.json` (table configs), `data/*.json`, `_action_items.json`,
`_analysis_brief.md`, and the footing checks. **Read `_analysis_brief.md` before
you write anything.** If any footing check says FAIL, stop and report it.

## Step 4 — write the narrative (this is your only job)

Assemble `document.xml` from `templates/report.smd/document.xml`.

Rules, all of them from the planner who built this by hand:

- **Three bullets per section, maximum.** Pick by absolute dollars, never by
  percent.
- **Lead with the business implication, then the number.**
- Write "trailing seven days", not "L7". No abbreviations of time windows.
- **Every number in prose must also be in a table on the same page.** If it is
  not in a table, cut it.
- **Never tell the reader what they manage.** They know.
- Every figure is a `<cell src="snapshots/…" path="…"/>`. A literal numeral in
  prose is a defect, not a shortcut.
- A `<table/>` points at `tables/*.json`, never at `snapshots/*.json`.
- Where last year is zero, print an em dash — not `$0`, not `−100%`.
- Third-party shortfalls **escalate to the buying team**. We do not control 3P
  buys, so never write "restore assortment" for a 3P line.
- Promotions are deliberate decisions. Say whether the offer worked. Never write
  "fix the promo".
- A large percentage on a tiny base is a base effect. Say so, and plan against
  the dollars.

## Step 5 — hydrate and check

Run the S-Doc save step so `<cell/>` tags hydrate into `<num>` tags with traces.
Then confirm: no unhydrated cells, no hardcoded numerals, every `<table/>` src
resolves to a table config that exists.

## Step 6 — HTML render (the customer's own page)

```
python3 scripts/prepare.py render-html --output {smd_dir}
```

This fills `templates/recap.html.tmpl` — the planner's own hand-built page,
carried verbatim, styles and all. Do not restyle it. It is read on a phone
before a 10:00 buy meeting and the inline CSS is deliberate, because external
stylesheets die in mail clients.

## Never

- Never send before the run has been read end to end.
- Never email anything from this playbook. Delivery is a separate, explicit step
  and `config/recipients.csv` is a real distribution list.
