-- All seven action signals for one league in ONE statement, keyed by
-- `signal_id`. The customer kept this SQL embedded in build_recap.py "because
-- they are all slightly different shapes and keeping them as separate files
-- meant nine copies of the same WHERE clause". A single UNION ALL over a
-- shared column contract fixes the duplication without hiding SQL in Python.
--
-- Framing rules carried verbatim from the customer's SKILL.md step 5:
--   * stockout_exposure is WAREHOUSE STOCK ONLY (isdropship = 'N'), reported as
--     dollars of weekly exposure, never as a count of items.
--   * third-party lines escalate to the buying team; we do not control 3P buys.
--   * promotions are deliberate decisions. Say whether it worked. Never "fix".
--
-- No ROUND().
WITH base AS (
    SELECT *
    FROM {{TABLE}}
    WHERE planner_nm = '{{PLANNER}}'
      {{BUYER_FILTER}}
      AND periodending = '{{WEEK}}'
      AND planningleague = '{{LEAGUE}}'
      {{HARD_EXCLUDE}}
)
,
signals AS (
    -- 1. Markdown exposure -- high weeks of supply while demand falls.
    SELECT 'markdown_exposure' AS signal_id, team AS name,
           CAST(NULL AS DOUBLE) AS sales_ty,
           SUM(ohr) AS oh_retail_ty,
           CAST(NULL AS DOUBLE) AS oo_retail,
           SUM(ohu) * 1.0 / NULLIF(SUM(ih_netunits_l28) / 4.0, 0) AS wos,
           (SUM(netdemand_l7) - SUM(netdemand_l7_ly))
               * 1.0 / NULLIF(SUM(netdemand_l7_ly), 0) * 100 AS yoy_pct,
           CAST(NULL AS DOUBLE) AS gm_delta_pts,
           CAST(NULL AS DOUBLE) AS st_pct_ty
    FROM base
    GROUP BY team
    HAVING SUM(ohu) * 1.0 / NULLIF(SUM(ih_netunits_l28) / 4.0, 0) > {{MARKDOWN_WOS_MIN}}
       AND SUM(netdemand_l7) < SUM(netdemand_l7_ly)
       AND SUM(ohr) > {{MARKDOWN_OHR_MIN}}

    UNION ALL
    -- 2. Stockout on selling items -- WAREHOUSE STOCK ONLY. Dollars per week.
    SELECT 'stockout_exposure', team,
           SUM(netdemand_l7), NULL, NULL, NULL, NULL, NULL, NULL
    FROM base
    WHERE isdropship = 'N' AND ohu = 0 AND netdemand_l7 > 0
    GROUP BY team

    UNION ALL
    -- 3. Low inventory on a fast seller.
    SELECT 'velocity_low_inventory', team,
           SUM(netdemand_l7), NULL, NULL,
           SUM(ohu) * 1.0 / NULLIF(SUM(ih_netunits_l28) / 4.0, 0),
           NULL, NULL,
           SUM(ih_netunits_l7) * 100.0 / NULLIF(SUM(ih_netunits_l7) + SUM(ohu), 0)
    FROM base
    WHERE isdropship = 'N'
    GROUP BY team
    HAVING SUM(netdemand_l7) > SUM(netdemand_l7_ly)
       AND SUM(ohu) * 1.0 / NULLIF(SUM(ih_netunits_l28) / 4.0, 0) < {{VELOCITY_WOS_MAX}}

    UNION ALL
    -- 4. Margin compression on real volume.
    SELECT 'margin_compression', team,
           SUM(netdemand_l7), NULL, NULL, NULL, NULL,
             (SUM(netdemand_l7) - SUM(netcost_l7))
                 * 1.0 / NULLIF(SUM(netdemand_l7), 0) * 100
           - (SUM(netdemand_l7_ly) - SUM(netcost_l7_ly))
                 * 1.0 / NULLIF(SUM(netdemand_l7_ly), 0) * 100,
           NULL
    FROM base
    GROUP BY team
    HAVING SUM(netdemand_l7) > {{MARGIN_SALES_MIN}}

    UNION ALL
    -- 5. On order into falling demand. 3P lines escalate to the buying team.
    SELECT 'oo_into_decline', team,
           NULL, NULL,
           SUM(ooretail_pastdue + ooretail_duenext30 + ooretail_duenext60
          + ooretail_duenext90 + ooretail_duebeyond90),
           NULL,
           (SUM(netdemand_l7) - SUM(netdemand_l7_ly))
               * 1.0 / NULLIF(SUM(netdemand_l7_ly), 0) * 100,
           NULL, NULL
    FROM base
    GROUP BY team
    HAVING SUM(netdemand_l7) < SUM(netdemand_l7_ly) * 0.9
       AND SUM(ooretail_pastdue + ooretail_duenext30 + ooretail_duenext60
          + ooretail_duenext90 + ooretail_duebeyond90) > {{OO_RETAIL_MIN}}

    UNION ALL
    -- 6. No replenishment pipeline -- selling, holding stock, nothing on order.
    SELECT 'no_pipeline', team,
           SUM(netdemand_l7), SUM(ohr), NULL, NULL, NULL, NULL, NULL
    FROM base
    WHERE isdropship = 'N'
    GROUP BY team
    HAVING SUM(ooretail_pastdue + ooretail_duenext30 + ooretail_duenext60
          + ooretail_duenext90 + ooretail_duebeyond90) = 0
       AND SUM(netdemand_l7) > {{NO_PIPELINE_SALES_MIN}}

    UNION ALL
    -- 7. Player demand acceleration.
    SELECT 'player_acceleration', byr_plyr_nm,
           SUM(netdemand_l7), NULL, NULL, NULL,
           (SUM(netdemand_l7) - SUM(netdemand_l7_ly))
               * 1.0 / NULLIF(SUM(netdemand_l7_ly), 0) * 100,
           NULL, NULL
    FROM base
    WHERE byr_plyr_nm <> 'N/A'
    GROUP BY byr_plyr_nm
    HAVING SUM(netdemand_l7) > {{PLAYER_SALES_MIN}}
)
-- The seven branches are UNIONed INSIDE a CTE on purpose: the platform's
-- read-only guard rejects a top-level UNION ALL outright with
-- "Only SELECT queries are allowed". See build/GAPS.md.
SELECT * FROM signals
;
