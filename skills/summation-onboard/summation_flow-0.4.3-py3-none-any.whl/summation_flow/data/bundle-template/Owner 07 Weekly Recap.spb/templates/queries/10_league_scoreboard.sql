-- League scoreboard: one row per planningleague for one planner area, plus a
-- TOTAL row emitted by the same statement.
--
-- Differences from the customer's sql/10_league_rollup.sql, all deliberate:
--  * planner / buyer list / week are placeholders, not literals a human edits.
--  * The Total row is produced here, from the RAW SUMS, instead of being added
--    in Python. Their comment said "a Total inside the SQL broke the share-of-
--    total window functions" -- true of their shape, not of this one, because
--    the base CTE keeps raw sums and every ratio is derived at the end.
--  * No ROUND() anywhere. Round at print time only.
WITH base AS (
    SELECT
        planningleague                                                    AS league,
        SUM(netdemand_l7)                                                 AS demand_ty,
        SUM(netdemand_l7_ly)                                              AS demand_ly,
        SUM(netcost_l7)                                                   AS cost_ty,
        SUM(netcost_l7_ly)                                                AS cost_ly,
        SUM(netunits_l7)                                                  AS units_ty,
        SUM(netunits_l7_ly)                                               AS units_ly,
        SUM(ih_netunits_l7)                                               AS ih_units_ty,
        SUM(ih_netunits_l7_ly)                                            AS ih_units_ly,
        SUM(ih_netunits_l28)                                              AS ih_units_l28,
        SUM(ohu)                                                          AS oh_units_ty,
        SUM(ohu_ly)                                                       AS oh_units_ly,
        SUM(ohr)                                                          AS oh_retail_ty,
        SUM(ohr_ly)                                                       AS oh_retail_ly,
        SUM(oounits_pastdue + oounits_duenext30 + oounits_duenext60
          + oounits_duenext90 + oounits_duebeyond90)    AS oo_units,
        SUM(ooretail_pastdue + ooretail_duenext30 + ooretail_duenext60
          + ooretail_duenext90 + ooretail_duebeyond90) AS oo_retail,
        SUM(views_l7)                                                     AS views_l7,
        SUM(views_l7 * instockpct_l7)                                     AS views_x_instock,
        COUNT(DISTINCT prdct_id)                                          AS total_products
    FROM {{TABLE}}
    WHERE planner_nm = '{{PLANNER}}'
      {{BUYER_FILTER}}
      AND periodending = '{{WEEK}}'
      {{HARD_EXCLUDE}}
    GROUP BY planningleague
    HAVING SUM(netdemand_l7) > 0 OR SUM(netdemand_l7_ly) > 0
),
rolled AS (
    SELECT 'league' AS row_type, league, demand_ty, demand_ly, cost_ty, cost_ly,
           units_ty, units_ly, ih_units_ty, ih_units_ly, ih_units_l28,
           oh_units_ty, oh_units_ly, oh_retail_ty, oh_retail_ly,
           oo_units, oo_retail, views_l7, views_x_instock, total_products
    FROM base
    UNION ALL
    SELECT 'total', 'TOTAL', SUM(demand_ty), SUM(demand_ly), SUM(cost_ty), SUM(cost_ly),
           SUM(units_ty), SUM(units_ly), SUM(ih_units_ty), SUM(ih_units_ly), SUM(ih_units_l28),
           SUM(oh_units_ty), SUM(oh_units_ly), SUM(oh_retail_ty), SUM(oh_retail_ly),
           SUM(oo_units), SUM(oo_retail), SUM(views_l7), SUM(views_x_instock),
           SUM(total_products)
    FROM base
)
SELECT
    row_type,
    league,
    demand_ty                                                          AS sales_ty,
    demand_ly                                                          AS sales_ly,
    (demand_ty - demand_ly) * 1.0 / NULLIF(demand_ly, 0) * 100         AS sales_yoy_pct,
    units_ty,
    units_ly,
    (units_ty - units_ly) * 1.0 / NULLIF(units_ly, 0) * 100            AS units_yoy_pct,
    -- GM% = (demand - cost) / demand. Movement is reported in POINTS.
    (demand_ty - cost_ty) * 1.0 / NULLIF(demand_ty, 0) * 100           AS gm_pct_ty,
    (demand_ly - cost_ly) * 1.0 / NULLIF(demand_ly, 0) * 100           AS gm_pct_ly,
      (demand_ty - cost_ty) * 1.0 / NULLIF(demand_ty, 0) * 100
    - (demand_ly - cost_ly) * 1.0 / NULLIF(demand_ly, 0) * 100         AS gm_delta_pts,
    demand_ty * 1.0 / NULLIF(units_ty, 0)                              AS aur_ty,
    demand_ly * 1.0 / NULLIF(units_ly, 0)                              AS aur_ly,
    -- Sell-through: in-house units sold / (sold + still on hand).
    ih_units_ty * 100.0 / NULLIF(ih_units_ty + oh_units_ty, 0)         AS st_pct_ty,
    ih_units_ly * 100.0 / NULLIF(ih_units_ly + oh_units_ly, 0)         AS st_pct_ly,
      ih_units_ty * 100.0 / NULLIF(ih_units_ty + oh_units_ty, 0)
    - ih_units_ly * 100.0 / NULLIF(ih_units_ly + oh_units_ly, 0)       AS st_delta_pts,
    oh_units_ty                                                        AS oh_units,
    oh_units_ly,
    oh_retail_ty,
    oh_retail_ly,
    (oh_retail_ty - oh_retail_ly) * 1.0 / NULLIF(oh_retail_ly, 0) * 100 AS oh_chg_pct,
    oo_units,
    oo_retail,
    -- Weeks of supply: on-hand units over the TRAILING FOUR-WEEK AVERAGE of
    -- weekly in-house net units. NOT last week's units. The customer's dbt
    -- model still carries the one-week version -- see GAPS.md.
    oh_units_ty * 1.0 / NULLIF(ih_units_l28 / 4.0, 0)                  AS wos,
    -- In-stock has to be views-weighted; a plain average over-counts dead pages.
    views_x_instock * 100.0 / NULLIF(views_l7, 0)                      AS instock_pct,
    total_products
FROM rolled
ORDER BY row_type ASC, sales_ty DESC
;
