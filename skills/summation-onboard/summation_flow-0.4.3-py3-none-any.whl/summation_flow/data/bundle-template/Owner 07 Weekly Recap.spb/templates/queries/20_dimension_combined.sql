-- One dimension, one league: the top-N rows, the "everything else" tail row,
-- and the total, in ONE statement, distinguished by `row_type`.
--
-- The customer kept these as two files (20_dimension_topn.sql and
-- 21_dimension_tail.sql) and their own notes record the consequence:
--   "figure out why my top-5 subtotal and the 'all other' row sometimes do not
--    add to the total"  (notes-to-self.md, TODO)
-- They do not add up because the two files recomputed ratios from different
-- expressions. Here every row_type is derived from the SAME raw sums, so the
-- top-N rows, the tail row and the total are arithmetically consistent by
-- construction. Shares always foot to 100.
--
-- No ROUND(). Round at print time only.
WITH base AS (
    SELECT
        {{DIM_EXPR}}                                                      AS name,
        {{NAME2_EXPR}}                                                    AS name2,
        SUM(netdemand_l7)                                                 AS demand_ty,
        SUM(netdemand_l7_ly)                                              AS demand_ly,
        SUM(netcost_l7)                                                   AS cost_ty,
        SUM(netcost_l7_ly)                                                AS cost_ly,
        SUM(netunits_l7)                                                  AS units_ty,
        SUM(netunits_l7_ly)                                               AS units_ly,
        SUM(ih_netunits_l7)                                               AS ih_units_ty,
        SUM(ih_netunits_l7_ly)                                            AS ih_units_ly,
        SUM(ih_netunits_l28)                                              AS ih_units_l28,
        SUM(ohu)                                                          AS oh_units_ty,
        SUM(ohu_ly)                                                       AS oh_units_ly,
        SUM(ohr)                                                          AS oh_retail_ty,
        SUM(ohr_ly)                                                       AS oh_retail_ly,
        SUM(ooretail_pastdue + ooretail_duenext30 + ooretail_duenext60
          + ooretail_duenext90 + ooretail_duebeyond90) AS oo_retail,
        SUM(views_l7)                                                     AS views_l7,
        SUM(views_l7 * instockpct_l7)                                     AS views_x_instock
    FROM {{TABLE}}
    WHERE planner_nm = '{{PLANNER}}'
      {{BUYER_FILTER}}
      AND periodending = '{{WEEK}}'
      AND planningleague = '{{LEAGUE}}'
      {{HARD_EXCLUDE}}
      {{DIM_EXCLUDE}}
    GROUP BY {{DIM_GROUP}}
    HAVING SUM(netdemand_l7) > 0 OR SUM(netdemand_l7_ly) > 0
),
ranked AS (
    SELECT base.*,
           ROW_NUMBER() OVER (ORDER BY demand_ty DESC) AS rk,
           COUNT(*)     OVER ()                        AS total_rows
    FROM base
),
shaped AS (
    SELECT 'top' AS row_type, rk, name, name2, total_rows, 1 AS member_rows,
           demand_ty, demand_ly, cost_ty, cost_ly, units_ty, units_ly,
           ih_units_ty, ih_units_ly, ih_units_l28, oh_units_ty, oh_units_ly,
           oh_retail_ty, oh_retail_ly, oo_retail, views_l7, views_x_instock
    FROM ranked
    WHERE rk <= {{TOP_N}}

    UNION ALL

    SELECT 'tail', {{TOP_N}} + 1,
           'All other ' || CAST(COUNT(*) AS VARCHAR) || ' {{DIM_NOUN_PLURAL}}',
           NULL, MAX(total_rows), COUNT(*),
           SUM(demand_ty), SUM(demand_ly), SUM(cost_ty), SUM(cost_ly),
           SUM(units_ty), SUM(units_ly), SUM(ih_units_ty), SUM(ih_units_ly),
           SUM(ih_units_l28), SUM(oh_units_ty), SUM(oh_units_ly),
           SUM(oh_retail_ty), SUM(oh_retail_ly), SUM(oo_retail),
           SUM(views_l7), SUM(views_x_instock)
    FROM ranked
    WHERE rk > {{TOP_N}}
    HAVING COUNT(*) > 0

    UNION ALL

    SELECT 'total', {{TOP_N}} + 2,
           'Total', NULL, MAX(total_rows), COUNT(*),
           SUM(demand_ty), SUM(demand_ly), SUM(cost_ty), SUM(cost_ly),
           SUM(units_ty), SUM(units_ly), SUM(ih_units_ty), SUM(ih_units_ly),
           SUM(ih_units_l28), SUM(oh_units_ty), SUM(oh_units_ly),
           SUM(oh_retail_ty), SUM(oh_retail_ly), SUM(oo_retail),
           SUM(views_l7), SUM(views_x_instock)
    FROM ranked
),
grand AS (
    SELECT SUM(demand_ty) AS g_ty, SUM(demand_ly) AS g_ly,
           SUM(demand_ty) - SUM(demand_ly) AS g_delta
    FROM ranked
)
SELECT
    s.row_type,
    s.rk                                                                AS rank_order,
    s.name,
    s.name2,
    s.total_rows,
    s.member_rows,
    s.demand_ty                                                         AS sales_ty,
    s.demand_ly                                                         AS sales_ly,
    (s.demand_ty - s.demand_ly) * 1.0 / NULLIF(s.demand_ly, 0) * 100    AS yoy_pct,
    (s.demand_ty - s.cost_ty) * 1.0 / NULLIF(s.demand_ty, 0) * 100      AS gm_pct_ty,
    (s.demand_ly - s.cost_ly) * 1.0 / NULLIF(s.demand_ly, 0) * 100      AS gm_pct_ly,
      (s.demand_ty - s.cost_ty) * 1.0 / NULLIF(s.demand_ty, 0) * 100
    - (s.demand_ly - s.cost_ly) * 1.0 / NULLIF(s.demand_ly, 0) * 100    AS gm_delta_pts,
    s.demand_ty * 1.0 / NULLIF(s.units_ty, 0)                           AS aur_ty,
    s.demand_ly * 1.0 / NULLIF(s.units_ly, 0)                           AS aur_ly,
    s.units_ty,
    s.units_ly,
    s.demand_ty * 100.0 / NULLIF(g.g_ty, 0)                             AS share_pct,
    s.demand_ly * 100.0 / NULLIF(g.g_ly, 0)                             AS share_pct_ly,
    (s.demand_ty - s.demand_ly) * 1.0 / NULLIF(g.g_delta, 0) * 100      AS sales_contrib_pct,
    s.ih_units_ty * 100.0 / NULLIF(s.ih_units_ty + s.oh_units_ty, 0)    AS st_pct_ty,
    s.ih_units_ly * 100.0 / NULLIF(s.ih_units_ly + s.oh_units_ly, 0)    AS st_pct_ly,
    s.oh_retail_ty,
    s.oh_retail_ly,
    (s.oh_retail_ty - s.oh_retail_ly) * 1.0 / NULLIF(s.oh_retail_ly, 0) * 100 AS oh_chg_pct,
    s.oo_retail,
    s.oh_units_ty * 1.0 / NULLIF(s.ih_units_l28 / 4.0, 0)               AS wos,
    s.views_x_instock * 100.0 / NULLIF(s.views_l7, 0)                   AS instock_pct
FROM shaped s CROSS JOIN grand g
ORDER BY s.rk
;
