-- Freshness / load guard. Runs FIRST. Stop the run if any check trips.
--   rows_this_week     = 0                -> ETL has not landed the week
--   latest_saturday   <> week_asked_for   -> the table is stale
--   planners_this_week < {{PLANNER_GUARD}} -> partial load, every share is wrong
--
-- Parameterised. The customer edited the date by hand every Monday
-- (cleanroom sql/00_freshness.sql: "Yes, I know I should parameterise it.").
SELECT
    '{{WEEK}}'                                     AS week_asked_for,
    (SELECT COUNT(*)
       FROM {{TABLE}}
      WHERE periodending = '{{WEEK}}')             AS rows_this_week,
    (SELECT CAST(MAX(periodending) AS VARCHAR)
       FROM {{TABLE}})                             AS latest_saturday,
    (SELECT COUNT(DISTINCT planner_nm)
       FROM {{TABLE}}
      WHERE periodending = '{{WEEK}}')             AS planners_this_week,
    (SELECT COUNT(DISTINCT planningleague)
       FROM {{TABLE}}
      WHERE periodending = '{{WEEK}}')             AS leagues_this_week,
    {{PLANNER_GUARD}}                              AS planner_guard
;
