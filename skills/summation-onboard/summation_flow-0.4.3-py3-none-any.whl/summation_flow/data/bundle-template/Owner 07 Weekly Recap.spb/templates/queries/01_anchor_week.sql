-- Step 0. Resolve the anchor week by ASKING THE TABLE, never the calendar.
-- The ETL lands Sunday night, sometimes Monday, sometimes Tuesday
-- (cleanroom notes-to-self.md 2026-03-23: publishing a four-planner week).
-- The distinct-planner guard is what makes a partial load fail loudly.
SELECT CAST(periodending AS VARCHAR) AS periodending
FROM {{TABLE}}
GROUP BY periodending
HAVING COUNT(DISTINCT planner_nm) >= {{PLANNER_GUARD}}
ORDER BY periodending DESC
LIMIT 1
;
