-- The whole snapshot, in one query. One week, one owner area, split by segment.
-- Run it Monday morning; paste the two rows and the total into the page.
--
-- Things I have got wrong before, kept here so they travel with the query:
--   * Year over year shifts by 364 days, not 365, or the comparison lands on a
--     different weekday. `revenue_7d_prior` already carries that alignment.
--   * Round only at print time. Never in SQL.
--   * The owner code below is the one thing that changes between areas.
SELECT segment,
       SUM(revenue_7d)       AS revenue,
       SUM(revenue_7d_prior) AS revenue_prior,
       SUM(units_7d)         AS units
FROM analytics.synthetic_wbr_data
WHERE week_ending = '2026-04-04'
  AND owner_code  = 'OWNER_07'
GROUP BY segment
ORDER BY revenue DESC;
