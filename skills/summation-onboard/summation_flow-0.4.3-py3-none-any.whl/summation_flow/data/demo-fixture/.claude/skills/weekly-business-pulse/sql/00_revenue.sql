-- Revenue this week vs the same week last year (prior columns are 52-week-shifted)
SELECT SUM(revenue_7d) AS revenue,
       SUM(revenue_7d_prior) AS revenue_prior,
       (SUM(revenue_7d) - SUM(revenue_7d_prior)) * 100.0 / SUM(revenue_7d_prior) AS yoy_pct
FROM analytics.synthetic_wbr_data
WHERE week_ending = '2026-04-04' AND owner_code = 'OWNER_07'
  AND buyer_code IN ('BQ_02','BQ_09','BQ_14X');
