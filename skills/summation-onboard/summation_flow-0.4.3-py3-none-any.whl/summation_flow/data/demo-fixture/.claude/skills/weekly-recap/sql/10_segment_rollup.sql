-- Segment table plus the totals row.
-- No ROUND() in here — rounding happens at print time only.
SELECT segment,
       SUM(revenue_7d)                                            AS revenue,
       SUM(revenue_7d_prior)                                      AS revenue_prior,
       SUM(units_7d)                                              AS units,
       SUM(onhand_value)                                          AS onhand_value,
       SUM(onhand_units) * 1.0 / NULLIF(SUM(sold_units_28d)/4.0,0) AS weeks_of_supply
FROM analytics.synthetic_wbr_data
WHERE owner_code = 'OWNER_07'
  AND week_ending = '2026-04-04'
  AND buyer_code IN ('BQ_02', 'BQ_09', 'BQ_14')
GROUP BY segment
ORDER BY revenue DESC;
