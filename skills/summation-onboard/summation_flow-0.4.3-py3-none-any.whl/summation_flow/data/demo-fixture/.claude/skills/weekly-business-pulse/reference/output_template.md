# Output template

Paste-ready markdown. One page. Status line, six areas, the week's risks, and what I'm doing about
the worst one.

```markdown
# Northline Sports — Weekly Business Pulse
Week ending {WEEK}. Overall: {OVERALL_STATUS}

| Area | Status | Where it landed |
|---|---|---|
| Revenue        | {REV_STATUS}     | {REV_LINE} |
| Margin         | {MARGIN_STATUS}  | {MARGIN_LINE} |
| Inventory      | {INV_STATUS}     | {INV_LINE} |
| In-stock       | {STOCK_STATUS}   | {STOCK_LINE} |
| Open POs       | {PO_STATUS}      | {PO_LINE} |
| Traffic        | {TRAFFIC_STATUS} | {TRAFFIC_LINE} |

## Risks this week
- {RISK_1}
- {RISK_2}
- {RISK_3}

## What I'm doing about it
{ACTION}
```

Rules: every "Where it landed" cell carries the number AND its change. Risks are specific — a
group or a line, a dollar figure, a percent. Never "some areas are soft."
