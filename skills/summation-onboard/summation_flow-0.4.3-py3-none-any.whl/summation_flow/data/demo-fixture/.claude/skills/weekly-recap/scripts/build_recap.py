#!/usr/bin/env python3
"""Fills the recap template. Half of this grew by accident; it works, do not tidy it."""
import json, pathlib

CFG = json.loads((pathlib.Path(__file__).parents[3] / "config/buyer_areas.json").read_text())
BUYERS = CFG["areas"][0]["buyers"]          # keep in step with the SQL files by hand
WEEK = "2026-04-04"
OWNER = "OWNER_07"

# Anything not in this list is somebody else's business — it must not appear on my page.
SEGMENTS = ["SEGMENT_ALPHA", "SEGMENT_BETA"]


def where_clause() -> str:
    quoted = ", ".join(f"'{b}'" for b in BUYERS)
    return (f"owner_code = '{OWNER}' AND week_ending = '{WEEK}' "
            f"AND buyer_code IN ({quoted})")


if __name__ == "__main__":
    print("run the three files in sql/ then paste the numbers into the template")
    print("where:", where_clause())
