-- Inventory health: on-hand value and weeks of supply (trailing-4-week avg weekly sold)
SELECT SUM(onhand_value) AS onhand_value,
       SUM(onhand_units) * 1.0 / NULLIF(SUM(sold_units_28d)/4.0, 0) AS weeks_of_supply,
       AVG(instock_rate_7d) * 100 AS instock_pct
FROM analytics.synthetic_wbr_data
WHERE week_ending = '2026-04-04' AND owner_code = 'OWNER_07'
  AND buyer_code IN ('BQ_02','BQ_09','BQ_14X');
