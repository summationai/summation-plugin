# Gotchas — read before you trust the numbers

- **In-stock looks alarming and mostly isn't.** The table carries drop-ship (3P) rows whose
  `instock_rate_7d` reads near zero because they're vendor-fulfilled, not warehoused. A blended
  in-stock of ~66% is dragged down by those. For a true 1P read, filter `dropship_flag = 'N'` —
  the pulse currently does NOT, so treat in-stock as directional, not literal.
- **BQ_14 vs BQ_14X.** The buyer list used to say `BQ_14`, which matches nothing. The real code is
  `BQ_14X`. If revenue looks 15% light, that's the filter, not the business.
- **Weeks of supply is on-hand over the trailing-4-week average of weekly sold units.** Not last
  week's units. Using one week makes a slow week look like a crisis.
- **Prior columns are already shifted 52 weeks** (364 days), so YoY compares like weekdays. Don't
  shift again.
- **No rounding until the end.** Sum exact, round when you write the line.
