---
name: weekly-business-pulse
description: A one-page Monday health check on the business — revenue, margin, inventory and open commitments — with a 🟢/🟡/🔴 status on each and the week's real risks called out by name. Run it before the 9am stand-up.
allowed-tools: [Bash, Read, Write]
argument-hint: "[week-ending YYYY-MM-DD]"
---

<!--
  Adapted from anthropics/knowledge-work-plugins `small-business/business-pulse`
  (Apache-2.0). Repointed from SaaS connectors (QuickBooks/HubSpot/Shopify) to
  Northline's own warehouse, because that is where our numbers actually live.
  See NOTICE for attribution.
-->

# Weekly Business Pulse — Northline Sports

Every Monday before the 9am I run this so I walk in already knowing where the week landed and
what's on fire. It reads the warehouse, scores each area, and writes the one-pager I paste into
the leadership channel.

## How I run it

1. Read `reference/data_sources.md` for the connection and the one table everything comes from.
2. Read `reference/thresholds.md` — the 🟢/🟡/🔴 cutoffs. These are mine; tune them, don't guess.
3. Pull this week's numbers (the queries are in data_sources).
4. Score each area against the thresholds.
5. Write the brief using `reference/output_template.md`.
6. Read `reference/gotchas.md` before trusting anything — the warehouse has a few traps.

## What it covers

Six areas, each with a status and a one-line reason:

- **Revenue** — this week vs the same week last year.
- **Margin** — gross margin dollars and rate.
- **Inventory health** — weeks of supply, and whether we're overstocked.
- **In-stock** — are the things people want actually on the shelf.
- **Open commitments** — purchase orders we owe money on, especially anything overdue.
- **Traffic** — page views, as a leading signal.

## The rules I hold to

- **Numbers lead. Every number carries its change.** "Revenue $350k" is useless; "revenue $350k,
  down 4.6% on last year" is the report.
- **Risks are specific or they're noise.** Not "some groups are down" — "GROUP_02 down 16.1% on
  $28k of revenue." Name it, size it, or leave it out.
- **Do not invent or estimate numbers.** If the warehouse doesn't have it, it doesn't go in.
- **Overall status is the worst of the six, not the average.** One 🔴 makes the week 🔴.

## Approval

- Saving the brief to my own drive: automatic.
- Posting it to the leadership channel: I read it once, then post.
- Posting anything unflattering (a red area, a miss): I sit with it for a minute before I post,
  because the channel isn't only leadership.
