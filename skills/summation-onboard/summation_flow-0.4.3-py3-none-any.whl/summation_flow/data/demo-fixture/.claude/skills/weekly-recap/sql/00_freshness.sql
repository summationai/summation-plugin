-- Run this FIRST. Confirms the week actually loaded before anything else runs.
-- Three buyers is a full load. Fewer means partial — stop.
SELECT week_ending,
       COUNT(DISTINCT buyer_code) AS buyers,
       COUNT(*)                   AS rows_loaded
FROM analytics.synthetic_wbr_data
WHERE owner_code = 'OWNER_07'
  AND week_ending = '2026-04-04'
GROUP BY week_ending;
