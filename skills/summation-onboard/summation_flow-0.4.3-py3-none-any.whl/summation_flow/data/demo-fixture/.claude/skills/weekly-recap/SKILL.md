---
name: weekly-recap
description: Build my Monday weekly recap for OWNER_07.
---

# Weekly recap

Every Monday morning I put together the recap for my area before the 09:15 call. This is the
process. Run it in order; the whole thing takes about ten minutes.

## What it covers

One week, one owner area, split by segment and then by group. Revenue against prior year, units,
on-hand value, weeks of supply.

## Step 1 — check the data actually landed

Run `sql/00_freshness.sql` first. **Do not skip this.** The load usually finishes Sunday night but
sometimes it is Monday, and once it was Tuesday. If you build the recap from a half-loaded week every
share number on the page is wrong and nobody notices until the call.

The check counts distinct buyers for the week. There should be three. Anything less means a partial
load — stop and wait.

## Step 2 — the numbers

`sql/10_segment_rollup.sql` gives the segment table and the totals.
`sql/20_group_topn.sql` gives the top five groups.

Both read from `analytics.synthetic_wbr_data`, one row per product per week.

## Step 3 — build the page

`python3 scripts/build_recap.py` fills the template and writes into `reports/`.

## Things I have got wrong before

- **Weeks of supply** is on-hand units over the *trailing four-week average* of weekly sold units.
  Not last week's units. I had this wrong for a month and the numbers looked plausible the whole time.
- **Year over year shifts by 364 days**, not 365, or the comparison lands on a different weekday.
- The buyer list lives in `config/buyer_areas.json`. If a code looks wrong, ask me — do not guess.
- Round only at print time. Never in SQL.
