-- Gross margin dollars and rate
SELECT SUM(revenue_7d - cost_7d) AS margin_dollars,
       SUM(revenue_7d - cost_7d) * 100.0 / SUM(revenue_7d) AS margin_pct
FROM analytics.synthetic_wbr_data
WHERE week_ending = '2026-04-04' AND owner_code = 'OWNER_07'
  AND buyer_code IN ('BQ_02','BQ_09','BQ_14X');
