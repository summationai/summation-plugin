-- Top five groups by revenue, with share of the area.
SELECT group_name,
       SUM(revenue_7d) AS revenue,
       SUM(units_7d)   AS units
FROM analytics.synthetic_wbr_data
WHERE owner_code = 'OWNER_07'
  AND week_ending = '2026-04-04'
  AND buyer_code IN ('BQ_02', 'BQ_09', 'BQ_14')
GROUP BY group_name
ORDER BY revenue DESC
LIMIT 5;
