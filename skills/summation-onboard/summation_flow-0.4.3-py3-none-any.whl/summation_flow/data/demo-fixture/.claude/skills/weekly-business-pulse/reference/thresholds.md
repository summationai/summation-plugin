# Thresholds — the 🟢/🟡/🔴 cutoffs

These are mine, set by feel over a couple of quarters. They are the first thing to argue about,
so keep them in one place. (When this becomes a real Summation playbook these should be *typed
parameters* on the Run button, not constants buried in a file — right now they're constants.)

| Area | 🟢 green | 🟡 yellow | 🔴 red |
|---|---|---|---|
| Revenue (YoY) | flat or up | down 0–5% | down more than 5% |
| Margin rate | 48% or better | 44–48% | below 44% |
| Weeks of supply | 8–14 | 14–18 or 6–8 | over 18 or under 6 |
| In-stock rate | 92%+ | 85–92% | below 85% |
| Overdue POs | under $100k | $100–300k | over $300k |
| Traffic (WoW) | up | flat | down |

**Overall status is the worst single area, never the average.** A red anywhere makes the week red.
