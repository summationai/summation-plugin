# Data sources

Everything in the pulse comes from **one table** in our warehouse. No SaaS connectors — the
adapted version reads the warehouse directly, which is the only place the numbers reconcile.

## Connection

- Warehouse: Postgres (the analytics reader role).
- Table: `analytics.synthetic_wbr_data` — one row per product, per buyer, per week.
- Scope for the pulse: `owner_code = 'OWNER_07'`, the current `week_ending`, and our three active
  buyer codes `('BQ_02','BQ_09','BQ_14X')`.

## The queries

```sql
-- Revenue: this week vs the same week last year (prior columns are already 52-week-shifted)
SELECT SUM(revenue_7d) AS revenue,
       SUM(revenue_7d_prior) AS revenue_prior,
       (SUM(revenue_7d) - SUM(revenue_7d_prior)) * 100.0 / SUM(revenue_7d_prior) AS yoy_pct
FROM analytics.synthetic_wbr_data
WHERE week_ending = :week AND owner_code = 'OWNER_07'
  AND buyer_code IN ('BQ_02','BQ_09','BQ_14X');

-- Margin
SELECT SUM(revenue_7d - cost_7d) AS margin_dollars,
       SUM(revenue_7d - cost_7d) * 100.0 / SUM(revenue_7d) AS margin_pct
FROM analytics.synthetic_wbr_data WHERE ...;

-- Inventory health: weeks of supply = on-hand units / (trailing-4-week avg weekly sold)
SELECT SUM(onhand_value) AS onhand_value,
       SUM(onhand_units) * 1.0 / NULLIF(SUM(sold_units_28d)/4.0, 0) AS weeks_of_supply
FROM analytics.synthetic_wbr_data WHERE ...;

-- In-stock rate
SELECT AVG(instock_rate_7d) * 100 AS instock_pct FROM analytics.synthetic_wbr_data WHERE ...;

-- Open commitments: purchase orders we owe on, split by overdue vs coming
SELECT SUM(onorder_value_overdue) AS po_overdue,
       SUM(onorder_value_next90)  AS po_next90
FROM analytics.synthetic_wbr_data WHERE ...;

-- Traffic
SELECT SUM(page_views_7d) AS page_views FROM analytics.synthetic_wbr_data WHERE ...;

-- Risks: the groups falling hardest, and the lines most overstocked
SELECT group_name, SUM(revenue_7d) AS rev,
       (SUM(revenue_7d)-SUM(revenue_7d_prior))*100.0/SUM(revenue_7d_prior) AS yoy
FROM analytics.synthetic_wbr_data WHERE ... GROUP BY group_name ORDER BY yoy ASC LIMIT 3;

SELECT line_name, SUM(onhand_units)*1.0/NULLIF(SUM(sold_units_28d)/4.0,0) AS wos
FROM analytics.synthetic_wbr_data WHERE ... GROUP BY line_name ORDER BY wos DESC LIMIT 3;
```
