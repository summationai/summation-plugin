-- Open purchase orders we owe on, split overdue vs coming
SELECT SUM(onorder_value_overdue) AS po_overdue,
       SUM(onorder_value_next90)  AS po_next90
FROM analytics.synthetic_wbr_data
WHERE week_ending = '2026-04-04' AND owner_code = 'OWNER_07'
  AND buyer_code IN ('BQ_02','BQ_09','BQ_14X');
