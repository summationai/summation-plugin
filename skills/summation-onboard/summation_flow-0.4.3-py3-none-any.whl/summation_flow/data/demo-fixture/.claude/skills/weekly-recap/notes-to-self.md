# notes to self

2026-02-14 — Tried exporting to CSV and joining in a spreadsheet. Do not. Took an hour and the
totals disagreed with the warehouse by a few hundred every time.

2026-02-28 — Weeks of supply was wrong. I was dividing on-hand by *last week's* sold units, which
makes a slow week look like a supply crisis. It has to be the trailing four-week average:
`sum(onhand_units) / (sum(sold_units_28d) / 4.0)`. The dbt model still has the old version in it.

2026-03-09 — Year-over-year was comparing to the wrong weekday. Shift 364 days, not 365.

2026-03-22 — Added the on-hand value column because the buy meeting kept asking for it.

2026-04-01 — The segment total on the page does not always match the two segment rows. Have not
worked out why yet. Probably the two queries rounding differently. TODO.
