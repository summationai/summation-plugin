# Northline Sports — Weekly Business Pulse
Week ending 2026-04-04. Overall: 🟢 Healthy

| Area | Status | Where it landed |
|---|---|---|
| Revenue        | 🟡 | $350,490, down 4.6% on last year |
| Margin         | 🟢 | $175,571, 50.1% rate |
| Inventory      | 🟡 | $3.75M on hand, 19.5 weeks of supply |
| In-stock       | 🔴 | 65.9% — below the 85% floor |
| Open POs       | 🔴 | $499,367 overdue, another $1.08M due in 90 days |
| Traffic        | 🟢 | 1.05M page views, up on last week |

## Risks this week
- GROUP_02 is the sharpest drag — down 16.1% on $28,284 of revenue.
- LINE_LIMITED is overstocked at 22.6 weeks of supply; we're carrying too much of it.
- A mid-week promotion added about $41,900 of the revenue, so next week will look softer by
  comparison.

## What I'm doing about it
Chasing the overdue POs with the buying team first — half a million in overdue commitments is the
thing that actually hurts. In-stock looks bad but a lot of that is drop-ship, so I'm not panicking
on it yet.
