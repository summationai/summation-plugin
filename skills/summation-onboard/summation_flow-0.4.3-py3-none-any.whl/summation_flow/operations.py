"""Append-only records for external operations.

The snapshot says where a run is now.  This journal answers the harder recovery question: did a
request reach Summation before the process disappeared?  Payloads and credentials never belong
here; only stable bindings and returned object ids do.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass

from .state import Run


UNSAFE_STATES = {"submitted", "outcome_unknown"}
_AMBIGUOUS_HTTP_STATUSES = {408, 409, 425, 429}


def _http_status(error: Exception | str) -> int | None:
    """Recover an HTTP status through wrapper exceptions without recording response bodies."""

    current = error if isinstance(error, BaseException) else None
    seen: set[int] = set()
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        status = getattr(current, "status", None)
        if isinstance(status, int) and status:
            return status
        current = current.__cause__ or current.__context__
    return None


def operation_id(run: Run, stage: str, action: str, key: str) -> str:
    raw = f"{getattr(run, 'run_id', 'test-run')}\0{stage}\0{action}\0{key}".encode()
    return hashlib.sha256(raw).hexdigest()[:20]


def latest(run: Run) -> dict[str, dict]:
    out = {}
    for event in getattr(run, "events", lambda: [])():
        if event.get("event") == "operation" and event.get("operation_id"):
            out[event["operation_id"]] = event
    return out


def unsafe(run: Run) -> list[dict]:
    return [event for event in latest(run).values() if event.get("state") in UNSAFE_STATES]


@dataclass
class Operation:
    run: Run
    stage: str
    action: str
    key: str
    summary: str

    @property
    def id(self) -> str:
        return operation_id(self.run, self.stage, self.action, self.key)

    @property
    def last(self) -> dict | None:
        return latest(self.run).get(self.id)

    def _record(self, state: str, **facts) -> dict:
        event = {"event": "operation", "operation_id": self.id, "stage": self.stage,
                 "action": self.action, "summary": self.summary, "state": state,
                 "profile": self.run.profile, "project_id": self.run.project_id, **facts}
        append = getattr(self.run, "append_event", None)
        return append("operation", **{k: v for k, v in event.items() if k != "event"}) if append else event

    def planned(self, **facts) -> dict:
        return self._record("planned", **facts)

    def submitted(self, **facts) -> dict:
        return self._record("submitted", **facts)

    def confirmed(self, **facts) -> dict:
        return self._record("confirmed", **facts)

    def rejected(self, **facts) -> dict:
        return self._record("rejected", **facts)

    def unknown(self, error: Exception | str, **facts) -> dict:
        # Keep error shape, never request payloads: connector exceptions can contain secrets.
        return self._record("outcome_unknown", error_type=type(error).__name__, **facts)

    def failed(self, error: Exception | str, **facts) -> dict:
        """Record a definitive rejection as safe, and only ambiguous delivery as unknown.

        A normal 400/401/403/404/422 response proves the server answered and rejected the
        request. Timeouts, network failures, 5xx responses, and ambiguous concurrency statuses
        may have committed before the response was lost, so they remain unsafe to retry.
        """

        status = _http_status(error)
        error_type = type(error).__name__
        if status is not None and 400 <= status < 500 and status not in _AMBIGUOUS_HTTP_STATUSES:
            return self.rejected(error_type=error_type, http_status=status, **facts)
        return self.unknown(error, http_status=status, **facts)

    def refuse_unknown_retry(self) -> None:
        if self.last and self.last.get("state") in UNSAFE_STATES:
            raise SystemExit(
                f"the prior {self.summary} has an unknown outcome, so it will not be repeated. "
                f"Reconcile that operation in Summation before retrying (operation {self.id}).")
