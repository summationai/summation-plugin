"""Agent C — turn the checks a customer already wrote into their own verification suite.

Every hand-built report carries assertions. They are rarely `assert` statements: they are a comment
above a query saying "three buyers is a full load, fewer means partial — stop", a hardcoded list
with "anything not in this list must not appear on my page" beside it, a threshold nobody has
revisited. The author encoded what "correct" means and then had no way to enforce it, because the
report is built by hand and nothing runs those rules.

This finds them and emits a `custom-test-bundle/v1` for the `verif-tests` CLI, so the customer's own
rules become checks that run on every scheduled run instead of living in a comment.

Two things worth understanding about the target format:

`pass_criteria` is **prose read by a rubric judge**, not code. So a harvested threshold becomes a
sentence about what must be true of the finished report, and the original is quoted so a human can
see what it came from.

`requiredness` is therefore load-bearing. A rule is only `blocking` when the finished artifact
carries enough information to judge it. "Only these buyer codes may appear" is checkable from the
page. "The load had three distinct buyers" is not, unless the page says so — that one is advisory,
and calling it blocking would fail good reports for lack of evidence rather than for being wrong.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from pathlib import Path

MAX_TESTS = 200
MAX_CATEGORIES = 50
MAX_NAME = 200
MAX_CRITERIA = 2000

#: Prose that states a rule rather than describing a line of code.
RULE = re.compile(
    r"\b(must not|must|never|do not|don'?t|should not|always|stop and|stop\b|"
    r"has to be|required|expected|at least|no more than|fewer means|anything (?:not |else))\b", re.I)

#: A number the author treated as a boundary.
THRESHOLD = re.compile(
    r"\b(?:at least|minimum|min|no fewer than|fewer than|more than|over|under|below|above|"
    r"greater than|less than|exactly)\s+(\d[\d,\.]*)\b", re.I)

#: Small written numbers appear in exactly this kind of note ("there should be three").
WORD_NUMBERS = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}

CATEGORY_RULES = [
    ("data_completeness", re.compile(
        r"\b(partial|full load|loaded|freshness|landed|complete|missing|half[- ]loaded|"
        r"row count|distinct)\b", re.I)),
    ("scope", re.compile(
        r"\b(must not appear|somebody else|not mine|only|belongs to|scope|filter|whitelist|"
        r"buyer|owner|area)\b", re.I)),
    ("metric_definition", re.compile(
        r"\b(defined|definition|formula|calculat|average|denominator|weeks of supply|"
        r"year[- ]over[- ]year|shift)\b", re.I)),
    ("known_issue", re.compile(r"\b(todo|not worked out|unresolved|not sure why)\b", re.I)),
]


def categorise(text: str) -> str:
    for name, pat in CATEGORY_RULES:
        if pat.search(text):
            return name
    return "author_rule"


def slug(text: str, taken: set) -> str:
    """A lowercase snake_case id the bundle format will accept, unique within the bundle."""
    base = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    base = re.sub(r"_+", "_", base)[:100] or "check"
    if not base[0].isalpha():
        base = f"c_{base}"
    out, n = base, 2
    while out in taken:
        out = f"{base}_{n}"
        n += 1
    taken.add(out)
    return out


@dataclass
class Assertion:
    text: str            # what the author wrote, verbatim
    source: str          # path:line
    category: str
    number: int | None = None      # the boundary they named, when there was one

    def as_dict(self) -> dict:
        d: dict = {"text": self.text, "source": self.source, "category": self.category}
        if self.number is not None:
            d["number"] = self.number
        return d


def find_number(text: str) -> int | None:
    m = THRESHOLD.search(text)
    if m:
        try:
            return int(float(m.group(1).replace(",", "")))
        except ValueError:
            pass
    # "There should be three."
    m = re.search(r"\b(?:should be|there (?:should|must) be|expect)\s+(" +
                  "|".join(WORD_NUMBERS) + r")\b", text, re.I)
    if m:
        return WORD_NUMBERS[m.group(1).lower()]
    # A bare written number carries the boundary just as often: "Three buyers is a full load."
    m = re.search(r"\b(" + "|".join(WORD_NUMBERS) + r")\b", text, re.I)
    return WORD_NUMBERS[m.group(1).lower()] if m else None


def _comment_lines(path: Path) -> list[tuple[int, str]]:
    """Comment text from SQL, Python and Markdown prose alike, with line numbers."""
    out: list[tuple[int, str]] = []
    suffix = path.suffix.lower()
    for i, raw in enumerate(path.read_text(errors="replace").splitlines(), 1) if suffix != ".md" else []:
        line = raw.strip()
        if not line:
            continue
        if suffix == ".sql":
            m = re.match(r"--\s*(.+)$", line)
            if m:
                out.append((i, m.group(1).strip()))
        elif suffix == ".py":
            m = re.match(r"#\s*(.+)$", line)
            if m:
                out.append((i, m.group(1).strip()))
    if suffix in (".md", ".markdown"):
        # Prose wraps. Reading it line-wise splits a rule across two entries and yields fragments
        # like "load — stop and wait.", which is neither quotable nor judgeable. Join each
        # paragraph, then split it into sentences, keeping the line the paragraph started on.
        para: list[str] = []
        start = 0
        for i, raw in enumerate(path.read_text(errors="replace").splitlines() + [""], 1):
            line = re.sub(r"[*`#>]+", "", raw).strip()
            if line:
                if not para:
                    start = i
                para.append(line)
                continue
            if para:
                joined = " ".join(para)
                # A rule often spans two short sentences — "Round only at print time. Never in
                # SQL." Splitting strictly on the full stop drops both halves: the first states
                # no obligation on its own and the second is too short to survive the length
                # filter. So a short sentence is folded back into the one before it.
                merged: list[str] = []
                for sentence in re.split(r"(?<=[.!?])\s+", joined):
                    sentence = sentence.strip()
                    if not sentence:
                        continue
                    if merged and len(sentence) < 30:
                        merged[-1] = f"{merged[-1]} {sentence}"
                    else:
                        merged.append(sentence)
                for sentence in merged:
                    out.append((start, sentence))
                para = []
    return out


SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv"}


def harvest(root: Path) -> list[Assertion]:
    """Every rule the author stated, wherever they stated it."""
    found: list[Assertion] = []
    seen: set = set()
    for p in sorted(root.rglob("*")):
        if not p.is_file() or any(part in SKIP_DIRS for part in p.parts):
            continue
        if p.suffix.lower() not in (".sql", ".py", ".md", ".markdown"):
            continue
        rel = str(p.relative_to(root))
        for lineno, text in _comment_lines(p):
            if len(text) < 20 or not RULE.search(text):
                continue
            # Section dividers and pure punctuation carry no rule.
            if set(text) <= set("-=# "):
                continue
            key = re.sub(r"\W+", "", text.lower())
            if key in seen:
                continue
            seen.add(key)
            found.append(Assertion(text=text, source=f"{rel}:{lineno}",
                                   category=categorise(text), number=find_number(text)))
    return found


#: Rules a finished report cannot supply the evidence for. Marking these blocking would fail good
#: reports for want of evidence rather than for being wrong, which is the fastest way to get a
#: verification suite switched off.
NOT_JUDGEABLE_FROM_ARTEFACT = re.compile(
    r"\b(ask me|do not guess|stop and wait|run .* first|do not skip|do not tidy)\b", re.I)


def to_test(a: Assertion, taken: set) -> dict:
    """One harvested rule as a rubric test.

    The criteria is written for a judge that can see the finished report and nothing else, and it
    quotes the author so a reader can tell what it was derived from and argue with it.
    """
    blocking = not NOT_JUDGEABLE_FROM_ARTEFACT.search(a.text) and a.category in (
        "scope", "metric_definition", "data_completeness")
    if a.category == "known_issue":
        blocking = False

    name = re.sub(r"\s+", " ", a.text).rstrip(".")[:MAX_NAME]
    lead = {
        "data_completeness": "The report must not be built from an incomplete load.",
        "scope": "The report must show only what belongs to this owner.",
        "metric_definition": "The metric must be calculated the way its author defined it.",
        "known_issue": "A discrepancy the author recorded and never resolved.",
        "author_rule": "A rule the author stated about their own report.",
    }[a.category]
    number = f" The author named a boundary of {a.number}." if a.number is not None else ""
    criteria = (
        f"{lead}{number} The author wrote: \"{a.text}\" ({a.source}). "
        f"Judge the finished report against that statement. If the report does not carry enough "
        f"information to decide, say so rather than passing it."
    )[:MAX_CRITERIA]

    return {
        "test_id": slug(a.text[:60], taken),
        "category": a.category,
        "name": name,
        "pass_criteria": criteria,
        "requiredness": "blocking" if blocking else "advisory",
        "render_dependent": False,
    }


def to_bundle(assertions: list[Assertion], subject_type: str = "html") -> dict:
    """A `custom-test-bundle/v1` the verif-tests CLI will accept.

    Caps are enforced here rather than discovered at upload: the format allows 200 tests and 50
    distinct categories, and a bundle that trips either is rejected wholesale, losing the good
    tests along with the surplus.
    """
    taken: set = set()
    tests = [to_test(a, taken) for a in assertions[:MAX_TESTS]]
    cats = {t["category"] for t in tests}
    if len(cats) > MAX_CATEGORIES:                      # not reachable with a fixed vocabulary,
        keep = set(sorted(cats)[:MAX_CATEGORIES])        # but the format allows free-text categories
        tests = [t for t in tests if t["category"] in keep]
    return {"version": "custom-test-bundle/v1", "subject_type": subject_type, "tests": tests}


def write_bundle(bundle: dict, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(bundle, indent=2) + "\n")
    return path
