"""Every call to Summation goes through here.

The guardrails below are not style preferences — each one is a defect that cost time
today, encoded so no caller can repeat it. See LEDGER.md references inline.
"""
from __future__ import annotations
import json, shutil, subprocess, time
from pathlib import Path

from . import settings
from .httpclient import Client, load as load_config


def sumcli_path() -> str:
    """Where the `sumcli` binary is on this machine.

    Asked rather than assumed. The old constant pointed only at `~/.local/bin/sumcli`, which is
    where the shell installer puts it and not where a package manager or a uv tool bin dir on
    another machine would.
    """
    return shutil.which("sumcli") or str(Path.home() / ".local/bin/sumcli")


#: Kept as a module constant because `doctor` reports it, but resolved rather than hard-coded.
SUMCLI = sumcli_path()


class PlatformError(RuntimeError):
    """Carries an actionable message. Never a bare traceback (R-018: the CLI crashes
    formatting its own 422s, so we never rely on its error envelope)."""


# --------------------------------------------------------------------------- client
def _client(profile: str | None = None):
    """No host check here any more.

    There used to be one, and it sat in the wrong place twice over: it fired on reads as well as
    writes, and it judged the hostname, which cannot tell a customer's own tenant from a
    stranger's. The gate now sits where the decision belongs — asked once of a person at `init`,
    naming the tenant, and re-checked before every stage that writes. See `tenant.py`.
    """
    conf = load_config(profile)
    if not conf.base_url:
        raise PlatformError(
            f"profile '{conf.profile}' has no base_url in {settings.config_path()}. "
            f"Set one with: sumcli config set-profile {conf.profile} --base-url <host>")
    return Client(conf), conf


def base_url_for(profile: str | None = None) -> str:
    """The API base URL a profile resolves to.

    Exposed so urls.py can derive the app host from it rather than hard-coding one. It went
    unnoticed that the hard-coded app host did not exist, because nothing ever resolved it.
    """
    return _client(profile)[1].base_url


def api(method: str, path: str, profile: str | None = None, **kw):
    c, _ = _client(profile)
    try:
        return c.request(method, path, **kw)
    except PlatformError:
        raise
    except Exception as e:
        raise PlatformError(f"{method} {path} failed: {str(e)[:400]}") from e


# --------------------------------------------------------------------------- sumcli
def cli(*args: str, profile: str | None = None, timeout: int = 300) -> dict:
    """Run sumcli with --profile always present (R-001) and parse JSON defensively."""
    profile = settings.resolve_profile(profile)
    cmd = [sumcli_path(), "--profile", profile, "--output", "json", *args]
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        # `reports generate --no-wait` blocks rather than returning (found 2026-08-06). A
        # timeout here does NOT mean the work failed — the run starts server-side regardless —
        # so this is raised as an actionable message rather than a traceback.
        raise PlatformError(
            f"sumcli {' '.join(args[:2])} did not return within {timeout}s. This is expected for "
            f"reports generate: the --no-wait flag blocks instead of returning, but the work has "
            f"already started on the server. Nothing is lost."
        )
    if not p.stdout.strip():
        # R-018: any API 422 crashes the CLI, so stdout is empty and the traceback is on stderr.
        tail = (p.stderr or "").strip().splitlines()[-1:] or ["no output"]
        raise PlatformError(f"sumcli {' '.join(args[:3])} produced no JSON. Last line: {tail[0][:300]}")
    try:
        d = json.loads(p.stdout)
    except json.JSONDecodeError:
        raise PlatformError(f"sumcli returned non-JSON: {p.stdout[:300]}")
    if not d.get("ok", True):
        raise PlatformError(f"sumcli error: {json.dumps(d.get('error'))[:300]}")
    return d.get("result", d)


# --------------------------------------------------------------------------- queries
def query(sql: str, profile: str | None = None, limit: int = 200) -> list[dict]:
    """Read-only SQL, returning real rows.

    ALWAYS NAME YOUR COLUMNS. The executor wraps user SQL to describe it, and an unnamed
    column breaks the wrapper: `SELECT 1 FROM t LIMIT 1` fails with an upstream error while
    `SELECT COUNT(*) AS n FROM t` succeeds. A readiness probe written the obvious way can
    therefore never succeed, which looks exactly like a table that does not exist.


    Two envelope shapes exist for the same operation (R-044): the raw API returns
    data.result.rows, the CLI wraps it as result.query.result.rows, and the CLI's own
    top-level result.rows is ALWAYS EMPTY (R-016). Handle all three. Values arrive as
    strings and column aliases come back camelCased (R-017).
    """
    if limit < 1:
        raise PlatformError("limit must be >= 1 — 0 is rejected by the API and crashes the CLI (R-018)")
    d = api("POST", "/v1/query-executions", profile=profile, json={"sql": sql, "limit": limit})
    d = d.get("data", d)
    res = d.get("result") or (d.get("query") or {}).get("result") or {}
    return [r.get("columns", {}) for r in (res.get("rows") or [])]


def snake(row: dict) -> dict:
    """Undo the camelCasing so callers can use the alias they wrote (R-017)."""
    import re
    return {re.sub(r"(?<!^)(?=[A-Z])", "_", k).lower(): v for k, v in row.items()}


def num(row: dict, key: str) -> float:
    r = snake(row)
    v = r.get(key)
    if v in (None, ""): raise PlatformError(f"column '{key}' absent from {sorted(r)}")
    return float(v)


# --------------------------------------------------------------------------- upload
SKIP = ("__pycache__", ".pyc", ".DS_Store", "local_run.py", "compare.py")


def upload_base64(local: Path, project: str, dest: str, profile: str | None = None) -> None:
    """Write a file with content base64-encoded, keeping its real name.

    The edge WAF rejects text bodies under ~8 KiB containing <!doctype, <style or <link
    (LEDGER R-008), which blocks ordinary HTML templates. The write endpoint accepts an
    explicit `encoding: base64`, so we can bypass body inspection without the filename
    games that misled a cold reader earlier (R-039). This is the client-side version of the
    one-line CLI fix: add html/htm to BINARY_EXTENSIONS.
    """
    import base64
    payload = {"content": base64.b64encode(local.read_bytes()).decode("ascii"),
               "encoding": "base64"}
    api("PUT", f"/v1/projects/{project}/files/content", profile=profile,
        params={"path": dest}, json=payload)


def upload_bundle(bundle: Path, project: str, dest_root: str,
                  profile: str | None = None) -> dict:
    """Upload a .spb file by file, MANIFEST LAST.

    Ordering is load-bearing (R-027): a bundle deployed without its manifest lists as a
    perfectly healthy playbook with zero parameters, and nothing warns you. Never mkdir the
    folder first — an explicitly created folder gets FOLDER kind and the manifest sync then
    silently no-ops.
    """
    files = [p for p in sorted(bundle.rglob("*"))
             if p.is_file() and not any(s in str(p) for s in SKIP)]
    manifest = [p for p in files if p.name == "manifest.yaml"]
    body = [p for p in files if p.name != "manifest.yaml"]
    out = {"uploaded": [], "failed": [], "order": "manifest-last"}
    for p in body + manifest:
        rel = p.relative_to(bundle).as_posix()
        try:
            cli("files", "upload", str(p), "--project", project,
                "--path", f"{dest_root}/{rel}", profile=profile)
            out["uploaded"].append(rel)
        except PlatformError as e:
            if "403" in str(e):
                # Self-heal: retry base64-encoded, same filename (R-008).
                try:
                    upload_base64(p, project, f"{dest_root}/{rel}", profile=profile)
                    out["uploaded"].append(rel)
                    out.setdefault("waf_bypassed", []).append(rel)
                    continue
                except PlatformError as e2:
                    out["failed"].append({"file": rel,
                        "error": f"blocked by edge policy, and the base64 retry also failed: {str(e2)[:150]}"})
                    continue
            out["failed"].append({"file": rel, "error": str(e)[:180]})
    return out


def wait_queryable(connection_id: str, profile: str | None = None,
                   timeout: int = 300) -> tuple[bool, float, str | None]:
    """Wait until an attached dataset can actually be queried.

    `status: DEPLOYED` is necessary but NOT sufficient — measured 2026-08-06, a dataset
    reporting DEPLOYED took a further 17s before the query engine would accept it. Polling on
    the status alone therefore produces a race that looks like "the table does not exist".
    The only honest readiness test is a successful query, so that is what this does.
    """
    t0 = time.time()
    while time.time() - t0 < timeout:
        d = api("GET", f"/v1/connections/data/{connection_id}/datasets", profile=profile).get("data", {})
        rows = d.get("datasets", [])
        if any(r.get("status") in ("FAILED", "ERROR") for r in rows):
            return False, time.time() - t0, None
        for r in rows:
            if r.get("status") != "DEPLOYED":
                continue
            try:
                query(f"SELECT COUNT(*) AS n FROM {r['name']}", profile=profile, limit=1)
                return True, time.time() - t0, r["name"]
            except PlatformError:
                pass          # deployed but the engine has not picked it up yet
        time.sleep(4)
    return False, time.time() - t0, None
