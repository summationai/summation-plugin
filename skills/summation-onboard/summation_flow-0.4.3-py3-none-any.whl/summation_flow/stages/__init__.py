"""Stage implementations. Each is a plain function taking parsed args and returning an exit code.

Nothing here asks a question or makes a judgement call — that is the skill's job. If a step
here has more than one defensible answer, it is in the wrong file (BUILD-SPEC §0.1).
"""
from __future__ import annotations
import contextlib
import csv
import hashlib
import io
import json, os, re, shutil, subprocess, sys, textwrap, time
from pathlib import Path

from sf_ledger import SCHEMA_PATH as SF_SCHEMA_PATH

from ..state import (Run, all_runs, new_run, set_current, tree_key, ROOT, STAGES,
                     current_run_id)
from .. import journey as J
from .. import platform as P
from .. import settings
from .. import tenant as T
from ..urls import url
from .. import context as CTX
from .. import advise as ADV
from .. import fidelity as F
from .. import experience as X
from ..operations import Operation, UNSAFE_STATES

#: The fixture the flow actually runs on. `doctor` used to check `cleanroom`, which was
#: retired weeks ago — so the preflight validated a directory nothing uses and never
#: checked the one its own closing line tells you to pass. It now ships inside the package, so
#: it is present wherever the tool is, and `init --input demo` resolves to it.
FIXTURE = settings.demo_fixture()

#: What to type to mean "the fixture that came with the tool". Without it, the only way to name
#: the demo input was a path on the one machine it was written on.
DEMO_INPUT_ALIASES = ("demo", "demo-fixture")
DEMO_REFERENCE = FIXTURE / "reports" / "2026-04-04-owner-07-weekly-recap.html"

#: Fast-loop fixture for testing the journey rather than artifact complexity. Unlike `demo`, it
#: has one ordinary artifact candidate, so intake's format-neutral auto-selection is exercised.
TINY_FIXTURE = settings.tiny_fixture()
TINY_INPUT_ALIASES = ("tiny", "tiny-fixture")

#: What the deterministic extractor can read. Everything else is read by the conducting agent
#: and arrives back as a ledger — see `parse --from-ledger`.
PARSED_SUFFIXES = (".html", ".htm")

#: What counts as a possible reference artifact when the input is a folder. This is a set, not a
#: preference list: format cannot tell us which of several customer files is the artifact they
#: mean to reproduce. One candidate is safe to infer; several require `init --artifact`.
ARTIFACT_SUFFIXES = frozenset({
    ".html", ".htm", ".pdf", ".pptx", ".ppt", ".docx", ".doc",
    ".xlsx", ".xlsm", ".xls", ".csv", ".key", ".numbers",
    ".sdoc", ".smd", ".md", ".rtf", ".txt",
})

#: Directories that hold somebody's tooling rather than their report.
_NOT_AN_ARTIFACT = {".git", "node_modules", "__pycache__", ".venv", "venv", ".tox"}


def _vendored(module: str, argv: list[str]) -> tuple[int, str]:
    """Run one of the vendored tools in-process; give back (exit code, captured output).

    These used to be subprocesses launched with a particular `cwd`, which is a large part of why
    the tool ran nowhere else: cold verify used `cwd=ROOT/"coldverify"` purely so that
    `python -m coldverify.run` could find its package. Importing does the same work with no
    opinion about the working directory or about which interpreter is on PATH. The output is
    captured exactly as `subprocess.run(capture_output=True)` captured it, so the messages the
    stages print on failure are unchanged.
    """
    import importlib
    buf = io.StringIO()
    try:
        main = importlib.import_module(module).main
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            rc = main(argv)
    except SystemExit as e:                  # argparse usage errors exit rather than return
        rc = e.code if isinstance(e.code, int) else 2
    except Exception as e:                   # a crash is a failure, not a traceback shown to a user
        return 1, f"{buf.getvalue()}\n{type(e).__name__}: {e}"
    return int(rc or 0), buf.getvalue()


def _ack_without_run(args, action: str):
    """The tenant gate for the two stages that have no run to hang it on.

    `reset` and `orphans --delete` act on a whole tenant rather than on one run's objects, so
    there is no recorded acknowledgement to check against — the same question is asked directly,
    in the same words, and answered the same way.
    """
    t = T.resolve(getattr(args, "profile_given", None))
    print(T.banner(t, action), file=sys.stderr)
    named = (os.environ.get(T.ACK_ENV) or "").strip()
    if named:
        if named != t.profile:
            raise T.TenantRefused(
                f"{T.ACK_ENV}={named!r} does not acknowledge {t.profile!r} ({t.base_url}).")
        return t
    if not sys.stdin.isatty():
        raise T.TenantNeedsAck(
            f"Waiting for you to confirm the tenant. This acts on '{t.label}' ({t.base_url}), and "
            f"stdin is not a terminal, so it cannot ask you here.\n"
            f"    This is a question, not an error. Once you have confirmed the tenant, set "
            f"{T.ACK_ENV}={t.profile} and run the same command again.\n"
            f"    (exit code 2 means 'awaiting your confirmation', not 'failed'.)")
    try:
        typed = input(f"  type the profile name to act on {t.label} ({t.profile}): ").strip()
    except (EOFError, KeyboardInterrupt):
        _say(); raise T.TenantRefused("cancelled — nothing was changed")
    if typed != t.profile:
        raise T.TenantRefused(
            f"got {typed!r}, expected {t.profile!r} — cancelled, nothing was changed")
    return t


def _resolve_input(raw: str) -> Path:
    """What `--input` means. Packaged fixture aliases or an ordinary path."""
    key = raw.strip().lower()
    if key in DEMO_INPUT_ALIASES:
        return FIXTURE
    if key in TINY_INPUT_ALIASES:
        return TINY_FIXTURE
    return Path(raw).expanduser().resolve()


def _code_root(r) -> Path:
    """Where a run's *code* lives — its queries, config, the producing skill. This is the code
    scope from `init --code`; it falls back to the input folder, so a single-process run is
    unchanged. fanout, detect and context read from here, not from wherever the artifact sits."""
    return Path(getattr(r, "code_dir", "") or r.input_dir)


def _collect_run_evidence(r: Run) -> dict:
    """Collect the exact source package this run's contract must remain bound to."""

    meta = r.read("input.json")
    package_root = Path(r.input_dir).resolve()
    document = Path(meta["document"]).resolve() if meta.get("document") else None
    collected = F.collect_package_evidence(
        package_root,
        document,
        artifact_only=bool(meta.get("input_is_file")),
    )

    # `--code` may name a separate skill/query tree outside the artifact's folder.  It is still
    # supplied source material and therefore part of the acceptance boundary.  Do not record its
    # machine-specific absolute path; the manifest is root-relative and location-independent.
    code_root = _code_root(r).resolve()
    try:
        code_root.relative_to(package_root)
        code_is_already_in_package = True
    except ValueError:
        code_is_already_in_package = code_root == package_root
    if not code_is_already_in_package:
        collected["supplemental_packages"] = {
            "code": F.collect_tree_manifest(code_root),
        }
    return collected


def _write_run_evidence(r: Run) -> dict:
    try:
        previous = r.read("evidence.json")
    except SystemExit:
        previous = None
    collected = _collect_run_evidence(r)
    if previous and F.evidence_fingerprint(previous) != F.evidence_fingerprint(collected):
        r.invalidate_from("parse", "the supplied artifact, code, or resources changed")
    r.write("evidence.json", collected)
    total = collected["package"]["file_count"]
    total += sum(item["file_count"] for item in (collected.get("supplemental_packages") or {}).values())
    truncated = collected["package"]["truncated"] or any(
        item["truncated"] for item in (collected.get("supplemental_packages") or {}).values()
    )
    r.mark("evidence", "failed" if truncated else "done",
           f"{total} supplied file(s)" + (", inventory truncated" if truncated else ""),
           "evidence.json")
    return collected


def _artifact_candidates(src: Path) -> list[Path]:
    """Every possible reference artifact, with no format-based ranking."""

    candidates = []
    for p in sorted(src.rglob("*")):
        if not p.is_file() or _NOT_AN_ARTIFACT & set(p.parts):
            continue
        if p.suffix.lower() in ARTIFACT_SUFFIXES:
            candidates.append(p)
    return candidates


def _find_artifact(src: Path) -> Path | None:
    """Return the only possible artifact; ambiguity is not a selection rule."""

    candidates = _artifact_candidates(src)
    return candidates[0] if len(candidates) == 1 else None


def _declared_artifact(root: Path, raw: str) -> Path:
    """Resolve an explicitly chosen primary artifact and keep it inside the supplied package."""

    # Compare canonical paths. On macOS `/tmp` is a symlink to `/private/tmp`; installed-package
    # smoke tests (and any customer package reached through a symlink) otherwise reject a file
    # that is genuinely inside the selected input directory.
    root = root.expanduser().resolve()
    selected = Path(raw).expanduser()
    selected = selected.resolve() if selected.is_absolute() else (root / selected).resolve()
    try:
        selected.relative_to(root)
    except ValueError as exc:
        raise SystemExit(f"--artifact must be inside the --input package: {selected}") from exc
    if not selected.is_file():
        raise SystemExit(f"--artifact is not a file: {selected}")
    return selected


def _ambiguous_artifacts(root: Path, candidates: list[Path]) -> str:
    shown = "\n".join(f"      - {path.relative_to(root)}" for path in candidates[:12])
    more = f"\n      … and {len(candidates) - 12} more" if len(candidates) > 12 else ""
    return (
        f"the input contains {len(candidates)} possible reference artifacts, and file type does "
        f"not tell us which one the customer means:\n{shown}{more}\n"
        "    Re-run with `--artifact <path-inside-input>` to choose one, or `--no-artifact` "
        "if these are supporting resources and the requirements will come from conversation."
    )


def _extraction_route(doc: Path | None) -> str:
    """`parser` when the deterministic extractor can read it, `model` otherwise.

    This is the whole of the format decision, and it is deliberately one line: everything the
    parser cannot read is handed to the agent, rather than each new format needing its own
    branch here. The alternative — a list of formats we refuse — is how intake came to accept
    only `.html` in the first place.
    """
    if doc is None:
        return "model"
    return "parser" if doc.suffix.lower() in PARSED_SUFFIXES else "model"


#: Stages that create or destroy something in somebody's tenant. Everything not named here
#: reads, or works entirely on local files, and is deliberately not gated: `init`, `parse`,
#: `fanout`, `verify --cold`, `detect`, `request-access`, `output-target`, `build`, `params`,
#: `advise`, `doctor`, `status` and `open` create nothing, and most of the early value is in
#: them. `init` left this set in U3: it no longer creates the project or asks the tenant
#: question — both wait for the first stage that actually touches the tenant, so a person sees
#: the defects in their own report before signing in to anything.
WRITING_STAGES = {
    "connect", "deploy", "run", "schedule", "verify-full",
    "context-upload", "orphans-delete", "reset", "teardown",
}


def _ensure_project(r) -> None:
    """Create the platform project on first use, and open it so the person can watch it fill.

    Deferred out of `init` (U3): the project is created the first time a writing stage needs a
    place to put things, not at the door. This is also the earliest honest "watch here" browser
    moment (U12) — before this, there was no project page to open.
    """
    if r.project_id:
        return
    project_name = f"onboarding-{r.run_id}"
    op = Operation(r, "project", "project.create", project_name, "project creation")
    if op.last and op.last.get("state") in UNSAFE_STATES:
        projects = P.api("GET", "/v1/projects", profile=r.profile).get("data", {}).get("projects") or []
        existing = next((p for p in projects if p.get("name") == project_name), None)
        if not existing:
            op.refuse_unknown_retry()
        r.project_id = existing["id"]
        r.record_object("project", r.project_id, "reconciled after interrupted creation")
        op.confirmed(object_ids=[r.project_id], reconciled=True)
        _ok(f"project {r.project_id} recovered from an interrupted creation")
        return
    op.planned(binding=project_name)
    op.submitted()
    try:
        res = P.cli("projects", "create", "--name", project_name, profile=r.profile)
    except Exception as exc:
        op.failed(exc)
        raise
    r.project_id = res["project"]["id"]
    r.record_object("project", r.project_id, "created on first tenant write")
    op.confirmed(object_ids=[r.project_id])
    r.save()
    _ok(f"project {r.project_id} created — everything this run builds lands here")
    _open_evidence("project", r, "your project — watch it fill up")


def _ensure_writable(args, r, stage: str, needs_project: bool = True) -> None:
    """The tenant gate, now that it lives at the first write rather than at `init` (U3/U4).

    If the run already carries an acknowledgement, re-check it has not drifted onto another
    tenant — the original guarantee. If it does not (the ack was deferred out of `init`), ask
    now, naming the tenant, and record the answer on the run. A project is created here too,
    unless the stage genuinely needs none (a tenant-level connection does not).
    """
    profile_given = getattr(args, "profile_given", None)
    if profile_given and profile_given != r.profile:
        raise T.TenantRefused(
            f"REFUSING: run {r.run_id} is bound to profile '{r.profile}', but this command "
            f"selected '{profile_given}'. Start or resume the run for that profile instead.")
    if r.tenant_ack:
        T.require(r, r.profile, stage)
    else:
        t = T.resolve(r.profile)
        r.tenant_ack = T.acknowledge(t)
        r.save()
    if needs_project:
        _ensure_project(r)


def _run(args, writes: str | None = None, needs_project: bool = True) -> Run:
    """Resolve which run to act on, and say so out loud. Naming it in the output is what turns a
    stolen-pointer failure from a five-minute mystery into an obvious mismatch.

    `writes` names the stage when it is about to create or destroy something: the tenant is
    acknowledged (or re-checked) and, unless `needs_project` is False, the project is created on
    first use.
    """
    rid = getattr(args, "run", None)
    r = Run.load(rid)
    if writes:
        _ensure_writable(args, r, writes, needs_project=needs_project)
    print(f"  [run {r.run_id} · project {r.project_id or '—'}]")
    if writes:
        ack = r.tenant_ack or {}
        # Say it every time, not just at the gate. A person who walks back to a terminal an hour
        # later should not have to remember which tenant this run belongs to.
        _info(f"tenant     {ack.get('tenant_name') or ack.get('profile')}  ({ack.get('base_url')})")
    return r


def _authorize_permission_write(args, r: Run, *, writes: str, permission: str,
                                needs_project: bool = True) -> None:
    """Check the exact customer grant before even the deferred project-creation write."""

    grant = X.require_permission(r, permission)
    if not r.tenant_ack:
        tenant = T.resolve(r.profile)
        r.tenant_ack = T.acknowledge_from_permission(tenant, grant)
        r.save()
        # The customer chose the action before browser authentication. Once whoami proves the
        # exact tenant, replace that pre-auth grant with an otherwise identical tenant-bound one.
        # This is an audit upgrade, not a second approval.
        if not (grant.get("scope") or {}).get("tenant_id"):
            grant = X.grant_permission(r, permission, grant.get("actor"))
    _ensure_writable(args, r, writes, needs_project=needs_project)
    ack = r.tenant_ack or {}
    _info(f"tenant     {ack.get('tenant_name') or ack.get('profile')}  ({ack.get('base_url')})")


# --------------------------------------------------------------------------- browser evidence (U12)
def _file_name(f: dict) -> str:
    """A platform file's display name. `sumcli files list` spells it `name` in some shapes and
    `fileName` in others (U7), so every reader tolerates both rather than guessing one."""
    return f.get("name") or f.get("fileName") or ""


def _chat_rows(payload: dict) -> list[dict]:
    """The chat-list response has shipped under both keys; keep URL construction tolerant."""
    return payload.get("conversations") or payload.get("chats") or []


def _latest_chat_id(r) -> str:
    """The report-generation chat that the schedules page should reopen alongside its detail."""
    run_state = r.read("run.json")
    if run_state.get("chat_id"):
        return run_state["chat_id"]

    # Older runs only persisted the count. Recover once from the same project and upgrade their
    # local artifact so every later `open schedules` is deterministic.
    rows = _chat_rows(P.cli("chats", "list", "--project", r.project_id, profile=r.profile))
    rows = [row for row in rows if row.get("id")]
    if not rows:
        raise SystemExit("no chat found for this run's project — cannot build the schedule link")
    chat_id = max(rows, key=lambda row: row.get("updatedAt", ""))["id"]
    run_state["chat_id"] = chat_id
    r.write("run.json", run_state)
    return chat_id


def _open_url(u: str, prov: str, headline: str) -> bool:
    """Open a resolved evidence URL in the default browser, or say plainly why it did not.

    The whole point of these URLs is that a human opens one to confirm something is real, so the
    bar for actually launching is "the host resolves". A host that does not (or an unknown app
    host) prints instead of opening — a 404 in front of a customer is the failure urls.py exists
    to prevent. `SF_NO_OPEN` suppresses the launch for runs that must not spawn a browser.
    """
    if u.startswith("<app host unknown"):
        _warn(f"cannot open {headline} — app host unknown for this profile; set SF_APP_URL to "
              f"the tenant's App URL and it will open here")
        return False
    if "HOST DOES NOT RESOLVE" in prov:
        _warn(f"not opening {headline} — its host does not resolve; visit the URL above yourself")
        return False
    if os.environ.get("SF_NO_OPEN"):
        _info(f"SF_NO_OPEN is set — not launching a browser; open {headline} at the URL above")
        return False
    rc = subprocess.run(["open", u], check=False).returncode
    _ok(f"opened {headline} in your browser" if rc == 0
        else f"could not launch a browser — open {headline} at the URL above yourself")
    return rc == 0


def _open_evidence(kind: str, r, headline: str, **ids) -> None:
    """Print an evidence URL and open it. The flow's four browser moments (U12) all go through
    here: the project after the first write, the playbook after deploy, the report after the
    render check, and the schedules view after schedule."""
    u, prov = url(kind, profile=r.profile, project_id=r.project_id, **ids)
    _say(); _info(f"evidence: {u}")
    _open_url(u, prov, headline)


def _short(p: Path) -> str:
    """A path to print. Relative to the data dir when it is under it, absolute when it is not.

    `relative_to` raises rather than falling back, so a run directory outside `SF_ROOT` — an
    older run, a moved root, a test — turned a success message into a ValueError traceback after
    all the work had already been done.
    """
    try:
        return str(p.relative_to(ROOT))
    except ValueError:
        return str(p)


def _say(msg=""): print(msg)
def _ok(msg):     print(f"  ✓ {msg}")
def _warn(msg):   print(f"  ! {msg}")
def _info(msg):   print(f"    {msg}")


# ============================================================ login
def login(args) -> int:
    """Make device login usable from an agent tool whose output appears only on completion.

    `sumcli auth login` prints its approval URL and then polls. When an agent runs it as one
    blocking Bash call, the person may never see the URL while the process is alive. Piping it
    through `head` makes that failure even less legible. This wrapper reads the authentic URL
    from sumcli's own output, opens it immediately, and then lets sumcli keep ownership of polling
    and credential persistence.
    """
    profile = settings.resolve_profile(getattr(args, "profile", None))
    command = [P.sumcli_path(), "--profile", profile, "auth", "login"]
    try:
        proc = subprocess.Popen(
            command,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
        )
    except OSError as exc:
        raise SystemExit(f"could not start Summation sign-in: {exc}")

    browser_opened = False
    output: list[str] = []
    try:
        assert proc.stdout is not None
        for raw in proc.stdout:
            line = raw.rstrip()
            output.append(line)
            if not browser_opened:
                match = re.search(r"https://[^\s]+", line)
                if match:
                    approval_url = match.group(0)
                    _say(); _info(f"sign-in approval: {approval_url}")
                    browser_opened = _open_url(
                        approval_url,
                        "returned directly by the Summation authentication service",
                        "the Summation sign-in page",
                    )
                    if not browser_opened:
                        proc.terminate()
                        proc.wait(timeout=5)
                        raise SystemExit(
                            "the approval URL was created but the browser could not be opened. "
                            "Sign-in was paused; nothing was denied."
                        )
                    _info("waiting for your approval in the browser")
            if line.startswith("Verification code:"):
                _info(line)
        rc = proc.wait()
    except KeyboardInterrupt:
        proc.terminate()
        with contextlib.suppress(Exception):
            proc.wait(timeout=5)
        _say(); _warn("sign-in paused — nothing was declined or denied")
        return 130

    if not browser_opened:
        detail = next((line for line in reversed(output) if line.strip()), "no response from sumcli")
        raise SystemExit(f"sign-in did not return an approval URL: {detail}")
    if rc != 0:
        detail = next((line for line in reversed(output) if line.strip()), f"exit {rc}")
        raise SystemExit(f"sign-in did not complete: {detail}")
    _ok(f"signed in with profile {profile}")
    return 0


# ============================================================ doctor
def doctor(args) -> int:
    """A diagnostic, not a gate at the door (U2).

    The old doctor failed a brand-new machine for things it needs at step 7 or never — a
    warehouse credential, a connection file, psql. That inverts the flow's own philosophy: show
    value before asking for access. So doctor now FAILS only on genuine blockers — the things
    without which the tool cannot run at all — and reports everything needed later as pending,
    not as a fault. A machine with Python, this package and its libraries passes, even before
    anyone has signed in.
    """
    _say("Diagnostic — blockers now, everything else when the flow reaches it\n")
    checks, fail = [], 0

    def chk(name, ok, detail="", blocker=True):
        """`blocker=True` counts toward the exit code; `blocker=False` is pending, never a fault."""
        nonlocal fail
        checks.append({"check": name, "ok": bool(ok), "detail": detail, "blocker": blocker})
        if ok:
            glyph = "✓"
        elif blocker:
            glyph = "✗"; fail += 1
        else:
            glyph = "⏸"                          # needed later in the flow, not now
        print(f"  {glyph} {name}" + (f"  — {detail}" if detail else ""))

    # ---- genuine blockers: without these nothing runs ----
    chk("python >= 3.11", sys.version_info >= (3, 11), sys.version.split()[0])
    sumcli = P.sumcli_path()
    chk("sumcli installed", Path(sumcli).exists(), sumcli)
    # Import them rather than looking for directories beside us. The old check asked whether
    # `~/plg-e2e/extractor` existed, which is neither necessary nor sufficient for an import.
    for pkg in ("extractor", "coldverify", "paramcheck"):
        try:
            mod = __import__(pkg)
            chk(f"{pkg} importable", True, getattr(mod, "__file__", "") or "")
        except ImportError as e:
            chk(f"{pkg} importable", False, str(e)[:90])
    try:
        import jsonschema  # noqa: F401
        chk("jsonschema", True)
    except ImportError:
        chk("jsonschema", False, "pip install jsonschema")
    chk("writable data dir", _writable(ROOT), str(ROOT))
    # A malformed shared config IS a real blocker — sumcli calls `tomllib.load` bare and half the
    # flow shells out to it — but only when a file actually exists. A machine with none is fine;
    # the file is written when someone signs in.
    if settings.config_path().exists():
        toml_ok = settings.config_is_toml()
        chk("shared config is valid TOML", toml_ok,
            "" if toml_ok else f"{settings.config_path()} does not parse as TOML — every sumcli "
                               f"call will fail until its values are quoted")
    else:
        chk("shared config file", False,
            f"none yet at {settings.config_path()} — written when you sign in", blocker=False)

    # ---- needed later in the flow, never at hello (U2): pending, not failure ----
    prof = settings.resolve_profile(getattr(args, "profile", None))
    base = settings.base_url(prof)
    chk(f"profile '{prof}' configured", bool(base),
        base or "no base_url yet — set when you sign in, needed at `connect`", blocker=False)
    try:
        who = P.cli("auth", "whoami", profile=prof)
        ident = who.get("identity", {})
        chk(f"signed in to {prof}", True, f"{ident.get('user_id','?')} scopes={ident.get('scopes')}")
    except Exception as e:
        chk(f"signed in to {prof}", False,
            f"not yet — sign in before `connect` ({_diagnostic_error(e)})", blocker=False)
    # Both fixtures ship inside the package. The demo exercises artifact complexity; tiny keeps
    # repeated journey testing fast. Their absence is a packaging fault, never a customer gate.
    for label, root in (("demo fixture present", FIXTURE),
                        ("tiny fixture present", TINY_FIXTURE)):
        doc = next(iter(sorted(root.rglob("*.html"))), None) if root.exists() else None
        chk(label, doc is not None,
            f"{root}" + (f"  ({doc.name})" if doc else "  — missing from the package"),
            blocker=False)
    # Report on the connection file WITHOUT echoing it — a reader cannot `cat` a file holding a
    # live password. It is written just before `connect`, so its absence now is expected.
    cf = Path(getattr(args, "config_file", None) or Path.home() / "pg-conn.json")
    if cf.exists():
        try:
            body = json.loads(cf.read_text())
            keys = sorted((body.get("config") or {}).keys())
            has_pw = bool((body.get("secrets") or {}).get("pg_pass"))
            want = {"pg_host", "pg_port", "pg_db", "pg_user"}
            missing = sorted(want - set(keys))
            chk(f"connection file {cf.name}", not missing and has_pw,
                f"keys {keys}, password {'present' if has_pw else 'MISSING'}"
                + (f", missing {missing}" if missing else ""),
                blocker=False)
        except Exception as e:
            chk(f"connection file {cf.name}", False, f"unreadable: {str(e)[:60]}", blocker=False)
    else:
        chk("connection file", False,
            f"none yet — you write it just before `connect` (expected at {cf})", blocker=False)

    _say()
    pending = sum(1 for c in checks if not c["ok"] and not c["blocker"])
    passed = sum(1 for c in checks if c["ok"])
    if fail:
        _say(f"  {fail} blocker(s) — fix those before starting."
             + (f"  ({pending} item(s) pending, which is fine this early.)" if pending else ""))
    else:
        _say(f"  Ready — {passed} check(s) pass"
             + (f", {pending} not needed yet (they come later in the flow)." if pending else "."))
        _say("  Start with:")
        # The closing line used to name a directory that exists on one laptop, so the first
        # thing the guide told a cold reader to type could not work for them. `demo` resolves
        # to whatever the installed package carries; the path is printed so it is not magic.
        _say("      summation-flow init --input demo")
        _info(f"`demo` is the fixture that shipped with this tool: {FIXTURE}")
        _info("`tiny` is the fast journey test: one artifact, one query, one planted defect "
              f"({TINY_FIXTURE})")
        _info("point --input at your own material — a folder, a repo, or any single artifact file")
    return 1 if fail else 0


def _diagnostic_error(error: Exception) -> str:
    """One complete, secret-free error for a diagnostic row—not half a JSON envelope."""

    message = " ".join(str(error).split())
    prefix = "sumcli error: "
    if message.startswith(prefix):
        try:
            payload = json.loads(message[len(prefix):]) or {}
            code = payload.get("code")
            detail = payload.get("message") or payload.get("detail") or "authentication unavailable"
            message = f"{code}: {detail}" if code else str(detail)
        except (json.JSONDecodeError, TypeError):
            pass
    return textwrap.shorten(message, width=140, placeholder="…")


def _writable(d: Path) -> bool:
    """Can we actually create the run directory? Asked, not assumed — a read-only HOME is the
    kind of thing that fails four stages later with a confusing error."""
    try:
        d.mkdir(parents=True, exist_ok=True)
        probe = d / ".write-probe"
        probe.write_text("ok"); probe.unlink()
        return True
    except OSError:
        return False


# ============================================================ init
def init(args) -> int:
    raw_input = args.input
    demo_input = raw_input.strip().lower() in DEMO_INPUT_ALIASES
    src = _resolve_input(raw_input)
    if not src.exists(): raise SystemExit(f"input not found: {src}")
    input_is_file = src.is_file()
    # "Drop in your report" has to mean a report. Pointing at a single .html file used to fail
    # with "no .html report found under <that exact .html file>", because rglob on a file matches
    # nothing. A file is the most natural thing to hand over, so accept it and treat its folder as
    # the working directory — that is where any SQL or config alongside it will be.
    #
    # Any format is accepted. `init` refusing a PDF was the flow refusing the thing most people
    # actually build, and it refused it at the only stage where nothing has been created yet —
    # so the person's first experience of onboarding was being told their report was the wrong
    # shape. What the deterministic parser can read, it reads; the rest is the agent's to read,
    # and that decision is recorded here and acted on by `parse`.
    declared = getattr(args, "artifact", None)
    no_artifact = bool(getattr(args, "no_artifact", False))
    if input_is_file:
        if declared or no_artifact:
            raise SystemExit(
                "--input already names one file; do not combine it with --artifact or --no-artifact"
            )
        doc, src = src, src.parent
        selection = "input-file"
    else:
        if no_artifact:
            doc = None
            selection = "declared-none"
        elif declared:
            doc = _declared_artifact(src, declared)
            selection = "declared"
        elif demo_input:
            if not DEMO_REFERENCE.is_file():
                raise SystemExit(f"the packaged demo reference artifact is missing: {DEMO_REFERENCE}")
            doc = DEMO_REFERENCE
            selection = "packaged-demo"
        else:
            candidates = _artifact_candidates(src)
            if len(candidates) > 1:
                raise SystemExit(_ambiguous_artifacts(src, candidates))
            doc = candidates[0] if candidates else None
            selection = "only-candidate" if doc else "none-found"
    route = _extraction_route(doc)

    # No tenant question, no project, no sign-in here (U3). `init` and everything through intake
    # — parse, fanout, verify --cold, request-access, detect — read local files, so a person
    # sees the defects in their own report before authenticating anything. The tenant is
    # acknowledged, and the project created, at the first stage that actually touches the tenant
    # (`connect`/`deploy`), guarded by `_ensure_writable`.
    r = new_run()
    inferred_name = (doc.stem if doc else src.name).replace("_", " ").replace("-", " ")
    r.name = (getattr(args, "name", None) or " ".join(inferred_name.split()).title() or r.run_id)
    r.input_dir, r.input_key = str(src), tree_key(src)
    # The code scope. When a folder holds several processes, --input names the chosen artifact and
    # --code names the folder whose queries/config/skill build it, so fanout and detect read only
    # that process instead of the whole tree (U18). The agent supplies both — it already worked out
    # which files are this process's when it looked. Omitted, the code scope is the input folder,
    # which is exactly today's single-process behaviour.
    if getattr(args, "code", None):
        code = _resolve_input(args.code)
        if not code.exists():
            raise SystemExit(f"--code path not found: {code}")
        r.code_dir = str(code)
    r.profile = settings.resolve_profile(getattr(args, "profile_given", None))
    if args.project:
        # A project the person named already exists; record it without creating anything. The
        # tenant is still acknowledged at the first writing stage.
        r.project_id = args.project
    r.bindings["project_target"] = (
        f"project:{r.project_id}" if r.project_id else f"create:onboarding-{r.run_id}"
    )
    r.save()
    r.write("input.json", {"dir": str(src), "key": r.input_key,
                           "document": str(doc) if doc else None,
                           "input_is_file": input_is_file,
                           "artifact_selection": selection,
                           "format": (doc.suffix.lower().lstrip(".") if doc else None),
                           "extraction": route})
    r.mark("init", "done", f"input {r.input_key}", "input.json")
    collected = _write_run_evidence(r)
    X.create_front_door(r)

    _say(f"Run {r.run_id}")
    _ok(f"input      {src}")
    if doc:
        _ok(f"document   {doc.name}")
        _info(f"selected by {selection.replace('-', ' ')}; format did not affect selection")
    if r.code_dir:
        _ok(f"code       {Path(r.code_dir).name}  (fanout and detect read only this process)")
    if not doc:
        _warn(f"no artifact found under {src} that looks like a report")
    if r.project_id:
        _ok(f"project    {r.project_id}")
    _info(f"key        {r.input_key}")
    supplied_count = collected["package"]["file_count"] + sum(
        item["file_count"] for item in (collected.get("supplemental_packages") or {}).values()
    )
    _ok(f"evidence   {supplied_count} supplied file(s) fingerprinted")
    _info("no project or sign-in yet — intake runs on your files; the tenant is confirmed at "
          "the first step that creates anything")
    _say(); _say(X.render_front_door(r))
    if route == "model":
        # Said at `init`, not saved for `parse`, because this is the moment the agent can still
        # ask for the HTML or the code instead. Finding out two stages later that it has to read
        # a 40-page PDF itself is a worse place to learn it.
        _say()
        _warn("there is no deterministic reader for this — `parse` will hand the read to you")
        _info("`parse` prints the ledger contract and what to do with it; nothing fails")
    _say(); _say("  Next:  summation-flow parse")
    return 0


# ============================================================ evidence
def evidence(args) -> int:
    """Re-collect the source boundary after an intentional package change."""

    r = _run(args); r.require("init")
    collected = _write_run_evidence(r)
    X.source_map(r)
    source = collected.get("source") or {}
    total = collected["package"]["file_count"] + sum(
        item["file_count"] for item in (collected.get("supplemental_packages") or {}).values()
    )
    _ok(f"{total} supplied file(s) pinned to {F.evidence_fingerprint(collected)[:12]}")
    if source.get("name"):
        _info(f"reference artifact: {source['name']} ({source.get('format')})")
    else:
        _warn("no reference artifact was supplied; the customer conversation must define fidelity")
    if r.status_of("evidence") == "failed":
        raise SystemExit("the package inventory was truncated; narrow the declared input/code roots before building")
    _say(); _say("  Next:  summation-flow parse")
    return 0


# ============================================================ status
def status(args) -> int:
    rid = getattr(args, 'run', None) or current_run_id()
    if not rid:
        _say("No active run. Try `summation-flow resume`, or start with `summation-flow init --input <dir>`.")
        return 0
    r = Run.load(rid)
    output_format = getattr(args, "format", "card")
    if output_format == "json":
        _say(json.dumps(J.view(r).to_dict(), indent=2))
        return 0
    if output_format == "card":
        _say(J.render_card(r))
        return 0
    _say(f"Run {r.run_id}   project {r.project_id}   profile {r.profile}")
    _say(f"input {r.input_dir}\n")
    glyph = {"done":"✓","degraded":"~","blocked":"✗","failed":"✗","skipped":"-","running":"…","not-started":" "}
    for s in STAGES:
        st = r.status_of(s)
        d = (r.stages.get(s) or {}).get("detail","")
        print(f"  {glyph.get(st,'?')} {s:16} {st:12} {d[:60]}")
    if r.created_objects:
        _say(f"\n  {len(r.created_objects)} object(s) created — `summation-flow teardown` removes them")
    _say("\n" + J.render_card(r))
    return 0


def _run_line(r: Run) -> str:
    j = J.view(r)
    return (f"{r.run_id:8} {j.name[:28]:28}  Stage {j.phase_number}/{j.phase_total}  "
            f"{j.phase_title}  [{j.status}]")


def runs(args) -> int:
    saved = all_runs()
    if not getattr(args, "all", False):
        saved = [r for r in saved if J.is_resumable(r)]
    if not saved:
        _say("No unfinished onboarding runs were found on this machine.")
        return 0
    _say("Saved onboarding runs (this machine and flow-state directory):")
    for r in saved:
        _say("  " + _run_line(r))
    return 0


def resume(args) -> int:
    """Select but never advance a saved run."""
    explicit = getattr(args, "run", None)
    if explicit:
        r = Run.load(explicit)
    else:
        candidates = [r for r in all_runs() if J.is_resumable(r)]
        # A run is only an automatic match inside the selected profile boundary.  An explicitly
        # named run is still shown, but never executed, so a person can resolve profile drift.
        candidates = [r for r in candidates if r.profile == args.profile]
        if not candidates:
            _say(f"No unfinished onboarding run matches profile {args.profile!r} on this machine.")
            return 0
        if len(candidates) > 1:
            _say("More than one onboarding can be resumed. Choose one by name, then pass its run id:")
            for candidate in candidates:
                _say("  " + _run_line(candidate))
            return 2
        r = candidates[0]
    set_current(r.run_id)
    _say(J.render_card(r, welcome_back=True))
    _say("\nCheckpoint selected. Nothing has been executed.")
    return 0


# ============================================================ parse
def parse(args) -> int:
    """Document -> claim ledger, by whichever route the artifact allows.

    The ledger is the boundary, not the parser. Everything downstream — `verify --cold`, the
    traceability diff, the comparison at the end — reads `ledger.json` and never the document,
    so a ledger a model wrote gets exactly the same treatment as one the DOM parser produced.
    That is what makes intake extensible without a second pipeline.
    """
    r = _run(args); r.require("init"); r.require("evidence")
    if getattr(args, "from_ledger", None):
        return _parse_from_ledger(args, r)
    meta = r.read("input.json")
    doc = Path(meta["document"]) if meta.get("document") else None
    if _extraction_route(doc) == "model":
        return _parse_hand_upward(r, meta, doc)

    out = r.artifacts / "ledger.json"
    r.artifacts.mkdir(parents=True, exist_ok=True)
    rc, log = _vendored("extractor.run", ["-i", str(doc), "-o", str(out)])
    if rc != 0:
        raise SystemExit(f"extraction failed: {log[-300:]}")
    led = json.loads(out.read_text())
    # The ledger says how it was made, and so does the run. Both, because they answer for
    # different readers: the run state is what the CLI prints, and the ledger is what travels
    # when somebody hands the artifact to a colleague or attaches it to a finding.
    led["extraction_method"] = "parser"
    out.write_text(json.dumps(led, indent=2))
    r.write("extraction.json", {"method": "parser", "document": str(doc),
                                "format": meta.get("format"), "schema": LEDGER_SCHEMA})
    n = len(led["claims"]); rep = led["extraction_report"]
    r.mark("parse", "done", f"{n} claims", "ledger.json")
    _ok(f"{n} claims from {doc.name}")
    _info(f"{rep.get('tables_found')} tables, {rep.get('prose_blocks_found')} prose blocks, "
          f"{rep.get('unparseable')} unparseable")
    frac = rep.get("checkable_fraction") or 0
    _info(f"{frac*100:.0f}% of the figures can be checked without connecting any data — "
          f"the rest need the warehouse")
    _say(); _say("  Next:  summation-flow fanout")
    return 0


#: Printed wherever an agent is asked to write a ledger, so the contract is never a file it has
#: to go looking for. Resolved from the installed package, not from this checkout.
LEDGER_SCHEMA = SF_SCHEMA_PATH


def _parse_hand_upward(r, meta: dict, doc: Path | None) -> int:
    """No parser for this artifact — say so to the agent, and hand it the job.

    Deliberately exit 0. This is the flow working, not failing: the stage is marked `blocked`,
    which stops `fanout` from running on a ledger that does not exist yet, and the instruction
    is addressed to whoever is conducting rather than to a person. An exit code of 1 here would
    read as "this tool is broken" to an agent trained to treat non-zero as a fault.
    """
    fmt = (meta.get("format") or "unknown").upper()
    r.mark("parse", "blocked", f"{fmt} needs a model-written ledger", "")
    _warn(f"there is no deterministic reader for {fmt}. This is not a failure — read it yourself.")
    _say()
    _say("  TO THE AGENT CONDUCTING THIS FLOW:")
    _say()
    if doc:
        _info(f"1. Read the artifact:  {doc}")
    else:
        _info(f"1. Find their report under {meta.get('dir')} and read it. Nothing there looked "
              f"like one, so say what you used.")
    _info(f"2. Write one row per number, against the contract at:")
    _info(f"     {LEDGER_SCHEMA}")
    _info("   Record what the document SHOWS, not what it means: value_displayed exactly as "
          "rendered, value_parsed (or null — a null is a finding, not a gap to guess at), "
          "displayed_precision, unit (percent and points are different units), and where it sits.")
    _info('   Set  "extraction_method": "model"  at the top. It is what lets every finding '
          "downstream carry its caveat honestly.")
    _info("   Count charts you could not read in extraction_report.charts_unreadable. An absent "
          "count reads as 'no charts' to everyone downstream.")
    _info("3. Check it, and fix what it names:")
    _info(f"     python3 -m sf_ledger <your-ledger.json>")
    _info("4. Hand it back:")
    _info(f"     summation-flow parse --from-ledger <your-ledger.json> --run {r.run_id}")
    _say()
    _info("Then tell them what you found — and that you read it yourself rather than parsing "
          "it, before you show them a single finding.")
    return 0


def _parse_from_ledger(args, r) -> int:
    """Accept a ledger somebody else wrote, on exactly the terms the parser's own output meets.

    Validation is the whole of this stage. A model-written ledger that is merely plausible is
    worse than none: every downstream check would run happily and report findings about numbers
    that were never in the document.
    """
    import sf_ledger

    src = Path(args.from_ledger).expanduser()
    if not src.exists():
        raise SystemExit(f"ledger not found: {src}")
    findings = sf_ledger.validate_file(str(src))
    _say(findings.render())
    _say()
    _info(f"{findings.summary()}  (contract: {LEDGER_SCHEMA})")
    if not findings.ok:
        r.mark("parse", "failed", findings.summary(), "")
        raise SystemExit(
            f"the ledger does not satisfy the contract, so nothing downstream may run on it.\n"
            f"    Every error above names the field. Fix them and re-run:\n"
            f"      summation-flow parse --from-ledger {src} --run {r.run_id}\n"
            f"    A defect here is a defect in the reading, not in their document.")

    led = json.loads(src.read_text())
    # Written, not merely required. An agent that omitted it has not lied about provenance —
    # it has forgotten a field — and the run knows the truth either way.
    stated = led.get("extraction_method")
    led["extraction_method"] = stated or "model"
    out = r.artifacts / "ledger.json"
    r.artifacts.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(led, indent=2))
    r.write("extraction.json", {"method": led["extraction_method"], "stated_in_ledger": stated,
                                "source": str(src), "format": r.read("input.json").get("format"),
                                "schema": LEDGER_SCHEMA,
                                "findings": json.loads(findings.to_json())})

    n = len(led.get("claims") or [])
    rep = led.get("extraction_report") or {}
    r.mark("parse", "done", f"{n} claims (extraction: {led['extraction_method']})", "ledger.json")
    _ok(f"{n} claims accepted from {src.name}")
    _info(f"{rep.get('tables_found')} tables, {rep.get('prose_blocks_found')} prose blocks, "
          f"{rep.get('unparseable')} unparseable, {rep.get('charts_unreadable')} unreadable chart(s)")
    if not stated:
        _warn("the ledger did not say how it was extracted; recorded as `model`, because a "
              "hand-delivered ledger is not parser output")
    if led["extraction_method"] != "parser":
        _warn("extraction was model-driven — a wrong reading produces a wrong finding. Say that "
              "before you show them any finding, not after.")
    _say(); _say("  Next:  summation-flow fanout")
    return 0


# ============================================================ fanout (deterministic half)
SQL_TABLE = re.compile(r"\bfrom\s+([a-zA-Z_][\w.]*)", re.I)
SQL_CTE   = re.compile(r"(?:\bwith\s+|,\s*)([a-zA-Z_]\w*)\s+as\s*\(", re.I)
SQL_IN    = re.compile(r"(\w+)\s+in\s*\(([^)]*)\)", re.I)
SQL_EQ    = re.compile(r"(\w+)\s*=\s*'([^']+)'")


# The word "from" appears in English prose, so a bare regex over .py/.md yields nonsense
# candidates like "ranked" or "every". Require either a SQL file or a name that is shaped like a
# real table, and reject an explicit stop-list of words that follow "from" in ordinary sentences.
_STOP = {"the","a","an","this","that","these","those","last","each","every","all","both","either",
         "config","ranked","here","there","it","its","their","our","your","which","what","when",
         "where","who","whom","one","two","them","him","her","us","me","you","now","then","above",
         "below","within","without","scratch","memory","disk","cache"}


# A literal is only worth validating if it is a real value. Template placeholders — f-string
# braces, jinja, printf, bound parameters — are substituted at runtime and would each be
# reported as "matches 0 rows", which is noise that buries the one finding that matters.
_PLACEHOLDER = re.compile(r"^\s*(\{+[^}]*\}+|%[sd]|%\([^)]*\)s|:\w+|\?|\$\d+|<[^>]*>)\s*$")


def _is_placeholder(value: str) -> bool:
    return bool(_PLACEHOLDER.match(value)) or value.strip() == ""


def _looks_like_table(name: str, path: Path) -> bool:
    n = name.lower()
    if n in _STOP or len(n) < 4: return False
    if path.suffix == ".sql": return True
    return ("_" in n or "." in n) and not n.endswith((".py", ".json", ".yml", ".csv", ".md"))


def _scan_sql(root: Path) -> dict:
    """Extract table and literal usage from every SQL-bearing file.

    Deterministic and unit-testable, which is why it lives here rather than in the skill.
    The judgement half — which conflicting definition wins, what a rule means — is the
    skill's job.
    """
    tables, literals = {}, {}
    for p in sorted(root.rglob("*")):
        if not p.is_file() or p.suffix not in (".sql", ".py", ".yml", ".yaml", ".json"): continue
        if ".git" in p.parts: continue
        try: text = p.read_text(errors="ignore")
        except Exception: continue
        ctes = {m.group(1).lower() for m in SQL_CTE.finditer(text)}   # a CTE is not a source table
        for m in SQL_TABLE.finditer(text):
            if m.group(1).lower() in ctes: continue
            t = m.group(1).strip().rstrip(";")
            if _looks_like_table(t, p):
                tables.setdefault(t, []).append(f"{p.relative_to(root)}:{text[:m.start()].count(chr(10))+1}")
        for col, blob in SQL_IN.findall(text):
            for v in re.findall(r"'([^']+)'", blob):
                if _is_placeholder(v): continue
                literals.setdefault((col, v), []).append(str(p.relative_to(root)))
        for col, v in SQL_EQ.findall(text):
            if _is_placeholder(v): continue
            if col.lower() in ("planner_nm","owner_code","byr_nm","buyer_code","planningleague","segment"):
                literals.setdefault((col, v), []).append(str(p.relative_to(root)))
    return {"tables": tables, "literals": literals}


def fanout(args) -> int:
    r = _run(args); r.require("parse")
    src = _code_root(r)
    cache = ROOT / ".cache" / f"survey-{r.input_key}.json"
    if cache.exists() and not args.live:
        survey = json.loads(cache.read_text())
        _warn(f"replayed from cache (key {r.input_key}) — pass --live to re-scan")
    else:
        scan = _scan_sql(src)
        tables = sorted(scan["tables"], key=lambda t: -len(scan["tables"][t]))
        survey = {"input_key": r.input_key,
                  "tables": [{"name": t, "seen_at": sorted(set(scan["tables"][t]))[:6]} for t in tables],
                  "literals": [{"column": c, "value": v, "seen_at": sorted(set(loc))}
                               for (c, v), loc in scan["literals"].items()],
                  "scanned_at": time.strftime("%Y-%m-%dT%H:%M:%S")}
        cache.parent.mkdir(parents=True, exist_ok=True)
        cache.write_text(json.dumps(survey, indent=2))
    # The counts are the point of this stage, so they print on both paths. The cache is keyed to
    # the input's content, not to the run, so a first-ever run replays too — and used to print
    # nothing but the replay warning, leaving the guide's expected numbers unverifiable.
    _ok(f"{src.name}: {len(survey['tables'])} table(s), {len(survey['literals'])} literal(s)")
    r.write("survey.json", survey)
    r.mark("fanout", "done", f"{len(survey['tables'])} tables, {len(survey['literals'])} literals",
           "survey.json")
    X.source_map(r)
    for t in survey["tables"][:4]:
        _info(f"table  {t['name']}   ({len(t['seen_at'])} site(s))")
    _say(); _say("  Next:  summation-flow verify --cold")
    return 0


# ============================================================ verify
def verify(args) -> int:
    if getattr(args, "fidelity", False):
        return _verify_fidelity(args)
    if getattr(args, "render", False):
        return _verify_render(args)
    return _verify_cold(args) if args.cold else _verify_full(args)


def _fidelity_output(args, r: Run) -> tuple[Path, Path | None, bool]:
    """Resolve the produced package and selected artifact for the fidelity pass."""

    supplied = getattr(args, "output", None)
    if supplied:
        selected = Path(supplied).expanduser().resolve()
        if not selected.exists():
            raise SystemExit(f"produced artifact not found: {selected}")
        package_root = selected if selected.is_dir() else selected.parent
        if selected.is_dir():
            if selected.suffix.lower() in {".sdoc", ".sdeck", ".smd"}:
                document = selected
            else:
                candidates = _artifact_candidates(selected)
                if len(candidates) > 1:
                    raise SystemExit(
                        _ambiguous_artifacts(selected, candidates).replace(
                            "Re-run with `--artifact <path-inside-input>` to choose one, or `--no-artifact` "
                            "if these are supporting resources and the requirements will come from conversation.",
                            "Pass the exact produced file to `verify --fidelity --output`; the verifier "
                            "will still fingerprint its package separately."
                        )
                    )
                document = candidates[0] if candidates else None
        else:
            document = selected
        artifact_only = selected.is_file()
        r.write("fidelity-output.json", {
            "package_root": str(package_root),
            "document": str(document) if document else None,
            "artifact_only": artifact_only,
        })
        return package_root, document, artifact_only
    try:
        remembered = r.read("fidelity-output.json")
    except SystemExit:
        raise SystemExit(
            "--fidelity needs the produced artifact on its first run. Pass --output <file-or-folder>; "
            "the path is remembered for the independent verification rerun."
        )
    package_root = Path(remembered["package_root"])
    document = Path(remembered["document"]) if remembered.get("document") else None
    if not package_root.exists() or (document is not None and not document.exists()):
        raise SystemExit("the remembered produced artifact is no longer present; pass --output again")
    return package_root, document, bool(remembered.get("artifact_only"))


def _verify_fidelity(args) -> int:
    """Bind an independent requirement-by-requirement review to the exact output."""

    r = _run(args); r.require("run")
    contract_now, source_evidence = _require_contract_ready(r)
    package_root, document, artifact_only = _fidelity_output(args, r)
    output_evidence = F.collect_package_evidence(package_root, document, artifact_only=artifact_only)
    observation_diff = F.compare_observations(source_evidence, output_evidence)
    r.write("output-evidence.json", output_evidence)
    r.write("observable-diff.json", observation_diff)

    assessment_path = r.artifacts / "fidelity-assessment.json"
    supplied = getattr(args, "assessment", None)
    created = False
    if supplied:
        path = Path(supplied).expanduser().resolve()
        if not path.is_file():
            raise SystemExit(f"fidelity assessment not found: {path}")
        try:
            assessment = F.load_assessment(path)
        except (OSError, json.JSONDecodeError) as exc:
            raise SystemExit(f"fidelity assessment is not valid JSON: {exc}")
    elif assessment_path.exists():
        assessment = json.loads(assessment_path.read_text())
    else:
        assessment = F.assessment_template(contract_now, output_evidence, observation_diff)
        created = True
    r.write("fidelity-assessment.json", assessment)

    source_input = r.read("input.json")
    packet = F.verification_packet(
        run_id=r.run_id,
        source_package=r.input_dir,
        source_artifact=source_input.get("document"),
        produced_package=package_root,
        produced_artifact=document,
        contract=contract_now,
        source_evidence=source_evidence,
        output_evidence=output_evidence,
        observation_diff=observation_diff,
        contract_path=r.artifacts / "fidelity-contract.json",
        source_evidence_path=r.artifacts / "evidence.json",
        output_evidence_path=r.artifacts / "output-evidence.json",
        observation_diff_path=r.artifacts / "observable-diff.json",
        assessment_path=assessment_path,
    )
    r.write("independent-verification.json", packet)
    request_path = r.artifacts / "independent-verification.md"
    request_path.write_text(F.render_verification_request(packet), encoding="utf-8")

    findings = F.assessment_findings(assessment, contract_now, output_evidence, observation_diff)
    proof = X.proof_packet(r)
    if findings:
        explicit_failure = bool(assessment.get("unexplained_differences")) or any(
            item.get("status") in ("fail", "blocked") for item in assessment.get("results", [])
        )
        if explicit_failure:
            r.invalidate_from("scaffold", "verification found fidelity gaps that require a rebuild")
        r.mark("verify-fidelity", "failed" if explicit_failure else "blocked",
               f"{len(findings)} fidelity item(s) remain", "fidelity-assessment.json")
        _warn("the produced artifact has not passed the approved fidelity contract:")
        for finding in findings:
            _say(f"      {'✗' if explicit_failure else '⏸'} {finding}")
        _say()
        if created:
            _say("  TO AN INDEPENDENT VERIFIER: review the source artifact, approved contract,")
            _say("  produced artifact and observable diff. Fill one result per requirement, cite")
            _say("  concrete evidence, and list every unexplained difference. Do not reuse the")
            _say("  authoring agent's conclusions as evidence and do not mark a result deterministic")
            _say("  unless a deterministic test actually produced it.")
            _info(f"fresh-agent request:   {request_path}")
            _info(f"assessment worksheet: {assessment_path}")
            _info(f"observable diff:      {r.artifacts / 'observable-diff.json'}")
        _info(f"current proof receipt: {r.artifacts / 'proof-receipt.md'} "
              f"({proof['overall_result']})")
        _say(); _say(f"  Then:  summation-flow verify --fidelity --run {r.run_id}")
        return 1 if explicit_failure else 0

    r.mark("verify-fidelity", "done", f"{len(assessment['results'])} requirement(s) pass",
           "fidelity-assessment.json")
    _ok(f"fidelity gate passes: {len(assessment['results'])} requirement(s), "
        "0 unexplained differences")
    _info(f"output pinned to {F.evidence_fingerprint(output_evidence)[:12]}")
    _info(f"proof receipt {proof['sha256'][:12]}: {r.artifacts / 'proof-receipt.md'}")
    _say(); _say("  Next:  summation-flow schedule")
    return 0


def _require_fidelity_assessment_ready(r: Run) -> None:
    contract_now, source_evidence = _require_contract_ready(r)
    r.require("verify-fidelity")
    remembered = r.read("fidelity-output.json")
    package_root = Path(remembered["package_root"])
    document = Path(remembered["document"]) if remembered.get("document") else None
    if not package_root.exists() or (document is not None and not document.exists()):
        raise SystemExit("the produced artifact used for fidelity verification is no longer present")
    output_evidence = F.collect_package_evidence(
        package_root, document, artifact_only=bool(remembered.get("artifact_only"))
    )
    observation_diff = F.compare_observations(source_evidence, output_evidence)
    assessment = r.read("fidelity-assessment.json")
    findings = F.assessment_findings(assessment, contract_now, output_evidence, observation_diff)
    if findings:
        raise SystemExit(
            "the finished artifact no longer passes its approved fidelity contract:\n    - "
            + "\n    - ".join(findings)
            + f"\n    Re-run `summation-flow verify --fidelity --run {r.run_id}`."
        )


def _project_files(r) -> list[dict]:
    got = P.cli("files", "list", "--project", r.project_id, profile=r.profile)
    return got.get("result", got).get("files") or got.get("files") or []


def _run_bundle(r):
    """The staged bundle directory for this run, if build produced one."""
    try:
        p = Path((r.read("build.json") or {}).get("bundle") or "")
        return p if p.exists() else None
    except SystemExit:
        return None


def _verify_render(args) -> int:
    """Did the produced document actually render its tables?

    The gate U16 needed. `verify --cold` checks the ledger, `verify --full` checks that every
    cited number traces to a query — neither notices when a <table/> resolves to a data file the
    run never saved, so all six tables come out empty while every other check passes. This reads
    the FINISHED document off the platform and fails when a table points at nothing.

    OUT OF THE FLOW since 2026-08-11, callable for internal use only. Its inventory comes from
    the project file listing, and the platform stores a produced .sdoc as a sealed entity whose
    inner snapshots never appear there — so a table-bearing report fails regardless of what the
    rendered page shows (room-002: gate red on all six tables, markdown render full of data).
    The two earlier green runs were trivial passes on a document with no <table/> tags at all.
    It rejoins STAGES when it judges the rendered document (files download --format markdown)
    instead of the listing.
    """
    from sf_lint.render import check_rendered

    r = _run(args); r.require("run")
    files = _project_files(r)

    def name_of(f):
        return f.get("name") or f.get("fileName") or ""

    docs = [f for f in files if name_of(f).endswith(".sdoc")]
    if not docs:
        raise SystemExit("no produced .sdoc found in the project — has `run` completed? "
                         "The report can take several minutes to land; try again shortly.")
    doc = max(docs, key=lambda f: f.get("updatedAt", ""))
    doc_name = name_of(doc)
    inventory = [name_of(f) for f in files] + [f.get("path", "") for f in files]

    def read_file(src):
        base = src.rsplit("/", 1)[-1]
        hit = next((f for f in files if name_of(f) == base), None)
        if not hit:
            return None
        try:
            got = P.cli("files", "download", hit["id"], "--project", r.project_id,
                        profile=r.profile)
            path = got.get("result", got).get("path")
            return Path(path).read_text() if path else None
        except (P.PlatformError, OSError):
            return None

    src = _run_bundle(r)
    cand = list(src.rglob("document.xml")) if src else []
    if not cand:
        raise SystemExit("could not read the document.xml to check its tables against the "
                         "produced files.")
    findings = check_rendered(cand[0].read_text(), inventory, read_file)
    _say(findings.render()); _say()
    r.write("verify-render.json", {"document": doc_name,
                                   "findings": json.loads(findings.to_json())})
    if findings.ok:
        r.mark("verify-render", "done", "all tables resolve to data", "verify-render.json")
        _ok(f"every table in '{doc_name}' resolves to data present in the document")
        # Browser moment (U12): the report's content is proven to have landed — open it now.
        # This is the honest "after run" open: the .sdoc existed minutes ago, but only here is
        # it known to have rendered its tables.
        if doc.get("id"):
            _open_evidence("report", r, "your finished report", file_id=doc["id"])
        _say(); _say("  Next:  summation-flow schedule")
        return 0
    r.mark("verify-render", "failed", "a table renders empty", "verify-render.json")
    _warn("a table in the produced report resolves to no data and will render EMPTY. The "
          "queries ran, but a result was never saved as the snapshot the table reads. Re-author "
          "so each table config's dataframe_path names a file the run actually writes.")
    return 1


def _verify_cold(args) -> int:
    r = _run(args); r.require("parse")
    led = r.artifacts / "ledger.json"; out = r.artifacts / "findings.json"
    rc, log = _vendored("coldverify.run", ["--ledger", str(led), "--out", str(out)])
    if rc != 0 or not out.exists():
        raise SystemExit(f"cold verify failed: {log[-300:]}")
    fs = json.loads(out.read_text()).get("findings", [])
    tiers = {}
    for f in fs: tiers[f.get("tier","?")] = tiers.get(f.get("tier","?"), 0) + 1
    defects = [f for f in fs if f.get("tier") in ("D","C")]
    r.mark("verify-cold", "done", f"{len(defects)} defect claims, {len(fs)} findings", "findings.json")
    X.source_map(r)
    _ok(f"{len(defects)} defect claims, {len(fs)} findings in total")
    _info(f"severity: {tiers.get('D',0)} high [D], {tiers.get('C',0)} medium [C], "
          f"{tiers.get('B',0)} low [B]")
    _info("low is mostly coverage and hygiene gaps, but it does include real display defects — "
          "read them rather than assuming they are noise")
    _say()
    # Print every finding, wrapped. Cutting the statement at a fixed 95 characters hid the part
    # that carried the meaning, and printing only the top tiers with no "and N more" made a
    # partial list look complete.
    width = max(60, min(shutil.get_terminal_size((100, 24)).columns, 110))
    for tier, label in (("D", "high"), ("C", "medium"), ("B", "low")):
        group = [f for f in fs if f.get("tier") == tier]
        for f in group:
            head = f"  [{tier}] {f.get('check_id')}"
            _say(head)
            for line in textwrap.wrap(str(f.get("statement") or ""), width - 8):
                _say(f"        {line}")
        if group: _say()
    _info(f"full findings, with the claim ids each one rests on: {out}")
    _warn("measured recall on an unseen document is ~47% — treat this as a floor, not a clean bill")
    # One line, every time, when the ledger was not produced by the parser. Cold verify checks
    # the ledger against itself; if the reading was wrong the finding is wrong, and the person
    # has no way to know that from the finding. It travels with the findings rather than sitting
    # in a report somewhere, because the moment it matters is the moment they are read out.
    if _extraction_method(r) != "parser":
        _warn("extraction was model-driven, not parsed: a figure read wrongly produces a finding "
              "that is wrong in the same way. Every finding names its page and cell — say this "
              "before you present them, and let them check you.")
    _say(); _say("  Next:  summation-flow request-access")
    return 0


def _extraction_method(r) -> str:
    """How this run's ledger was produced: `parser`, `model`, or `hybrid`.

    Read from the run's own record first, and from the ledger only as a fallback, so a ledger
    edited after the fact cannot quietly change the provenance the CLI reports. A run from
    before intake accepted anything but HTML has neither, and was parsed.
    """
    try:
        return (r.read("extraction.json") or {}).get("method") or "parser"
    except SystemExit:
        pass
    led = r.artifacts / "ledger.json"
    if led.exists():
        try:
            return json.loads(led.read_text()).get("extraction_method") or "parser"
        except (OSError, json.JSONDecodeError):
            pass
    return "parser"


def _verify_full(args) -> int:
    r = _run(args, writes="verify-full"); r.require("deploy")
    res = {"report_verify": None, "suite": None}
    try:
        out = P.cli("reports", "verify", r.read("deploy.json")["playbook_id"],
                    "--project", r.project_id, "--no-wait", profile=r.profile, timeout=120)
        res["report_verify"] = "started"; _ok("report verification started")
    except P.PlatformError as e:
        res["report_verify"] = f"failed: {e}"; _warn(f"report verify: {str(e)[:140]}")
    # The custom-test suite is operator-only (LEDGER R-043): verif-tests authenticates with
    # impersonation headers against agent-service, so this leg cannot work for a customer.
    vt = shutil.which("verif-tests") or str(Path.home() / ".local/bin/verif-tests")
    if Path(vt).exists():
        res["suite"] = "verif-tests present; upload is non-idempotent so list-and-diff is required"
        _warn("deploying a reusable test suite needs an internal operator, so a customer cannot do this yet")
    else:
        res["suite"] = "verif-tests not installed"
        _warn("verif-tests not installed — suite leg skipped")
    r.write("verify-full.json", res)
    r.mark("verify-full", "degraded", "report verify started; suite internal-only", "verify-full.json")
    _say(); _say("  Next:  summation-flow schedule")
    return 0


# ============================================================ request-access  (stage 5 renderer)
def request_access(args) -> int:
    r = _run(args); r.require("fanout")
    survey = r.read("survey.json")
    tables = survey["tables"]
    if not tables: raise SystemExit("survey found no tables — re-run fanout --live")

    # Literal validation CANNOT happen here for a new customer: their warehouse is not reachable
    # until `connect` runs, so there is nothing to validate against. This is a real ordering
    # constraint, not an implementation gap — the highest-value findings require the credential
    # they are meant to justify. We therefore state what is needed now, and validate immediately
    # after connecting (see `_validate_literals`, called by `connect`).
    reachable = _table_reachable(tables[0]["name"], r.profile) if tables else False
    broken, checked = ([], 0)
    if reachable:
        broken, checked = _validate_literals(survey, tables, r.profile)
    choice = getattr(args, "choose", None)
    req = {"tables": tables, "literals_checked": checked, "broken_literals": broken,
           "literals_pending": [] if reachable else survey["literals"],
           "warehouse_reachable_yet": reachable, "choice": choice,
           "options": ["connect read-only", "paste an export", "skip and mark unverifiable"]}
    r.write("access-request.json", req)
    X.record_decision(
        r,
        kind="data-access-path",
        question="How should this workflow obtain the required data?",
        choices=["connect", "export", "skip"],
        recommendation="connect",
        binding={
            "profile": r.profile,
            "source_sha256": X.canonical_sha256(r.read("evidence.json")),
            "tables": [table.get("name") for table in tables],
        },
        choice=choice,
        actor=getattr(args, "by", None),
    )
    low_risk_grant = X.grant_low_risk_data_choice(r) if choice else None
    access_status = "done" if choice else "blocked"
    access_detail = (f"{choice} chosen" if choice else
                     f"waiting for a data-access choice for {len(tables)} table(s)")
    r.mark("request-access", access_status, access_detail,
           "access-request.json")

    _say("To rebuild this report I need:\n")
    for t in tables[:3]:
        _say(f"  {t['name']}")
        _info(f"how I know: {', '.join(t['seen_at'][:3])}")
        _say()
        _say("    → connect it read-only     I can pre-fill everything but the password")
        _say("    → paste an export instead")
        _say("    → skip it                  I build anyway and mark those figures unverified")
        _say()
    if broken:
        _say(f"Before you connect — {len(broken)} value(s) in your own config match nothing:\n")
        for b in broken:
            _say(f"  ✗ {b['column']} = '{b['value']}' matches 0 rows")
            _info(f"{', '.join(b['seen_at'][:3])}")
            if b["closest"]: _info(f"closest actual value: {b['closest']}")
            _say()
    elif reachable:
        _info(f"all {checked} filter literal(s) resolve against the warehouse")
    else:
        _info(f"{len(survey['literals'])} filter value(s) in their code cannot be checked yet — "
              f"this warehouse is not connected. They are validated the moment it is.")
    if choice:
        _ok(f"recorded choice: {choice}")
        if low_risk_grant:
            _info("that choice also approves the matching read-only, new-project data scope; "
                  "no second approval or tenant confirmation is needed")
        if choice == "skip":
            _warn("figures that need this warehouse will be marked unverified and stay that way")
    else:
        _info("no choice recorded — pass --choose connect|export|skip to record one. "
              "It is written to access-request.json as the decision this run made.")
    _say("  Next:  summation-flow detect" if choice else
         "  Paused: ask which data-access path they want, then re-run with --choose")
    return 0


# ============================================================ scoped permissions
def permit(args) -> int:
    r = _run(args)
    if args.group == "data":
        r.require("request-access")
        access_choice = r.read("access-request.json").get("choice")
        if not access_choice:
            raise SystemExit("choose the data-access path before granting Data permission")
        if access_choice == "export" and not (r.artifacts / "data-export-evidence.json").exists():
            raise SystemExit(
                "the export must be fingerprinted before Data permission can bind to it. "
                f"Run `summation-flow connect --export-file <path> --run {r.run_id}` first; "
                "that local read will pause and show the exact permission scope."
            )
    else:
        r.require("build")
        X.require_preview(r)
    grant = X.grant_permission(r, args.group, getattr(args, "by", None))
    scope = grant["scope"]
    _ok(f"{args.group} permission recorded from {grant['actor']}")
    _info(f"scope {X.canonical_sha256(scope)[:12]} — {', '.join(scope['actions'])}")
    _info("it expires automatically if a bound source, candidate, profile, or target changes")
    _say(); _say("  Next:  summation-flow detect" if args.group == "data"
                 else "  Next:  summation-flow deploy")
    return 0


def _table_reachable(name: str, profile: str) -> bool:
    for cand in (name, name.split(".")[-1], "dataset"):
        try:
            P.query(f"SELECT COUNT(*) AS n FROM {cand}", profile=profile, limit=1); return True
        except P.PlatformError:
            continue
    return False


def _resolve_table(name: str, profile: str, connection_id: str | None = None) -> str | None:
    """Find the name the query engine actually exposes for an attached dataset.

    It is NOT the source table, and it is not stable: the platform derives it from the
    connection name plus the source path, e.g. `sf_005_31980_postgres_analytics_dataset`.
    So it must be read back from the API rather than guessed — an earlier version guessed
    `dataset`, which happened to be right once and silently wrong afterwards.
    """
    cands = []
    if connection_id:
        try:
            ds = P.api("GET", f"/v1/connections/data/{connection_id}/datasets",
                       profile=profile).get("data", {}).get("datasets", [])
            cands += [d["name"] for d in ds if d.get("status") == "DEPLOYED"]
        except P.PlatformError:
            pass
    cands += ["dataset", name.split(".")[-1], name]
    for cand in cands:
        try:
            P.query(f"SELECT COUNT(*) AS n FROM {cand}", profile=profile, limit=1); return cand
        except P.PlatformError:
            continue
    return None


def _validate_literals(survey: dict, tables: list, profile: str, connection_id=None):
    """Check every filter literal against the real domain. This is the check that found a stale
    buyer code costing 66% of demand (LEDGER R-019). It needs a connected warehouse."""
    tbl = _resolve_table(tables[0]["name"], profile, connection_id) if tables else None
    if not tbl: return [], 0
    broken, checked = [], 0
    for lit in survey["literals"]:
        col, val = lit["column"], lit["value"]
        try:
            rows = P.query(f"SELECT COUNT(*) AS n FROM {tbl} WHERE {col} = '{val}'",
                           profile=profile, limit=5)
            checked += 1
            if int(float(P.snake(rows[0]).get("n", 0))) == 0:
                near = P.query(f"SELECT DISTINCT {col} AS v FROM {tbl} "
                               f"WHERE {col} LIKE '{val[:5]}%' LIMIT 3", profile=profile, limit=5)
                broken.append({"column": col, "value": val, "hits": 0,
                               "seen_at": lit["seen_at"],
                               "closest": [P.snake(x).get("v") for x in near]})
        except P.PlatformError:
            pass
    return broken, checked


# ============================================================ detect
DBT_HINTS = ("dbt_project.yml", "profiles.yml", ".profiles.yml")


def detect(args) -> int:
    r = _run(args); r.require("init")
    src = _code_root(r)
    found, negatives = {}, []
    for name, globs in {"dbt": DBT_HINTS, "cube": ("cube.js","cube.py"),
                        "superset": ("superset_config.py",), "lookml": ("*.lkml",),
                        "git": (".git",)}.items():
        hits = [str(p.relative_to(src)) for g in globs for p in src.rglob(g)]
        if hits: found[name] = hits
        else: negatives.append(name)

    tmpl, prefilled = None, {}
    prof = next((p for p in src.rglob("profiles.yml")), None) or next((p for p in src.rglob(".profiles.yml")), None)
    if prof:
        text = prof.read_text(errors="ignore")
        for key, pat in {"pg_host": r"host:\s*(\S+)", "pg_port": r"port:\s*(\S+)",
                         "pg_db": r"dbname:\s*(\S+)", "pg_user": r"user:\s*(\S+)",
                         "pg_sslmode": r"sslmode:\s*(\S+)"}.items():
            m = re.search(pat, text)
            if m and "env_var" not in m.group(1): prefilled[key] = m.group(1).strip('"\'')
        tmpl = {"config": prefilled, "secrets": {"pg_pass": "<PASTE YOUR PASSWORD HERE>"}}
        r.write("conn-template.json", tmpl)

    r.write("detected.json", {"found": found, "not_present": negatives,
                              "prefilled_from": str(prof.relative_to(src)) if prof else None})
    r.mark("detect", "done", f"{len(found)} integration(s) found", "detected.json")
    for k, v in found.items(): _ok(f"{k}: {v[0]}")
    for n in negatives: _info(f"{n}: not present")
    if not tmpl:
        _info("no readable dbt profile found, so there is nothing to pre-fill — "
              "you will need to write the connection file by hand")
    if tmpl:
        _say(); _ok(f"pre-filled {len(prefilled)} of 6 connection fields from {prof.name}")
        _info(f"wrote {(r.artifacts / 'conn-template.json')} — everything except the password")
        _warn("the connector expects pg_host / pg_port / pg_db / pg_user / pg_pass — the public docs "
              "show form labels instead, so those names are the ones that work")
    choice = None
    try:
        choice = r.read("access-request.json").get("choice")
    except SystemExit:
        pass
    if choice == "skip":
        next_step = "summation-flow connect (records the deliberate no-data boundary)"
    elif choice == "export":
        next_step = "summation-flow connect --export-file <their export>"
    else:
        next_step = "summation-flow connect  (or --config-file when saved access is unavailable)"
    _say(); _say(f"  Next:  {next_step}")
    return 0


# ============================================================ connect
def connect(args) -> int:
    r = _run(args); r.require("request-access")
    survey = r.read("survey.json")
    tables = survey["tables"]
    config_file = getattr(args, "config_file", None)
    export_file = getattr(args, "export_file", None)
    choice = r.read("access-request.json").get("choice")

    if choice == "skip":
        if config_file or export_file:
            raise SystemExit(
                "the customer chose skip, so connect will not read a credential or export. "
                "Re-record the data-access decision before supplying one."
            )
        X.require_permission(r, "data")
        unresolved = [table.get("name") for table in tables if table.get("name")]
        r.write("connection.json", {
            "connection_id": None, "reused": False, "access_source": "skipped-by-customer",
            "warehouse_verified": False, "unverified_tables": unresolved,
        })
        r.mark("connect", "done", "live data skipped; dependent results remain unverified",
               "connection.json")
        _ok("continuing without live warehouse access, as the customer chose")
        _warn(f"{len(unresolved)} required table(s) remain unverified and the fidelity contract "
              "must preserve that limitation")
        _say(); _say("  Next:  summation-flow context --upload")
        return 0

    if choice == "export":
        if config_file:
            raise SystemExit(
                "the customer chose an export, not a warehouse connection. Pass --export-file, "
                "or re-record the data-access decision."
            )
        if not export_file:
            raise SystemExit("the export path needs --export-file <customer file or directory>")
        supplied = Path(export_file).expanduser().resolve()
        if not supplied.exists():
            raise SystemExit(f"customer export not found: {supplied}")
        previous_binding = None
        try:
            previous_binding = r.read("data-export-evidence.json").get("evidence_sha256")
        except SystemExit:
            pass
        root = supplied if supplied.is_dir() else supplied.parent
        export_evidence = F.collect_package_evidence(
            root, supplied, artifact_only=supplied.is_file()
        )
        export_binding = F.evidence_fingerprint(export_evidence)
        r.write("data-export-evidence.json", {
            "path": str(supplied), "evidence_sha256": export_binding,
            "evidence": export_evidence,
        })
        if previous_binding and previous_binding != export_binding:
            r.invalidate_from(
                "connect",
                "the customer-provided data export changed; data resolution, the fidelity "
                "contract, the build, and verification must be repeated",
            )
        # The first call intentionally pauses here: permission must cover this exact export,
        # not an abstract promise that some file will be supplied later.
        X.require_permission(r, "data")
        r.write("connection.json", {
            "connection_id": None, "reused": False, "access_source": "customer-export",
            "export_path": str(supplied), "export_sha256": export_binding,
            "warehouse_verified": False,
        })
        r.mark("connect", "done", f"customer export {export_binding[:12]} pinned",
               "connection.json")
        _ok(f"using the customer-provided export pinned at {export_binding[:12]}")
        _info("no warehouse credential, connection, or tenant write was used for this step")
        _say(); _say("  Next:  summation-flow context --upload")
        return 0

    if choice != "connect":
        raise SystemExit(
            "the data-access decision is missing or unknown. Re-run request-access with "
            "--choose connect|export|skip."
        )
    if export_file:
        raise SystemExit(
            "the customer chose a live connection, not an export. Pass --config-file or re-record "
            "the data-access decision."
        )
    _authorize_permission_write(args, r, writes="connect", permission="data")

    # The customer may already have governed access through the Summation profile they signed in
    # with. `request-access` deliberately tests that before asking for a warehouse credential; the
    # connect stage must honour the result. Requiring a raw password after successfully querying
    # their table is both unnecessary and a regression from the easiest cold-room path.
    if not config_file:
        tbl = _resolve_table(tables[0]["name"], r.profile) if tables else None
        if not tbl:
            raise SystemExit(
                "the required table is not queryable through this Summation profile yet. "
                "Connect it in Summation or pass --config-file for a new read-only connection"
            )
        rows = P.query(f"SELECT COUNT(*) AS n FROM {tbl}", profile=r.profile, limit=5)
        n = int(float(P.snake(rows[0])["n"])) if rows else 0
        broken, checked = _validate_literals(survey, tables, r.profile)
        _report_literals(broken, checked)
        r.write("literals.json", {"checked": checked, "broken": broken, "queryable_as": tbl})
        r.write("connection.json", {
            "connection_id": None,
            "reused": True,
            "access_source": "saved-summation-profile",
            "rows": n,
            "queryable_as": tbl,
            "seconds": 0.0,
        })
        r.mark("connect", "done", f"existing access to {tbl}, {n} rows", "connection.json")
        _ok(f"using existing Summation access to `{tbl}`")
        _info("the customer's saved profile worked — no warehouse password or new connection was needed")
        _ok(f"{n} rows queryable through the platform")
        _say(); _say("  Next:  summation-flow context --upload")
        return 0

    cf = Path(config_file).expanduser()
    if not cf.exists(): raise SystemExit(f"config file not found: {cf}")
    body = json.loads(cf.read_text())
    if "secrets" not in body or not body.get("config"):
        raise SystemExit("config file needs both a `config` and a `secrets` block")
    if any(k.startswith("pg_") for k in body["config"]) is False:
        _warn("config keys do not look like pg_* — the connector expects pg_host/pg_port/pg_db/pg_user")

    t0 = time.time()
    # Reuse before creating. Two reasons, one principled and one forced:
    # a customer connects their warehouse once rather than once per report; and because
    # connections cannot be deleted once a dataset is attached (LEDGER R-045), creating one per
    # run leaks them. After ~6 accumulated on the same source table, new attachments began
    # returning status=FAILED, so a fresh connection per run actually stops working.
    # `connections list` returns empty even when connections exist, so discovery uses our own
    # run records rather than the API.
    reused = _reusable_connection(r)
    if reused:
        cid, tbl = reused
        _ok(f"reusing connection {cid} (already attached and queryable as `{tbl}`)")
        _info("a warehouse is connected once, not once per report")
        rows = P.query(f"SELECT COUNT(*) AS n FROM {tbl}", profile=r.profile, limit=5)
        n = int(float(P.snake(rows[0])["n"])) if rows else 0
        broken, checked = _validate_literals(r.read("survey.json"),
                                             r.read("survey.json")["tables"], r.profile, cid)
        _report_literals(broken, checked)
        r.write("literals.json", {"checked": checked, "broken": broken, "queryable_as": tbl})
        r.write("connection.json", {"connection_id": cid, "reused": True, "rows": n,
                                    "queryable_as": tbl, "seconds": round(time.time()-t0, 1)})
        r.mark("connect", "done", f"{cid} reused, {n} rows", "connection.json")
        _ok(f"{n} rows queryable through the platform")
        _say(); _say("  Next:  summation-flow context --upload")
        return 0

    connection_name = f"{r.run_id}-onboarding"
    create_op = Operation(r, "connect", "connection.create", connection_name,
                          "warehouse connection creation")
    recovered = None
    if create_op.last and create_op.last.get("state") in UNSAFE_STATES:
        connectors = P.api("GET", "/v1/connections/data", profile=r.profile).get("data", {}) \
            .get("connectors", [])
        recovered = next((item for item in connectors if item.get("name") == connection_name), None)
        if not recovered:
            create_op.refuse_unknown_retry()
    if recovered:
        cid = recovered.get("id")
        r.record_object("connection", cid, "reconciled after interrupted creation")
        create_op.confirmed(object_ids=[cid], reconciled=True)
    else:
        create_op.planned(binding=connection_name)
        create_op.submitted()
        try:
            created = P.api("POST", "/v1/connections/data", profile=r.profile,
                            json={"name": connection_name, "type": "POSTGRES",
                                  "description": f"summation-flow {r.run_id}",
                                  "config": body["config"], "secrets": body["secrets"]})
        except Exception as exc:
            create_op.failed(exc)
            raise
        conn = created.get("data", created)
        cid = (conn.get("connection") or conn).get("id") or conn.get("id")
        r.record_object("connection", cid, "created by connect")
        create_op.confirmed(object_ids=[cid])
    _ok(f"connection {cid}")

    # Test BEFORE attaching: the recovery path for a bad credential is delete-and-recreate,
    # which destroys dataset attachments (LEDGER R-042).
    test = P.api("POST", f"/v1/connections/data/{cid}/tests", profile=r.profile).get("data", {})
    if not test.get("success"):
        raise SystemExit(f"connection test failed before attaching anything: {json.dumps(test)[:200]}\n"
                         f"    fix the config and re-run; nothing was attached, so nothing is orphaned")
    _ok("credential verified")

    schemas = P.api("POST", f"/v1/connections/data/{cid}/resources", profile=r.profile,
                    json={"max_results": 50}).get("data", {}).get("resources", [])
    src = None
    for s in schemas:
        tabs = P.api("POST", f"/v1/connections/data/{cid}/resources", profile=r.profile,
                     json={"path_prefix": s["name"], "max_results": 50}).get("data", {}).get("resources", [])
        for t in tabs:
            if t.get("resourceType") == "TABLE":
                src = t["fromSource"]; _ok(f"found {t['name']}  ({src})"); break
        if src: break
    if not src: raise SystemExit("browsed the connection but found no tables")

    attach_op = Operation(r, "connect", "connection.attach", f"{cid}:{src}",
                          "dataset attachment")
    attached = False
    if attach_op.last and attach_op.last.get("state") in UNSAFE_STATES:
        datasets = P.api("GET", f"/v1/connections/data/{cid}/datasets",
                         profile=r.profile).get("data", {}).get("datasets", [])
        attached = any(item.get("fromSource") == src or item.get("from_source") == src
                       for item in datasets)
        if not attached:
            attach_op.refuse_unknown_retry()
        attach_op.confirmed(object_ids=[cid], reconciled=True)
    if not attached:
        attach_op.planned(connection_id=cid, source=src)
        attach_op.submitted()
        try:
            P.api("POST", f"/v1/connections/data/{cid}/datasets", profile=r.profile,
                  json={"datasets": [{"from_source": src}]})
        except Exception as exc:
            attach_op.failed(exc)
            raise
        attach_op.confirmed(object_ids=[cid])
    ok, waited, tbl = P.wait_queryable(cid, profile=r.profile)
    if not ok:
        ds = P.api("GET", f"/v1/connections/data/{cid}/datasets",
                   profile=r.profile).get("data", {}).get("datasets", [])
        st = [d.get("status") for d in ds]
        if any(x in ("FAILED", "ERROR") for x in st):
            raise SystemExit(
                f"the dataset attachment FAILED (status {st}). This is not a timeout. The usual "
                f"cause is accumulated attachments on the same source table: connections cannot be "
                f"deleted once attached, and past ~6 on one table new attachments "
                f"start failing. Re-run `connect` — it will reuse a working connection if one exists.")
        raise SystemExit(f"dataset never became queryable within {waited:.0f}s (status {st})")
    _ok(f"queryable in {waited:.0f}s  (as `{tbl}`)")
    _info("note: `status: DEPLOYED` arrives ~17s before the query engine accepts the table, "
          "so readiness is tested by querying rather than by reading the status")

    rows = P.query(f"SELECT COUNT(*) AS n FROM {tbl}", profile=r.profile, limit=5)
    n = int(float(P.snake(rows[0])["n"])) if rows else 0
    broken, checked = _validate_literals(r.read("survey.json"),
                                        r.read("survey.json")["tables"], r.profile, cid)
    _report_literals(broken, checked)
    r.write("literals.json", {"checked": checked, "broken": broken,
                              "queryable_as": _resolve_table(src.split(".")[-1], r.profile, cid)})
    r.write("connection.json", {"connection_id": cid, "from_source": src, "rows": n,
                                "seconds": round(time.time() - t0, 1)})
    r.mark("connect", "done", f"{cid}, {n} rows queryable", "connection.json")
    _ok(f"{n} rows queryable through the platform")
    _say(); _say("  Next:  summation-flow context --upload")
    return 0


def _reusable_connection(r) -> tuple[str, str] | None:
    """Find a connection from an earlier run that still works and has a queryable dataset."""
    from ..state import RUNS
    seen = []
    for f in sorted(RUNS.glob("sf-*/artifacts/connection.json"), reverse=True):
        try: cid = json.loads(f.read_text()).get("connection_id")
        except Exception: continue
        if not cid or cid in seen: continue
        seen.append(cid)
        try:
            ds = P.api("GET", f"/v1/connections/data/{cid}/datasets",
                       profile=r.profile).get("data", {}).get("datasets", [])
        except P.PlatformError:
            continue
        for d in ds:
            if d.get("status") != "DEPLOYED": continue
            try:
                P.query(f"SELECT COUNT(*) AS n FROM {d['name']}", profile=r.profile, limit=1)
                r.record_object("connection-reused", cid, "pre-existing, not created by this run")
                return cid, d["name"]
            except P.PlatformError:
                continue
    return None


def _report_literals(broken, checked) -> None:
    if broken:
        _say()
        _warn(f"{len(broken)} filter value(s) in their own code match nothing in this warehouse:")
        for b in broken:
            _say(f"      ✗ {b['column']} = '{b['value']}'  →  0 rows")
            _info(f"  {', '.join(b['seen_at'][:3])}")
            if b["closest"]: _info(f"  closest actual value: {b['closest']}")
    elif checked:
        _ok(f"all {checked} filter literal(s) resolve")


# ============================================================ output-target
def output_target(args) -> int:
    """What should this playbook produce?

    All three come from the same queries and the same snapshots, so the numbers are identical by
    construction rather than by comparison. What differs is how much survives: a page carries
    everything, a document nearly everything, and a deck carries only what the person said to put
    on each slide — which is why a deck needs a plan and the other two do not.
    """
    r = _run(args); r.require("connect")
    formats = list(dict.fromkeys(args.format or ["sdoc"]))     # de-dup, keep order

    slides = None
    if "sdeck" in formats:
        if args.slides_file:
            path = Path(args.slides_file).expanduser()
            if not path.exists():
                raise SystemExit(f"slide plan not found: {path}")
            try:
                slides = json.loads(path.read_text())
            except json.JSONDecodeError as e:
                raise SystemExit(f"slide plan is not valid JSON: {e}")
            problems = _check_slides(slides)
            if problems:
                raise SystemExit("slide plan rejected:\n  " + "\n  ".join(problems))
        else:
            # Refuse rather than invent an outline. A deck is a narrative the person owns; guessing
            # at it produces something they have to argue with every week.
            raise SystemExit(
                "a deck needs a slide plan — pass --slides-file.\n"
                "  Ask them what goes on each slide, then write it as:\n"
                '  {"slides": [{"title": "Where the week landed", '
                '"content": ["revenue", "units", "yoy"]}]}\n'
                "  content items: a metric name, table:<name>, or text:<literal>"
            )

    target_payload = {"formats": formats, "slides": slides}
    target_binding = hashlib.sha256(json.dumps(target_payload, sort_keys=True).encode()).hexdigest()
    if r.bindings.get("output-target") and r.bindings["output-target"] != target_binding:
        r.invalidate_from("contract", "the requested output format or slide plan changed")
    r.bindings["output-target"] = target_binding
    r.save()
    r.write("output-target.json", target_payload)
    r.mark("output-target", "done", ", ".join(formats), "output-target.json")
    _ok(f"output: {', '.join(formats)}")
    if slides:
        _info(f"{len(slides['slides'])} slide(s), exactly as they described them")
        for i, sl in enumerate(slides["slides"], 1):
            _info(f"  {i}. {sl['title']}")
    _say(); _say("  Next:  summation-flow contract")
    return 0


# ============================================================ fidelity contract
def _contract_readiness(r: Run) -> tuple[dict, dict, list[str]]:
    """Read the approved contract against freshly collected source evidence."""

    evidence_now = _collect_run_evidence(r)
    contract_now = r.read("fidelity-contract.json")
    findings = F.readiness_findings(contract_now, evidence_now)
    try:
        context_state = r.read("context.json")
    except SystemExit:
        context_state = {}
    if not context_state.get("uploaded"):
        findings.append("the recovered project knowledge has not been uploaded")
    for label, manifest in (evidence_now.get("supplemental_packages") or {}).items():
        if manifest.get("truncated"):
            findings.append(f"the {label} package inventory was truncated")
    return contract_now, evidence_now, findings


def _require_contract_ready(r: Run) -> tuple[dict, dict]:
    r.require("contract")
    contract_now, evidence_now, findings = _contract_readiness(r)
    if findings:
        raise SystemExit(
            "the approved fidelity contract is no longer release-ready:\n    - "
            + "\n    - ".join(findings)
            + f"\n    Re-run `summation-flow contract --run {r.run_id}` after resolving them."
        )
    return contract_now, evidence_now


def contract(args) -> int:
    """Create the agent handoff, then deterministically validate customer approval."""

    r = _run(args); r.require("context"); r.require("output-target")
    current_evidence = _write_run_evidence(r)
    # Re-collecting evidence can reopen the graph. Do not use approvals gathered against the old
    # source to leap over the newly reopened understanding/data phases.
    r.require("context"); r.require("output-target")
    supplied = getattr(args, "contract_file", None)
    existing = r.artifacts / "fidelity-contract.json"

    if supplied:
        path = Path(supplied).expanduser().resolve()
        if not path.is_file():
            raise SystemExit(f"fidelity contract not found: {path}")
        try:
            candidate = F.load_contract(path)
        except (OSError, json.JSONDecodeError) as exc:
            raise SystemExit(f"fidelity contract is not valid JSON: {exc}")
    elif existing.exists():
        candidate = json.loads(existing.read_text())
    else:
        target = r.read("output-target.json")
        candidate = F.contract_template(
            current_evidence,
            name=_playbook_title(r),
            target_format="+".join(target.get("formats") or ["sdoc"]),
        )

    structural = F.validate_contract(candidate)
    r.write("fidelity-contract.json", candidate)
    if structural:
        r.mark("contract", "failed", f"{len(structural)} structural error(s)", "fidelity-contract.json")
        _warn("the fidelity contract is structurally invalid:")
        for finding in structural:
            _say(f"      ✗ {finding}")
        return 1

    findings = F.readiness_findings(candidate, current_evidence)
    context_state = r.read("context.json")
    if not context_state.get("uploaded"):
        findings.append("the recovered project knowledge has not been uploaded")
    for label, manifest in (current_evidence.get("supplemental_packages") or {}).items():
        if manifest.get("truncated"):
            findings.append(f"the {label} package inventory was truncated")
    if findings:
        r.mark("contract", "blocked", f"{len(findings)} approval item(s) remain", "fidelity-contract.json")
        _warn("the fidelity contract is not approved yet:")
        for finding in findings:
            _say(f"      ⏸ {finding}")
        _say()
        _say("  TO THE AGENT: complete the contract from the cold findings, connected data,")
        _say("  resolved definitions and customer decisions. Summarise every requirement and")
        _say("  source correction to the customer; only after they explicitly approve it, record")
        _say("  their name and approval time in the file. Do not approve it on their behalf.")
        _info(f"contract worksheet: {existing}")
        if not context_state.get("uploaded"):
            _info(f"ship the reviewed knowledge first: summation-flow context --upload --run {r.run_id}")
        _say(); _say(f"  Then:  summation-flow contract --run {r.run_id}")
        return 0

    contract_binding = F.contract_fingerprint(candidate)
    if r.bindings.get("contract") and r.bindings["contract"] != contract_binding:
        r.invalidate_from("scaffold", "the approved fidelity contract changed")
    r.bindings["contract"] = contract_binding
    r.save()
    r.mark("contract", "done", f"{len(candidate['requirements'])} approved requirement(s)",
           "fidelity-contract.json")
    _ok(f"customer-approved contract: {len(candidate['requirements'])} requirement(s), "
        f"{len(candidate['source_findings'])} source decision(s)")
    _info(f"bound to source evidence {candidate['source_evidence_sha256'][:12]}")
    _say(); _say("  Next:  summation-flow scaffold")
    return 0


#: Content tokens a slide may carry. Deliberately few — a slide plan is a person telling us what
#: they present, not a template language.
def _check_slides(spec) -> list:
    problems = []
    if not isinstance(spec, dict) or not isinstance(spec.get("slides"), list):
        return ['expected {"slides": [...]}']
    if not spec["slides"]:
        return ["the plan has no slides in it"]
    for i, sl in enumerate(spec["slides"], 1):
        if not isinstance(sl, dict):
            problems.append(f"slide {i} is not an object"); continue
        if not str(sl.get("title", "")).strip():
            problems.append(f"slide {i} has no title")
        content = sl.get("content")
        if not isinstance(content, list) or not content:
            problems.append(f"slide {i} has no content")
            continue
        for item in content:
            if not isinstance(item, str) or not item.strip():
                problems.append(f"slide {i} has an empty content item")
    return problems


# ============================================================ scaffold
#: What the platform's own `create_playbook.py` refuses in a title, because the script wraps the
#: title in `.spb/` itself. Kept identical to the platform's list: a bundle whose name the
#: platform would have rejected is one nobody can create there by hand afterwards.
_TITLE_SUFFIXES = (".spb", ".srb", ".sdoc", ".smd", ".sdeck", ".html")

#: Per chosen format: the file the agent authors, what it is, and the `template_path` the
#: manifest declares. `.sdoc` rather than `.smd`, because the platform accepts only `.sdoc` now
#: and a skeleton naming the retired extension teaches the agent to write a bundle it refuses.
#: The manifest points at the *package directory*, which is what `create_playbook.py`'s own
#: `outputs:` example declares; the file inside it is where the authoring happens.
_OUTPUT_SKELETON = {
    "sdoc":  ("templates/{stem}.sdoc/document.xml", "the document, section by section",
              "templates/{stem}.sdoc/"),
    "sdeck": ("templates/{stem}.sdeck/slides.json", "the deck, in the order they named",
              "templates/{stem}.sdeck/"),
    "html":  ("templates/{stem}.html.tmpl", "their own page template, carried across verbatim",
              "templates/{stem}.html.tmpl"),
}

#: Side-files a bundle carries beside its queries: the buyer list, the area map, the
#: distribution list. Data, not code — a `.py` beside the report is the thing that builds it,
#: not something the playbook needs at run time.
_SIDE_FILE_SUFFIXES = (".json", ".csv", ".yaml", ".yml")


def _playbook_title(r) -> str:
    """A name for their playbook, from their own artifact.

    The ledger's `source.title` first, because that is the title the document gives itself.
    Falling back to the file name and then to the folder is deliberate ordering: each step is a
    worse name than the last, and a playbook called `input` is one they will rename.
    """
    for candidate in (_ledger_title(r), _document_stem(r), Path(r.input_dir).name):
        title = _clean_title(candidate or "")
        if title:
            return title
    return "Onboarded Report"


def _ledger_title(r) -> str:
    led = r.artifacts / "ledger.json"
    if not led.exists():
        return ""
    try:
        return ((json.loads(led.read_text()).get("source") or {}).get("title") or "").strip()
    except (OSError, json.JSONDecodeError):
        return ""


def _document_stem(r) -> str:
    try:
        doc = (r.read("input.json") or {}).get("document")
    except SystemExit:
        return ""
    if not doc:
        return ""
    return re.sub(r"[-_]+", " ", Path(doc).stem).strip()


def _clean_title(raw: str) -> str:
    """A title the platform would also accept, and a directory name that cannot escape.

    A date in the title is dropped. `Weekly Recap — week ending 2026-04-04` names one week; the
    playbook produces every week, and a bundle called after last April is one nobody trusts in
    June.
    """
    t = raw.strip()
    t = re.sub(r"\s*[—–-]?\s*(week ending|for the week of|as of|week of)\s*[\d/-]+\s*$", "", t,
               flags=re.I)
    # Both spellings, because the date arrives either from a title (`2026-04-04`) or from a file
    # name already de-slugged into words (`2026 04 04 owner 07 weekly recap`).
    t = re.sub(r"\s*\b\d{4}[-/ ]\d{2}[-/ ]\d{2}\b\s*", " ", t)
    t = re.sub(r"[/\\:]", " ", t)
    for suf in _TITLE_SUFFIXES:
        if t.lower().endswith(suf):
            t = t[: -len(suf)]
    t = re.sub(r"\s+", " ", t).strip(" .-—–_")
    return t[:80]


def _side_files(r, src: Path) -> list[Path]:
    """The customer's own config, as the survey saw it.

    Two sources, both evidenced rather than guessed: a file the fan-out survey found a filter
    literal in, and anything data-shaped under a folder called `config`. Guessing more widely
    ends with somebody's `.env` inside a bundle that gets uploaded.
    """
    out: dict[str, Path] = {}
    try:
        survey = r.read("survey.json")
    except SystemExit:
        survey = {"literals": []}
    for lit in survey.get("literals") or []:
        for rel in lit.get("seen_at") or []:
            rel = rel.split(":")[0]
            p = (src / rel)
            if p.is_file() and p.suffix.lower() in _SIDE_FILE_SUFFIXES:
                out.setdefault(p.name, p)
    for p in sorted(src.rglob("*")):
        if not p.is_file() or _NOT_AN_ARTIFACT & set(p.parts):
            continue
        if p.suffix.lower() in _SIDE_FILE_SUFFIXES and "config" in {x.lower() for x in p.parts}:
            out.setdefault(p.name, p)
    return [out[k] for k in sorted(out)]


def scaffold(args) -> int:
    """The empty bundle, and the brief for filling it.

    Everything here has one right answer, which is why it is code: the folder layout, the
    manifest stub, which skeleton each chosen format needs, and which of their own config files
    travel with it. What goes *inside* those files depends entirely on the customer, so none of
    it is written here — the agent authors against the platform's `playbooks` skill, and `lint`
    decides whether what it wrote is real.
    """
    r = _run(args); r.require("output-target"); _require_contract_ready(r)
    target = r.read("output-target.json")
    formats = target.get("formats") or ["sdoc"]
    title = _playbook_title(r)
    stem = title

    bundle_root = r.dir / "bundle"
    if bundle_root.exists():
        shutil.rmtree(bundle_root)
    dst = bundle_root / f"{title}.spb"
    (dst / "templates" / "queries").mkdir(parents=True, exist_ok=True)

    # `outputs:` in the shape the platform reads. It is what drives the per-artifact email
    # controls in the schedule wizard, so a block written in some other shape is a control the
    # person never sees, on a playbook that otherwise looks finished.
    outputs = []
    for fmt in formats:
        _rel, _what, declared = _OUTPUT_SKELETON[fmt]
        outputs.append({"id": {"sdoc": "main_report", "sdeck": "main_deck",
                               "html": "main_page"}[fmt],
                        "kind": {"sdoc": "report", "sdeck": "deck", "html": "html"}[fmt],
                        "title": title,
                        "template_path": declared.format(stem=stem)})

    created_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    (dst / "manifest.yaml").write_text(_manifest_stub(title, created_at, outputs))
    (dst / "instructions.md").write_text(_INSTRUCTIONS_STUB)
    (dst / "context.md").write_text("")

    made = []
    for fmt in formats:
        rel, what, _declared = _OUTPUT_SKELETON[fmt]
        rel = rel.format(stem=stem)
        path = dst / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        if fmt == "sdeck" and target.get("slides"):
            # The plan is already theirs — they gave it at `output-target`. Writing it here
            # rather than asking again is the difference between a flow that remembers and one
            # that interviews you twice.
            path.write_text(json.dumps(target["slides"], indent=2) + "\n")
            (dst / "slides.json").write_text(json.dumps(target["slides"], indent=2) + "\n")
        else:
            path.write_text(_SKELETONS[fmt])
        made.append((rel, what))

    copied = []
    for p in _side_files(r, Path(r.input_dir)):
        shutil.copy2(p, dst / p.name)
        copied.append(p.name)

    r.write("scaffold.json", {"bundle": str(dst), "title": title, "formats": formats,
                              "outputs": outputs, "side_files": copied,
                              "authored": [rel for rel, _ in made]})
    r.mark("scaffold", "done", f"{title}.spb, {'+'.join(formats)}", "scaffold.json")

    _ok(f"skeleton at {_short(dst)}")
    _info(f"title      {title}")
    _info(f"produces   {', '.join(formats)}  (declared in manifest.yaml as the platform reads it)")
    if copied:
        _ok(f"carried {len(copied)} config file(s) of theirs into the bundle: {', '.join(copied)}")
    else:
        _info("no config side-files found in their tree — nothing to carry")
    _say()
    _say("  TO THE AGENT: author these, in this order. Follow the platform's `playbooks` skill;")
    _say("  it is installed as a plugin, so invoke it rather than inventing bundle conventions.")
    _say()
    _info("1. templates/queries/*.sql — their SQL, one file per query, their logic kept.")
    _info("   Every literal the survey flagged becomes a {{PARAMETER}}, and you narrate each")
    _info("   substitution to them as you make it. A date or period parameter means a discovery")
    _info("   query comes first — lint fails a period-parameterised bundle without one.")
    _info("2. manifest.yaml — parameters typed, with real options wherever the survey knows the")
    _info("   value domain. A select with no options renders an empty dropdown.")
    for rel, what in made:
        _info(f"3. {rel} — {what}")
    _info("4. tables/*.json — one config per <table/>. A <table/> pointed at a raw snapshot")
    _info("   renders empty, which is the most common way a rebuilt report arrives blank.")
    _info("5. instructions.md — from the sections they confirmed, in their order, carrying their")
    _info("   framing rules across in their words.")
    _say()
    _info("Nothing may reach outside the bundle: no path from their laptop, no sumcli, no file")
    _info("that was not uploaded. scripts/prepare.py is allowed and often right.")
    _say(); _say("  Next:  author the bundle, then  summation-flow lint")
    return 0


def _manifest_stub(title: str, created_at: str, outputs: list) -> str:
    """The manifest `create_playbook.py` writes, plus the block the flow already knows.

    The platform's scaffold leaves `outputs:` commented out because it cannot know what the
    playbook produces. This flow asked, at `output-target`, so it writes the block live — that
    is the one place where knowing more than the platform's scaffold is honest.
    """
    lines = [f"title: {json.dumps(title)}",
             'description: ""',
             f"created_at: {created_at}",
             "",
             "# Parameters the person picks before a run. Type them properly: a `select` with",
             "# real options is a planner who cannot typo their own code into an empty report.",
             "parameters: []",
             "",
             "# What this playbook produces. This block is what gives the schedule wizard its",
             "# per-artifact email controls, so it is written from the format they chose rather",
             "# than left for the platform to discover at run time.",
             "outputs:"]
    for o in outputs:
        lines.append(f"  - id: {o['id']}")
        lines.append(f"    kind: {o['kind']}")
        lines.append(f"    title: {json.dumps(o['title'])}")
        lines.append(f"    template_path: {o['template_path']}")
    return "\n".join(lines) + "\n"


_INSTRUCTIONS_STUB = """\
## Step:

<!-- Written from the sections they confirmed, in the order they confirmed them. Their framing
     rules belong here in their words — what escalates to whom, what a promotion means, what is
     deliberately excluded. Those are the parts a generic report gets wrong first. -->
"""

_SKELETONS = {
    "sdoc": """\
<!-- The document. Every figure is a <cell/> naming the snapshot it came from and the field
     within it; a numeral typed into the prose cannot be traced and lint fails it. Every
     <table/> points at tables/<name>.json, never at a raw snapshot. -->
<document>
</document>
""",
    "sdeck": """\
{"slides": []}
""",
    "html": """\
<!-- Their page template, carried across verbatim: their colours, their column order, their
     inline CSS, their header. You are filling it, not redesigning it. -->
""",
}


# ============================================================ lint
def lint(args) -> int:
    """The deterministic gate on whatever was authored.

    Read-only, and deliberately not in WRITING_STAGES: it reads a folder and, when a warehouse
    is reachable, executes SELECTs against it. Nothing it does creates or destroys anything, and
    gating it behind the tenant question would have put the most useful check in the flow behind
    a prompt about creating objects.
    """
    r = _run(args); r.require("scaffold"); _require_contract_ready(r)
    import sf_lint

    bundle = Path(r.read("scaffold.json")["bundle"])
    if not bundle.is_dir():
        raise SystemExit(f"the scaffolded bundle is gone: {bundle}\n"
                         f"    Re-run `summation-flow scaffold --run {r.run_id}`.")

    survey = None
    try:
        survey = r.read("survey.json")
    except SystemExit:
        _warn("no fan-out survey on this run, so lint cannot tell a hardcoded literal from a "
              "deliberate one — run `summation-flow fanout` for that check to mean anything")
    try:
        formats = r.read("output-target.json").get("formats") or None
    except SystemExit:
        formats = None

    accepted = list(getattr(args, "accept_literal", None) or [])
    accepted_by = getattr(args, "accepted_by", None)
    if accepted and not accepted_by:
        raise SystemExit(
            "--accept-literal needs --accepted-by <who>. A literal left hardcoded is a decision "
            "about their business, and a decision with nobody's name on it is not one.")
    # Accumulated across runs of the stage. Somebody who accepted a literal on Tuesday should not
    # have to remember to re-type it on Wednesday to keep the gate quiet.
    prior = _prior_acceptances(r)
    for value in accepted:
        prior[value] = accepted_by
    if prior:
        r.write("accepted-literals.json", prior)

    runner, why = _query_runner(r, args)
    findings = sf_lint.lint_bundle(
        str(bundle),
        survey=survey,
        outputs=formats,
        accepted_literals=list(prior),
        accepted_by=accepted_by or (sorted(set(v for v in prior.values() if v)) or [None])[0],
        query_runner=runner,
        param_values=_remembered_params(r, args),
    )
    # Where the loop stands, before the detail. An authoring loop with real dry-runs takes
    # minutes per iteration, and a person watching it deserves a headline — "am I close?" —
    # not just a fresh wall of findings (UX finding U9, observed live).
    prior_errors = None
    try:
        prev_findings = r.read("lint.json").get("findings") or []
        prior_errors = sum(1 for f in prev_findings
                           if str(f.get("severity", "")).lower() == "error")
    except SystemExit:
        pass
    qdir = bundle / "templates" / "queries"
    q_total = len(list(qdir.glob("*.sql"))) if qdir.exists() else 0
    now = json.loads(findings.to_json())
    errors_now = sum(1 for f in now if str(f.get("severity", "")).lower() == "error")
    q_bad = len({f.get("file") for f in now
                 if str(f.get("severity", "")).lower() == "error"
                 and str(f.get("code", "")).startswith("query.")})
    head = []
    if q_total:
        head.append(f"{q_total - q_bad} of {q_total} queries clean")
    head.append(f"{errors_now} finding(s) left")
    if prior_errors is not None and prior_errors != errors_now:
        head.append(f"{'down' if errors_now < prior_errors else 'UP'} from {prior_errors}")
    _say(f"  → {' · '.join(head)}")
    _say()
    _say(findings.render())
    _say()
    if why:
        _info(why)
    _info(findings.summary())
    r.write("lint.json", {"bundle": str(bundle), "outputs": formats,
                          "accepted_literals": prior, "dry_run": why or "warehouse dry run ran",
                          "findings": json.loads(findings.to_json())})
    r.mark("lint", "done" if findings.ok else "failed", findings.summary(), "lint.json")
    if findings.ok:
        _ok("lint passes — every check named a file, and none of them fired")
        _say(); _say("  Next:  summation-flow build")
        return 0
    _warn("fix the findings rather than softening them: each check exists because it has already "
          "shipped a report that rendered empty or ran against nothing")
    _say(); _say(f"  Then:  summation-flow lint --run {r.run_id}")
    return 1


def _prior_acceptances(r) -> dict:
    try:
        prior = r.read("accepted-literals.json")
    except SystemExit:
        return {}
    return dict(prior) if isinstance(prior, dict) else {}


def _remembered_params(r, args) -> dict:
    """Dry-run values, remembered across stages the way accepted literals are.

    A date parameter whose emptiness is the point (discovery decides at run time) still needs a
    value to dry-run with. `lint --param` supplies it once; `build` re-lints through the same
    run, so it must see the same values or a correct bundle fails its own gate — which is
    exactly what happened on the first real proof run.
    """
    prior = {}
    try:
        prior = r.read("dryrun-params.json")
    except SystemExit:
        pass
    merged = {**prior, **_lint_params(args)}
    if merged != prior:
        r.write("dryrun-params.json", merged)
    return merged


def _lint_params(args) -> dict:
    out = {}
    for raw in getattr(args, "param", None) or []:
        if "=" not in raw:
            raise SystemExit(f"--param expects NAME=VALUE, got {raw!r}")
        k, v = raw.split("=", 1)
        out[k.strip()] = v
    return out


def _query_runner(args_run, args):
    """A read-only warehouse for the dry run, or an honest reason there is none.

    Bound only when it can actually work. A runner that raises "sumcli is not on PATH" once per
    query turns an environment problem into five findings about their SQL, and an author who
    sees five red lines about queries that are fine learns to distrust the gate.
    """
    import sf_lint.query as Q

    if getattr(args, "no_dry_run", False):
        return None, ("dry run skipped by --no-dry-run: every query below substituted cleanly "
                      "and none of them was proved to run")
    if not Path(P.sumcli_path()).exists() and not shutil.which("sumcli"):
        return None, ("no `sumcli` on PATH, so no query was executed. Substitution was checked; "
                      "running them is what catches the failures that read fine.")
    if not settings.base_url(args_run.profile):
        return None, (f"profile '{args_run.profile}' has no base_url in "
                      f"{settings.config_path()}, so no query was executed")
    return Q.SumcliQueryRunner(args_run.profile), None


# ============================================================ build
def _bind_build(r: Run, bundle: Path) -> None:
    binding = tree_key(bundle)
    bindings = getattr(r, "bindings", {})
    if bindings.get("build") and bindings["build"] != binding:
        r.invalidate_from("deploy", "the authored playbook changed")
    bindings["build"] = binding
    r.bindings = bindings
    save = getattr(r, "save", None)
    if save:
        save()


def build(args) -> int:
    """Scaffold if it has not been scaffolded, then gate.

    `build` used to copy `bundle-template` wholesale, which meant every customer left with the
    demo's report carrying their project id. The loop that replaces it — scaffold, author, lint,
    fix — is a conversation, so the only parts that live here are its ends: the skeleton and the
    exit condition.
    """
    if getattr(args, "from_template", False):
        return _build_from_template(args)
    r = _run(args); r.require("output-target"); _require_contract_ready(r)
    if r.status_of("scaffold") not in ("done", "degraded"):
        _info("nothing scaffolded on this run yet — scaffolding first")
        rc = scaffold(args)
        if rc:
            return rc
        _say()
        r = Run.load(r.run_id)
    rc = lint(args)
    if rc:
        r = Run.load(r.run_id)
        r.mark("build", "failed", "lint did not pass", "lint.json")
        _warn("build is not finished: a bundle that fails lint is one that deploys and then "
              "renders empty. Author the fixes and run `build` again.")
        return rc
    r = Run.load(r.run_id)
    bundle = Path(r.read("scaffold.json")["bundle"])
    n_sql = len(list((bundle / "templates" / "queries").glob("*.sql")))
    formats = r.read("output-target.json").get("formats") or ["sdoc"]
    _bind_build(r, bundle)
    r.write("build.json", {"bundle": str(bundle), "queries": n_sql, "formats": formats,
                           "built_from": "artifact"})
    r.mark("build", "done", f"{n_sql} queries, {'+'.join(formats)}", "build.json")
    _ok(f"built from their artifact — {n_sql} query file(s), lint clean")
    preview_receipt = X.create_preview(r, bundle)
    _ok(f"sealed candidate {preview_receipt['candidate']['sha256'][:12]} for review")
    _info("nothing has been deployed; promotion needs customer approval for this exact digest")
    _say(); _say(f"  Next:  summation-flow permit promote --by <customer name> --run {r.run_id}")
    return 0


def _build_from_template(args) -> int:
    """The demo copy, kept as an escape hatch and labelled as one.

    It exists for the eval baseline, where the question is whether the platform half of the flow
    works, and a hand-built bundle is a constant rather than the thing under test. It is not a
    shortcut for a customer: what it produces is the demo's report.
    """
    r = _run(args); r.require("output-target"); _require_contract_ready(r)
    # The bundle skeleton must come from a fully synthetic template. It used to be copied from
    # build/, which is the bundle from the ORIGINAL real-data work: real planner codes, real area
    # and league names, and real colleagues' names. Every run staged those and `deploy` uploaded
    # them. The input fixture being synthetic was never enough — the template is what ships.
    src = settings.bundle_template()
    if not src.exists():
        raise SystemExit(f"bundle template missing: {src}")
    # Clear the whole bundle directory, not just this bundle's own folder. A rename left the
    # previous bundle sitting beside the new one, and `deploy` walks the directory — so a stale
    # bundle would have been uploaded alongside the current one.
    bundle_root = r.dir / "bundle"
    if bundle_root.exists(): shutil.rmtree(bundle_root)
    dst = bundle_root / src.name
    dst.parent.mkdir(parents=True, exist_ok=True); shutil.copytree(src, dst)
    man = dst / "manifest.yaml"
    if not man.exists(): raise SystemExit("bundle has no manifest.yaml")
    for bad in ("push_config", "created_at"):
        if re.search(rf"^{bad}:", man.read_text(), re.M):
            _warn(f"manifest carries `{bad}`, which is not in the model — harmless but dead weight")
    n_sql = len(list((dst / "templates" / "queries").glob("*.sql"))) if (dst/"templates"/"queries").exists() else 0

    # Carry the output choice into the bundle. Until now `output-target` wrote a file that nothing
    # read, so the format question was answered and then discarded — the bundle came out identical
    # whatever was chosen. What ships has to know what it was asked for.
    target = r.read("output-target.json")
    formats = target.get("formats") or ["sdoc"]
    (dst / "outputs.json").write_text(json.dumps({"formats": formats}, indent=2) + "\n")
    if target.get("slides"):
        (dst / "slides.json").write_text(json.dumps(target["slides"], indent=2) + "\n")

    _bind_build(r, dst)
    r.write("build.json", {"bundle": str(dst), "queries": n_sql, "formats": formats,
                            "built_from": "demo-template"})
    r.mark("build", "done", f"{n_sql} queries from the demo template, {'+'.join(formats)}",
           "build.json")
    preview_receipt = X.create_preview(r, dst)
    _warn("DEMO TEMPLATE, NOT BUILT FROM THE ARTIFACT. This bundle is the sample recap, with "
          "the sample's queries, tables and prose. It is here so a baseline run can measure the "
          "platform half of the flow; it is not a rebuild of anyone's report.")
    _ok(f"bundle staged at {_short(dst)}")
    _info(f"{n_sql} parameterised queries, manifest present")
    _info(f"produces: {', '.join(formats)}"
          + (f" ({len(target['slides']['slides'])} slides)" if target.get("slides") else ""))
    _info(f"to build theirs instead: summation-flow build --run {r.run_id}  (no --from-template)")
    _ok(f"sealed candidate {preview_receipt['candidate']['sha256'][:12]} for review")
    _say(); _say(f"  Next:  summation-flow permit promote --by <customer name> --run {r.run_id}")
    return 0


# ============================================================ preview
def preview(args) -> int:
    r = _run(args); r.require("build"); _require_contract_ready(r)
    receipt = X.create_preview(r, Path(r.read("build.json")["bundle"]))
    candidate = receipt["candidate"]
    _ok(f"sealed local candidate {candidate['sha256']}")
    _info(f"review copy: {candidate['sealed_path']}")
    _info("this is a review boundary, not a separate Summation preview environment")
    _info(f"target: {receipt['target']['profile']} · {receipt['target']['project']}")
    _say(); _say(f"  Next:  summation-flow permit promote --by <customer name> --run {r.run_id}")
    return 0


# ============================================================ deploy
def deploy(args) -> int:
    r = _run(args); r.require("build")
    _preview_receipt, sealed_bundle = X.require_preview(r)
    _require_contract_ready(r)
    _authorize_permission_write(args, r, writes="deploy", permission="promote")
    bundle = sealed_bundle
    dest = f"/{bundle.name}"
    op = Operation(r, "deploy", "playbook.upload", f"{r.project_id}:{dest}:{tree_key(bundle)}",
                   "playbook deployment")
    before = P.cli("playbooks", "list", "--project", r.project_id,
                   profile=r.profile)["playbooks"]
    last = op.last
    pb = None
    res = {"uploaded": [], "failed": [], "waf_bypassed": [], "reconciled": False}
    if last and last.get("state") == "confirmed":
        expected = set(last.get("object_ids") or [])
        pb = next((item for item in before if item.get("fileId") in expected), None)
        if not pb:
            raise SystemExit(
                "the saved deployment receipt names a playbook that is no longer present. "
                "Do not redeploy automatically; review the project and rebuild or explicitly start a new revision.")
        res["reconciled"] = True
    elif last and last.get("state") in UNSAFE_STATES:
        old_ids = set(last.get("before_playbook_ids") or [])
        candidates = [item for item in before if _file_name(item) == bundle.name
                      and item.get("fileId") not in old_ids]
        if len(candidates) != 1:
            # When an upload may have replaced an existing bundle under the same id, listing by
            # name cannot prove which bytes won. This endpoint has no idempotency-key contract,
            # so an unknown result is a pause, never permission to upload twice.
            op.refuse_unknown_retry()
        pb = candidates[0]
        op.confirmed(object_ids=[pb["fileId"]], reconciled=True)
        res["reconciled"] = True
    else:
        before_ids = [item.get("fileId") for item in before if item.get("fileId")]
        op.planned(destination=dest, before_playbook_ids=before_ids)
        op.submitted(before_playbook_ids=before_ids)
        try:
            res = P.upload_bundle(bundle, r.project_id, dest, profile=r.profile)
        except Exception as exc:
            op.failed(exc, before_playbook_ids=before_ids)
            raise
        after = P.cli("playbooks", "list", "--project", r.project_id,
                      profile=r.profile)["playbooks"]
        pb = next((item for item in after if _file_name(item) == bundle.name), None)

    if res.get("reconciled"):
        _ok(f"reconciled deployed candidate to playbook {pb['fileId']}")
    else:
        _ok(f"uploaded {len(res['uploaded'])} file(s), manifest last")
    for rel in res.get("waf_bypassed", []):
        _info(f"{rel}: refused as plain text by the edge policy; re-sent base64 under the same "
              f"name. Nothing was lost.")
    for f in res["failed"]: _warn(f"{f['file']}: {f['error'][:170]}")

    if not pb:
        op.unknown("playbook absent after upload")
        raise SystemExit("upload finished but no playbook is listed — check the folder suffix")
    r.record_object("playbook", pb["fileId"], bundle.name)

    show = P.cli("playbooks", "show", pb["fileId"], "--project", r.project_id,
                 profile=r.profile)["playbook"]
    params = show["manifest"].get("parameters") or []
    if not params:
        raise SystemExit("playbook registered with ZERO parameters — the manifest did not sync. "
                         "It will look healthy and run wrong (LEDGER R-027). Re-upload manifest.yaml.")
    _ok(f"playbook {pb['fileId']}  title '{show['manifest'].get('title')}'")
    for p_ in params:
        _info(f"param {p_['id']:22} {p_['type']:8} required={p_.get('isRequired')} "
              f"options={len(p_.get('options') or [])}")
    r.write("deploy.json", {"playbook_id": pb["fileId"], "title": show["manifest"].get("title"),
                            "parameters": [p_["id"] for p_ in params], "upload": res})
    op.confirmed(object_ids=[pb["fileId"]])
    r.mark("deploy", "done" if not res["failed"] else "degraded",
           f"{pb['fileId']}, {len(params)} params", "deploy.json")
    # Browser moment (U12): the playbook is real now — open it so the person sees it land.
    _open_evidence("playbook", r, "your playbook", playbook_id=pb["fileId"])
    _say("  Next:  summation-flow params  then  summation-flow run")
    return 0


# ============================================================ params
def params(args) -> int:
    r = _run(args); r.require("deploy")
    man = Path(r.read("build.json")["bundle"]) / "manifest.yaml"
    cases = [("valid", {}), ("bogus value", {}), ("label not value", {}), ("required omitted", {})]
    out = []
    for label, _ in cases:
        pass
    # Drive the real validator so its behaviour, not a reimplementation, is what we assert.
    rc, log = _vendored("paramcheck.validate", ["--manifest", str(man), "--params-json", "{}"])
    rejected = rc != 0
    out.append({"case": "required omitted", "rejected": rejected, "detail": log[-300:]})
    r.write("params.json", {"cases": out})
    r.mark("params", "done" if rejected else "failed", "validator exercised", "params.json")
    _ok("parameter validator exercised against the real manifest")
    _info("a missing required parameter is rejected here; the platform itself would have accepted it")
    _say(); _say("  Next:  summation-flow run")
    return 0


# ============================================================ run
def run(args) -> int:
    r = _run(args); r.require("deploy")
    _authorize_permission_write(args, r, writes="run", permission="promote")
    dep = r.read("deploy.json")
    prompt = (f"/create-report\n\nPlease run the playbook \"{dep['title']}\" and generate the report.\n\n"
              f"@/{Path(r.read('build.json')['bundle']).name}\n")
    op = Operation(r, "run", "report.generate", dep["playbook_id"], "first report generation")
    last = op.last
    chats = P.cli("chats", "list", "--project", r.project_id, profile=r.profile)
    before_rows = _chat_rows(chats)

    if last and last.get("state") == "confirmed":
        state = "reconciled from the saved platform receipt"
        expected = set(last.get("object_ids") or [])
        chat_rows = [row for row in before_rows if row.get("id") in expected] or before_rows
    elif last and last.get("state") in UNSAFE_STATES:
        previous = set(last.get("before_chat_ids") or [])
        chat_rows = [row for row in before_rows if row.get("id") not in previous]
        if not chat_rows:
            op.refuse_unknown_retry()
        state = "reconciled after an interrupted request"
        op.confirmed(object_ids=[row.get("id") for row in chat_rows if row.get("id")],
                     reconciled=True)
    else:
        before_ids = [row.get("id") for row in before_rows if row.get("id")]
        op.planned(before_chat_ids=before_ids)
        op.submitted(before_chat_ids=before_ids)
        _info("triggering via a chat message — there is no direct run endpoint yet")
        try:
            P.cli("reports", "generate", "-m", prompt, "--project", r.project_id,
                  "--no-wait", profile=r.profile, timeout=90)
            state = "started"
        except P.PlatformError as exc:
            # The endpoint commonly commits before the CLI times out.  Record uncertainty first,
            # then resolve it from the new chat rather than submitting a duplicate request.
            op.failed(exc, before_chat_ids=before_ids)
            state = "submitted; response did not return"
        chats = P.cli("chats", "list", "--project", r.project_id, profile=r.profile)
        rows_after = _chat_rows(chats)
        chat_rows = [row for row in rows_after if row.get("id") not in set(before_ids)]
        if not chat_rows:
            raise SystemExit(
                f"report generation was submitted but its outcome is not visible yet. "
                f"It will not be submitted again; re-run this stage to reconcile operation {op.id}.")
        op.confirmed(object_ids=[row.get("id") for row in chat_rows if row.get("id")],
                     reconciled="submitted" in state)
    chat_id = (max(chat_rows, key=lambda row: row.get("updatedAt", "")).get("id")
               if chat_rows else None)
    r.write("run.json", {"state": state, "chats": len(chat_rows), "chat_id": chat_id})
    r.mark("run", "degraded" if "response did not return" in state else "done", state, "run.json")
    # Lead with the fact a human cares about; the plumbing detail stays one line below, in
    # plainly agent-facing terms (U10: an agent recited the old timeout warning to a customer).
    _ok(f"report generation is running on the platform — it typically lands in ~10 minutes")
    _info(f"run {state}; {len(chat_rows)} chat(s) in the project")
    _info("agent note, not for the person: the CLI's 90s wait returning early is normal and "
          "does not mean failure — poll the project's files, or `status`, for the artifact")
    # The report's browser moment (U12): the .sdoc appears minutes before its content lands, so
    # opening it straight away would show an empty page. The conducting agent renders the
    # produced document (files download --format markdown) and opens it once tables show rows.
    # Print the URL now so it is visible while the run finishes.
    u, _prov = url("project", profile=r.profile, project_id=r.project_id)
    _info(f"watch it land here: {u}")
    # Neither verify --full (U14) nor verify --render (2026-08-11) is part of the flow: the
    # playbook verifies itself as it generates, and the render gate judged the produced document
    # by a file listing that never shows a sealed .sdoc's snapshots, so it failed every
    # table-bearing report. Both stay callable for internal use. `verify --fidelity` is the gate
    # that stands after run: it judges the produced artifact against the approved contract.
    _say(); _say("  Next:  summation-flow verify --fidelity")
    return 0


# ============================================================ schedule
def schedule(args) -> int:
    """Put the playbook on a schedule and leave it there.

    This used to create a schedule, prove two platform behaviours, and delete it again — which
    made it a test of the schedules API rather than a step in someone's onboarding, while the
    skill told them they were leaving with a scheduled report. They were not. The behaviours are
    still asserted, but as warnings alongside a schedule that survives.

    Cadence and recipients are the person's call, so they arrive as arguments; the skill asks.
    SF_NO_EMAIL forces zero recipients for our own runs, so a test can never mail a real person.
    """
    r = _run(args); r.require("deploy"); _require_fidelity_assessment_ready(r)
    X.require_proof_pass(r)
    _ensure_writable(args, r, "schedule")
    ack = r.tenant_ack or {}
    _info(f"tenant     {ack.get('tenant_name') or ack.get('profile')}  ({ack.get('base_url')})")
    pb = r.read("deploy.json")["playbook_id"]

    # Field names are load-bearing and the API does not police them: it takes `time_of_day` and
    # `zone_id`, and silently DROPS anything it does not recognise, then applies its own defaults.
    # Sending hour/minute/timezone produced a schedule that reported success and ran at 09:00 UTC
    # instead of the time asked for. Same family as R-024: accepted, ignored, no error.
    spec = {"type": args.cadence, "time_of_day": args.at, "zone_id": args.timezone}
    if args.cadence == "weekly":
        spec["days_of_week"] = [args.day.upper()]

    recipients, source = _recipients(args, r)
    # Reserved domains (RFC 2606) can never receive mail, and the platform rejects them with an
    # opaque 400 that names no field. The demo fixture's own list is all `.example`, so the first
    # time anyone tries to deliver they hit a wall with no clue why. Catch it here and say what
    # to do about it.
    RESERVED = (".example", ".test", ".invalid", ".localhost")
    bad = [e for e, _ in recipients if e.lower().rsplit("@", 1)[-1].endswith(RESERVED)]
    if bad:
        raise SystemExit(
            f"these addresses can never receive mail: {', '.join(bad)}\n"
            f"    They are on reserved domains, so the platform rejects the whole schedule with "
            f"an unhelpful 400.\n"
            f"    The fixture ships deliberately fake addresses. Ask the person for a real one "
            f"and pass --recipients <address>.")
    suppressed = bool(os.environ.get("SF_NO_EMAIL")) and recipients
    if suppressed:
        _warn(f"SF_NO_EMAIL is set — dropping {len(recipients)} recipient(s); this run mails nobody")
        recipients = []

    config = {"params": {}}
    if recipients:
        # Objects, not strings. `email` is the only required field; `name` is carried when their
        # own distribution list has one, because a person reading the schedule in the app should
        # see who these people are, not just addresses.
        config["email_recipients"] = [{"email": e, "name": n} if n else {"email": e}
                                      for e, n in recipients]
        # Recipients alone do not turn delivery on. A schedule created with --email comes back
        # with `outputConfig: {}` and mails nobody; the schedules that actually send carry an
        # explicit email.enabled block. Naming a recipient and not delivering to them is the
        # worst of the three outcomes, so we always send both.
        config["output_config"] = {
            "email": {"enabled": True,
                      "artifacts": {"default": {"attach": "pdf", "includeLink": True}}},
            "slack": {"enabled": False,
                      "artifacts": {"default": {"attach": "pdf", "includeLink": True}}},
        }

    description = f"summation-flow {r.run_id}"
    op_key = hashlib.sha256(json.dumps({"playbook": pb, "schedule": spec, "config": config},
                                      sort_keys=True).encode()).hexdigest()[:20]
    op = Operation(r, "schedule", "schedule.create", op_key, "schedule creation")

    def listed_schedules():
        got = P.api("GET", "/v1/schedules", profile=r.profile,
                    params={"kind": "playbook", "project_id": r.project_id}).get("data", {})
        return [x for x in (got.get("schedules") or [])
                if (x.get("target") or {}).get("playbookId") == pb
                and x.get("description") == description]

    # Reconcile before writing. A re-run, including one after a lost response, reuses the
    # schedule bound to this run instead of creating a duplicate.
    mine = listed_schedules()
    if mine:
        op.confirmed(object_ids=[x.get("id") for x in mine if x.get("id")], reconciled=True)
    else:
        op.refuse_unknown_retry()
        op.planned(playbook_id=pb)
        op.submitted()
        try:
            P.api("POST", "/v1/schedules", profile=r.profile,
                  json={"kind": "playbook", "description": description,
                        "target": {"project_id": r.project_id, "playbook_id": pb},
                        "schedule": spec, "config": config})
        except Exception as exc:
            op.failed(exc)
            raise
        # A 2xx is not evidence: the route returns success for schedules that do not exist
        # (R-050). Believe the list.
        mine = listed_schedules()
    if not mine:
        op.unknown("schedule absent after accepted request")
        raise SystemExit("the schedule request was accepted but is not visible in the list yet. "
                         "Its outcome is unknown, so the flow will not create another until this "
                         "operation is reconciled.")
    op.confirmed(object_ids=[x.get("id") for x in mine if x.get("id")])

    for x in mine:
        r.record_object("schedule", x.get("id"), "created by schedule")

    # Assert the stored cadence is the one requested. The write is not evidence; only the
    # read-back is. This check is the entire reason the wrong-field bug was findable.
    stored = (mine[0].get("schedule") or {}).get("recurrence") or {}
    got_time, got_zone = stored.get("timeOfDay"), mine[0].get("zoneId")
    if recipients:
        oc = (mine[0].get("config") or {}).get("outputConfig") or {}
        if not ((oc.get("email") or {}).get("enabled")):
            _warn("recipients are stored but email delivery is NOT enabled — the platform kept "
                  "the addresses and will mail nobody. Do not tell them it sends.")
    if got_time != args.at or (got_zone or "").upper() != args.timezone.upper():
        _warn(f"the platform stored {got_time} {got_zone}, not {args.at} {args.timezone} — "
              f"it accepted the request and changed it. Do not tell them it runs at "
              f"{args.at}; it does not.")

    when = (f"every {args.day.lower()} at {args.at}" if args.cadence == "weekly"
            else f"daily at {args.at}")
    _ok(f"scheduled — runs {when} {args.timezone}")
    if recipients:
        _ok(f"emails {len(recipients)} recipient(s) from {source}: "
            f"{', '.join(e for e, _ in recipients)}")
    else:
        _info("no email recipients — it runs and files the report; nobody is mailed")
    _info(f"schedule {mine[0].get('id')}; {len(mine)} live for this playbook")
    # Stated, not relied upon: the platform accepts `paused: true` and ignores it (R-023), so a
    # schedule is always live from creation. Deleting one needs an undocumented confirm=true
    # (R-026). Both matter to whoever turns this off later.
    _warn("a schedule is ACTIVE from the moment it is created — the platform accepts "
          "`paused: true` and ignores it, so there is no create-it-paused option to offer")

    schedule_id = mine[0].get("id")
    chat_id = _latest_chat_id(r)
    r.write("schedule.json", {"schedule_ids": [x.get("id") for x in mine],
                              "chat_id": chat_id, "cadence": spec,
                              "recipients": [e for e, _ in recipients], "recipients_from": source,
                              "suppressed_by_sf_no_email": suppressed})
    r.mark("schedule", "done",
           f"{when} {args.timezone}, {len(recipients)} recipient(s)", "schedule.json")
    # Browser moment (U12): the schedule is live and read back from the list — open the view
    # where the person watches the cadence they just created.
    _open_evidence("schedules", r, "your schedule", schedule_id=schedule_id,
                   chat_id=chat_id)
    _say(); _say("  Next:  summation-flow share")
    return 0


def _recipients(args, r) -> tuple[list[str], str]:
    """Who gets the email. Explicit list wins; otherwise a CSV; otherwise nobody.

    Reading a CSV is a thing with one right answer, so it lives here. *Choosing* whether those
    are the right people is a judgement about their business, so the skill asks and passes the
    answer in — this never guesses on their behalf.
    """
    if args.recipients:
        return [(x.strip(), None) for x in args.recipients.split(",") if x.strip()], "--recipients"
    path = args.recipients_from
    if not path:
        return [], "none"
    f = Path(path).expanduser()
    if not f.exists():
        raise SystemExit(f"recipients file not found: {f}")
    out: list[tuple[str, str | None]] = []
    for row in csv.DictReader(f.read_text().splitlines()):
        name = next((v for k, v in (row or {}).items()
                     if k and k.strip().lower() == "name" and v), None)
        for k, v in (row or {}).items():
            if k and "email" in k.lower() and v and "@" in v:
                out.append((v.strip(), (name or "").strip() or None))
    if not out:
        raise SystemExit(f"no email column found in {f}")
    return out, str(f)


# ============================================================ share
def share(args) -> int:
    r = _run(args); r.require("deploy"); _require_fidelity_assessment_ready(r)
    X.require_proof_pass(r)
    u, prov = url("sharing", profile=r.profile, project_id=r.project_id)
    r.write("share.json", {
        "state": "in-app-handoff", "sharing_confirmed": False, "app_url": u,
        "instruction": "Use Share in the app to add people or copy the artifact link.",
    })
    r.mark("share", "done", "in-app handoff opened; sharing not confirmed", "share.json")
    _say(); _info(f"evidence: {u}")
    _open_url(u, prov, "your project")
    _say()
    _say("  Nothing was shared by this command. Sharing is completed in the app.")
    _say("  To share the project with specific people — or share just the finished artifact — "
         "click Share in the upper-right, then add them or copy the link.")
    _say(); _ok("onboarding complete")
    return 0


# ============================================================ open
def open_obj(args) -> int:
    r = _run(args)
    ids = {"project_id": r.project_id}
    if args.kind == "playbook":
        ids["playbook_id"] = args.id or r.read("deploy.json")["playbook_id"]
    elif args.kind == "file":
        if not args.id:
            raise SystemExit("open file needs --id <the project's file id>")
        ids["file_id"] = args.id
    elif args.kind == "report":
        ids["file_id"] = args.id or _latest_report_file_id(r)
    elif args.kind == "schedules":
        schedule_state = r.read("schedule.json")
        schedule_ids = schedule_state.get("schedule_ids") or []
        if not args.id and not schedule_ids:
            raise SystemExit("no schedule recorded for this run — run `summation-flow schedule` first")
        ids["schedule_id"] = args.id or schedule_ids[0]
        ids["chat_id"] = schedule_state.get("chat_id") or _latest_chat_id(r)
    u, prov = url(args.kind, profile=r.profile, **ids)
    _ok(f"{u}   ({prov})")
    # Open when the host resolves — the same bar the flow's own browser moments use (U12). A host
    # that does not resolve, or an unknown app host, prints instead so a 404 cannot surprise a
    # person. `_open_url` decides; `SF_APP_URL` is what makes an inferred URL openable in a room.
    _open_url(u, prov, args.kind)
    return 0


# ============================================================ proof receipt
def receipt(args) -> int:
    r = _run(args)
    packet = X.read_record(r, "proof-packet.json")
    X.validate_proof(packet)
    _say(X.render_proof_receipt(packet))
    return 0


def _latest_report_file_id(r) -> str | None:
    """The most recently updated produced .sdoc in the project, if any — for `open report`."""
    files = _project_files(r)
    docs = [f for f in files if _file_name(f).endswith(".sdoc")]
    if not docs:
        raise SystemExit("no produced .sdoc found in the project yet — has `run` completed?")
    return max(docs, key=lambda f: f.get("updatedAt", "")).get("id")


# ============================================================ advise
def advise(args) -> int:
    """What are you doing by hand, over and over, that should be a playbook?

    Reads only the person's own prompts, only on this machine, and sends nothing anywhere. It
    needs no run and touches no platform object — it is a question about them, not about us.
    """
    roots = [Path.home() / ".claude" / "projects", Path.home() / ".codex" / "sessions"]
    present = [r for r in roots if r.exists()]
    if not present:
        _warn("no Claude or Codex session history found on this machine, so there is nothing to "
              "read. This command has nothing to say rather than a weak opinion.")
        return 1
    _info(f"reading your own prompts from {', '.join(str(r) for r in present)}")
    _info("nothing leaves this machine, and assistant output is not read — only what you typed")
    _say()

    res = ADV.advise(present, top=args.top, limit=args.limit)
    if not res["candidates"]:
        _ok(f"read {res['sessions_read']} session(s); nothing recurs often enough to call a habit")
        return 0

    _ok(f"read {res['sessions_read']} session(s), {res['prompts_considered']} of your own prompts")
    _say()
    for n, c in enumerate(res["candidates"], 1):
        _say(f"  {n}. {c['label']}")
        why = [f"{len(c['days'])} separate days"]
        if c["cadence_hits"]: why.append(f"{c['cadence_hits']} mention a cadence")
        if c["artefact_hits"]: why.append(f"{c['artefact_hits']} produce an artefact")
        _info(f"why: {', '.join(why)}")
        for e in c["examples"][:2]:
            _info(f"  {e['day']}  \"{e['text'][:96]}\"")
        _say()
    _warn("this is a heuristic over word overlap, not a model of value — a conversational habit "
          "can rank as highly as real work. Read the evidence before believing the order.")
    _say("  Next:  pick one, then  summation-flow init --input <where that work lives>")
    return 0


# ============================================================ context
def context(args) -> int:
    """Recover the context the customer already wrote down, and put it where a run can use it."""
    r = _run(args); r.require("fanout")
    src = _code_root(r)

    # Session history is opt-in and never discovered silently. Reading someone's entire agent
    # history because it happens to be on the disk is not a thing to do by default, however
    # useful the contents are.
    sessions = []
    if getattr(args, "sessions", False):
        for d in (Path.home() / ".claude" / "projects", Path.home() / ".codex" / "sessions"):
            if d.exists():
                sessions.append(d)
        if sessions:
            _warn(f"reading past agent sessions from {', '.join(str(d) for d in sessions)} — "
                  f"only the human's own corrective messages are kept")
        else:
            _info("no session directories found; mining the input only")

    m = CTX.mine(src, session_dirs=sessions)
    title = src.name.replace("-", " ").title()
    doc = CTX.render_knowledge(m, title)

    # Plain markdown in a `knowledge` folder, deliberately NOT a `.spb`. This is knowledge about
    # the business, not a playbook — and a `.spb` sat in the project looking like a second
    # playbook next to the real one, which is what a person sees when they open the project.
    bundle = r.dir / "context" / "knowledge"
    if bundle.exists(): shutil.rmtree(bundle)
    bundle.mkdir(parents=True, exist_ok=True)
    (bundle / (args.as_file or "recovered-context.md")).write_text(doc)
    context_payload = {
        "items": [i.as_dict() for i in m.items],
        "conflicts": m.conflicts,
        "sources_read": m.sources_read,
        "sources_skipped": m.sources_skipped,
        "bundle": str(bundle),
        "uploaded": None,
    }
    r.write("context.json", context_payload)

    kinds = {}
    for i in m.items: kinds[i.kind] = kinds.get(i.kind, 0) + 1
    _ok(f"recovered {len(m.items)} item(s) from {len(m.sources_read)} source(s) they already had")
    _info(", ".join(f"{v} {k.replace('_',' ')}" for k, v in sorted(kinds.items())) or "nothing")

    if m.conflicts:
        _say()
        _warn(f"{len(m.conflicts)} definition(s) disagree with themselves across their own stack:")
        for c in m.conflicts:
            _say(f"  ✗ {c['subject'].replace('_', ' ')}")
            for v in c["variants"]:
                when = f", recorded {v['dated']}" if v.get("dated") else ""
                _info(f"  {v['expression']}")
                _info(f"      {v['source']}{when}")
        _warn("which one is right is a decision, not a lookup — do not resolve this silently")

    uploaded = None
    if getattr(args, "upload", False):
        # Reading their own files is not a write. Putting them in somebody's project is — so the
        # tenant is acknowledged and the project created here, on first use (U3), exactly as any
        # other writing stage.
        _authorize_permission_write(args, r, writes="context --upload", permission="data")
        existing = _knowledge_files(r)
        if existing:
            _info(f"{len(existing)} file(s) already in /knowledge: {', '.join(existing)}")
            _info("uploading the same name replaces it; a new name sits alongside — the choice "
                  "is yours to make with them, not the CLI's")
        knowledge_key = f"{r.project_id}:/knowledge:{tree_key(bundle)}"
        op = Operation(r, "context", "knowledge.upload", knowledge_key,
                       "project knowledge upload")
        op.planned(destination="/knowledge")
        op.submitted()
        try:
            uploaded = P.upload_bundle(bundle, r.project_id, "/knowledge", profile=r.profile)
        except Exception as exc:
            op.failed(exc)
            raise
        if uploaded.get("failed"):
            op.unknown("one or more knowledge files failed")
        else:
            op.confirmed(object_ids=uploaded.get("uploaded") or [])
        _ok(f"uploaded {len(uploaded['uploaded'])} context file(s) to the project")
        # Scope, every time. The app's `Knowledge` section is described as shared across the
        # organisation; these files land in one project. Same word, different reach, and the
        # person cannot see the difference from here.
        _info("Only this project will leverage this knowledge. If you want your whole team to "
              "share it, please go to the 'Knowledge' section in the app.")
        _info("the platform reads files in a project as knowledge, so a run can use them; there "
              "is no context API yet, so this is the supported route")
    else:
        _info(f"written to {bundle} — pass --upload to put it in the project")

    context_payload["uploaded"] = uploaded
    r.write("context.json", context_payload)

    r.mark("context", "done",
           f"{len(m.items)} items, {len(m.conflicts)} conflicts", "context.json")
    _say(); _say("  Next:  summation-flow output-target")
    return 0


def _knowledge_files(r) -> list[str]:
    """Markdown already in the project's /knowledge folder.

    The agent needs this to decide whether a recovered definition belongs in an existing note or
    in one of its own. Listing is mechanical; the decision is not, so this only reports.
    """
    try:
        got = P.cli("files", "list", "--project", r.project_id, profile=r.profile)
    except P.PlatformError:
        return []
    out = []
    for f in (got.get("result", got) or {}).get("files", []) or []:
        name = f.get("name") or f.get("fileName") or ""
        path = f.get("path") or ""
        if name.endswith(".md") and ("knowledge" in path.lower() or not path):
            out.append(name)
    return sorted(set(out))

# ============================================================ reset
def reset(args) -> int:
    """Return the environment to a clean pre-run state so the demo can be run again.

    Deliberately narrow. It only ever removes things this tool created, identified by the
    `onboarding-sf-` project prefix and the connection names in OURS. Anything else in the tenant
    is counted and reported, never touched — a reset that could reach a colleague's project would
    be a worse hazard than the mess it cleans up.
    """
    projects = P.api("GET", "/v1/projects", profile=args.profile).get("data", {}).get("projects") or []
    mine = [x for x in projects if str(x.get("name", "")).startswith("onboarding-sf-")]
    conns = P.api("GET", "/v1/connections/data", profile=args.profile).get("data", {}) \
             .get("connectors", [])
    my_conns = [c for c in conns if str(c.get("name", "")).startswith(OURS)]
    free = [c for c in my_conns if not (c.get("datasetCount") or 0)]
    local_runs = sorted((ROOT / "runs").glob("sf-*")) if (ROOT / "runs").exists() else []
    cache = sorted((ROOT / ".cache").glob("survey-*.json")) if (ROOT / ".cache").exists() else []

    _ok(f"{len(mine)} project(s), {len(free)} removable connection(s), "
        f"{len(local_runs)} local run dir(s), {len(cache)} cache file(s)")
    for x in mine[:10]:
        _info(f"project    {x['id']}  {x.get('name')}")
    stuck = len(my_conns) - len(free)
    if stuck:
        _warn(f"{stuck} connection(s) can never be removed: a dataset is attached and the API has "
              f"no dataset-delete route. Reset cannot clear those, and no command can.")
    if len(projects) - len(mine):
        _info(f"{len(projects) - len(mine)} project(s) belong to other work and are not touched")

    # `--yes` used to be a bare "I am certain" with nothing attached to it, which is the same
    # shape as the retired SF_ALLOW_HOST: an acknowledgement that does not say what it
    # acknowledges. Naming the tenant is now the confirmation, and `--yes` only decides whether
    # it is typed or supplied by SF_ACK_TENANT.
    if args.yes and not (os.environ.get(T.ACK_ENV) or "").strip():
        raise T.TenantRefused(
            f"--yes no longer stands alone: it did not say which tenant it was certain about.\n"
            f"    Name it:  {T.ACK_ENV}=<profile> summation-flow reset --yes")
    _ack_without_run(args, f"About to DELETE {len(mine)} project(s) in")

    gone = 0
    for x in mine:
        try:
            P.cli("projects", "delete", "--project", x["id"], "--confirm", profile=args.profile)
            gone += 1
        except P.PlatformError as e:
            _warn(f"project {x['id']}: {str(e)[:100]}")
    for c in free:
        try:
            P.cli("connections", "delete", c["id"], "--confirm", profile=args.profile)
        except P.PlatformError as e:
            _warn(f"connection {c['id']}: {str(e)[:100]}")
    for d in local_runs:
        shutil.rmtree(d, ignore_errors=True)
    for f in cache:
        f.unlink(missing_ok=True)
    cur = ROOT / "runs" / "CURRENT"
    cur.unlink(missing_ok=True)
    _ok(f"removed {gone} project(s), {len(free)} connection(s), {len(local_runs)} local run dir(s)")
    _info("the fanout cache is cleared, so the next run scans the fixture fresh")
    if stuck:
        _warn(f"{stuck} connection(s) remain by platform limitation — `summation-flow orphans` "
              f"lists them")
    _say(); _say("  Next:  summation-flow doctor  then  summation-flow init --input demo")
    return 0


# ============================================================ orphans
#: Connections this tool creates are named after their run. Anything else in the tenant belongs
#: to somebody else and is never a candidate for deletion.
OURS = ("sf-", "plg-trial-")


def orphans(args) -> int:
    """List the connections teardown could not remove, and delete the ones that are removable.

    The guide told a reader that orphaned connections exist and are cleaned up by hand, without
    saying how to see them. The obvious command is actively misleading: `sumcli connections list`
    reports zero because the API returns them under `connectors` while the CLI reads `connections`.
    So this reads the API directly.
    """
    conns = P.api("GET", "/v1/connections/data", profile=args.profile).get("data", {}) \
             .get("connectors", [])
    mine = [c for c in conns if str(c.get("name", "")).startswith(OURS)]
    other = len(conns) - len(mine)
    _ok(f"{len(conns)} connection(s) in the tenant; {len(mine)} created by summation-flow")
    if other:
        _info(f"{other} belong to someone else and are never touched by this command")
    free, stuck = [], []
    for c in mine:
        (free if not (c.get("datasetCount") or 0) else stuck).append(c)
    for c in mine:
        n = c.get("datasetCount") or 0
        _info(f"{c['id']}  {c.get('name',''):22} datasets={n}"
              f"{'   removable' if not n else '   stuck (no detach route exists)'}")
    if not args.delete:
        _say()
        if free:
            _info(f"{len(free)} removable — re-run with --delete to remove them")
        if stuck:
            _warn(f"{len(stuck)} cannot be removed at all: a dataset is attached and the API has "
                  f"no dataset-delete route. They stay until that route exists.")
        return 0
    _ack_without_run(args, f"About to DELETE {len(free)} connection(s) in")
    removed = 0
    for c in free:
        try:
            P.cli("connections", "delete", c["id"], "--confirm", profile=args.profile)
            removed += 1; _ok(f"removed {c['id']}")
        except P.PlatformError as e:
            _warn(f"{c['id']}: {str(e)[:120]}")
    _ok(f"{removed} removed, {len(stuck)} still stuck")
    return 0


# ============================================================ teardown
def teardown(args) -> int:
    r = _run(args, writes="teardown")
    if not r.created_objects:
        _ok(f"{r.run_id} created nothing to remove")
        return 0
    _warn(f"about to PERMANENTLY DELETE {len(r.created_objects)} object(s) belonging to "
          f"{r.run_id}, including project {r.project_id}")
    for o in r.created_objects[:8]:
        _info(f"{o['kind']:11} {o['id']}")
    _info("")
    _info("`init` moves a shared pointer, so this may not be the run you worked on.")

    # A cold replication test caught this destroying a project with no confirmation while the
    # guide promised one. The failure mode is specific — another `init` moves the shared
    # pointer, so a bare `teardown` can name someone else's project — and a y/N prompt does
    # not defend against it, because the wrong answer is still "y". Typing the run id does:
    # you have to look at what is on screen and agree that it is yours.
    if getattr(args, "yes", False):
        _warn("--yes given: skipping confirmation")
    elif not sys.stdin.isatty():
        _warn("REFUSING: teardown destroys a project and stdin is not a terminal, so it cannot "
              "ask. Re-run in a terminal, or pass --yes if you are certain of the run above.")
        return 1
    else:
        try:
            typed = input(f"  type the run id to confirm ({r.run_id}): ").strip()
        except (EOFError, KeyboardInterrupt):
            _say(); _warn("cancelled — nothing was deleted"); return 1
        if typed != r.run_id:
            _warn(f"got {typed!r}, expected {r.run_id!r} — cancelled, nothing was deleted")
            return 1
    # Dedupe: re-running a stage records the same object again.
    seen, objs = set(), []
    for o in r.created_objects:
        key = (o["kind"], o["id"])
        if key not in seen: seen.add(key); objs.append(o)
    removed, left = [], []
    order = {"schedule": 0, "dataset": 1, "connection": 2, "playbook": 3, "project": 4}
    for o in sorted(objs, key=lambda x: order.get(x["kind"], 9)):
        k, i = o["kind"], o["id"]
        try:
            # Every destructive route requires an explicit confirmation, and each spells it
            # differently: schedules and connections take ?confirm=true, the CLI takes --confirm.
            # None of it is documented (LEDGER R-026), and a teardown that misses it reports
            # failure while leaving live objects behind.
            if k == "schedule":
                P.api("DELETE", f"/v1/schedules/{i}", profile=r.profile, params={"confirm": "true"})
            elif k == "connection":
                # A connection cannot be deleted while a dataset is attached, and there is NO
                # dataset-delete route in the live API (LEDGER R-045). So this is expected to fail
                # once anything has been attached. Report it as a platform limitation with the
                # object id, rather than as our failure.
                ds = P.api("GET", f"/v1/connections/data/{i}/datasets",
                           profile=r.profile).get("data", {}).get("datasets", [])
                if ds:
                    left.append({**o, "reason": f"{len(ds)} dataset(s) attached and no detach route exists"})
                    _warn(f"connection {i} cannot be removed: {len(ds)} dataset(s) attached, "
                          f"and the API has no dataset-delete route (R-045). Orphaned by design.")
                    continue
                P.cli("connections", "delete", i, "--confirm", profile=r.profile)
            elif k == "project":
                P.cli("projects", "delete", "--project", i, "--confirm", profile=r.profile)  # option
            elif k == "playbook":
                # It lives inside the project, so deleting the project takes it. Counting it as
                # "left behind" overstated the residue and contradicted the guide, which named
                # only the connection.
                removed.append({**o, "note": "removed with its project"})
                _ok(f"playbook {i} removed with its project")
                continue
            else: left.append(o); continue
            removed.append(o); _ok(f"removed {k} {i}")
        except P.PlatformError as e:
            # Idempotency: an object already removed by an earlier teardown is a success, not a
            # failure. Without this, re-running teardown reports failures for its own past work.
            if "404" in str(e) or "not_found" in str(e) or "not be found" in str(e):
                removed.append({**o, "note": "already gone"}); _ok(f"{k} {i} already gone")
            else:
                left.append(o); _warn(f"{k} {i}: {str(e)[:120]}")
    r.write("teardown.json", {"removed": removed, "left": left})
    r.mark("teardown", "done" if not left else "degraded", f"{len(removed)} removed", "teardown.json")
    if left: _warn(f"{len(left)} object(s) left — listed in teardown.json")
    return 0
