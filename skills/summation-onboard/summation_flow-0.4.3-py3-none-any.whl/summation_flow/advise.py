"""Look at what someone already does by hand, and say what is worth automating.

Eric's framing: *"tell me what I'm not taking advantage of."* People arrive with months of agent
history in which they have rebuilt the same thing by hand a dozen times, and no sense of which of
those is worth turning into a playbook. The evidence is already on their disk.

What this does: read the human's own prompts out of past Claude and Codex sessions, group them
into recurring pieces of work, and rank those by how much repetition they represent. What it does
not do: send anything anywhere, read assistant output, or decide anything. It produces candidates
with citations, and a person picks.

It is a heuristic and says so. The ranking is defensible — repetition across distinct days, with a
bias toward work that describes itself in cadence language — but it is not a model of value, and a
confident-sounding list of the wrong things would be worse than no list.
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path

# Words that carry no signal about what the work *is*.
STOP = set("""
a an the and or but if then than that this these those there here of to in on for with without
from by as at into over under about after before again is are was were be been being do does did
doing done can could should would will shall may might must have has had having i you he she it
we they me him her them my your his its our their what which who whom whose when where why how
all any both each few more most other some such no nor not only own same so too very just now
please make sure use using used run running get getting let lets like want need also add added
fix fixed change changed update updated check checked look looking see seeing go going take taking
put putting keep keeping try trying help me us one two three new old good bad right wrong yes ok
okay thanks thank sorry actually really quite maybe perhaps still yet even ever never always
file files line lines code test tests error errors issue issues problem thing things way ways
work works working worked stuff item items version versions
""".split())

# Tokens that are machinery rather than subject matter.
NOISE = re.compile(r"^(https?:|/|~|\.|--|[0-9]+$|[a-f0-9]{8,}$)")

#: Text that arrives in the "user" slot but was not typed by the person: harness plumbing, other
#: agents talking, tool output, pasted images. Run against real history, these dominated the
#: ranking completely — the top result was agent-to-agent chatter, which would have had us
#: recommending that someone automate their teammate notifications. Matched anywhere in the text,
#: not just at the start, because they are frequently prefixed with a line of narration.
MACHINE_MARKERS = (
    "<teammate-message", "another claude session sent a message",
    "<system-reminder", "<local-command", "<command-name", "<command-message",
    "<task-notification", "<bash-stdout", "<bash-stderr", "<function_results",
    "[image: source:", "[request interrupted", "caveat: the messages below",
    "<local-command-stdout", "this is how claude code surfaces",
    "[system notification", "tool result", "<new-diagnostics",
    "<bash-input", "base directory for this skill", "<user-prompt-submit-hook",
)


def is_machine_text(text: str) -> bool:
    low = text.lower()
    if any(mark in low for mark in MACHINE_MARKERS):
        return True
    # Dense angle-bracket tagging is plumbing even when the tag name is unfamiliar.
    tags = len(re.findall(r"</?[a-z][a-z0-9_-]{2,}>", low))
    return tags >= 3

#: Language that says "this happens on a cadence" — the strongest signal that hand-work recurs.
CADENCE = re.compile(
    r"\b(weekly|every week|each week|monday|tuesday|wednesday|thursday|friday|"
    r"daily|every day|each day|monthly|every month|quarterly|recurring|again|"
    r"this week'?s|last week'?s|as usual|same as|refresh|re-?run)\b", re.I)

#: Language that says "the output is an artefact somebody receives".
ARTEFACT = re.compile(
    r"\b(report|recap|deck|dashboard|summary|digest|export|deliverable|slide|"
    r"one[- ]pager|update for|send (?:it |this )?to)\b", re.I)


@dataclass
class Prompt:
    text: str
    day: str          # YYYY-MM-DD
    project: str      # the directory the session ran in
    source: str       # file:line
    terms: set = field(default_factory=set)


@dataclass
class Candidate:
    label: str
    terms: list
    days: list
    projects: list
    examples: list          # (day, text, source)
    score: float
    cadence_hits: int
    artefact_hits: int

    def as_dict(self) -> dict:
        return {
            "label": self.label, "terms": self.terms, "days": self.days,
            "projects": self.projects, "score": round(self.score, 2),
            "cadence_hits": self.cadence_hits, "artefact_hits": self.artefact_hits,
            "examples": [{"day": d, "text": t, "source": s} for d, t, s in self.examples],
        }


def salient_terms(text: str, keep: int = 6) -> set:
    """The words that say what a prompt is *about*.

    Frequency inside one prompt is a poor signal — prompts are short — so this keeps the longest
    non-stopword tokens, which in practice are the domain nouns rather than the verbs.
    """
    text = re.sub(r"https?://\S+", " ", text)          # a link is not a topic
    text = re.sub(r"`[^`]*`", " ", text)                # nor is quoted code
    text = re.sub(r"/[\w./-]{6,}", " ", text)           # nor is a path
    words = re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", text.lower())
    cand = [w for w in words if w not in STOP and not NOISE.match(w) and len(w) > 3]
    if not cand:
        return set()
    counts = Counter(cand)
    ranked = sorted(counts, key=lambda w: (-counts[w], -len(w), w))
    return set(ranked[:keep])


def read_session(path: Path, max_lines: int = 8000) -> list[Prompt]:
    """Human prompts only.

    Assistant output is deliberately ignored: what an agent said is not evidence of what the
    person wanted. Tool results and system-injected text are filtered because they are neither.
    """
    out: list[Prompt] = []
    try:
        fh = path.open(errors="replace")
    except OSError:
        return out
    with fh:
        for i, line in enumerate(fh, 1):
            if i > max_lines:
                break
            try:
                rec = json.loads(line)
            except (ValueError, TypeError):
                continue
            if rec.get("type") != "user":
                continue
            msg = rec.get("message")
            if not isinstance(msg, dict) or msg.get("role") != "user":
                continue
            content = msg.get("content")
            texts: list[str] = []
            if isinstance(content, str):
                texts = [content]
            elif isinstance(content, list):
                texts = [p.get("text", "") for p in content
                         if isinstance(p, dict) and p.get("type") == "text"]
            for t in texts:
                t = (t or "").strip()
                if not (25 < len(t) < 2000) or is_machine_text(t):
                    continue
                day = str(rec.get("timestamp") or "")[:10]
                out.append(Prompt(
                    text=re.sub(r"\s+", " ", t),
                    day=day or "unknown",
                    project=str(rec.get("cwd") or path.parent.name),
                    source=f"{path.name}:{i}",
                    terms=salient_terms(t),
                ))
    return out


def cluster(prompts: list[Prompt], min_days: int = 2) -> list[Candidate]:
    """Group prompts that share subject matter, and rank by how much repetition they represent.

    Grouping is on term *pairs* rather than single terms. One shared word puts "the marketing
    report" and "the marketing budget" in the same bucket, which is how you end up recommending
    something nobody does. Two shared words is a much stronger claim about being the same work.
    """
    buckets: dict[frozenset, list[Prompt]] = defaultdict(list)
    for p in prompts:
        terms = sorted(p.terms)
        for a in range(len(terms)):
            for b in range(a + 1, len(terms)):
                buckets[frozenset((terms[a], terms[b]))].append(p)

    seen_examples: set = set()
    cands: list[Candidate] = []
    for pair, group in buckets.items():
        days = sorted({p.day for p in group if p.day != "unknown"})
        if len(days) < min_days:
            continue
        cadence = sum(1 for p in group if CADENCE.search(p.text))
        artefact = sum(1 for p in group if ARTEFACT.search(p.text))
        # Distinct days is the backbone: ten prompts in one sitting is one piece of work, while
        # the same request on six different days is a habit, and a habit is what a playbook
        # replaces. Cadence and artefact language are supporting evidence, weighted lower.
        score = len(days) * 2.0 + cadence * 1.5 + artefact * 1.0 + len(group) * 0.15
        ex = sorted({(p.day, p.text[:180], p.source) for p in group})[:3]
        cands.append(Candidate(
            label=" + ".join(sorted(pair)),
            terms=sorted(pair), days=days,
            projects=sorted({p.project for p in group})[:4],
            examples=ex, score=score,
            cadence_hits=cadence, artefact_hits=artefact,
        ))

    cands.sort(key=lambda c: -c.score)

    # Overlapping pairs describe the same habit from different angles. Keep the strongest and
    # drop anything whose evidence is already represented, so the list reads as distinct work.
    out: list[Candidate] = []
    for c in cands:
        key = {e[2] for e in c.examples}
        if key & seen_examples:
            continue
        seen_examples |= key
        out.append(c)
    return out


def session_files(roots: list[Path], limit: int = 400) -> list[Path]:
    """Newest sessions first, capped. History is large and the recent past is what matters."""
    found: list[Path] = []
    for r in roots:
        if r.exists():
            found += list(r.rglob("*.jsonl"))
    found.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    return found[:limit]


def advise(roots: list[Path], top: int = 5, limit: int = 400) -> dict:
    files = session_files(roots, limit=limit)
    prompts: list[Prompt] = []
    for f in files:
        prompts += read_session(f)
    cands = cluster(prompts)
    return {
        "sessions_read": len(files),
        "prompts_considered": len(prompts),
        "candidates": [c.as_dict() for c in cands[:top]],
        "method": (
            "Grouped the person's own prompts by shared subject terms, ranked by how many "
            "distinct days each piece of work recurs across. A heuristic, not a model of value — "
            "every candidate carries its evidence so it can be judged rather than believed."
        ),
    }
